module.exports = {
  name: 'administration',
  preset: '../../jest.config.js',
  coverageDirectory: '../../coverage/apps/administration',
  reporters: [
    'default',
    ['jest-junit', { output: 'test-reports/administration.xml', suiteName: 'administration tests' }]
  ]
};
