import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {
  ErrorContainerComponent,
  PageNotFoundComponent,
  AccessDeniedComponent
} from '@content-platform/error-handling';
import { AdAuthGuard } from '@content-platform/auth';

const routes: Routes = [
  {
    path: 'applications',
    canActivate: [AdAuthGuard],
    children: [
      {
        path: '',
        loadChildren: './applications/applications.module#ApplicationsModule'
      }
    ]
  },
  {
    path: 'roles',
    canActivate: [AdAuthGuard],
    children: [
      {
        path: '',
        loadChildren: './roles/roles.module#RolesModule'
      }
    ]
  },
  {
    path: 'users',
    canActivate: [AdAuthGuard],
    children: [
      {
        path: '',
        loadChildren: './users/users.module#UsersModule'
      }
    ]
  },
  {
    path: 'schema-config',
    canActivate: [AdAuthGuard],
    children: [
      {
        path: '',
        loadChildren: './schema-config/schema-config.module#SchemaConfigModule'
      }
    ]
  },
  {
    path: 'error',
    component: ErrorContainerComponent
  },
  {
    path: 'access-denied',
    component: AccessDeniedComponent
  },
  { path: '', redirectTo: '/applications', pathMatch: 'full' },
  {
    path: '**',
    pathMatch: 'full',
    component: PageNotFoundComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { initialNavigation: 'enabled' })],
  exports: [RouterModule]
})
export class AppRoutingModule {}
