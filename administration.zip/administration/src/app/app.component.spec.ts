import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppComponent } from './app.component';
import { RouterTestingModule } from '@angular/router/testing';

import * as testHelpers from '@content-platform/unit-test-helpers';
import { StoreModule } from '@ngrx/store';
import { routerReducer } from '@ngrx/router-store';
import { fromApplication, fromUserPermissionList } from '@content-platform/application-api';
import { fromAuth } from '@content-platform/auth';
import { MatListModule, MatIconModule } from '@angular/material';
import { UserPermissionsService } from '@content-platform/application-api';
import { of } from 'rxjs';

const mockPermissionsService = {
  hasFeatureAsync() {
    return of(false);
  }
};

describe('Administration AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        StoreModule.forRoot({
          routerReducer: routerReducer,
          application: fromApplication.reducer,
          auth: fromAuth.authReducer,
          userPermissionList: fromUserPermissionList.reducer
        }),
        MatListModule,
        MatIconModule
      ],
      declarations: [
        AppComponent,
        testHelpers.MockComponent({
          selector: 'app-nav-bar',
          inputs: ['appTitle', 'additionalMenuItems', 'isAppMenuShow']
        }),
        testHelpers.MockComponent({
          selector: 'app-global-sidenav',
          inputs: ['sideNavData']
        }),
        testHelpers.MockComponent({
          selector: 'app-footer',
          inputs: ['version']
        })
      ],
      providers: [{ provide: UserPermissionsService, useValue: mockPermissionsService }]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
