import { Component, Optional } from '@angular/core';
import { Store, select } from '@ngrx/store';

import { Observable } from 'rxjs';
import { map, combineLatest } from 'rxjs/operators';

import { environment } from '../environments/environment';

import { authSelectors } from '@content-platform/auth';
import { UserMenuItem, SideNavItem } from '@content-platform/navigation';
import { DebugFlagsDialogService } from '@content-platform/reusable-ui/feature-flags';
import {
  userPermissionListSelectors,
  UserPermissionsService
} from '@content-platform/application-api';
import { AdministrationState } from './reducers';
import { SCHEMA_EDITOR_KEY } from './schema-config/schema-editor/schema-editor-routing.module';
import { DATASET_MANAGER_KEY } from './schema-config/dataset-manager/dataset-manager-routing.module';
import { FEATURE_FLAG_KEY } from '@content-platform/development';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  hasValidAccess$: Observable<boolean>;
  version = environment.version;
  isLoggedIn$: Observable<boolean>;

  private globalEntryMenu: SideNavItem = {
    iconSrc: '/assets/ge-icon.png',
    title: 'Global Entry',
    hidden: true,
    children: [
      {
        route: 'schema-config/schema-editor',
        icon: 'description',
        title: 'Schema Editor'
      },
      {
        route: 'schema-config/field-schema-editor',
        icon: 'description',
        title: 'Field Schema Editor'
      },
      {
        route: 'schema-config/dataset-manager',
        icon: 'library_books',
        title: 'Dataset Manager'
      }
    ]
  };

  sideNavData: SideNavItem[] = [
    {
      iconSrc: '/assets/dashboard-icon.png',
      title: 'The Content Platform',
      children: [
        {
          route: 'applications',
          icon: 'settings_applications',
          title: 'Applications'
        },
        { route: 'users', icon: 'people', title: 'Users' },
        {
          route: 'roles',
          icon: 'account_circle',
          title: 'Roles'
        }
      ]
    },
    this.globalEntryMenu
  ];

  extraMenuItems: UserMenuItem[] = [];

  constructor(
    private store: Store<AdministrationState>,
    private permissionService: UserPermissionsService,
    @Optional() private debugFlagDialogService: DebugFlagsDialogService
  ) {
    this.hasValidAccess$ = this.store.pipe(
      select(authSelectors.getIsLoggedIn),
      combineLatest(this.store.pipe(select(userPermissionListSelectors.hasUserPermission))),
      map(([loggedIn, hasUserPermissions]) => loggedIn && hasUserPermissions)
    );

    this.permissionService.hasFeatureAsync(FEATURE_FLAG_KEY).subscribe(canAccess => {
      if (canAccess) {
        this.extraMenuItems.push({
          buttonName: 'Feature Flags',
          buttonAction: () => {
            this.debugFlagDialogService.showDebugFlagsModal();
          }
        });
      }
    });
    this.permissionService.hasFeatureAsync(SCHEMA_EDITOR_KEY).subscribe(canAccess => {
      this.globalEntryMenu.hidden = canAccess ? false : this.globalEntryMenu.hidden;
      this.globalEntryMenu.children[0].hidden = !canAccess;
    });
    this.permissionService.hasFeatureAsync(DATASET_MANAGER_KEY).subscribe(canAccess => {
      this.globalEntryMenu.hidden = canAccess ? false : this.globalEntryMenu.hidden;
      this.globalEntryMenu.children[0].hidden = !canAccess;
    });
  }
}
