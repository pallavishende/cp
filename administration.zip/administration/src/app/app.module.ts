import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {
  BrowserAnimationsModule,
  NoopAnimationsModule
} from '@angular/platform-browser/animations';
import { NxModule } from '@nrwl/nx';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { StoreRouterConnectingModule, RouterStateSerializer } from '@ngrx/router-store';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

import { environment } from '../environments/environment';

import { LoggingModule } from '@content-platform/logging';
import { AuthModule, AdAuthGuard } from '@content-platform/auth';
import { ApplicationApiModule } from '@content-platform/application-api';
import { NotificationsModule } from '@content-platform/notifications';
import { AwsModule } from '@content-platform/aws';
import { CustomSerializer, reducers } from './reducers';
import { effects } from './effects';
import { NavigationModule } from '@content-platform/navigation';
import { MatListModule, MatIconModule } from '@angular/material';
import { AutoLoginModule } from '@content-platform/e2e-test-helpers';
import { PermissionsModule } from '@content-platform/application-api';
import { ErrorHandlingModule } from '@content-platform/error-handling';
import { DevelopmentModule } from '@content-platform/development';
import { ReusableUiFeatureFlagsModule } from '@content-platform/reusable-ui/feature-flags';
import { InterceptorsModule } from '@content-platform/interceptors';
import { PreferencesApiModule } from '@content-platform/preferences-api';
import { ConfigurationModule } from '@content-platform/configuration';
import { LoadingSpinnerModule } from '@content-platform/reusable-ui/loading-spinner';
import { DynamicFormsApiModule } from '@content-platform/dynamic-forms-api';

@NgModule({
  imports: [
    BrowserModule,
    StoreModule.forRoot(reducers),
    EffectsModule.forRoot(effects),
    NxModule.forRoot(),
    ConfigurationModule,
    environment.disableAnimations ? NoopAnimationsModule : BrowserAnimationsModule,
    !environment.production ? StoreDevtoolsModule.instrument({}) : [],
    environment.qa ? AutoLoginModule.forRoot(environment.skipAutomaticLogin) : [],
    LoggingModule.forRoot({ production: environment.production, version: environment.version }),
    ErrorHandlingModule.forRoot({ handleAllFailActions: true }),
    AuthModule,
    NavigationModule.forRoot({
      production: environment.production
    }),
    ApplicationApiModule.forRoot({
      appName: 'Administration',
      production: environment.production
    }),
    StoreRouterConnectingModule,
    NotificationsModule,
    MatListModule,
    MatIconModule,
    PermissionsModule,
    AppRoutingModule,
    DevelopmentModule.forRoot(environment.production, []),
    InterceptorsModule,
    AwsModule,
    PreferencesApiModule.forRoot({
      useLocalStorage: false
    }),
    DynamicFormsApiModule.forRoot({}),
    LoadingSpinnerModule.withNavigationLoading(),
    ReusableUiFeatureFlagsModule
  ],
  providers: [AdAuthGuard, { provide: RouterStateSerializer, useClass: CustomSerializer }],
  declarations: [AppComponent],
  bootstrap: [AppComponent]
})
export class AppModule {}
