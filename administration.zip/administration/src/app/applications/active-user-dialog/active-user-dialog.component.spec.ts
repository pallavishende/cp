import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { fromRole } from '@content-platform/application-api';
import { MaterialMockModule, MockPipe, MockComponent } from '@content-platform/unit-test-helpers';
import { StoreModule } from '@ngrx/store';
import { of } from 'rxjs';
import { RolesGuard } from '../../guards';
import { ActiveUserDialogComponent } from './active-user-dialog.component';
import { ClipboardService } from '@content-platform/common-helpers';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

describe('ActiveUserDialogComponent', () => {
  let component: ActiveUserDialogComponent;
  let fixture: ComponentFixture<ActiveUserDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MaterialMockModule, StoreModule.forRoot({ role: fromRole.reducer })],
      providers: [
        {
          provide: RolesGuard,
          useValue: {
            checkStore: () => of(true)
          }
        },
        {
          provide: ClipboardService,
          useValue: { copyToClipboard: () => {} }
        },
        MatDialog,
        { provide: MatDialogRef, useValue: {} },
        {
          provide: MAT_DIALOG_DATA,
          useValue: [{ appId: 1 }]
        }
      ],
      declarations: [
        ActiveUserDialogComponent,
        MockPipe('displayName'),
        MockComponent({ selector: 'app-spinner-dialog' })
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActiveUserDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
