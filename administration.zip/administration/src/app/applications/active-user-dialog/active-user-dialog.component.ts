import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { applicationSelectors } from '@content-platform/application-api';
import { ClipboardService } from '@content-platform/common-helpers';
import { UserProfile } from '@content-platform/graph-api';
import { notificationActions, NotificationType } from '@content-platform/notifications';
import { Store, select } from '@ngrx/store';
import { sortBy, uniq } from 'lodash';
import { take } from 'rxjs/operators';
import { RolesGuard } from '../../guards';
import { AdministrationState } from '../../reducers';

@Component({
  selector: 'app-active-user-dialog',
  templateUrl: './active-user-dialog.component.html',
  styleUrls: ['./active-user-dialog.component.scss']
})
export class ActiveUserDialogComponent implements OnInit {
  loadingUsersData = true;
  usersList: { userProfile: UserProfile; roleNames: string[] }[] = [];

  constructor(
    public dialogRef: MatDialogRef<ActiveUserDialogComponent>,
    @Inject(MAT_DIALOG_DATA)
    public data: { appId: number },
    private store: Store<AdministrationState>,
    private clipboardService: ClipboardService,
    private rolesGuard: RolesGuard
  ) {}

  ngOnInit() {
    this.rolesGuard
      .checkStore()
      .pipe(take(1))
      .subscribe(loaded => {
        if (loaded) {
          this.store
            .pipe(
              select(applicationSelectors.getApplicationUsers(this.data.appId)),
              take(1)
            )
            .subscribe(users => {
              this.loadingUsersData = false;
              this.usersList = sortBy(users, ['userProfile.givenName', 'userProfile.surname']);
            });
        } else {
          this.loadingUsersData = false;
        }
      });
  }

  copyAllEmailAddressses() {
    const emailAddresses = uniq(this.usersList.map(user => user.userProfile.mail));
    this.clipboardService.copyToClipboard(emailAddresses.join('; '));
    this.dispatchSuccessNotification('Successfully copied email addresses.');
  }

  private dispatchSuccessNotification(message: string) {
    this.store.dispatch(
      new notificationActions.Open({
        type: NotificationType.Success,
        inputs: {
          props: {
            message
          }
        }
      })
    );
  }
}
