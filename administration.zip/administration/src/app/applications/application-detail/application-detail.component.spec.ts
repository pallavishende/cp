import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { fromApplication, UserPermissionsService } from '@content-platform/application-api';
import { LoggerService } from '@content-platform/logging';
import { ContentHeaderBarService } from '@content-platform/navigation';
import {
  MaterialMockModule,
  MaterialServiceMocks,
  MockDirective,
  MockPipe
} from '@content-platform/unit-test-helpers';
import { StoreModule } from '@ngrx/store';
import { NgPipesModule } from 'ngx-pipes';
import { of } from 'rxjs';
import { ApplicationDetailComponent } from './application-detail.component';

describe('ApplicationDetailComponent', () => {
  let component: ApplicationDetailComponent;
  let fixture: ComponentFixture<ApplicationDetailComponent>;
  let routeStub;
  let headerService: ContentHeaderBarService;
  let hasFeature = true;

  beforeEach(async(() => {
    routeStub = {
      data: of({
        application: {
          name: 'test',
          url: 'url',
          uuid: 'id',
          roles: [],
          features: []
        }
      })
    };

    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        MaterialMockModule,
        NgPipesModule,
        StoreModule.forRoot({ application: fromApplication.reducer })
      ],
      providers: [
        { provide: ActivatedRoute, useValue: routeStub },
        { provide: ContentHeaderBarService, useValue: { setButtons: () => {} } },
        { provide: UserPermissionsService, useValue: { hasFeature: () => hasFeature } },
        { provide: MatDialog, useValue: new MaterialServiceMocks.MatDialog<boolean>(true) },
        {
          provide: LoggerService,
          useValue: {
            instance: () => {
              return { info: () => {} };
            }
          }
        }
      ],
      declarations: [
        ApplicationDetailComponent,
        MockPipe('displayName'),
        MockPipe('userProfile'),
        MockDirective({ selector: '[appIfFeatureAsync]', inputs: ['appIfFeatureAsync'] }),
        MockDirective({ selector: '[appIfDebugFlagAsync]', inputs: ['appIfDebugFlagAsync'] })
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicationDetailComponent);
    component = fixture.componentInstance;
    headerService = TestBed.get(ContentHeaderBarService);
    spyOn(headerService, 'setButtons').and.callThrough();
  });

  it('should create', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('should call set buttons if has feature', () => {
    fixture.detectChanges();
    expect(headerService.setButtons).toHaveBeenCalled();
  });

  it('should not call set buttons if it does not have feature', () => {
    hasFeature = false;
    fixture.detectChanges();
    expect(headerService.setButtons).not.toHaveBeenCalled();
  });
});
