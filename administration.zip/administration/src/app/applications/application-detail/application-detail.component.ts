import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Application, UserPermissionsService } from '@content-platform/application-api';
import { LoggerService } from '@content-platform/logging';
import { ContentHeaderBarService, ContentHeaderButton } from '@content-platform/navigation';
import { take } from 'rxjs/operators';
import { MatDialog } from '@angular/material';
import { ActiveUserDialogComponent } from '../active-user-dialog/active-user-dialog.component';

@Component({
  selector: 'app-application-detail',
  templateUrl: './application-detail.component.html',
  styleUrls: ['./application-detail.component.scss']
})
export class ApplicationDetailComponent implements OnInit, OnDestroy {
  application: Application;
  contentHeaderButtons: ContentHeaderButton[] = [];
  private routeSub: Subscription;
  private logger: LoggerService;

  constructor(
    private route: ActivatedRoute,
    private contentHeaderBarService: ContentHeaderBarService,
    private router: Router,
    private userPermissionsService: UserPermissionsService,
    private dialog: MatDialog,
    loggerService: LoggerService
  ) {
    this.logger = loggerService.instance('ApplicationDetailComponent');
  }

  ngOnInit() {
    this.contentHeaderButtons = [
      {
        name: 'EDIT',
        type: 'raised',
        onClick: () => {
          this.router.navigate(['./edit'], { relativeTo: this.route });
        }
      }
    ];

    this.routeSub = this.route.data.subscribe(data => {
      this.application = data.application;
      if (this.userPermissionsService.hasFeature('edit_apps')) {
        this.contentHeaderBarService.setButtons(this.contentHeaderButtons);
      }
    });
  }

  getAllActiveUsers() {
    this.dialog
      .open(ActiveUserDialogComponent, {
        data: {
          appId: this.application.id
        }
      })
      .afterClosed()
      .pipe(take(1))
      .subscribe();
  }

  tabChange(event) {
    this.logger.info(`Switched to ${event.tab.textLabel} tab`);
  }

  ngOnDestroy() {
    this.routeSub.unsubscribe();
  }
}
