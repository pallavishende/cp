import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { StoreModule } from '@ngrx/store';
import { routerReducer } from '@ngrx/router-store';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute } from '@angular/router';
import { of, Subject } from 'rxjs';

import { ApplicationEditComponent } from './application-edit.component';
import { fromRole } from '@content-platform/application-api';
import { MaterialMockModule } from '@content-platform/unit-test-helpers';
import { NgPipesModule, OrderByPipe } from 'ngx-pipes';
import { ContentHeaderBarService } from '@content-platform/navigation';
import { LoggerService } from '@content-platform/logging';

describe('ApplicationEditComponent', () => {
  let component: ApplicationEditComponent;
  let fixture: ComponentFixture<ApplicationEditComponent>;
  let routeStub;

  function getKeyUpEvent(value: string) {
    return {
      target: {
        value
      }
    };
  }

  beforeEach(async(() => {
    routeStub = {
      data: of({
        application: {
          name: 'test',
          url: 'url',
          uuid: 'id',
          roles: [],
          features: [
            {
              id: 6362,
              name: 'submit',
              key: 'submit',
              metadataConfig: { type: 'string', dataset: null, allowMultiple: false }
            },
            { id: 6507, name: 'edit', key: 'edit_app', metadataConfig: null },
            {
              id: 6361,
              name: 'view',
              key: 'view_app',
              metadataConfig: { type: 'string', dataset: null, allowMultiple: false }
            }
          ]
        }
      })
    };

    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        RouterTestingModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialMockModule,
        NgPipesModule,
        StoreModule.forRoot({ routerReducer: routerReducer, role: fromRole.reducer })
      ],
      providers: [
        { provide: ActivatedRoute, useValue: routeStub },
        OrderByPipe,
        {
          provide: ContentHeaderBarService,
          useValue: {
            onClick: new Subject(),
            setButtons: () => {}
          }
        },
        {
          provide: LoggerService,
          useValue: {
            instance: () => {
              return { info: () => {} };
            }
          }
        }
      ],
      declarations: [ApplicationEditComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicationEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('add feature', () => {
    it('should allow a user to add a new feature', () => {
      component.addFeature();

      expect(component.featuresFormArray.value.length).toBe(4);
    });

    it('should set the key of a feature based on the name', () => {
      component.addFeature();
      component.addFeature();
      component.onFeatureNameKeyup(getKeyUpEvent('Feature One$$'), 0);
      component.onFeatureNameKeyup(getKeyUpEvent('Another Feature Dude!'), 1);

      expect(component.featuresFormArray.value[0].key).toBe('feature_one__');
      expect(component.featuresFormArray.value[1].key).toBe('another_feature_dude_');
    });
  });

  describe('remove feature', () => {
    it('should allow a user to remove a feature', () => {
      component.addFeature();
      component.addFeature();

      expect(component.featuresFormArray.value.length).toBe(5);
      component.removeFeature(0);
      expect(component.featuresFormArray.value.length).toBe(4);
    });
  });

  describe('key validation error', () => {
    it('should give an appropiate message based on validation error', () => {
      expect(component.getKeyValidationErrorMessage({ minlength: true })).toContain(
        'must be at least'
      );
      expect(component.getKeyValidationErrorMessage({ required: true })).toContain('is required');
      expect(component.getKeyValidationErrorMessage({ pattern: true })).toContain('letters');
      expect(component.getKeyValidationErrorMessage(null)).toEqual('');
    });
  });
});
