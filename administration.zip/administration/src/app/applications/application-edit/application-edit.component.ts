import { Component, OnInit, OnDestroy } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  FormControl,
  FormArray,
  Validators,
  ValidatorFn,
  AbstractControl,
  ValidationErrors
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { BehaviorSubject, Subject } from 'rxjs';

import {
  Application,
  applicationActions,
  Feature,
  FeatureMetadataTypes
} from '@content-platform/application-api';
import { AdministrationState } from '../../reducers';

import { OrderByPipe } from 'ngx-pipes';
import { isEqual } from 'lodash';
import { ContentHeaderBarService, ContentHeaderButton } from '@content-platform/navigation';
import { takeUntil } from 'rxjs/operators';
import { LoggerService } from '@content-platform/logging';

function uniqueKey(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {
    if (control.parent && control.parent.parent) {
      const featuresForm = control.parent.parent;
      const matchedKeys = (<FormGroup[]>featuresForm.controls).filter(
        formControl =>
          formControl.value.key === control.value && control !== formControl.controls.key
      );
      if (matchedKeys.length > 0) {
        return { key: { value: control.value } };
      }
    }
    return null;
  };
}

const FEATURE_KEY_MINLENGTH = 4;

@Component({
  selector: 'app-application-edit',
  templateUrl: './application-edit.component.html',
  styleUrls: ['./application-edit.component.scss']
})
export class ApplicationEditComponent implements OnInit, OnDestroy {
  application: Application;
  isNew = false;
  form: FormGroup;
  roleSearchStateCtrl: FormControl;
  isFormChanged: boolean;
  contentHeaderButtons: ContentHeaderButton[] = [];
  metadataTypes = FeatureMetadataTypes;

  private deletedFeatureIds: number[] = [];
  private onDestroy = new Subject<void>();
  private saveDisabled = new BehaviorSubject<boolean>(true);
  private logger: LoggerService;

  private keyValidators = [
    Validators.required,
    Validators.minLength(FEATURE_KEY_MINLENGTH),
    uniqueKey(),
    Validators.pattern('^[a-zA-Z0-9_]*$')
  ];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private store: Store<AdministrationState>,
    private orderPipe: OrderByPipe,
    private contentHeaderBarService: ContentHeaderBarService,
    loggerService: LoggerService
  ) {
    this.logger = loggerService.instance('ApplicationEditComponent');
    this.form = this.fb.group({
      name: '',
      global: false
    });
    this.roleSearchStateCtrl = new FormControl();

    this.form.valueChanges.pipe(takeUntil(this.onDestroy)).subscribe(formData => {
      const originalData = {
        name: this.application.name,
        global: this.application.global,
        features: this.orderPipe.transform(this.application.features, 'name')
      };

      this.isFormChanged = !isEqual(formData, originalData);
      this.saveDisabled.next(!this.isFormChanged || !this.form.valid);
    });
  }

  ngOnInit() {
    this.route.data.pipe(takeUntil(this.onDestroy)).subscribe(data => {
      if (data.application) {
        this.application = { ...data.application };
        this.isNew = !this.application.id;
        this.application.features = this.application.features || [];
        const { name, global } = this.application;
        this.setFeaturesForm();
        this.form.patchValue({
          name,
          global
        });

        this.contentHeaderButtons = [
          {
            name: 'CANCEL',
            onClick: () => {
              this.router.navigate(['..'], { relativeTo: this.route });
            }
          },
          {
            name: this.isNew ? 'CREATE' : 'SAVE',
            color: 'accent',
            type: 'flat',
            disabled$: this.saveDisabled.asObservable(),
            onClick: () => {
              this.isNew ? this.create() : this.save();
            }
          }
        ];
        this.contentHeaderBarService.setButtons(this.contentHeaderButtons);
      }
    });
  }

  private setFeaturesForm() {
    const featureFormGroups = this.orderPipe
      .transform(this.application.features, 'name')
      .map(feature => {
        feature.metadataConfig = feature.metadataConfig || {};
        return this.fb.group({
          name: feature.name,
          key: [feature.key, this.keyValidators],
          id: feature.id,
          metadataConfig: this.fb.group({
            type: feature.metadataConfig.type,
            dataset: feature.metadataConfig.dataset,
            allowMultiple: feature.metadataConfig.allowMultiple
          })
        });
      });
    const featureFormArray = this.fb.array(featureFormGroups);
    this.form.setControl('features', featureFormArray);
  }

  get featuresFormArray(): FormArray {
    return this.form.get('features') as FormArray;
  }

  private createKeyFromName(name: string): string {
    return name.toLowerCase().replace(/[^a-zA-Z0-9]/g, '_');
  }

  onFeatureNameKeyup(event, formIndex: number) {
    const keyForm = this.featuresFormArray.controls[formIndex].get('key');
    if (keyForm.value === '' || keyForm.untouched) {
      const sampleKey = this.createKeyFromName(event.target.value);
      keyForm.patchValue(sampleKey);
    }
  }

  addFeature() {
    const fg = this.fb.group({
      name: '',
      key: ['', this.keyValidators],
      metadataConfig: this.fb.group({ type: '', dataset: '', allowMultiple: false })
    });
    this.featuresFormArray.push(fg);
    this.logger.info('Added new feature');
  }

  removeFeature(index: number) {
    const feature: Feature = this.getFeatureFromIndex(index);
    if (feature) {
      this.deletedFeatureIds.push(feature.id);
      this.featuresFormArray.removeAt(index);
    }
    this.logger.info('Removed feature', feature);
  }

  private getFeatureFromIndex(index: number): Feature {
    const feature: Feature = this.featuresFormArray.at(index).value;
    return feature;
  }

  save() {
    this.store.dispatch(
      new applicationActions.Update({
        ...this.application,
        features: this.featuresFormArray.value,
        deletedFeatures: this.deletedFeatureIds,
        ...this.form.value
      })
    );
  }

  create() {
    this.store.dispatch(
      new applicationActions.Create({
        ...this.form.value,
        features: this.featuresFormArray.value
      })
    );
  }

  ngOnDestroy() {
    this.onDestroy.next();
  }

  getKeyValidationErrorMessage(errors: ValidationErrors): string {
    if (!errors || Object.keys(errors).length === 0) {
      return '';
    }
    const errorType = Object.keys(errors)[0];
    const messageStart = 'Feature key ';
    switch (errorType) {
      case 'minlength':
        return messageStart + `must be at least ${FEATURE_KEY_MINLENGTH} characters`;
      case 'required':
        return messageStart + 'is required';
      case 'pattern':
        return messageStart + 'can only be letters, numbers or underscores';
    }

    return messageStart + 'error';
  }

  isDatasetValueRequired(featureIndex: number): boolean {
    const feature = this.featuresFormArray.value[featureIndex];
    return feature.metadataConfig && feature.metadataConfig.type === 'dataset';
  }
}
