import { Store, select } from '@ngrx/store';
import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { take, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { Application } from '@content-platform/application-api';
import { AdministrationState, getSelectedApplication } from '../reducers';

@Injectable()
export class ApplicationResolver implements Resolve<Application> {
  constructor(private store: Store<AdministrationState>, private router: Router) {}

  resolve(): Observable<Application> {
    return this.waitForApplicationDataToLoad();
  }

  waitForApplicationDataToLoad(): Observable<Application> {
    return this.store.pipe(
      select(getSelectedApplication),
      tap(application => {
        if (!application) {
          this.router.navigate(['/applications']);
        }
      }),
      take(1)
    );
  }
}
