import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApplicationResolver } from './application.resolver';
import { ApplicationDetailComponent } from './application-detail/application-detail.component';
import { ApplicationEditComponent } from './application-edit/application-edit.component';
import { ApplicationsGuard, RolesGuard, ErrorGuard } from '../guards';
import {
  applicationSelectors,
  UserPermissionListGuard,
  FeatureGuard,
  applicationActions
} from '@content-platform/application-api';
import {
  ContentContainerComponent,
  ContentNavigationListComponent
} from '@content-platform/reusable-ui/components';

export function deleteApplication(item, store) {
  store.dispatch(new applicationActions.Delete(item.id));
}

const EDIT_FEATURE_KEY = 'edit_apps';
const DELETE_FEATURE_KEY = 'delete_apps';

const routes: Routes = [
  {
    path: '',
    component: ContentContainerComponent,
    data: {
      title: 'Application(s)'
    },
    canActivate: [UserPermissionListGuard, ApplicationsGuard, ErrorGuard],
    children: [
      {
        path: ':applicationId',
        component: ApplicationDetailComponent,
        resolve: { application: ApplicationResolver }
      },
      {
        path: '',
        component: ContentNavigationListComponent,
        outlet: 'navigation-list',
        data: {
          itemsSelector: applicationSelectors.getAllApplicationItems,
          showCreateNewFeatureKey: EDIT_FEATURE_KEY,
          showDeleteFeatureKey: DELETE_FEATURE_KEY,
          deleteFunction: deleteApplication,
          title: 'Applications'
        }
      },
      {
        path: ':applicationId/edit',
        component: ApplicationEditComponent,
        resolve: { application: ApplicationResolver },
        data: {
          featureGuard: { key: EDIT_FEATURE_KEY }
        },
        canActivate: [RolesGuard, FeatureGuard]
      },
      {
        path: ':applicationId/new',
        component: ApplicationEditComponent,
        data: {
          application: { name: 'New Application' },
          featureGuard: { key: EDIT_FEATURE_KEY }
        },
        canActivate: [RolesGuard, FeatureGuard]
      }
    ]
  },
  { path: '*', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ApplicationsRoutingModule {}
