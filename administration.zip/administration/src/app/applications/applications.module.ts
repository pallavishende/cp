import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgPipesModule, OrderByPipe } from 'ngx-pipes';

import {
  MatListModule,
  MatIconModule,
  MatCardModule,
  MatSlideToggleModule,
  MatInputModule,
  MatButtonModule,
  MatAutocompleteModule,
  MatCheckboxModule,
  MatTabsModule,
  MatMenuModule,
  MatSelectModule,
  MatDialogModule
} from '@angular/material';

import { ApplicationsRoutingModule } from './applications-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ApplicationDetailComponent } from './application-detail/application-detail.component';
import { ApplicationResolver } from './application.resolver';
import { ApplicationEditComponent } from './application-edit/application-edit.component';
import { guards } from '../guards';
import { GraphApiModule } from '@content-platform/graph-api';
import { PermissionsModule } from '@content-platform/application-api';
import { DevelopmentModule } from '@content-platform/development';
import { PipesModule } from '@content-platform/pipes';
import { ReusableUiContentNavigationModule } from '@content-platform/reusable-ui/components';
import { ActiveUserDialogComponent } from './active-user-dialog/active-user-dialog.component';
import { CommonHelpersModule } from '@content-platform/common-helpers';
import { LoadingSpinnerModule } from '@content-platform/reusable-ui/loading-spinner';

@NgModule({
  imports: [
    CommonModule,
    ApplicationsRoutingModule,
    MatListModule,
    MatIconModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatTabsModule,
    MatMenuModule,
    MatSelectModule,
    MatAutocompleteModule,
    MatSlideToggleModule,
    MatDialogModule,
    LoadingSpinnerModule,
    FormsModule,
    ReactiveFormsModule,
    GraphApiModule,
    ReusableUiContentNavigationModule,
    PermissionsModule,
    MatCheckboxModule,
    NgPipesModule,
    DevelopmentModule,
    PipesModule,
    CommonHelpersModule
  ],
  providers: [...guards, ApplicationResolver, OrderByPipe],
  declarations: [ApplicationDetailComponent, ApplicationEditComponent, ActiveUserDialogComponent],
  entryComponents: [ActiveUserDialogComponent]
})
export class ApplicationsModule {}
