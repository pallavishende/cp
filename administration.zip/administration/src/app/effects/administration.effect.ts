import { tap, map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Router } from '@angular/router';
import {
  applicationActions,
  roleActions,
  userRoleListActions,
  UserRoleList
} from '@content-platform/application-api';
import {
  datasetActions,
  fromDataset,
  layoutSchemaActions,
  fieldSchemaActions
} from '@content-platform/dynamic-forms-api';

@Injectable()
export class AdministrationEffects {
  constructor(private actions$: Actions, private router: Router) {}

  @Effect({ dispatch: false })
  updateApplicationSuccess$ = this.actions$.pipe(
    ofType(applicationActions.UPDATE_SUCCESS, applicationActions.CREATE_SUCCESS),
    map((action: applicationActions.UpdateSuccess) => action.payload),
    tap(app => {
      this.router.navigate(['applications', app.id]);
    })
  );

  @Effect({ dispatch: false })
  updateRoleSuccess$ = this.actions$.pipe(
    ofType(roleActions.UPDATE_SUCCESS, roleActions.CREATE_SUCCESS),
    map((action: roleActions.UpdateSuccess) => action.payload),
    tap(role => {
      this.router.navigate(['roles', role.id]);
    })
  );

  @Effect({ dispatch: false })
  updateSchemaSuccess$ = this.actions$.pipe(
    ofType(layoutSchemaActions.UPDATE_SUCCESS, layoutSchemaActions.CREATE_SUCCESS),
    map((action: layoutSchemaActions.UpdateSuccess) => action.payload),
    tap(schema => {
      this.router.navigate(['/schema-config/schema-editor', schema.contentType]);
    })
  );

  @Effect({ dispatch: false })
  updateFieldSchemaSuccess$ = this.actions$.pipe(
    ofType(fieldSchemaActions.UPDATE_SUCCESS, fieldSchemaActions.CREATE_SUCCESS),
    map((action: fieldSchemaActions.UpdateSuccess) => action.payload),
    tap(schema => {
      this.router.navigate(['/schema-config/field-schema-editor', schema.fieldKey]);
    })
  );

  @Effect({ dispatch: false })
  updateDatasetSuccess$ = this.actions$.pipe(
    ofType(datasetActions.UPDATE_SUCCESS, datasetActions.CREATE_SUCCESS),
    map((action: datasetActions.UpdateSuccess) => action.payload),
    tap(dataset => {
      this.router.navigate(['/schema-config/dataset-manager', fromDataset.getDatasetId(dataset)]);
    })
  );

  @Effect({ dispatch: false })
  deleteRoleSuccess$ = this.actions$.pipe(
    ofType(roleActions.DELETE_SUCCESS),
    map((action: roleActions.DeleteSuccess) => action.payload),
    tap(() => {
      this.router.navigate(['roles']);
    })
  );

  @Effect({ dispatch: false })
  deleteApplicationSuccess$ = this.actions$.pipe(
    ofType(applicationActions.DELETE_SUCCESS),
    map((action: applicationActions.DeleteSuccess) => action.payload),
    tap(() => {
      this.router.navigate(['applications']);
    })
  );

  @Effect({ dispatch: false })
  deleteSchemaSuccess$ = this.actions$.pipe(
    ofType(layoutSchemaActions.DELETE_SUCCESS),
    map((action: layoutSchemaActions.DeleteSuccess) => action.payload),
    tap(() => {
      this.router.navigate(['/schema-config/schema-editor']);
    })
  );

  @Effect({ dispatch: false })
  deleteFieldSchemaSuccess$ = this.actions$.pipe(
    ofType(fieldSchemaActions.DELETE_SUCCESS),
    map((action: fieldSchemaActions.DeleteSuccess) => action.payload),
    tap(() => {
      this.router.navigate(['/schema-config/field-schema-editor']);
    })
  );

  @Effect({ dispatch: false })
  updateUserRoleListSuccess$ = this.actions$.pipe(
    ofType(userRoleListActions.UPDATE_SUCCESS),
    map((action: userRoleListActions.UpdateSuccess) => action.payload),
    tap((userRoleList: UserRoleList) => {
      this.router.navigate(['users', userRoleList.uuid]);
    })
  );
}
