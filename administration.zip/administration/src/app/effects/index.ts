import { AdministrationEffects } from './administration.effect';

export const effects = [AdministrationEffects];
export * from './administration.effect';
