import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';

import { Store, select } from '@ngrx/store';
import { Observable, of } from 'rxjs';

import { filter, catchError, withLatestFrom, map } from 'rxjs/operators';
import { applicationSelectors, applicationActions } from '@content-platform/application-api';
import { AdministrationState } from '../reducers';

@Injectable()
export class ApplicationsGuard implements CanActivate {
  constructor(protected store: Store<AdministrationState>) {}

  canActivate(): Observable<boolean> {
    return this.checkStore().pipe(catchError(() => of(false)));
  }

  checkStore(): Observable<boolean> {
    return this.store.pipe(
      select(applicationSelectors.getApplicationsLoading),
      withLatestFrom(this.store.pipe(select(applicationSelectors.getApplicationsLoaded))),
      filter(([loading, loaded], index) => {
        if (!loaded && !loading && index === 0) {
          this.store.dispatch(new applicationActions.Load());
          return false;
        }
        return !loading;
      }),
      map(([, loaded]) => loaded as boolean)
    );
  }
}
