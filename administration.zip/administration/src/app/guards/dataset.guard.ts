import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot } from '@angular/router';

import { Store, select } from '@ngrx/store';
import { Observable, of } from 'rxjs';

import { filter, withLatestFrom, map, catchError } from 'rxjs/operators';

import { AdministrationState } from '../reducers';
import { datasetSelectors, datasetActions, fromDataset } from '@content-platform/dynamic-forms-api';

const DATASET_GUARD_DATA_PROPERTY = 'datasetId';

@Injectable()
export class DatasetGuard implements CanActivate {
  constructor(protected store: Store<AdministrationState>) {}

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    const datasetName = route.params[DATASET_GUARD_DATA_PROPERTY] as string;
    let datasetLookup;
    try {
      datasetLookup = fromDataset.getDatasetLookupFromId(datasetName);
    } catch {
      return of(false);
    }

    return this.checkStore(datasetLookup.contentType, datasetLookup.fieldKey).pipe(
      catchError(() => of(false))
    );
  }

  checkStore(contentType: string, fieldKey: string): Observable<boolean> {
    return this.store.pipe(
      select(datasetSelectors.getDatasetLoading),
      withLatestFrom(
        this.store.pipe(
          select(datasetSelectors.getDatasetByContentTypeAndFieldKey(contentType, fieldKey))
        )
      ),
      filter(([loading, dataset], index) => {
        if (!dataset && !loading && index === 0) {
          this.store.dispatch(new datasetActions.Load({ contentType, fieldKey }));
          return false;
        }
        return !loading;
      }),
      map(() => true)
    );
  }
}
