import { map } from 'rxjs/operators';
import { Injectable, NgZone } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

import { Store, select } from '@ngrx/store';
import { Observable, combineLatest } from 'rxjs';

import {
  roleSelectors,
  applicationSelectors,
  userRoleListSelectors,
  userPermissionListSelectors
} from '@content-platform/application-api';

import { GenericErrorGuard, fromError } from '@content-platform/error-handling';

@Injectable()
export class ErrorGuard extends GenericErrorGuard implements CanActivate {
  constructor(store: Store<fromError.State>, router: Router, zone: NgZone) {
    super(store, router, zone);
  }

  /**
   * Returned Observable is true when no longer loading
   *
   * @returns {Observable<boolean>}
   * @memberof ErrorGuard
   */
  protected waitUntil(): Observable<boolean> {
    return combineLatest(
      this.store.pipe(select(roleSelectors.getRolesLoading)),
      this.store.pipe(select(applicationSelectors.getApplicationsLoading)),
      this.store.pipe(select(userRoleListSelectors.getUserRoleListLoading)),
      this.store.pipe(select(userPermissionListSelectors.getUserPermissionListLoading))
    ).pipe(map(loadingArray => !loadingArray.includes(true)));
  }
}
