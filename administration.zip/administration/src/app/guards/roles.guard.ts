import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';

import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';

import { filter, withLatestFrom, map } from 'rxjs/operators';

import { roleSelectors, roleActions } from '@content-platform/application-api';
import { AdministrationState } from '../reducers';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(protected store: Store<AdministrationState>) {}

  canActivate(): Observable<boolean> {
    return this.checkStore();
  }

  checkStore(): Observable<boolean> {
    return this.store.pipe(
      select(roleSelectors.getRolesLoading),
      withLatestFrom(this.store.pipe(select(roleSelectors.getRolesLoaded))),
      filter(([loading, loaded], index) => {
        if (!loaded && !loading && index === 0) {
          this.store.dispatch(new roleActions.Load());
          return false;
        }
        return !loading;
      }),
      map(([, loaded]) => loaded as boolean)
    );
  }
}
