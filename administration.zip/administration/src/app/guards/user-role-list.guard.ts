import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRoute } from '@angular/router';

import { Store, select } from '@ngrx/store';
import { Observable, of } from 'rxjs';

import { tap, filter, catchError } from 'rxjs/operators';

import { userRoleListActions } from '@content-platform/application-api';
import { AdministrationState, getSelectedUserRoleListLoaded } from '../reducers';

@Injectable()
export class UserRoleListGuard implements CanActivate {
  constructor(protected store: Store<AdministrationState>, private route: ActivatedRoute) {}

  canActivate(): Observable<boolean> {
    return this.checkStore().pipe(catchError(() => of(false)));
  }

  checkStore(): Observable<boolean> {
    return this.store.pipe(
      select(getSelectedUserRoleListLoaded),
      tap(loaded => {
        if (!loaded) {
          this.store.dispatch(new userRoleListActions.LoadById(this.route.snapshot.params.userId));
        }
      }),
      filter(loaded => loaded)
    );
  }
}
