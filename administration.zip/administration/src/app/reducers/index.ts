import { createFeatureSelector, createSelector, ActionReducerMap } from '@ngrx/store';
import { Auth, fromAuth } from '@content-platform/auth';
import {
  fromApplication,
  applicationSelectors,
  roleSelectors,
  userRoleListSelectors
} from '@content-platform/application-api';
import * as fromRouter from '@ngrx/router-store';
import { Params, RouterStateSnapshot, ActivatedRouteSnapshot } from '@angular/router';
import { routerReducer } from '@ngrx/router-store';
import {
  layoutSchemaSelectors,
  datasetSelectors,
  fieldSchemaSelectors
} from '@content-platform/dynamic-forms-api';

export interface RouterStateUrl {
  url: string;
  queryParams: Params;
  params: Params;
}

export interface AdministrationState {
  auth: Auth;
  application: fromApplication.State;
  routerReducer: fromRouter.RouterReducerState<RouterStateUrl>;
}

export const reducers: ActionReducerMap<AdministrationState> = {
  auth: fromAuth.authReducer,
  routerReducer: routerReducer,
  application: fromApplication.reducer
};

export class CustomSerializer implements fromRouter.RouterStateSerializer<RouterStateUrl> {
  serialize(routerState: RouterStateSnapshot): RouterStateUrl {
    const { url } = routerState;
    const { queryParams } = routerState.root;

    let state: ActivatedRouteSnapshot = routerState.root;
    while (state.firstChild) {
      state = state.firstChild;
    }
    const { params } = state;

    return { url, queryParams, params };
  }
}

export const getRouterState = createFeatureSelector<fromRouter.RouterReducerState<RouterStateUrl>>(
  'routerReducer'
);

export const getSelectedApplication = createSelector(
  applicationSelectors.getApplicationEntities,
  getRouterState,
  (applications, router) => {
    return router.state && router.state.params && applications[router.state.params.applicationId];
  }
);

export const getSelectedRole = createSelector(
  roleSelectors.getRoleEntities,
  getRouterState,
  (roles, router) => {
    return router.state && router.state.params && roles[router.state.params.roleId];
  }
);

export const getSelectedUserProfile = createSelector(
  getRouterState,
  router => {
    return router.state && router.state.params && router.state.params.userId;
  }
);

export const getSelectedSchemaEditor = createSelector(
  getRouterState,
  layoutSchemaSelectors.getSchemaEntities,
  (router, entities) => {
    if (router.state && router.state.params && router.state.params.contentType) {
      return entities[router.state.params.contentType];
    }
  }
);

export const getSelectedFieldSchema = createSelector(
  getRouterState,
  fieldSchemaSelectors.getSchemaEntities,
  (router, entities) => {
    if (router.state && router.state.params && router.state.params.fieldKey) {
      return entities[router.state.params.fieldKey];
    }
  }
);

export const getSelectedDatasetManager = createSelector(
  getRouterState,
  datasetSelectors.getDatasetEntities,
  (router, entities) => {
    if (router.state && router.state.params && router.state.params.datasetId) {
      return entities[router.state.params.datasetId];
    }
  }
);

export const getSelectedUserRoleList = createSelector(
  userRoleListSelectors.getUserRoleListEntities,
  getRouterState,
  (userRoleLists, router) => {
    return router.state && router.state.params && userRoleLists[router.state.params.userId];
  }
);

export const getSelectedUserRoleListLoaded = createSelector(
  userRoleListSelectors.getUserRoleListEntities,
  getRouterState,
  (userRoleLists, router) => {
    return !!(router.state && router.state.params && userRoleLists[router.state.params.userId]);
  }
);
