import { Store, select } from '@ngrx/store';
import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { take, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { Application, applicationSelectors } from '@content-platform/application-api';
import { AdministrationState } from '../reducers';

@Injectable()
export class ApplicationsResolver implements Resolve<Application[]> {
  constructor(private store: Store<AdministrationState>, private router: Router) {}

  resolve(): Observable<Application[]> {
    return this.waitForApplicationDataToLoad();
  }

  waitForApplicationDataToLoad(): Observable<Application[]> {
    return this.store.pipe(
      select(applicationSelectors.getAllApplicationItems),
      tap(apps => {
        if (!apps) {
          this.router.navigate(['/']);
        }
      }),
      take(1)
    );
  }
}
