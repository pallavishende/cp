import { Store, select } from '@ngrx/store';
import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { tap, take } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AdministrationState, getSelectedDatasetManager } from '../reducers';
import { Dataset } from '@content-platform/dynamic-forms-api';

@Injectable()
export class DatasetManagerResolver implements Resolve<Dataset> {
  constructor(private store: Store<AdministrationState>, private router: Router) {}

  resolve(): Observable<Dataset> {
    return this.store.pipe(
      select(getSelectedDatasetManager),
      tap(dataset => {
        if (!dataset) {
          this.router.navigate(['/schema-config/dataset-manager']);
        }
      }),
      take(1)
    );
  }
}
