import { Store, select } from '@ngrx/store';
import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { tap, take } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AdministrationState, getSelectedFieldSchema } from '../reducers';
import { FieldSchemaResponse } from '@content-platform/dynamic-forms-api';

@Injectable()
export class FieldSchemaResolver implements Resolve<FieldSchemaResponse> {
  constructor(private store: Store<AdministrationState>, private router: Router) {}

  resolve(): Observable<FieldSchemaResponse> {
    return this.store.pipe(
      select(getSelectedFieldSchema),
      tap(schema => {
        if (!schema) {
          this.router.navigate(['/schema-config/field-schema-editor']);
        }
      }),
      take(1)
    );
  }
}
