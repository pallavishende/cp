import { Store, select } from '@ngrx/store';
import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { take, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AdministrationState, getSelectedRole } from '../reducers';
import { Role } from '@content-platform/application-api';

@Injectable()
export class RoleResolver implements Resolve<Role> {
  constructor(private store: Store<AdministrationState>, private router: Router) {}

  resolve(): Observable<Role> {
    return this.waitForApplicationDataToLoad();
  }

  waitForApplicationDataToLoad(): Observable<Role> {
    return this.store.pipe(
      select(getSelectedRole),
      tap(application => {
        if (!application) {
          this.router.navigate(['/roles']);
        }
      }),
      take(1)
    );
  }
}
