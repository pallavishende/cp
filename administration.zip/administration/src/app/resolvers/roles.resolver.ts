import { Store, select } from '@ngrx/store';
import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { take, tap, map } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AdministrationState } from '../reducers';
import { Role, roleSelectors } from '@content-platform/application-api';

@Injectable()
export class RolesResolver implements Resolve<Role[]> {
  constructor(private store: Store<AdministrationState>, private router: Router) {}

  resolve(): Observable<Role[]> {
    return this.waitForRolesDataToLoad();
  }

  waitForRolesDataToLoad(): Observable<Role[]> {
    return this.store.pipe(
      select(roleSelectors.getAllRoleItems),
      tap(roles => {
        if (!roles) {
          this.router.navigate(['/']);
        }
      }),
      map(roles => {
        return roles || [];
      }),
      take(1)
    );
  }
}
