import { Store, select } from '@ngrx/store';
import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { tap, take } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AdministrationState, getSelectedSchemaEditor } from '../reducers';
import { LayoutSchemaResponse } from '@content-platform/dynamic-forms-api';

@Injectable()
export class SchemaEditorResolver implements Resolve<LayoutSchemaResponse> {
  constructor(private store: Store<AdministrationState>, private router: Router) {}

  resolve(): Observable<LayoutSchemaResponse> {
    return this.store.pipe(
      select(getSelectedSchemaEditor),
      tap(schema => {
        if (!schema) {
          this.router.navigate(['/schema-config/schema-editor']);
        }
      }),
      take(1)
    );
  }
}
