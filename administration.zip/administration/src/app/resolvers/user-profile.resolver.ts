import { Store, select } from '@ngrx/store';
import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { tap, take, switchMap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AdministrationState, getSelectedUserProfile } from '../reducers';
import { GraphApi, UserProfile } from '@content-platform/graph-api';

@Injectable()
export class UserProfileResolver implements Resolve<UserProfile> {
  constructor(
    private store: Store<AdministrationState>,
    private router: Router,
    private graphApi: GraphApi
  ) {}

  resolve(): Observable<UserProfile> {
    return this.store.pipe(
      select(getSelectedUserProfile),
      tap(userId => {
        if (!userId) {
          this.router.navigate(['/users']);
        }
      }),
      take(1),
      switchMap(userId => this.graphApi.getUser(userId))
    );
  }
}
