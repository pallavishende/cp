import { Store, select } from '@ngrx/store';
import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { tap, take, filter } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AdministrationState, getSelectedUserRoleList } from '../reducers';
import { UserRoleList } from '@content-platform/application-api';
import { userRoleListActions } from '@content-platform/application-api';

@Injectable()
export class UserRoleListResolver implements Resolve<UserRoleList> {
  constructor(private store: Store<AdministrationState>) {}

  resolve(route: ActivatedRouteSnapshot): Observable<UserRoleList> {
    return this.store.pipe(
      select(getSelectedUserRoleList),
      tap(userRoleList => {
        if (!userRoleList) {
          this.store.dispatch(new userRoleListActions.LoadById(route.params.userId));
        }
      }),
      filter(userRoleList => !!userRoleList),
      take(1)
    );
  }
}
