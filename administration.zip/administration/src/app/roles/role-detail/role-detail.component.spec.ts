import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { ContentHeaderBarService } from '@content-platform/navigation';
import { StoreModule } from '@ngrx/store';
import { of } from 'rxjs';
import { NgPipesModule } from 'ngx-pipes';
import { MaterialMockModule, MockPipe, MockDirective } from '@content-platform/unit-test-helpers';
import { fromRole, UserPermissionsService } from '@content-platform/application-api';

import { RoleDetailComponent } from './role-detail.component';
import { LoggerService } from '@content-platform/logging';
import { MatTooltipModule } from '@angular/material';

describe('RoleDetailComponent', () => {
  let component: RoleDetailComponent;
  let fixture: ComponentFixture<RoleDetailComponent>;
  let routeStub;
  let headerService: ContentHeaderBarService;
  let hasFeature = true;

  beforeEach(async(() => {
    routeStub = {
      data: of({
        role: {
          name: 'test',
          uuid: 'id',
          users: [],
          permissions: []
        },
        applications: []
      })
    };

    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        MaterialMockModule,
        NgPipesModule,
        MatTooltipModule,
        StoreModule.forRoot({ role: fromRole.reducer })
      ],
      providers: [
        { provide: ActivatedRoute, useValue: routeStub },
        { provide: ContentHeaderBarService, useValue: { setButtons: () => {} } },
        { provide: UserPermissionsService, useValue: { hasFeature: () => hasFeature } },
        {
          provide: LoggerService,
          useValue: {
            instance: () => {
              return { info: () => {} };
            }
          }
        }
      ],
      declarations: [
        RoleDetailComponent,
        MockPipe('displayName'),
        MockPipe('userProfile'),
        MockDirective({ selector: '[appIfFeatureAsync]', inputs: ['appIfFeatureAsync'] }),
        MockDirective({ selector: '[appIfDebugFlagAsync]', inputs: ['appIfDebugFlagAsync'] })
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RoleDetailComponent);
    component = fixture.componentInstance;
    headerService = TestBed.get(ContentHeaderBarService);
    spyOn(headerService, 'setButtons').and.callThrough();
  });

  it('should create', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('should call set buttons if has feature', () => {
    fixture.detectChanges();
    expect(headerService.setButtons).toHaveBeenCalled();
  });

  it('should not call set buttons if it does not have feature', () => {
    hasFeature = false;
    fixture.detectChanges();
    expect(headerService.setButtons).not.toHaveBeenCalled();
  });
});
