import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ContentHeaderBarService, ContentHeaderButton } from '@content-platform/navigation';

import {
  Role,
  Permission,
  Application,
  Feature,
  UserPermissionsService
} from '@content-platform/application-api';
import { UserProfile } from '@content-platform/graph-api';
import { LoggerService } from '@content-platform/logging';
import { DisplayNamePipe } from '@content-platform/pipes';

@Component({
  selector: 'app-role-detail',
  templateUrl: './role-detail.component.html',
  styleUrls: ['./role-detail.component.scss']
})
export class RoleDetailComponent implements OnInit, OnDestroy {
  role: Role;
  applications: Application[];
  permissionsAssigned: { [appId: string]: Permission[] } = {};
  dpNamePipe: DisplayNamePipe;
  activeUsers: UserProfile[];
  contentHeaderButtons: ContentHeaderButton[] = [];
  private routeSub: Subscription;
  private logger: LoggerService;

  constructor(
    private route: ActivatedRoute,
    private contentHeaderBarService: ContentHeaderBarService,
    private router: Router,
    private userPermissionsService: UserPermissionsService,
    loggerService: LoggerService
  ) {
    this.dpNamePipe = new DisplayNamePipe();
    this.logger = loggerService.instance('RoleDetailComponent');
  }

  /**
   *
   * Hack to work with mat-expandable-panel in hidden mat-tab issue
   * {@link https://www.bountysource.com/issues/46433954-tabs-hidden-tabs-don-t-render-expansion-panels-correctly}
   *
   */
  showPermissionTabContent = false;
  tabChange(event) {
    this.logger.info(`Switched to ${event.tab.textLabel} tab`);
    Promise.resolve().then(
      () => (this.showPermissionTabContent = event.tab.textLabel === 'Permissions')
    );
  }

  ngOnInit() {
    this.contentHeaderButtons = [
      {
        name: 'EDIT',
        type: 'raised',
        onClick: () => {
          this.router.navigate(['./edit'], { relativeTo: this.route });
        }
      }
    ];
    this.routeSub = this.route.data.subscribe(data => {
      if (this.userPermissionsService.hasFeature('edit_roles')) {
        this.contentHeaderBarService.setButtons(this.contentHeaderButtons);
      }
      this.applications = data.applications;
      this.role = data.role;
      const { permissions } = this.role;
      this.activeUsers = [
        ...((this.role.users as UserProfile[]) || []).map(user => {
          user['displayName'] = this.dpNamePipe.transform(<UserProfile>user);
          return user;
        })
      ] as UserProfile[];

      this.applications.forEach(app => {
        const foundApp = this.role.applicationAdminPrivileges.find(
          appPriviledge => appPriviledge.id === app.id
        );
        if (foundApp) {
          this.permissionsAssigned[app.id] = app.features.map(feature => {
            return { feature };
          }) as Permission[];
        } else {
          this.permissionsAssigned[app.id] = permissions.filter(rolePermission =>
            app.features.map(feature => feature.id).includes(rolePermission.feature.id)
          );
        }
      });
    });
  }

  private findMatchingExistingPermission(feature: Feature): Permission {
    return this.role.permissions.find(permission => permission.feature.id === feature.id);
  }

  getPermissionMetadataString(feature: Feature): string {
    const existingPermission = this.findMatchingExistingPermission(feature);
    if (!existingPermission || !existingPermission.metadata) {
      return '';
    }
    return existingPermission.metadata.reduce((soFar, current, index) => {
      return (
        soFar +
        `${current.name}` +
        (current.description ? ` (${current.description})` : '') +
        (index < existingPermission.metadata.length - 1 ? ', ' : '')
      );
    }, '');
  }

  isRoleAppAdmin(appId: number): boolean {
    const foundApp = this.role.applicationAdminPrivileges.find(
      appPriviledge => appPriviledge.id === appId
    );
    if (foundApp) {
      return true;
    }
    return false;
  }

  ngOnDestroy() {
    this.routeSub.unsubscribe();
  }
}
