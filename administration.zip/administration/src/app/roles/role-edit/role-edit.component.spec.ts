import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { of, Subject } from 'rxjs';
import { StoreModule, Store } from '@ngrx/store';
import { routerReducer } from '@ngrx/router-store';
import { fromRole, roleActions, Feature } from '@content-platform/application-api';
import { RoleEditComponent } from './role-edit.component';
import { GraphApi, UserProfile } from '@content-platform/graph-api';
import {
  MaterialMockModule,
  MockPipe,
  MockDirective,
  MockComponent
} from '@content-platform/unit-test-helpers';
import { MatAutocompleteSelectedEvent } from '@angular/material';
import { NgPipesModule, OrderByPipe } from 'ngx-pipes';
import { ContentHeaderBarService } from '@content-platform/navigation';
import { LoggerService } from '@content-platform/logging';

describe('RoleEditComponent', () => {
  let component: RoleEditComponent;
  let fixture: ComponentFixture<RoleEditComponent>;
  let routeStub;
  let graphApi: GraphApi;
  let store: Store<fromRole.State>;

  const mockFeature: Feature = {
    name: 'edit',
    key: '222',
    id: 1234,
    metadataConfig: null
  };

  const mockPermissions = [
    {
      id: 444,
      feature: {
        id: 123,
        name: 'Edit',
        key: 'edit',
        metadataConfig: { type: 'string', dataset: null, allowMultiple: false }
      },
      metadata: [{ name: 'Hello World 1', description: '' }]
    },
    {
      id: 888,
      feature: {
        id: 567,
        name: 'View',
        key: 'view',
        metadataConfig: null
      },
      metadata: undefined
    },
    {
      id: 999,
      feature: {
        id: 345,
        name: 'Login',
        key: 'login',
        metadataConfig: { type: 'string', dataset: null, allowMultiple: false }
      },
      metadata: [{ name: 'Hello World 3', description: '' }]
    }
  ];

  beforeEach(() => {
    jest.useFakeTimers();
    routeStub = {
      data: of({
        role: {
          name: 'test',
          id: 333,
          permissions: mockPermissions,
          users: [],
          applicationAdminPrivileges: []
        },
        applications: [
          {
            id: 222,
            name: 'test',
            features: [
              {
                name: 'edit',
                key: '222',
                id: 1234,
                metadataConfig: null
              },
              mockPermissions[0].feature,
              mockPermissions[1].feature,
              mockPermissions[2].feature
            ]
          }
        ]
      })
    };
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        RouterTestingModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialMockModule,
        NgPipesModule,
        StoreModule.forRoot({ routerReducer: routerReducer, role: fromRole.reducer })
      ],
      providers: [
        { provide: ActivatedRoute, useValue: routeStub },
        {
          provide: GraphApi,
          useValue: {
            searchUsers: () => {
              return of([]);
            }
          }
        },
        { provide: ActivatedRoute, useValue: routeStub },
        OrderByPipe,
        {
          provide: ContentHeaderBarService,
          useValue: {
            onClick: new Subject(),
            setButtons: () => {}
          }
        },
        {
          provide: LoggerService,
          useValue: {
            instance: () => {
              return { info: () => {} };
            }
          }
        }
      ],
      declarations: [
        RoleEditComponent,
        MockPipe('displayName'),
        MockDirective({ selector: '[appIfFeatureAsync]', inputs: ['appIfFeatureAsync'] }),
        MockDirective({ selector: '[appIfNotFeatureAsync]', inputs: ['appIfNotFeatureAsync'] }),
        MockComponent({ selector: 'app-field-dropdown', inputs: ['field', 'parentFormGroup'] })
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    store = TestBed.get(Store);
    graphApi = TestBed.get(GraphApi);

    fixture = TestBed.createComponent(RoleEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call create() action', () => {
    component.role.permissions = mockPermissions;
    const action = new roleActions.Create(component.role);
    spyOn(store, 'dispatch').and.callThrough();
    component.create();
    expect(store.dispatch).toHaveBeenCalledWith(action);
  });

  it('should call save() action', () => {
    component.appSelectedFeatures[222] = [
      mockPermissions[0].feature,
      mockPermissions[1].feature,
      mockPermissions[2].feature
    ];
    component.role.deletedPermissions = [];
    component.role.permissions = mockPermissions;
    const action = new roleActions.Update(component.role);
    spyOn(store, 'dispatch').and.callThrough();
    component.save();
    expect(store.dispatch).toHaveBeenCalledWith(action);
  });

  it('should call update permission list', () => {
    component.updatePermissionList(123, [mockFeature]);
    expect(component.appSelectedFeatures[123]).toEqual([mockFeature]);
  });

  it('should call updateAllPermissionList() without matching role admin with checked admin privelege', () => {
    component.updateAllPermissionList(123, true);
    expect(component.role.applicationAdminPrivileges).toEqual([]);
  });

  it('should call updateAllPermissionList() with matching role admin with checked admin privelege', () => {
    component.role.applicationAdminPrivileges = [{ id: 222 }];
    component.updateAllPermissionList(222, true);
    expect(component.role.applicationAdminPrivileges).toEqual([{ id: 222 }]);
    expect(component.role.permissions).toEqual(mockPermissions);
    expect(component.appSelectedFeatures[222]).toEqual([
      mockFeature,
      mockPermissions[0].feature,
      mockPermissions[1].feature,
      mockPermissions[2].feature
    ]);

    // Making sure we add the permission after create button is pressed
    spyOn(store, 'dispatch').and.callFake(action => {
      expect(action.payload.permissions).toEqual(
        [
          {
            feature: mockFeature,
            metadata: undefined
          }
        ].concat(mockPermissions)
      );
      return action;
    });
    component.create();
  });

  it('should call removeUser', () => {
    component.activeUsers = <UserProfile[]>[{ objectId: '111' }, { objectId: '222' }];
    component.removeUser(component.activeUsers[1]);
    expect(component.activeUsers).toEqual(<UserProfile[]>[{ objectId: '111' }]);
  });

  it('should call getPermissionMetadata', () => {
    expect(component.getPermissionMetadataString(mockPermissions[0].feature)).toBe('Hello World 1');
  });

  it('should call isSelected', () => {
    expect(component.isSelected(222, 123)).toBe(true);
  });

  it('should call onUpdateMetaData with metadataConfig is of string type', () => {
    component.onUpdateMetaData(mockPermissions[0].feature, 'Hello World 2222');
    // Making sure we update the metadata with new typed value after create button is pressed
    spyOn(store, 'dispatch').and.callFake(action => {
      expect(action.payload.permissions[0].metadata).toEqual([
        {
          name: 'Hello World 2222',
          description: ''
        }
      ]);
      return action;
    });
    component.create();
  });

  it('should call onUpdateMetaData for metadataConfig not defined', () => {
    component.onUpdateMetaData(mockPermissions[1].feature, 'Hello World 333');
    // Making sure we not update the metadata with new typed value(just in case) but metadataConfig is not defined
    // after create button is pressed
    spyOn(store, 'dispatch').and.callFake(action => {
      expect(action.payload.permissions[1].metadata).toBeFalsy();
      return action;
    });
    component.create();
  });

  describe('New User', () => {
    it('should add new user to user list, and subscribe to the filteredUsersObs', () => {
      spyOn(graphApi, 'searchUsers').and.callThrough();
      component.addNewUser();
      jest.advanceTimersByTime(500);
      expect(graphApi.searchUsers).toHaveBeenCalledWith('');
      expect(component['userSearchSub']).toBeDefined();
    });

    it('should trigger search if input field got updated calling onNewUserSearch', () => {
      spyOn(graphApi, 'searchUsers').and.callThrough();
      component.addNewUser();
      jest.advanceTimersByTime(500);
      component.onNewUserSearch('Test', { new: true, value: 'Test' });
      jest.advanceTimersByTime(500);
      expect(graphApi.searchUsers).toHaveBeenCalledWith('Test');
    });

    it('should set User value to UserProfile username if onNewUserSearch gets a UserProfile', () => {
      const newUser = {
        new: true,
        value: 'Test'
      };
      component.onNewUserSearch({ displayName: 'Display Name' } as UserProfile, newUser);
      expect(newUser.value).toEqual('Display Name');
    });

    it('should set User attr to UserProfile calling updateNewUser', () => {
      const newUser: { new: boolean; value: string; user?: UserProfile } = {
        new: true,
        value: 'Test'
      };
      component.updateNewUser(
        { option: { value: { displayName: 'Display Name' } } } as MatAutocompleteSelectedEvent,
        newUser
      );
      expect(newUser.user).toEqual(<UserProfile>{ displayName: 'Display Name' });
    });
  });
});
