import { Component, OnInit, OnDestroy } from '@angular/core';
import {
  Role,
  roleActions,
  Feature,
  Application,
  Permission
} from '@content-platform/application-api';
import { datasetActions } from '@content-platform/dynamic-forms-api';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { Subscription, Subject } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { AdministrationState } from '../../reducers/index';
import {
  startWith,
  switchMap,
  filter,
  debounceTime,
  map,
  distinctUntilChanged,
  takeUntil,
  tap
} from 'rxjs/operators';
import { GraphApi, UserProfile } from '@content-platform/graph-api';
import { MatAutocompleteSelectedEvent } from '@angular/material';
import { ContentHeaderButton, ContentHeaderBarService } from '@content-platform/navigation';
import { LoggerService } from '@content-platform/logging';
import { FieldSchema, fromDataset } from '@content-platform/dynamic-forms-api';
import { DisplayNamePipe } from '@content-platform/pipes';

interface NewUser {
  new: boolean;
  user?: UserProfile;
  value: string;
}

@Component({
  selector: 'app-role-edit',
  templateUrl: './role-edit.component.html',
  styleUrls: ['./role-edit.component.scss']
})
export class RoleEditComponent implements OnInit, OnDestroy {
  role: Role;
  isNew = false;
  panelOpenState: { [appId: number]: boolean } = {};
  userSearchStateCtrl: FormControl;
  applications: Application[];
  appSelectedFeatures: { [appId: number]: Feature[] } = {};
  featureMetadata: { [featureId: number]: any[] } = {};
  activeUsers: UserProfile[];
  newUsers: NewUser[] = [];
  dpNamePipe: DisplayNamePipe;
  filteredUsers: UserProfile[];
  contentHeaderButtons: ContentHeaderButton[] = [];
  private logger: LoggerService;
  private userSearchSub: Subscription;
  private userSearchSubject: Subject<string> = new Subject<string>();
  private onDestroy = new Subject<void>();

  metadataDatasetSchemas: { [featureId: number]: FieldSchema } = {};
  metadataDatasetFormGroups: { [featureId: number]: FormGroup } = {};

  /**
   *
   * Hack to work with mat-expandable-panel in hidden mat-tab issue
   * {@link https://www.bountysource.com/issues/46433954-tabs-hidden-tabs-don-t-render-expansion-panels-correctly}
   *
   */
  selectedTabIndex = 0;
  tabChange(event) {
    this.logger.info(`Switched to ${event.tab.textLabel} tab`);
    Promise.resolve().then(() => {
      this.selectedTabIndex = event.index;
      // On tab switch make sure we close all opened panels
      this.applications.forEach(app => (this.panelOpenState[app.id] = false));
    });
  }

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private store: Store<AdministrationState>,
    private graphApi: GraphApi,
    private fb: FormBuilder,
    private contentHeaderBarService: ContentHeaderBarService,
    loggerService: LoggerService
  ) {
    this.userSearchStateCtrl = new FormControl();
    this.dpNamePipe = new DisplayNamePipe();
    this.logger = loggerService.instance('RoleEditComponent');
  }

  ngOnInit() {
    this.route.data.pipe(takeUntil(this.onDestroy)).subscribe(data => {
      if (data.role) {
        this.role = { ...data.role };
        this.applications = data.applications;
        this.isNew = !data.role.id;
        const { users, permissions } = this.role;
        this.activeUsers = [
          ...((users as UserProfile[]) || []).map(user => {
            user['displayName'] = this.dpNamePipe.transform(<UserProfile>user);
            return user;
          })
        ] as UserProfile[];

        this.role.applicationAdminPrivileges = this.role.applicationAdminPrivileges || [];
        this.role.permissions = this.role.permissions || [];
        this.applications.forEach(app => {
          this.appSelectedFeatures[app.id] = app.features.filter(feature =>
            (permissions || [])
              .map(rolePermission => rolePermission.feature.id)
              .includes(feature.id)
          );

          // Update the Permissions based on the if the Role has admin priviledge for the app
          this.updateAllPermissionList(app.id, this.isRoleAppAdmin(app.id));

          this.setupDatasetMetadataFields(app);
        });

        (permissions || []).forEach(rolePermission => {
          this.featureMetadata[rolePermission.feature.id] = rolePermission.metadata || null;
        });

        this.contentHeaderButtons = [
          {
            name: 'CANCEL',
            onClick: () => {
              this.router.navigate(['..'], { relativeTo: this.route });
            }
          },
          {
            name: this.isNew ? 'CREATE' : 'SAVE',
            color: 'accent',
            type: 'flat',
            onClick: () => {
              this.isNew ? this.create() : this.save();
            }
          }
        ];
        this.contentHeaderBarService.setButtons(this.contentHeaderButtons);
      }
    });
  }

  private setupDatasetMetadataFields(app: Application) {
    app.features.filter(this.hasDatasetMetadata).forEach(feature => {
      const existingPerm = this.findMatchingExistingPermission(feature);
      const existingMetaData = existingPerm ? existingPerm.metadata : [];
      const datasetLookup = fromDataset.getDatasetLookupFromId(feature.metadataConfig.dataset);
      this.store.dispatch(new datasetActions.LoadForKeys(datasetLookup));
      this.metadataDatasetSchemas[feature.id] = {
        name: 'metadata',
        type: 'dropdown',
        multiSelect: feature.metadataConfig.allowMultiple,
        options: [
          { fieldKey: datasetLookup.fieldKey, contentType: datasetLookup.contentType },
          { valueProperty: 'object' }
        ]
      };
      this.metadataDatasetFormGroups[feature.id] = this.fb.group({
        metadata: feature.metadataConfig.allowMultiple ? [existingMetaData] : existingMetaData
      });
      this.metadataDatasetFormGroups[feature.id].valueChanges
        .pipe(takeUntil(this.onDestroy))
        .subscribe(metadataValue => {
          this.featureMetadata[feature.id] =
            metadataValue.metadata instanceof Array
              ? metadataValue.metadata
              : [metadataValue.metadata];
        });
    });
  }

  private subscribeToSearch() {
    if (!this.userSearchSub) {
      this.userSearchSub = this.userSearchSubject
        .asObservable()
        .pipe(
          startWith(''),
          distinctUntilChanged(),
          filter(state => typeof state === 'string'),
          debounceTime(500),
          tap(state => {
            this.logger.info(`Searching Users with ${state}`);
          }),
          switchMap(state => this.graphApi.searchUsers(state as string)),
          map(users => users.filter(user => !this.inActiveUserList(user)))
        )
        .subscribe(filteredUsers => {
          this.filteredUsers = filteredUsers;
        });
    }
  }

  private inActiveUserList(user: UserProfile): boolean {
    const activeIds = this.activeUsers.map(activeRole => activeRole.objectId);
    return activeIds.includes(user.objectId);
  }

  private blurActiveInputField(): void {
    const activeElement = document.activeElement as HTMLElement;
    if (activeElement && activeElement.localName === 'input') {
      activeElement.blur();
    }
  }

  private createPermission(feature: Feature): Permission {
    return <Permission>{ feature };
  }

  onNewUserSearch($event: string | UserProfile, user: NewUser): void {
    if ($event && (<UserProfile>$event).displayName) {
      user.value = (<UserProfile>$event).displayName;
      this.userSearchSubject.next('');
    } else {
      user.value = <string>$event;
      this.userSearchSubject.next(user.value);
    }
  }

  addNewUser() {
    this.logger.info('Adding New User Row');
    this.newUsers.splice(0, 0, {
      new: true,
      value: null
    });
    this.subscribeToSearch();
  }

  updateNewUser(data: MatAutocompleteSelectedEvent, newUserData: NewUser) {
    const user: UserProfile = data.option.value;
    if (!this.inActiveUserList(user)) {
      newUserData.user = user;
    } else {
      this.userSearchStateCtrl.reset();
    }
    this.blurActiveInputField();
  }

  removeUser(user: UserProfile) {
    this.activeUsers = this.activeUsers.filter(activeUser => activeUser !== user);
  }

  removeNewUser(user: NewUser) {
    this.newUsers = this.newUsers.filter(activeUser => activeUser !== user);
    this.logger.info('Removing New User Row');
  }

  private findMatchingExistingPermission(feature: Feature): Permission {
    return this.role.permissions.find(permission => permission.feature.id === feature.id);
  }

  save() {
    const permissions = this.getUpdatedPermissions();
    const deletedPermissions = this.role.permissions
      .filter(permission => !permissions.find(savedPerm => savedPerm.id === permission.id))
      .map(permission => permission.id);

    this.store.dispatch(
      new roleActions.Update({
        ...this.role,
        users: [...this.activeUsers, ...this.getNewUsers()],
        permissions,
        deletedPermissions
      })
    );
  }

  create() {
    this.store.dispatch(
      new roleActions.Create({
        ...this.role,
        users: [...this.activeUsers, ...this.getNewUsers()],
        permissions: this.getUpdatedPermissions()
      })
    );
  }

  private getNewUsers(): UserProfile[] {
    const newUsers = [];
    for (const newUser of this.newUsers) {
      if (newUser.user && !this.inActiveUserList(newUser.user)) {
        newUsers.push(newUser.user);
      }
    }
    return newUsers;
  }

  private getUpdatedPermissions(): Permission[] {
    return [].concat.apply(
      [],
      Object.keys(this.appSelectedFeatures).map(key => {
        return this.appSelectedFeatures[key].map((feature: Feature) => {
          const permission =
            this.findMatchingExistingPermission(feature) || this.createPermission(feature);
          return this.updateMetadataInPermission(permission);
        });
      })
    );
  }

  updateMetadataInPermission(permission: Permission): Permission {
    return { ...permission, metadata: this.featureMetadata[permission.feature.id] || undefined };
  }

  updatePermissionList(updatedAppId: number, features: Feature[]): void {
    this.appSelectedFeatures[updatedAppId] = features;
  }

  updateAllPermissionList(appId: number, isChecked: boolean): void {
    const foundApp = this.applications.find(app => app.id === appId);
    if (foundApp) {
      if (isChecked) {
        this.updatePermissionList(appId, foundApp.features);

        // only add if the appId is not existing
        if (!this.isRoleAppAdmin(appId)) {
          this.role = {
            ...this.role,
            applicationAdminPrivileges: [...this.role.applicationAdminPrivileges, { id: appId }]
          };
        }
      } else {
        this.role = {
          ...this.role,
          applicationAdminPrivileges: this.role.applicationAdminPrivileges.filter(
            appPriviledge => appPriviledge.id !== appId
          )
        };
      }
    }
  }

  isRoleAppAdmin(appId: number): boolean {
    const foundApp = this.role.applicationAdminPrivileges.find(
      appPriviledge => appPriviledge.id === appId
    );
    if (foundApp) {
      return true;
    }
    return false;
  }

  hasStringMetadata(feature: Feature): boolean {
    return (
      feature &&
      feature.metadataConfig &&
      feature.metadataConfig.type &&
      feature.metadataConfig.type.toLowerCase() === 'string'
    );
  }

  hasDatasetMetadata(feature: Feature): boolean {
    return (
      feature &&
      feature.metadataConfig &&
      feature.metadataConfig.type &&
      feature.metadataConfig.type.toLowerCase() === 'dataset'
    );
  }

  onUpdateMetaData(feature: Feature, formValue: string) {
    if (this.hasStringMetadata(feature)) {
      this.featureMetadata[feature.id] = [{ name: formValue, description: '' }];
    }
  }

  getPermissionMetadataString(feature: Feature): string {
    const existingPermission = this.findMatchingExistingPermission(feature);
    return existingPermission && existingPermission.metadata && existingPermission.metadata[0]
      ? existingPermission.metadata[0].name
      : null;
  }

  eventHandler($event): void {
    // Making sure we do not lose focus from the text input handler
    $event.stopPropagation();
  }

  isSelected(appId: number, featureId: number): boolean {
    return this.appSelectedFeatures[appId].map(feature => feature.id).includes(featureId);
  }

  ngOnDestroy() {
    this.onDestroy.next();
    if (this.userSearchSub) {
      this.userSearchSub.unsubscribe();
    }
  }
}
