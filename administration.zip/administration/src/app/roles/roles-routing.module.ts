import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RoleDetailComponent } from './role-detail/role-detail.component';
import { RoleEditComponent } from './role-edit/role-edit.component';
import { RolesGuard, ErrorGuard, ApplicationsGuard } from '../guards';
import {
  roleSelectors,
  UserPermissionListGuard,
  FeatureGuard,
  roleActions
} from '@content-platform/application-api';
import { ApplicationsResolver, RoleResolver } from '../resolvers';
import {
  ContentContainerComponent,
  ContentNavigationListComponent
} from '@content-platform/reusable-ui/components';

export function deleteRole(item, store) {
  store.dispatch(new roleActions.Delete(item.id));
}

const EDIT_FEATURE_KEY = 'edit_roles';
const DELETE_FEATURE_KEY = 'delete_roles';

const routes: Routes = [
  {
    path: '',
    component: ContentContainerComponent,
    data: {
      title: 'Role(s)'
    },
    canActivate: [UserPermissionListGuard, ApplicationsGuard, RolesGuard, ErrorGuard],
    children: [
      {
        path: ':roleId',
        component: RoleDetailComponent,
        resolve: {
          role: RoleResolver,
          applications: ApplicationsResolver
        }
      },
      {
        path: '',
        component: ContentNavigationListComponent,
        outlet: 'navigation-list',
        data: {
          itemsSelector: roleSelectors.getAllRoleItems,
          showCreateNew: false,
          showCreateNewFeatureKey: EDIT_FEATURE_KEY,
          showDeleteFeatureKey: DELETE_FEATURE_KEY,
          deleteFunction: deleteRole,
          title: 'Roles'
        }
      },
      {
        path: ':roleId/edit',
        component: RoleEditComponent,
        resolve: {
          role: RoleResolver,
          applications: ApplicationsResolver
        },
        data: { featureGuard: { key: EDIT_FEATURE_KEY } },
        canActivate: [FeatureGuard]
      },
      {
        path: ':roleId/new',
        component: RoleEditComponent,
        data: { role: { name: 'New Role' }, featureGuard: { key: EDIT_FEATURE_KEY } },
        resolve: {
          applications: ApplicationsResolver
        },
        canActivate: [FeatureGuard]
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RolesRoutingModule {}
