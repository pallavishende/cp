import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgPipesModule } from 'ngx-pipes';

import {
  MatListModule,
  MatIconModule,
  MatCardModule,
  MatSlideToggleModule,
  MatInputModule,
  MatButtonModule,
  MatExpansionModule,
  MatAutocompleteModule,
  MatSelectModule,
  MatTabsModule,
  MatCheckboxModule,
  MatMenuModule,
  MatTooltipModule
} from '@angular/material';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GraphApiModule } from '@content-platform/graph-api';
import { PermissionsModule } from '@content-platform/application-api';
import { RoleEditComponent } from './role-edit/role-edit.component';
import { RoleDetailComponent } from './role-detail/role-detail.component';
import { RolesRoutingModule } from './roles-routing.module';
import { RolesGuard, ErrorGuard, ApplicationsGuard } from '../guards';
import { ApplicationsResolver, RoleResolver } from '../resolvers';
import { DevelopmentModule } from '@content-platform/development';
import { DynamicFormBuilderModule } from '@content-platform/reusable-ui/dynamic-form-builder';
import { PipesModule } from '@content-platform/pipes';
import { ReusableUiContentNavigationModule } from '@content-platform/reusable-ui/components';

@NgModule({
  imports: [
    CommonModule,
    RolesRoutingModule,
    MatListModule,
    MatIconModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatExpansionModule,
    MatAutocompleteModule,
    MatSlideToggleModule,
    MatSelectModule,
    MatTabsModule,
    MatMenuModule,
    ReusableUiContentNavigationModule,
    FormsModule,
    ReactiveFormsModule,
    GraphApiModule,
    MatCheckboxModule,
    PermissionsModule,
    NgPipesModule,
    DevelopmentModule,
    DynamicFormBuilderModule,
    MatTooltipModule,
    PipesModule
  ],
  providers: [ApplicationsGuard, RolesGuard, ErrorGuard, RoleResolver, ApplicationsResolver],
  declarations: [RoleEditComponent, RoleDetailComponent],
  exports: []
})
export class RolesModule {}
