import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatasetManagerDetailComponent } from './dataset-manager-detail.component';
import {
  MaterialMockModule,
  MockDirective,
  MaterialServiceMocks
} from '@content-platform/unit-test-helpers';
import { ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material';
import { of, Subject } from 'rxjs';
import { RouterTestingModule } from '@angular/router/testing';
import { StoreModule } from '@ngrx/store';
import { fromLayoutSchema } from '@content-platform/dynamic-forms-api';
import { ContentHeaderBarService } from '@content-platform/navigation';
import { UserPermissionsService } from '@content-platform/application-api';

describe('DatasetManagerDetailComponent', () => {
  let component: DatasetManagerDetailComponent;
  let fixture: ComponentFixture<DatasetManagerDetailComponent>;
  let routeStub;
  let headerService: ContentHeaderBarService;
  let hasFeature = true;

  beforeEach(async(() => {
    routeStub = {
      data: of({
        dataset: {
          contentType: 'some-type',
          fieldKey: 'SomeField',
          id: 1234,
          value: []
        }
      })
    };

    TestBed.configureTestingModule({
      imports: [
        MaterialMockModule,
        RouterTestingModule,
        FormsModule,
        ReactiveFormsModule,
        StoreModule.forRoot({ application: fromLayoutSchema.reducer })
      ],
      declarations: [
        DatasetManagerDetailComponent,
        MockDirective({ selector: '[appIfFeatureAsync]', inputs: ['appIfFeatureAsync'] })
      ],
      providers: [
        { provide: ActivatedRoute, useValue: routeStub },
        { provide: MatDialog, useValue: new MaterialServiceMocks.MatDialog<boolean>(true) },
        {
          provide: ContentHeaderBarService,
          useValue: { setButtons: () => {}, onClick: new Subject() }
        },
        { provide: UserPermissionsService, useValue: { hasFeature: () => hasFeature } }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatasetManagerDetailComponent);
    component = fixture.componentInstance;
    headerService = TestBed.get(ContentHeaderBarService);
    spyOn(headerService, 'setButtons').and.callThrough();
  });

  it('should create', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('should call set buttons if has feature', () => {
    fixture.detectChanges();
    expect(headerService.setButtons).toHaveBeenCalled();
  });

  it('should not call set buttons if it does not have feature', () => {
    hasFeature = false;
    fixture.detectChanges();
    expect(headerService.setButtons).not.toHaveBeenCalled();
  });
});
