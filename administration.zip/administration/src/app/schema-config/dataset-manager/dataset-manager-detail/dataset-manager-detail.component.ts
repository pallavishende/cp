import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { Dataset, datasetActions } from '@content-platform/dynamic-forms-api';
import { Store } from '@ngrx/store';
import { Subscription, of } from 'rxjs';
import { filter, take } from 'rxjs/operators';
import { AdministrationState } from '../../../reducers';
import { ContentHeaderBarService, ContentHeaderButton } from '@content-platform/navigation';
import { UserPermissionsService } from '@content-platform/application-api';
import { ConfirmationDialogComponent } from '@content-platform/reusable-ui/components';

@Component({
  selector: 'app-dataset-manager-detail',
  templateUrl: './dataset-manager-detail.component.html',
  styleUrls: ['./dataset-manager-detail.component.scss']
})
export class DatasetManagerDetailComponent implements OnInit, OnDestroy {
  dataset: Dataset;
  contentHeaderButtons: ContentHeaderButton[] = [];
  private routeSub: Subscription;
  contentTypeName = new FormControl();
  fieldKeyName = new FormControl();

  constructor(
    private route: ActivatedRoute,
    private dialog: MatDialog,
    private store: Store<AdministrationState>,
    private router: Router,
    private contentHeaderBarService: ContentHeaderBarService,
    private userPermissionsService: UserPermissionsService
  ) {}

  ngOnInit() {
    this.contentHeaderButtons = [
      {
        name: 'DELETE',
        disabled$: of(true), // Delete functionality is not available on back end yet
        onClick: () => {
          this.delete();
        }
      },
      {
        name: 'EDIT',
        type: 'raised',
        onClick: () => {
          this.router.navigate(['./edit'], { relativeTo: this.route });
        }
      }
    ];

    this.routeSub = this.route.data.subscribe(data => {
      this.dataset = data.dataset;
      this.contentTypeName.setValue(this.dataset.contentType);
      this.fieldKeyName.setValue(this.dataset.fieldKey);
      if (this.userPermissionsService.hasFeature('edit_dataset')) {
        this.contentHeaderBarService.setButtons(this.contentHeaderButtons);
      }
    });
  }

  delete() {
    this.dialog
      .open(ConfirmationDialogComponent, {
        data: {
          message: `Are you sure you want to delete the dataset for content type: ${
            this.dataset.contentType
          } field: ${this.dataset.fieldKey}?`
        }
      })
      .afterClosed()
      .pipe(
        take(1),
        filter(result => result)
      )
      .subscribe(() => {
        this.store.dispatch(new datasetActions.Delete(this.dataset.id));
      });
  }

  ngOnDestroy() {
    this.routeSub.unsubscribe();
  }
}
