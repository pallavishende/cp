import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { fromLayoutSchema } from '@content-platform/dynamic-forms-api';
import { MaterialMockModule, MockComponent } from '@content-platform/unit-test-helpers';
import { ContentHeaderBarService } from '@content-platform/navigation';
import { StoreModule } from '@ngrx/store';
import { of } from 'rxjs';
import { DatasetManagerEditComponent } from './dataset-manager-edit.component';

describe('DatasetManagerEditComponent', () => {
  let component: DatasetManagerEditComponent;
  let fixture: ComponentFixture<DatasetManagerEditComponent>;
  let routeStub;

  beforeEach(async(() => {
    routeStub = {
      data: of({
        dataset: {
          contentType: 'some-type',
          fieldKey: 'SomeField',
          id: 1234,
          value: []
        }
      })
    };

    TestBed.configureTestingModule({
      imports: [
        MaterialMockModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        StoreModule.forRoot({ application: fromLayoutSchema.reducer })
      ],
      declarations: [
        DatasetManagerEditComponent,
        MockComponent({
          selector: 'app-action-menu',
          inputs: ['actions']
        })
      ],
      providers: [
        { provide: ActivatedRoute, useValue: routeStub },
        {
          provide: ContentHeaderBarService,
          useValue: {
            setButtons: () => {}
          }
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatasetManagerEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
