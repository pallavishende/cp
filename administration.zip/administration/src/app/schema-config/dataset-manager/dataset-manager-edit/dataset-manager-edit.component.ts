import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormArray, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import {
  Dataset,
  datasetActions,
  DatasetOptions,
  ActionMenuItem
} from '@content-platform/dynamic-forms-api';
import { ContentHeaderButton, ContentHeaderBarService } from '@content-platform/navigation';
import { Store } from '@ngrx/store';
import { BehaviorSubject, Subject, merge } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AdministrationState } from '../../../reducers';
import { isEqual } from 'lodash';
import { Sort, MatSort, SortDirection } from '@angular/material/sort';

@Component({
  selector: 'app-dataset-manager-edit',
  templateUrl: './dataset-manager-edit.component.html',
  styleUrls: ['./dataset-manager-edit.component.scss']
})
export class DatasetManagerEditComponent implements OnInit, OnDestroy {
  dataset: Dataset;
  updatedDatasetOptions: DatasetOptions[];
  isNew = false;
  form: FormGroup;

  private onDestroy = new Subject<void>();
  private saveDisabled = new BehaviorSubject<boolean>(true);
  contentHeaderButtons: ContentHeaderButton[] = [];

  private contentTypeName: FormControl;
  private fieldKeyName: FormControl;

  displayedActions: ActionMenuItem[];

  @ViewChild(MatSort)
  sort: MatSort;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private store: Store<AdministrationState>,
    private contentHeaderBarService: ContentHeaderBarService
  ) {
    this.form = this.fb.group({
      contentType: '',
      fieldKey: '',
      value: []
    });
    this.contentTypeName = this.form.get('contentType') as FormControl;
    this.fieldKeyName = this.form.get('fieldKey') as FormControl;
  }

  ngOnInit() {
    this.displayedActions = [
      { title: 'Move Up', icon: 'arrow_upward', key: 'up', disabled: false },
      { title: 'Move Down', icon: 'arrow_downward', key: 'down', disabled: false },
      { title: 'Add Next', icon: 'add_circle', key: 'next', disabled: false }
    ];
    this.route.data.pipe(takeUntil(this.onDestroy)).subscribe(data => {
      this.setDatasetObservable(data.dataset);
    });
    this.contentHeaderButtons = [
      {
        name: 'CANCEL',
        onClick: () => {
          this.router.navigate([this.isNew ? '../..' : '..'], { relativeTo: this.route });
        }
      },
      {
        name: this.isNew ? 'CREATE' : 'SAVE',
        color: 'accent',
        type: 'flat',
        disabled$: this.saveDisabled.asObservable(),
        onClick: () => (this.isNew ? this.create() : this.save())
      }
    ];
    this.contentHeaderBarService.setButtons(this.contentHeaderButtons);
  }
  save() {
    this.store.dispatch(
      new datasetActions.Update({
        ...this.dataset,
        contentType: this.contentTypeName.value,
        fieldKey: this.fieldKeyName.value,
        value: this.datasetUpdatedValue
      })
    );
  }

  create() {
    this.store.dispatch(
      new datasetActions.Create({
        ...this.dataset,
        contentType: this.contentTypeName.value,
        fieldKey: this.fieldKeyName.value,
        value: this.datasetUpdatedValue
      })
    );
  }

  get datasetUpdatedValue(): DatasetOptions[] {
    return this.groupsFormArray.value;
  }

  get groupsFormArray(): FormArray {
    return this.form.get('value') as FormArray;
  }

  getDatasetValuesFormArray(groupNumber: number): FormArray {
    return this.groupsFormArray.get([groupNumber]).get('values') as FormArray;
  }

  private setGroupsForm() {
    const groupFormGroups = (this.dataset.value || []).map(dataGroup => {
      const dsValues = (dataGroup.values || []).map(dsValue =>
        this.fb.group({
          name: dsValue.name,
          description: dsValue.description
        })
      );

      return this.fb.group({
        group: dataGroup.group,
        values: this.fb.array(dsValues)
      });
    });
    const groupsFormArray = this.fb.array(groupFormGroups);
    this.form.setControl('value', groupsFormArray);

    this.groupsFormArray.valueChanges
      .pipe(takeUntil(this.onDestroy))
      .subscribe(() => this.checkIfSaveShouldBeDisabled());
  }

  addDatasetValue(groupNumber: number, index: number = -1) {
    const fg = this.fb.group({
      name: '',
      description: ''
    });
    if (index !== -1) {
      this.getDatasetValuesFormArray(groupNumber).insert(index, fg);
    } else {
      this.getDatasetValuesFormArray(groupNumber).push(fg);
    }
  }

  removeDatasetValue(groupNumber: number, index: number) {
    this.getDatasetValuesFormArray(groupNumber).removeAt(index);
  }

  addGroup() {
    this.groupsFormArray.push(
      this.fb.group({
        group: '',
        values: this.fb.array([])
      })
    );
  }

  removeGroup(groupNumber: number) {
    this.groupsFormArray.removeAt(groupNumber);
  }

  moveGroupUp(groupNumber: number) {
    return this.moveGroup(groupNumber, 'up');
  }

  moveGroupDown(groupNumber: number) {
    return this.moveGroup(groupNumber, 'down');
  }

  private moveGroup(groupNumber: number, direction: 'up' | 'down') {
    const group = this.groupsFormArray.get([groupNumber]);
    this.groupsFormArray.removeAt(groupNumber);
    if (direction === 'up') {
      this.groupsFormArray.insert(groupNumber - 1, group);
    } else {
      // down
      this.groupsFormArray.insert(groupNumber + 1, group);
    }
  }

  private setDatasetObservable(dataset: Dataset) {
    if (dataset.contentType && dataset.fieldKey) {
      this.dataset = { ...dataset };
    } else {
      this.isNew = true;
      this.dataset = { ...dataset } as Dataset;
      this.updatedDatasetOptions = [] as DatasetOptions[];
    }

    this.contentTypeName.setValue(dataset.contentType);
    this.fieldKeyName.setValue(dataset.fieldKey);

    merge(this.contentTypeName.valueChanges, this.fieldKeyName.valueChanges)
      .pipe(takeUntil(this.onDestroy))
      .subscribe(() => this.checkIfSaveShouldBeDisabled());

    this.setGroupsForm();
  }

  checkIfSaveShouldBeDisabled(): void {
    if (!this.contentTypeName.value || !this.fieldKeyName.value) {
      this.saveDisabled.next(true);
    } else {
      const emptyValues =
        this.datasetUpdatedValue.length === 0 ||
        this.datasetUpdatedValue.reduce(
          (empty, currentGroup) =>
            empty ||
            currentGroup.values.reduce(
              (valueEmpty, value) => valueEmpty || !value.name || !value.description,
              false
            ),
          false
        );

      this.saveDisabled.next(
        emptyValues ||
          (isEqual(this.datasetUpdatedValue, this.dataset.value) &&
            this.contentTypeName.value === this.dataset.contentType &&
            this.fieldKeyName.value === this.dataset.fieldKey)
      );
    }
  }

  selectedMenu(action: ActionMenuItem, groupNumber: number, currentIndex: number) {
    switch (action.key) {
      case 'up':
      case 'down':
        this.moveDatasetValuePosition(groupNumber, currentIndex, action.key);
        break;
      case 'next':
        this.addDatasetValue(groupNumber, currentIndex + 1);
        break;
    }
  }

  private moveDatasetValuePosition(
    groupNumber: number,
    currentIndex: number,
    direction: 'up' | 'down'
  ): void {
    const currentValue = this.getDatasetValuesFormArray(groupNumber).get([currentIndex]);
    this.getDatasetValuesFormArray(groupNumber).removeAt(currentIndex);
    if (direction === 'up') {
      this.getDatasetValuesFormArray(groupNumber).insert(currentIndex - 1, currentValue);
    } else {
      this.getDatasetValuesFormArray(groupNumber).insert(currentIndex + 1, currentValue);
    }
  }

  getDisplayedActions(currentIndex: number, groupNumber: number): ActionMenuItem[] {
    return this.displayedActions.map(action => {
      action.disabled = false;
      if (action.key === 'up' && this.isTopItem(currentIndex)) {
        action.disabled = true;
      } else if (action.key === 'down' && this.isBottomItem(currentIndex, groupNumber)) {
        action.disabled = true;
      }

      return action;
    });
  }

  private isTopItem(index: number): boolean {
    return index === 0;
  }

  private isBottomItem(index: number, groupNumber: number): boolean {
    return this.getDatasetValuesFormArray(groupNumber).length - 1 === index;
  }

  sortData(sort: Sort, groupNumber: number) {
    const data = this.getDatasetValuesFormArray(groupNumber).value.slice();
    if (!sort.active) {
      this.getDatasetValuesFormArray(groupNumber).setValue(data);
      return;
    }
    // Just to make the sort arrow UI gets updated correctly as alternate(asc/desc)
    if (sort.direction === '') {
      this.sort.direction = 'asc' as SortDirection;
      this.sort.sortChange.emit({ active: sort.active, direction: 'asc' });
    }
    this.getDatasetValuesFormArray(groupNumber).setValue(
      data.sort((a, b) => {
        const isAsc = sort.direction === 'asc' || sort.direction === '';
        switch (sort.active) {
          case 'name':
            return this.compare(a.name, b.name, isAsc);
          case 'description':
            return this.compare(a.description, b.description, isAsc);
          default:
            return 0;
        }
      })
    );
  }

  private compare(a: number | string, b: number | string, isAsc: boolean) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }

  ngOnDestroy() {
    this.onDestroy.next();
  }
}
