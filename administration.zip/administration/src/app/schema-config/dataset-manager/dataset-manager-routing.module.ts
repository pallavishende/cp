import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ErrorGuard, DatasetGuard } from '../../guards';

import { UserPermissionListGuard, FeatureGuard } from '@content-platform/application-api';
import { DatasetManagerDetailComponent } from './dataset-manager-detail/dataset-manager-detail.component';
import { DatasetManagerEditComponent } from './dataset-manager-edit/dataset-manager-edit.component';
import { DatasetManagerResolver } from '../../resolvers';
import {
  ContentContainerComponent,
  EditorListComponent
} from '@content-platform/reusable-ui/components';

const EDIT_FEATURE_KEY = 'edit_dataset';
export const DATASET_MANAGER_KEY = 'dataset_manager';

const routes: Routes = [
  {
    path: '',
    component: ContentContainerComponent,
    data: {
      title: 'Dataset'
    },
    canActivate: [UserPermissionListGuard, ErrorGuard],
    children: [
      {
        path: ':datasetId',
        component: DatasetManagerDetailComponent,
        canActivate: [DatasetGuard],
        resolve: {
          dataset: DatasetManagerResolver
        }
      },
      {
        path: '',
        component: EditorListComponent,
        outlet: 'navigation-list',
        data: {
          title: 'Dataset',
          showCreateNewFeatureKey: DATASET_MANAGER_KEY
        }
      },
      {
        path: ':datasetId/edit',
        component: DatasetManagerEditComponent,
        data: { featureGuard: { key: EDIT_FEATURE_KEY } },
        canActivate: [FeatureGuard, DatasetGuard],
        resolve: {
          dataset: DatasetManagerResolver
        }
      },
      {
        path: ':datasetId/new',
        component: DatasetManagerEditComponent,
        data: { featureGuard: { key: EDIT_FEATURE_KEY }, dataset: { value: [] } },
        canActivate: [FeatureGuard]
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DatasetManagerRoutingModule {}
