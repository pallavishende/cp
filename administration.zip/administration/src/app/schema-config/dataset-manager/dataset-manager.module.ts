import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatCardModule,
  MatFormFieldModule,
  MatIconModule,
  MatInputModule,
  MatMenuModule,
  MatListModule,
  MatSortModule
} from '@angular/material';
import { PermissionsModule } from '@content-platform/application-api';
import { AwsModule } from '@content-platform/aws';
import { DatasetGuard, ErrorGuard } from '../../guards';
import { DatasetManagerResolver } from '../../resolvers';
import { DatasetManagerRoutingModule } from './dataset-manager-routing.module';
import { DatasetManagerDetailComponent } from './dataset-manager-detail/dataset-manager-detail.component';
import { DatasetManagerEditComponent } from './dataset-manager-edit/dataset-manager-edit.component';
import { ReusableUiContentNavigationModule, ReusableUiMenusModule } from '@content-platform/reusable-ui/components';
import { DynamicFormsApiModule } from '@content-platform/dynamic-forms-api';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    MatMenuModule,
    MatIconModule,
    MatListModule,
    AwsModule,
    DynamicFormsApiModule,
    DatasetManagerRoutingModule,
    ReusableUiContentNavigationModule,
    PermissionsModule,
    ReusableUiMenusModule,
    MatSortModule
  ],
  providers: [ErrorGuard, DatasetGuard, DatasetManagerResolver],
  declarations: [DatasetManagerDetailComponent, DatasetManagerEditComponent],
  entryComponents: []
})
export class DatasetManagerModule {}
