import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FieldSchemaEditorDetailComponent } from './field-schema-editor-detail.component';
import {
  MaterialMockModule,
  MockComponent,
  MockDirective,
  MaterialServiceMocks
} from '@content-platform/unit-test-helpers';
import { ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material';
import { of } from 'rxjs';
import { RouterTestingModule } from '@angular/router/testing';
import { StoreModule } from '@ngrx/store';
import { fromLayoutSchema } from '@content-platform/dynamic-forms-api';
import { ContentHeaderBarService } from '@content-platform/navigation';
import { UserPermissionsService } from '@content-platform/application-api';

describe('FieldSchemaEditorDetailComponent', () => {
  let component: FieldSchemaEditorDetailComponent;
  let fixture: ComponentFixture<FieldSchemaEditorDetailComponent>;
  let routeStub;
  let headerService: ContentHeaderBarService;
  let hasFeature = true;

  beforeEach(async(() => {
    routeStub = {
      data: of({
        schema: {
          name: 'test',
          contentSchema: {}
        }
      })
    };

    TestBed.configureTestingModule({
      imports: [
        MaterialMockModule,
        RouterTestingModule,
        StoreModule.forRoot({ application: fromLayoutSchema.reducer })
      ],
      declarations: [
        FieldSchemaEditorDetailComponent,
        MockComponent({
          selector: 'app-json-editor',
          inputs: ['json', 'options', 'disabled']
        }),
        MockDirective({ selector: '[appIfFeatureAsync]', inputs: ['appIfFeatureAsync'] })
      ],
      providers: [
        { provide: ActivatedRoute, useValue: routeStub },
        { provide: MatDialog, useValue: new MaterialServiceMocks.MatDialog<boolean>(true) },
        { provide: ContentHeaderBarService, useValue: { setButtons: () => {} } },
        { provide: UserPermissionsService, useValue: { hasFeature: () => hasFeature } }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FieldSchemaEditorDetailComponent);
    component = fixture.componentInstance;
    headerService = TestBed.get(ContentHeaderBarService);
    spyOn(headerService, 'setButtons').and.callThrough();
  });

  it('should create', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('should call set buttons if has feature', () => {
    fixture.detectChanges();
    expect(headerService.setButtons).toHaveBeenCalled();
  });

  it('should not call set buttons if it does not have feature', () => {
    hasFeature = false;
    fixture.detectChanges();
    expect(headerService.setButtons).not.toHaveBeenCalled();
  });
});
