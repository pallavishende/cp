import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ErrorGuard } from '../../guards';
import { FieldSchemaGuard } from '@content-platform/dynamic-forms-api';

import { UserPermissionListGuard, FeatureGuard } from '@content-platform/application-api';
import { FieldSchemaEditorDetailComponent } from './field-schema-editor-detail/field-schema-editor-detail.component';
import { FieldSchemaResolver } from '../../resolvers';
import {
  ContentContainerComponent,
  EditorListComponent
} from '@content-platform/reusable-ui/components';
import { FieldSchemaEditorEditComponent } from './field-schema-editor-edit/field-schema-editor-edit.component';

export const SCHEMA_EDITOR_KEY = 'field_schema_editor';

const routes: Routes = [
  {
    path: '',
    component: ContentContainerComponent,
    data: {
      title: 'Field Schema'
    },
    canActivate: [UserPermissionListGuard, ErrorGuard],
    children: [
      {
        path: ':fieldKey',
        component: FieldSchemaEditorDetailComponent,
        canActivate: [FieldSchemaGuard],
        resolve: {
          schema: FieldSchemaResolver
        }
      },
      {
        path: '',
        component: EditorListComponent,
        outlet: 'navigation-list',
        data: {
          title: 'Field Schema',
          placeholder: 'Field Schema Fieldkey',
          showCreateNewFeatureKey: SCHEMA_EDITOR_KEY
        }
      },
      {
        path: ':fieldKey/edit',
        component: FieldSchemaEditorEditComponent,
        data: { featureGuard: { key: SCHEMA_EDITOR_KEY } },
        canActivate: [FeatureGuard, ErrorGuard],
        resolve: {
          schema: FieldSchemaResolver
        }
      },
      {
        path: ':fieldKey/new',
        component: FieldSchemaEditorEditComponent,
        data: { featureGuard: { key: SCHEMA_EDITOR_KEY }, schema: {} },
        canActivate: [FeatureGuard]
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FieldSchemaEditorRoutingModule {}
