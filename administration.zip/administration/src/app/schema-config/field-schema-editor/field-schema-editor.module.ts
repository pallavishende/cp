import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatCardModule,
  MatFormFieldModule,
  MatIconModule,
  MatInputModule,
  MatMenuModule
} from '@angular/material';
import { PermissionsModule } from '@content-platform/application-api';
import { AwsModule } from '@content-platform/aws';
import { JsonEditorModule } from '@content-platform/reusable-ui/json-editor';
import { ErrorGuard } from '../../guards';
import { FieldSchemaResolver } from '../../resolvers';
import { FieldSchemaEditorRoutingModule } from './field-schema-editor-routing.module';
import { FieldSchemaEditorDetailComponent } from './field-schema-editor-detail/field-schema-editor-detail.component';
import { NavigationModule } from '@content-platform/navigation';
import { ReusableUiContentNavigationModule } from '@content-platform/reusable-ui/components';
import { FieldSchemaEditorEditComponent } from './field-schema-editor-edit/field-schema-editor-edit.component';
import { DynamicFormsApiModule } from '@content-platform/dynamic-forms-api';

@NgModule({
  imports: [
    CommonModule,
    JsonEditorModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    MatMenuModule,
    MatIconModule,
    AwsModule,
    DynamicFormsApiModule,
    FieldSchemaEditorRoutingModule,
    ReusableUiContentNavigationModule,
    PermissionsModule,
    NavigationModule
  ],
  providers: [ErrorGuard, FieldSchemaResolver],
  declarations: [FieldSchemaEditorDetailComponent, FieldSchemaEditorEditComponent],
  entryComponents: []
})
export class FieldSchemaEditorModule {}
