import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: 'schema-editor',
    loadChildren: './schema-editor/schema-editor.module#SchemaEditorModule'
  },
  {
    path: 'field-schema-editor',
    loadChildren: './field-schema-editor/field-schema-editor.module#FieldSchemaEditorModule'
  },
  {
    path: 'dataset-manager',
    loadChildren: './dataset-manager/dataset-manager.module#DatasetManagerModule'
  },
  { path: '*', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  declarations: [],
  exports: [RouterModule]
})
export class SchemaConfigRoutingModule {}
