import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SchemaConfigRoutingModule } from './schema-config-routing.module';
import { ReusableUiDialogsModule } from '@content-platform/reusable-ui/components';

@NgModule({
  imports: [CommonModule, ReusableUiDialogsModule, SchemaConfigRoutingModule],
  declarations: [],
  entryComponents: []
})
export class SchemaConfigModule {}
