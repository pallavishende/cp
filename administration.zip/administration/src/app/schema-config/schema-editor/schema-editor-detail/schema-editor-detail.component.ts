import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { Options } from '@content-platform/reusable-ui/json-editor';
import { LayoutSchemaResponse, layoutSchemaActions } from '@content-platform/dynamic-forms-api';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { filter, take } from 'rxjs/operators';
import { AdministrationState } from '../../../reducers';
import { ContentHeaderBarService, ContentHeaderButton } from '@content-platform/navigation';
import { UserPermissionsService } from '@content-platform/application-api';
import { ConfirmationDialogComponent } from '@content-platform/reusable-ui/components';

@Component({
  selector: 'app-schema-editor-detail',
  templateUrl: './schema-editor-detail.component.html',
  styleUrls: ['./schema-editor-detail.component.scss']
})
export class SchemaEditorDetailComponent implements OnInit, OnDestroy {
  schema: LayoutSchemaResponse;
  contentHeaderButtons: ContentHeaderButton[] = [];
  private routeSub: Subscription;

  jsonEditorOptions: Options = { flex: true, nowrap: false };
  jsonEditorDisabled = true;

  constructor(
    private route: ActivatedRoute,
    private dialog: MatDialog,
    private store: Store<AdministrationState>,
    private router: Router,
    private contentHeaderBarService: ContentHeaderBarService,
    private userPermissionsService: UserPermissionsService
  ) {}

  ngOnInit() {
    this.contentHeaderButtons = [
      {
        name: 'DELETE',
        onClick: () => {
          this.delete();
        }
      },
      {
        name: 'EDIT',
        type: 'raised',
        onClick: () => {
          this.router.navigate(['./edit'], { relativeTo: this.route });
        }
      }
    ];

    this.routeSub = this.route.data.subscribe(data => {
      this.schema = data.schema;
      if (this.userPermissionsService.hasFeature('edit_schema')) {
        this.contentHeaderBarService.setButtons(this.contentHeaderButtons);
      }
    });
  }

  delete() {
    this.dialog
      .open(ConfirmationDialogComponent, {
        data: { message: `Are you sure you want to delete ${this.schema.contentType} schema?` }
      })
      .afterClosed()
      .pipe(
        take(1),
        filter(result => result)
      )
      .subscribe(() => {
        this.store.dispatch(new layoutSchemaActions.Delete(this.schema.id));
      });
  }

  ngOnDestroy() {
    this.routeSub.unsubscribe();
  }
}
