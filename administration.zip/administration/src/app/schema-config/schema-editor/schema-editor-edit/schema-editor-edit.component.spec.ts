import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { fromLayoutSchema } from '@content-platform/dynamic-forms-api';
import { MaterialMockModule, MockComponent } from '@content-platform/unit-test-helpers';
import { StoreModule } from '@ngrx/store';
import { of, Subject } from 'rxjs';
import { SchemaEditorEditComponent } from './schema-editor-edit.component';
import { ContentHeaderBarService } from '@content-platform/navigation';

describe('SchemaEditorEditComponent', () => {
  let component: SchemaEditorEditComponent;
  let fixture: ComponentFixture<SchemaEditorEditComponent>;
  let routeStub;

  beforeEach(async(() => {
    routeStub = {
      data: of({
        schema: {
          name: 'test',
          contentSchema: {}
        }
      })
    };

    TestBed.configureTestingModule({
      imports: [
        MaterialMockModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        StoreModule.forRoot({ application: fromLayoutSchema.reducer })
      ],
      declarations: [
        SchemaEditorEditComponent,
        MockComponent({
          selector: 'app-json-editor',
          inputs: ['json', 'options'],
          outputs: ['onChange']
        })
      ],
      providers: [
        { provide: ActivatedRoute, useValue: routeStub },
        {
          provide: ContentHeaderBarService,
          useValue: {
            onClick: new Subject(),
            setButtons: () => {}
          }
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SchemaEditorEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
