import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormControl } from '@angular/forms';
import { Options, JsonEditorError } from '@content-platform/reusable-ui/json-editor';
import {
  LayoutSchema,
  LayoutSchemaResponse,
  layoutSchemaActions
} from '@content-platform/dynamic-forms-api';
import { ContentHeaderButton, ContentHeaderBarService } from '@content-platform/navigation';
import { Store } from '@ngrx/store';
import { merge, Subject, BehaviorSubject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { isEqual } from 'lodash';
import { AdministrationState } from '../../../reducers';

@Component({
  selector: 'app-schema-editor-edit',
  templateUrl: './schema-editor-edit.component.html',
  styleUrls: ['./schema-editor-edit.component.scss']
})
export class SchemaEditorEditComponent implements OnInit, OnDestroy {
  schema: LayoutSchemaResponse;
  updatedSchema: LayoutSchema;
  isNew = false;
  schemaName = new FormControl();
  schemaDescription = new FormControl();
  contentHeaderButtons: ContentHeaderButton[] = [];
  private onDestroy = new Subject<void>();
  private saveDisabled = new BehaviorSubject<boolean>(true);

  jsonEditorOptions: Options = { flex: true };
  jsonEditorDisabled = true;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private store: Store<AdministrationState>,
    private contentHeaderBarService: ContentHeaderBarService
  ) {}

  ngOnInit() {
    this.route.data.pipe(takeUntil(this.onDestroy)).subscribe(data => {
      this.setSchemaObservable(data.schema);

      this.contentHeaderButtons = [
        {
          name: 'CANCEL',
          onClick: () => {
            const backRoute = this.isNew ? ['../..'] : ['..'];
            this.router.navigate(backRoute, { relativeTo: this.route });
          }
        },
        {
          name: this.isNew ? 'CREATE' : 'SAVE',
          color: 'accent',
          type: 'flat',
          disabled$: this.saveDisabled.asObservable(),
          onClick: () => {
            this.isNew ? this.create() : this.save();
          }
        }
      ];
      this.contentHeaderBarService.setButtons(this.contentHeaderButtons);
    });
  }

  onUpdatedSchema(layoutSchema: LayoutSchema) {
    this.updatedSchema = layoutSchema;
    this.checkIfSaveShouldBeDisabled();
  }

  save() {
    this.store.dispatch(
      new layoutSchemaActions.Update({
        ...this.schema,
        layoutSchema: this.updatedSchema
      })
    );
  }

  create() {
    this.store.dispatch(
      new layoutSchemaActions.Create({
        ...this.schema,
        contentType: this.schemaName.value,
        layoutSchema: this.updatedSchema
      })
    );
  }

  onJSONParseError(error: JsonEditorError) {
    if (error) {
      this.saveDisabled.next(true);
    }
  }

  private setSchemaObservable(layoutSchema: LayoutSchemaResponse) {
    if (layoutSchema.id && layoutSchema.layoutSchema) {
      this.schema = { ...layoutSchema };
    } else {
      this.isNew = true;
      this.schema = { ...layoutSchema, layoutSchema: [{}] } as LayoutSchemaResponse;
      this.updatedSchema = {} as LayoutSchema;
      merge(this.schemaName.valueChanges, this.schemaDescription.valueChanges)
        .pipe(takeUntil(this.onDestroy))
        .subscribe(() => this.checkIfSaveShouldBeDisabled());
    }
  }

  checkIfSaveShouldBeDisabled(): void {
    if (this.isNew && (!this.schemaName.value || !this.schemaDescription.value)) {
      this.saveDisabled.next(true);
    } else if (!this.updatedSchema || Object.keys(this.updatedSchema).length === 0) {
      this.saveDisabled.next(true);
    } else {
      this.saveDisabled.next(isEqual(this.updatedSchema, this.schema.layoutSchema));
    }
  }

  ngOnDestroy() {
    this.onDestroy.next();
  }
}
