import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ErrorGuard } from '../../guards';
import { LayoutSchemaGuard } from '@content-platform/dynamic-forms-api';

import { UserPermissionListGuard, FeatureGuard } from '@content-platform/application-api';
import { SchemaEditorDetailComponent } from './schema-editor-detail/schema-editor-detail.component';
import { SchemaEditorEditComponent } from './schema-editor-edit/schema-editor-edit.component';
import { SchemaEditorResolver } from '../../resolvers';
import {
  ContentContainerComponent,
  EditorListComponent
} from '@content-platform/reusable-ui/components';

export const SCHEMA_EDITOR_KEY = 'schema_editor';

const routes: Routes = [
  {
    path: '',
    component: ContentContainerComponent,
    data: {
      title: 'Schema'
    },
    canActivate: [UserPermissionListGuard, ErrorGuard],
    children: [
      {
        path: ':contentType',
        component: SchemaEditorDetailComponent,
        canActivate: [LayoutSchemaGuard],
        resolve: {
          schema: SchemaEditorResolver
        }
      },
      {
        path: '',
        component: EditorListComponent,
        outlet: 'navigation-list',
        data: {
          title: 'Schema',
          placeholder: 'Schema Content Type',
          showCreateNewFeatureKey: SCHEMA_EDITOR_KEY
        }
      },
      {
        path: ':contentType/edit',
        component: SchemaEditorEditComponent,
        data: { featureGuard: { key: SCHEMA_EDITOR_KEY } },
        canActivate: [FeatureGuard, ErrorGuard],
        resolve: {
          schema: SchemaEditorResolver
        }
      },
      {
        path: ':contentType/new',
        component: SchemaEditorEditComponent,
        data: { featureGuard: { key: SCHEMA_EDITOR_KEY }, schema: {} },
        canActivate: [FeatureGuard]
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SchemaEditorRoutingModule {}
