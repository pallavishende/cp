import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatCardModule,
  MatFormFieldModule,
  MatIconModule,
  MatInputModule,
  MatMenuModule
} from '@angular/material';
import { PermissionsModule } from '@content-platform/application-api';
import { AwsModule } from '@content-platform/aws';
import { JsonEditorModule } from '@content-platform/reusable-ui/json-editor';
import { ErrorGuard } from '../../guards';
import { SchemaEditorResolver } from '../../resolvers';
import { SchemaEditorRoutingModule } from './schema-editor-routing.module';
import { SchemaEditorDetailComponent } from './schema-editor-detail/schema-editor-detail.component';
import { SchemaEditorEditComponent } from './schema-editor-edit/schema-editor-edit.component';
import { NavigationModule } from '@content-platform/navigation';
import { ReusableUiContentNavigationModule } from '@content-platform/reusable-ui/components';
import { DynamicFormsApiModule } from '@content-platform/dynamic-forms-api';

@NgModule({
  imports: [
    CommonModule,
    JsonEditorModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    MatMenuModule,
    MatIconModule,
    AwsModule,
    DynamicFormsApiModule,
    SchemaEditorRoutingModule,
    ReusableUiContentNavigationModule,
    PermissionsModule,
    NavigationModule
  ],
  providers: [ErrorGuard, SchemaEditorResolver],
  declarations: [SchemaEditorDetailComponent, SchemaEditorEditComponent],
  entryComponents: []
})
export class SchemaEditorModule {}
