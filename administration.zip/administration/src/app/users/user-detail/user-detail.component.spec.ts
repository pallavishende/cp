import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

import { NgPipesModule } from 'ngx-pipes';
import { of } from 'rxjs';

import { MaterialMockModule, MockPipe, MockDirective } from '@content-platform/unit-test-helpers';
import { UserDetailComponent } from './user-detail.component';
import { LoggerService } from '@content-platform/logging';
import { ContentHeaderBarService } from '@content-platform/navigation';
import { UserPermissionsService } from '@content-platform/application-api';

describe('UserDetailComponent', () => {
  let component: UserDetailComponent;
  let fixture: ComponentFixture<UserDetailComponent>;
  let headerService: ContentHeaderBarService;
  let hasFeature = true;
  let routeStub;

  beforeEach(async(() => {
    routeStub = {
      data: of({
        roles: [
          {
            name: 'test-role',
            uuid: 'id'
          }
        ],
        userProfile: {
          displayName: 'Some User',
          objectId: 'user-id-1234'
        },
        userRoleList: {
          uuid: 'user-id-1234',
          roles: []
        }
      })
    };

    TestBed.configureTestingModule({
      imports: [MaterialMockModule, RouterTestingModule, NgPipesModule],
      providers: [
        { provide: ActivatedRoute, useValue: routeStub },
        { provide: ContentHeaderBarService, useValue: { setButtons: () => {} } },
        { provide: UserPermissionsService, useValue: { hasFeature: () => hasFeature } },
        {
          provide: LoggerService,
          useValue: {
            instance: () => {
              return { info: () => {} };
            }
          }
        }
      ],
      declarations: [
        UserDetailComponent,
        MockPipe('displayName'),
        MockPipe('userProfile'),
        MockDirective({ selector: '[appIfFeatureAsync]', inputs: ['appIfFeatureAsync'] })
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserDetailComponent);
    component = fixture.componentInstance;
    headerService = TestBed.get(ContentHeaderBarService);
    spyOn(headerService, 'setButtons').and.callThrough();
  });

  it('should create', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('should call set buttons if has feature', () => {
    fixture.detectChanges();
    expect(headerService.setButtons).toHaveBeenCalled();
  });

  it('should not call set buttons if it does not have feature', () => {
    hasFeature = false;
    fixture.detectChanges();
    expect(headerService.setButtons).not.toHaveBeenCalled();
  });
});
