import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Role, UserRoleList, UserPermissionsService } from '@content-platform/application-api';
import { UserProfile } from '@content-platform/graph-api';
import { Subscription } from 'rxjs';
import { LoggerService } from '@content-platform/logging';
import { ContentHeaderBarService, ContentHeaderButton } from '@content-platform/navigation';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.scss']
})
export class UserDetailComponent implements OnInit, OnDestroy {
  roles: Role[];
  userProfile: UserProfile;
  userRoleList: UserRoleList;
  contentHeaderButtons: ContentHeaderButton[] = [];
  private routeSub: Subscription;
  private logger: LoggerService;

  constructor(
    loggerService: LoggerService,
    private route: ActivatedRoute,
    private contentHeaderBarService: ContentHeaderBarService,
    private userPermissionsService: UserPermissionsService,
    private router: Router
  ) {
    this.logger = loggerService.instance('UserDetailComponent');
  }

  ngOnInit() {
    this.contentHeaderButtons = [
      {
        name: 'EDIT',
        type: 'raised',
        onClick: () => {
          this.router.navigate(['./edit'], { relativeTo: this.route });
        }
      }
    ];

    this.routeSub = this.route.data.subscribe(data => {
      this.roles = data.roles || [];
      this.userProfile = data.userProfile;
      this.userRoleList = data.userRoleList;
      if (this.userPermissionsService.hasFeature('edit_users')) {
        this.contentHeaderBarService.setButtons(this.contentHeaderButtons);
      }
    });
  }

  tabChange(event) {
    this.logger.info(`Switched to ${event.tab.textLabel} tab`);
  }

  ngOnDestroy() {
    this.routeSub.unsubscribe();
  }
}
