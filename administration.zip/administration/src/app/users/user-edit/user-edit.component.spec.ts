import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog, MatAutocompleteSelectedEvent } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import {
  fromApplication,
  fromUserRoleList,
  Role,
  userRoleListActions
} from '@content-platform/application-api';
import {
  MaterialMockModule,
  MaterialServiceMocks,
  MockDirective,
  MockPipe
} from '@content-platform/unit-test-helpers';
import { routerReducer } from '@ngrx/router-store';
import { Store, StoreModule } from '@ngrx/store';
import { NgPipesModule } from 'ngx-pipes';
import { of, Subject } from 'rxjs';
import { UserEditComponent } from './user-edit.component';
import { ContentHeaderBarService } from '@content-platform/navigation';
import { LoggerService } from '@content-platform/logging';

describe('UserEditComponent', () => {
  let component: UserEditComponent;
  let fixture: ComponentFixture<UserEditComponent>;
  let routeStub;
  let store: Store<fromUserRoleList.State>;

  beforeEach(() => {
    routeStub = {
      data: of({
        roles: [{ id: 111, name: 'exiting role' }, { id: 333, name: 'New Role' }],
        userProfile: {
          displayName: 'Some User',
          objectId: 'user-id-1234'
        },
        userRoleList: {
          uuid: 'user-id-1234',
          roles: [{ id: 111, name: 'exiting role' }],
          id: 222
        }
      })
    };

    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        RouterTestingModule,
        NgPipesModule,
        MaterialMockModule,
        StoreModule.forRoot({
          routerReducer: routerReducer,
          application: fromApplication.reducer
        })
      ],
      providers: [
        { provide: ActivatedRoute, useValue: routeStub },
        { provide: MatDialog, useValue: new MaterialServiceMocks.MatDialog<boolean>(true) },
        {
          provide: ContentHeaderBarService,
          useValue: {
            onClick: new Subject(),
            setButtons: () => {}
          }
        },
        {
          provide: LoggerService,
          useValue: {
            instance: () => {
              return { info: () => {} };
            }
          }
        }
      ],
      declarations: [
        UserEditComponent,
        MockPipe('displayName'),
        MockDirective({
          selector: `input[appAutocomplete]`,
          exportAs: 'appAutocompleteTrigger',
          inputs: ['appAutocomplete', 'closeOnSelect', 'formControl']
        })
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    jest.useFakeTimers();
    store = TestBed.get(Store);
    fixture = TestBed.createComponent(UserEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('selectRole', () => {
    it('should add item to userRoleList, and remove from availableRoles', () => {
      expect(component.availableRoles).toEqual(<Role[]>[{ id: 333, name: 'New Role' }]);
      expect(component.userRoleList.roles).toEqual(<Role[]>[{ id: 111, name: 'exiting role' }]);
      component.selectRole({
        option: { value: { id: 333, name: 'New Role' } }
      } as MatAutocompleteSelectedEvent);
      expect(component.availableRoles).toEqual([]);
      expect(component.userRoleList.roles).toEqual(<Role[]>[
        { id: 111, name: 'exiting role' },
        { id: 333, name: 'New Role' }
      ]);
    });
  });

  describe('updateRoleList', () => {
    beforeEach(() => {
      component.selectRole({
        option: { value: { id: 333, name: 'New Role' } }
      } as MatAutocompleteSelectedEvent);
    });

    it('should remove items if not part of the roleIds', () => {
      component.updateRoleList([333]);
      expect(component.userRoleList.roles).toEqual(<Role[]>[{ id: 333, name: 'New Role' }]);
      expect(component.removedUserRoles).toEqual(<Role[]>[{ id: 111, name: 'exiting role' }]);
    });

    it('should update the filtered Roles and add items back in', () => {
      let roles;
      const unsubcribe = component.filteredRoles$.subscribe(filteredRoles => {
        roles = filteredRoles;
      });
      component['removeRoleSubject'].next();
      jest.advanceTimersByTime(500);
      expect(roles).toEqual([]);
      component.updateRoleList([]);
      expect(component.userRoleList.roles).toEqual([]);
      jest.advanceTimersByTime(500);
      expect(roles).toEqual([{ id: 111, name: 'exiting role' }, { id: 333, name: 'New Role' }]);
      unsubcribe.unsubscribe();
    });
  });

  it('should save', () => {
    const action = new userRoleListActions.Update(component.userRoleList);
    spyOn(store, 'dispatch').and.callThrough();
    component.save();
    expect(store.dispatch).toHaveBeenCalledWith(action);
  });

  it('should save with dialog', () => {
    component.updateRoleList([333]);
    expect(component.removedUserRoles).toEqual(<Role[]>[{ id: 111, name: 'exiting role' }]);
    spyOn(store, 'dispatch').and.callThrough();
    const action = new userRoleListActions.Update(component.userRoleList);
    component.save();
    expect(store.dispatch).toHaveBeenCalledWith(action);
  });
});
