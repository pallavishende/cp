import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent, MatDialog } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { Role, UserRoleList, userRoleListActions } from '@content-platform/application-api';
import { UserProfile } from '@content-platform/graph-api';
import { Store } from '@ngrx/store';
import { merge, Observable, Subject } from 'rxjs';
import { debounceTime, filter, map, startWith, take, takeUntil, tap } from 'rxjs/operators';
import { AdministrationState } from '../../reducers';
import { ContentHeaderBarService, ContentHeaderButton } from '@content-platform/navigation';
import { NotificationType, notificationActions } from '@content-platform/notifications';
import { LoggerService } from '@content-platform/logging';
import { DisplayNamePipe } from '@content-platform/pipes';
import { ConfirmationDialogComponent } from '@content-platform/reusable-ui/components';

@Component({
  selector: 'app-user-edit',
  templateUrl: './user-edit.component.html',
  styleUrls: ['./user-edit.component.scss']
})
export class UserEditComponent implements OnInit, OnDestroy {
  roles: Role[];
  roleEntities: { [key: number]: Role };
  userProfile: UserProfile;
  userRoleList: UserRoleList;
  originalUserRoleList: UserRoleList;
  userRoleIdList: number[];
  removedUserRoles: Role[] = [];
  availableRoles: Role[] = [];
  filteredRoles$: Observable<Role[]>;
  selectRoleFilterCtrl = new FormControl();
  private logger: LoggerService;
  private removeRoleSubject = new Subject<void>();
  private displayNamePipeRef: DisplayNamePipe;
  private onDestroy = new Subject<void>();

  constructor(
    private store: Store<AdministrationState>,
    private route: ActivatedRoute,
    private router: Router,
    private dialog: MatDialog,
    private contentHeaderBarService: ContentHeaderBarService,
    loggerService: LoggerService
  ) {
    this.logger = loggerService.instance('UserEditComponent');
    this.filteredRoles$ = <Observable<Role[]>>merge(
      this.selectRoleFilterCtrl.valueChanges,
      this.removeRoleSubject.asObservable()
    ).pipe(
      startWith(''),
      debounceTime(50),
      map(state => {
        const searchRegExp = new RegExp(state || '', 'i');
        return this.availableRoles.filter(role => searchRegExp.test(role.name));
      })
    );
  }

  ngOnInit() {
    this.route.data.pipe(takeUntil(this.onDestroy)).subscribe(data => {
      this.roles = data.roles;
      this.userProfile = data.userProfile;
      this.userRoleList = data.userRoleList;
      this.originalUserRoleList = <UserRoleList>{ roles: data.userRoleList.roles };
      this.setInitRoleListData();
      this.userRoleIdList = data.userRoleList.roles.map(role => role.id);
      this.roleEntities = this.roles.reduce((entities: { [id: number]: Role }, role) => {
        return {
          ...entities,
          [role.id]: role
        };
      }, {});
      this.availableRoles = this.roles.filter(role => !this.userRoleIdList.includes(role.id));

      const contentHeaderButtons: ContentHeaderButton[] = [
        {
          name: 'CANCEL',
          onClick: () => this.router.navigate(['..'], { relativeTo: this.route })
        },
        {
          name: 'SAVE',
          color: 'accent',
          type: 'flat',
          onClick: () => this.save()
        }
      ];
      this.contentHeaderBarService.setButtons(contentHeaderButtons);
    });
    this.displayNamePipeRef = new DisplayNamePipe();
  }

  private setInitRoleListData() {
    this.userRoleList.name = this.userProfile.displayName;
    this.userRoleList.modifiedDate = this.userProfile.lastDirSyncTime;
  }

  ngOnDestroy() {
    this.onDestroy.next();
  }

  save(): void {
    if (this.showRemoveDialog()) {
      this.logger.info('Showing Remove Dialog');
      const roleNames: string[] = this.removedUserRoles.map(
        (role, index) => index + 1 + '. ' + role.name
      );
      const messageData = {
        message: `Are you sure you want to remove these role(s) from user ${this.displayNamePipeRef.transform(
          this.userProfile
        )}?<br><br>
      ${roleNames.join('<br>')}`
      };
      this.dialog
        .open(ConfirmationDialogComponent, {
          data: messageData
        })
        .afterClosed()
        .pipe(
          take(1),
          tap(result => {
            if (!result) {
              this.logger.info('Cancelled Remove Dialog');
            }
          }),
          filter(result => result)
        )
        .subscribe(() => {
          this.store.dispatch(new userRoleListActions.Update(this.userRoleList));
        });
    } else {
      this.store.dispatch(new userRoleListActions.Update(this.userRoleList));
    }
  }

  removeRole(roleId: number): void {
    const roleIds = this.userRoleList.roles
      .filter(role => {
        return role.id !== roleId;
      })
      .map(role => role.id);
    this.updateRoleList(roleIds);
    this.logger.info('Removed Role', { roleId });
  }

  updateRoleList(roleIds: number[]): void {
    this.addToRemovedUserRoles(roleIds);
    this.userRoleList = {
      ...this.userRoleList,
      roles: this.userRoleList.roles.filter(role => roleIds.includes(role.id))
    };
    this.availableRoles = this.roles.filter(role => !roleIds.includes(role.id));
    this.removeRoleSubject.next();
  }

  selectRole(event: MatAutocompleteSelectedEvent): void {
    this.userRoleList = {
      ...this.userRoleList,
      roles: [...this.userRoleList.roles, event.option.value]
    };

    this.userRoleIdList = this.userRoleList.roles.map(role => role.id);
    this.availableRoles = this.roles.filter(role => !this.userRoleIdList.includes(role.id));

    // Show Notification that the role has been added to the list of roles successfully
    this.showUserNotification();
  }

  private addToRemovedUserRoles(roleIds: number[]): void {
    const originalList = this.originalUserRoleList.roles || [];
    this.removedUserRoles = originalList.filter(role => !roleIds.find(id => role.id === id));
  }

  private showRemoveDialog(): boolean {
    if (this.removedUserRoles.length > 0) {
      return true;
    }
    return false;
  }

  private showUserNotification() {
    this.store.dispatch(
      new notificationActions.Open({
        type: NotificationType.Success,
        inputs: {
          props: {
            message: 'User role successfully selected'
          }
        }
      })
    );
  }
}
