import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FeatureGuard, UserPermissionListGuard } from '@content-platform/application-api';
import {
  ContentContainerComponent,
  UsersListComponent
} from '@content-platform/reusable-ui/components';
import { ErrorGuard, RolesGuard } from '../guards';
import { RolesResolver, UserProfileResolver, UserRoleListResolver } from '../resolvers';
import { UserDetailComponent } from './user-detail/user-detail.component';
import { UserEditComponent } from './user-edit/user-edit.component';

const EDIT_FEATURE_KEY = 'edit_users';

const routes: Routes = [
  {
    path: '',
    component: ContentContainerComponent,
    data: {
      title: 'User(s)'
    },
    canActivate: [UserPermissionListGuard, ErrorGuard],
    resolve: { roles: RolesResolver },
    children: [
      {
        path: ':userId',
        component: UserDetailComponent,
        canActivate: [],
        resolve: {
          userProfile: UserProfileResolver,
          roles: RolesResolver,
          userRoleList: UserRoleListResolver
        }
      },
      {
        path: '',
        component: UsersListComponent,
        outlet: 'navigation-list'
      },
      {
        path: ':userId/edit',
        component: UserEditComponent,
        data: { featureGuard: { key: EDIT_FEATURE_KEY } },
        canActivate: [FeatureGuard, RolesGuard, ErrorGuard],
        resolve: {
          userProfile: UserProfileResolver,
          roles: RolesResolver,
          userRoleList: UserRoleListResolver
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsersRoutingModule {}
