import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {
  MatListModule,
  MatButtonModule,
  MatCardModule,
  MatInputModule,
  MatOptionModule,
  MatAutocompleteModule,
  MatFormFieldModule,
  MatIconModule,
  MatExpansionModule,
  MatTabsModule,
  MatMenuModule
} from '@angular/material';

import { NgPipesModule } from 'ngx-pipes';

import { GraphApiModule } from '@content-platform/graph-api';
import { PermissionsModule } from '@content-platform/application-api';

import { UsersRoutingModule } from './users-routing.module';

import { guards } from '../guards';

import { UserDetailComponent } from './user-detail/user-detail.component';
import { UserEditComponent } from './user-edit/user-edit.component';
import { RolesResolver, UserProfileResolver, UserRoleListResolver } from '../resolvers';
import { DevelopmentModule } from '@content-platform/development';
import { AppAutoCompleteModule } from '@content-platform/reusable-ui/custom-material-components';
import { NavigationModule } from '@content-platform/navigation';
import { PipesModule } from '@content-platform/pipes';
import { ReusableUiContentNavigationModule } from '@content-platform/reusable-ui/components';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    MatListModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatOptionModule,
    MatMenuModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    MatIconModule,
    MatExpansionModule,
    MatTabsModule,
    NgPipesModule,
    ReusableUiContentNavigationModule,
    GraphApiModule,
    UsersRoutingModule,
    PipesModule,
    PermissionsModule,
    NavigationModule,
    DevelopmentModule,
    AppAutoCompleteModule
  ],
  providers: [...guards, RolesResolver, UserProfileResolver, UserRoleListResolver],
  declarations: [UserDetailComponent, UserEditComponent],
  exports: []
})
export class UsersModule {}
