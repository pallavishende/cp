import { globalEnvironment } from '@environments/environment.e2e';

export const environment = {
  ...globalEnvironment,
  version: globalEnvironment.version,
  production: globalEnvironment.production
};
