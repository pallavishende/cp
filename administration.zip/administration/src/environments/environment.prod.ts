import { globalEnvironment } from '@environments/environment.prod';

export const environment = {
  ...globalEnvironment,
  version: globalEnvironment.version,
  production: globalEnvironment.production
};
