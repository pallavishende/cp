import { globalEnvironment } from '@environments/environment.qa';

export const environment = {
  ...globalEnvironment,
  version: globalEnvironment.version,
  production: globalEnvironment.production
};
