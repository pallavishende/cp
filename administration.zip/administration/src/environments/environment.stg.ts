import { globalEnvironment } from '@environments/environment.stg';

export const environment = {
  ...globalEnvironment,
  version: globalEnvironment.version,
  production: globalEnvironment.production
};
