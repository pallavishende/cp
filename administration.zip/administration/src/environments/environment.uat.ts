import { globalEnvironment } from '@environments/environment.uat';

export const environment = {
  ...globalEnvironment,
  version: globalEnvironment.version,
  production: globalEnvironment.production
};
