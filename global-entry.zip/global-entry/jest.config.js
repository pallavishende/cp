module.exports = {
  name: 'global-entry',
  preset: '../../jest.config.js',
  coverageDirectory: '../../coverage/apps/global-entry',
  reporters: [
    'default',
    ['jest-junit', { output: 'test-reports/global-entry.xml', suiteName: 'global-entry tests' }]
  ]
};
