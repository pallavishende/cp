import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdAuthGuard } from '@content-platform/auth';
import { TermsOfUseGuard } from '@content-platform/terms-of-use';
import {
  PageNotFoundComponent,
  AccessDeniedComponent,
  ErrorContainerComponent
} from '@content-platform/error-handling';
import { PreloadingStrategyService } from './services/preloading-strategy.service';

import { UserPermissionListGuard } from '@content-platform/application-api';
import { UserMetadataGuard } from './submission/form/guards';

const appRoutes: Routes = [
  {
    path: 'dashboard',
    canActivate: [AdAuthGuard, TermsOfUseGuard, UserMetadataGuard, UserPermissionListGuard],
    children: [
      {
        path: '',
        loadChildren: './submission/dashboard/dashboard.module#DashboardModule'
      }
    ],
    data: { preload: true, isDashboard:true }
  },
  {
    path: 'submission',
    canActivate: [AdAuthGuard, TermsOfUseGuard],
    loadChildren: './submission/form/submissions-form.module#SubmissionsFormModule',
    runGuardsAndResolvers: 'always'
  },
  {
    path: 'preferences',
    canActivate: [AdAuthGuard, TermsOfUseGuard],
    loadChildren: './preferences/preferences.module#PreferencesModule',
    pathMatch: 'full'
  },
  {
    path: 'technicalspecification',
    canActivate: [AdAuthGuard, TermsOfUseGuard],
    loadChildren: './tech-specifications/tech-specifications.module#TechSpecificationsModule',
    pathMatch: 'full'
  },
  {
    path: '',
    redirectTo: '/dashboard',
    pathMatch: 'full'
  },
  {
    path: 'access-denied',
    component: AccessDeniedComponent,
    data: {
      title: 'Sorry! Access Denied',
      icon: 'lock',
      description: "You don't have permission to access this link."
    }
  },
  {
    path: 'error',
    component: ErrorContainerComponent
  },
  {
    path: '**',
    pathMatch: 'full',
    component: PageNotFoundComponent,
    canActivate: []
  }
];
@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes, {
      initialNavigation: 'enabled',
      preloadingStrategy: PreloadingStrategyService,
      onSameUrlNavigation: 'reload'
    })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
