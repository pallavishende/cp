import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { APP_BASE_HREF } from '@angular/common';
import { AppComponent } from './app.component';
import { RouterTestingModule } from '@angular/router/testing';
import { MockComponent } from '@content-platform/unit-test-helpers';
import { StoreModule } from '@ngrx/store';
import {
  fromApplication,
  fromUserPermissionList,
  UserPermissionsService
} from '@content-platform/application-api';
import { fromAuth } from '@content-platform/auth';
import { TermsOfUseService } from '@content-platform/terms-of-use';
import { SubmissionService } from './services/submission.service';
import { TimelineService } from '@content-platform/reusable-ui/timeline';
import { FileUploadService } from '@content-platform/aws';
import { of, Subject } from 'rxjs';
import { StompRService } from '@stomp/ng2-stompjs';
import { OverlayModule } from '@angular/cdk/overlay';
import { LoggerService } from '@content-platform/logging';

const MockFileUploadService = {
  fileItems: [],
  fileEmitterSubject: of(['file']), // it is not clear what type this should be
  fileUploadSucceedSubject: of('filename'),
  setOverlay() {},
  overlayElem: of()
};

describe('Global Entry AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;

  class SubmisionServiceStub {
    loadSpinner = new Subject<boolean>();
  }
  class TimelineServiceStub {
    setTimelineOverlayRef() {}
  }
  class StompServiceStub {
    subscribe() {}
    initAndConnect() {}
    disconnect() {}
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        OverlayModule,
        RouterTestingModule,
        StoreModule.forRoot({
          application: fromApplication.reducer,
          auth: fromAuth.authReducer,
          userPermissionList: fromUserPermissionList.reducer
        })
      ],
      declarations: [
        AppComponent,
        MockComponent({ selector: 'app-timeline' }),
        MockComponent({
          selector: 'app-nav-bar',
          inputs: ['additionalMenuItems', 'isAppMenuShow']
        }),
        MockComponent({
          selector: 'app-global-sidenav',
          inputs: ['sideNavData', 'nonRouterLinks']
        }),
        MockComponent({
          selector: 'app-spinner-container',
          inputs: []
        }),
        MockComponent({ selector: 'app-content' }),
        MockComponent({
          selector: 'app-footer',
          inputs: ['version']
        })
      ],
      providers: [
        { provide: APP_BASE_HREF, useValue: '/' },
        { provide: SubmissionService, useClass: SubmisionServiceStub },
        { provide: StompRService, useClass: StompServiceStub },
        {
          provide: TimelineService,
          useClass: TimelineServiceStub
        },
        {
          provide: TermsOfUseService,
          useValue: {
            showTermsOfUseModal: () => {
              return of(true);
            }
          }
        },
        {
          provide: UserPermissionsService,
          useValue: {
            hasFeatureAsync: (_key: string) => {
              return of(true);
            },
            getFeatureMetadataListAsync: (_key: string) => {
              return of([]);
            }
          }
        },
        {
          provide: LoggerService,
          useValue: {
            instance: () => {
              return { log: () => {} };
            }
          }
        },
        { provide: FileUploadService, useValue: MockFileUploadService }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
