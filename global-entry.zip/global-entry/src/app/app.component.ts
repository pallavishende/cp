import { Component, OnInit, OnDestroy, Optional, ViewChild, AfterViewInit } from '@angular/core';
import { Store, select } from '@ngrx/store';

import { Router, RouterEvent, NavigationEnd } from '@angular/router';
import { TimelineComponent, TimelineService } from '@content-platform/reusable-ui/timeline';

import { Observable, Subject } from 'rxjs';
import {
  map,
  switchMap,
  skip,
  combineLatest,
  takeUntil,
  withLatestFrom,
  take
} from 'rxjs/operators';
import { StompRService } from '@stomp/ng2-stompjs';
import { Message } from '@stomp/stompjs';

import { UserMenuItem, SideNavItem } from '@content-platform/navigation';
import { Auth, authSelectors } from '@content-platform/auth';
import {
  userPermissionListSelectors,
  UserPermissionsService
} from '@content-platform/application-api';
import { TermsOfUseService } from '@content-platform/terms-of-use';
import {
  SubmissionPageState,
  SubmissionStatusAction,
  SubmissionStatusState
} from './submission/form/store';
import {
  DashboardState,
  NotificationDataAction,
  NotificationMessageState,
  getNotificationMessageState
} from './submission/dashboard/store';
import { environment } from '../environments/environment';
import { stompConfig } from './stomp-config';
import { DebugFlagsService, FEATURE_FLAG_KEY } from '@content-platform/development';
import { DebugFlagsDialogService } from '@content-platform/reusable-ui/feature-flags';
import { ComponentPortal } from '@angular/cdk/portal';
import { Overlay, OverlayConfig, OverlayRef } from '@angular/cdk/overlay';
import { globalEntryFeature, globalEntryMetadataKeys } from '../constants';
import { SubmissionService } from './services/submission.service';
import { SpinnerContainerComponent } from '@content-platform/reusable-ui/loading-spinner';
import { FileUploadService } from '@content-platform/aws';
import { PageNavigationComponent } from '@content-platform/reusable-ui/components';
import { LoggerService } from '@content-platform/logging';

export const NOTIFICATION_DEBUG_FLAG = 'enable_stomp_notifications';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent extends PageNavigationComponent
  implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild('spinner')
  spinner: SpinnerContainerComponent;
  private componentDestroyed$ = new Subject<boolean>();
  private createNavData: SideNavItem = {
    route: 'submission',
    icon: 'add_box',
    title: 'Upload',
    isActive: true,
    hidden: true,
    exactMatch: true
  };
  // Temporary fix to disable submission history in production
  private submissionHistoryData: SideNavItem = {
    fontSet: 'fa',
    icon: 'fa-history',
    title: 'Submission History',
    nonRouterLink: true
  };
  clickOnExpand: Boolean;
  version = environment.version;
  isLogged$: Observable<boolean>;
  hasValidAccess$: Observable<boolean>;
  messages$: Observable<Message>;
  message$: Observable<any>;
  loggedInUser$: Observable<adal.User>;
  loggedInUserEmail$: Observable<string>;
  notificationMessage$: Observable<NotificationMessageState>;
  extraMenuItems: UserMenuItem[] = [
    {
      buttonName: 'My Preferences',
      buttonAction: () => {
        this.router.navigate(['/preferences']);
      }
    },
    {
      buttonName: 'Terms Of Use',
      buttonAction: () => {
        this.touService.showTermsOfUseModal().subscribe();
      }
    }
  ];

  sideNavData: SideNavItem[] = [
    {
      route: 'dashboard',
      fontSet: 'fa',
      icon: 'fa-tachometer',
      title: 'Dashboard',
      isActive: true
    },
    this.createNavData
  ];
  currentRoute = '';
  setOverlayConfig: OverlayConfig;
  overlayRef: OverlayRef;
  navigatedToView: Boolean;

  private logger: LoggerService;

  constructor(
    private store: Store<Auth>,
    private stompService: StompRService,
    private dashboardStore: Store<DashboardState>,
    private viewStore: Store<SubmissionPageState>,
    private touService: TermsOfUseService,
    private permissionService: UserPermissionsService,
    private submissionService: SubmissionService,
    private router: Router,
    private overlay: Overlay,
    private timelineService: TimelineService,
    private fileUploadService: FileUploadService,
    loggerService: LoggerService,
    @Optional() private debugFlagService: DebugFlagsService,
    @Optional() private debugFlagDialogService: DebugFlagsDialogService
  ) {
    super();
    // get current route to display submission history
    this.router.events.pipe(takeUntil(this.componentDestroyed$)).subscribe((event: RouterEvent) => {
      if (event instanceof NavigationEnd && event.url) {
        this.currentRoute = event.url;
      }
    });
    // set config for overlay of submission history
    this.setOverlayConfig = {
      panelClass: 'history-panel',
      positionStrategy: this.overlay
        .position()
        .global()
        .left()
    };
    this.hasValidAccess$ = this.store.pipe(
      select(authSelectors.getIsLoggedIn),
      combineLatest(this.store.pipe(select(userPermissionListSelectors.hasUserPermission))),
      map(([loggedIn, hasUserPermissions]) => loggedIn && hasUserPermissions)
    );

    this.permissionService
      .hasFeatureAsync(FEATURE_FLAG_KEY)
      .pipe(take(1))
      .subscribe(canAccess => {
        if (canAccess) {
          this.extraMenuItems.push({
            buttonName: 'Feature Flags',
            buttonAction: () => {
              this.debugFlagDialogService.showDebugFlagsModal();
            }
          });
        }
      });
    this.logger = loggerService.instance('AppComponent');
    this.logger.log('Global Entry User Login');
  }

  // display submission history icon if current route is view
  get sideNavLinks() {
    if (this.currentRoute && this.currentRoute.includes('create')) {
      this.createNavData.exactMatch = false;
    }
    if (this.currentRoute && this.currentRoute.includes('view')) {
      this.createNavData.exactMatch = true;
      this.timelineService.timelineElem
        .pipe(takeUntil(this.componentDestroyed$))
        .subscribe(overlay => {
          this.overlayRef = overlay;
          if (this.overlayRef) {
            this.submissionHistoryData.isActive = true;
          } else {
            this.submissionHistoryData.isActive = false;
          }
        });
      return [this.submissionHistoryData];
    } else {
      if (this.overlayRef) {
        this.overlayRef.dispose();
        this.timelineService.setTimelineOverlayRef(undefined);
      }
      return [];
    }
  }
  ngOnInit() {
    // push notifications for all screens
    this.messages$ = this.store.pipe(
      select(authSelectors.getADUser),
      skip(1),
      map((user: adal.User) => user.userName.toUpperCase()),
      switchMap(loggedInUser => {
        return this.stompService.subscribe(`/queue/notify/${loggedInUser.toUpperCase()}`);
      })
    );

    if (this.debugFlagService) {
      this.debugFlagService
        .hasDebugFlagAsync(NOTIFICATION_DEBUG_FLAG)
        .pipe(takeUntil(this.componentDestroyed$))
        .subscribe(enabled => {
          this.initStomp(enabled);
        });
    }

    this.message$ = this.messages$.pipe(map((message: Message) => message.body));

    this.message$.pipe(takeUntil(this.componentDestroyed$)).subscribe(message => {
      const msgBody = JSON.parse(message);
      const submissionStatusState: SubmissionStatusState = {
        currentStatus: msgBody.submissionStatus.description,
        submissionId: msgBody.id,
        statusCode: msgBody.submissionStatus.code
      };
      this.viewStore.dispatch(new SubmissionStatusAction(submissionStatusState));
      this.dashboardStore.dispatch(new NotificationDataAction(msgBody));
    });

    // show notification message state
    this.notificationMessage$ = this.dashboardStore.pipe(select(getNotificationMessageState));

    // hide menu option based on permission
    this.permissionService
      .hasFeatureAsync(globalEntryFeature.CREATE_SUB)
      .pipe(
        withLatestFrom(
          this.permissionService.getFeatureMetadataListAsync(globalEntryMetadataKeys.CONTENT_TYPE)
        ),
        takeUntil(this.componentDestroyed$)
      )
      .subscribe(([canAccessCreate, contentTypes]) => {
        this.createNavData.hidden = !canAccessCreate || contentTypes.length === 0;
      });
  }

  ngAfterViewInit() {
    this.submissionService.loadSpinner.pipe(takeUntil(this.componentDestroyed$)).subscribe(res => {
      // setTimeouts are in place here because of https://github.com/angular/material2/issues/6815
      if (res) {
        setTimeout(() => this.spinner.openSpinner());
      } else {
        setTimeout(() => this.spinner.closeSpinner());
      }
    });
  }

  private initStomp(connect: boolean) {
    if (connect) {
      this.stompService.config = stompConfig;
      this.stompService.initAndConnect();
    } else {
      this.stompService.disconnect();
    }
  }

  ngOnDestroy() {
    this.componentDestroyed$.next(true);
  }

  onNavClick(item) {
    this.timelineService.timelineElem
      .pipe(takeUntil(this.componentDestroyed$))
      .subscribe(overlay => {
        this.overlayRef = overlay;
      });
    if (item.nonRouterLink && !this.overlayRef) {
      let newOverlayConfig: OverlayConfig;
      newOverlayConfig = this.setOverlayConfig;
      this.overlayRef = this.overlay.create(newOverlayConfig);
      const timelinePortal = new ComponentPortal(TimelineComponent);
      this.overlayRef.attach(timelinePortal);
      this.overlayRef.backdropClick().subscribe(() => this.overlayRef.detach());
      this.timelineService.setTimelineOverlayRef(this.overlayRef);
    } else if (this.overlayRef) {
      this.overlayRef.dispose();
      this.timelineService.setTimelineOverlayRef(undefined);
    }
  }

  onExpand() {
    if (this.overlayRef) {
      this.overlayRef.dispose();
      this.timelineService.setTimelineOverlayRef(undefined);
    }
  }

  // checks if a submission creation is in progress,
  // used by PageNavigationComponent to display warning message while navigating
  canDeactivate(): boolean {
    return this.fileUploadService.uploadingFilesCount !== 0;
  }
}
