import { NgModule } from '@angular/core';
import {
  BrowserAnimationsModule,
  NoopAnimationsModule
} from '@angular/platform-browser/animations';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MatListModule,
  MatIconModule,
  MatToolbarModule,
  MatCardModule
} from '@angular/material';
import { NxModule } from '@nrwl/nx';
import { MarkdownModule } from 'ngx-markdown';
import { environment } from '../environments/environment';

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import {
  StoreRouterConnectingModule,
  RouterStateSerializer,
  NavigationActionTiming
} from '@ngrx/router-store';
import { reducers, CustomSerializer } from './reducers';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

import { AuthModule } from '@content-platform/auth';
import { NavigationModule } from '@content-platform/navigation';
import { DevelopmentModule } from '@content-platform/development';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent, NOTIFICATION_DEBUG_FLAG } from './app.component';
import { SubmissionService } from './services/submission.service';
import { VideoPreviewModule } from './submission/shared/video-preview/video-preview.module';
import { LoggingModule } from '@content-platform/logging';
import { LocalStorageService } from './services/localStorage.service';
import { ToasterModule } from './toaster/toaster.module';
import { AutoLoginModule } from '@content-platform/e2e-test-helpers';
import { VideoPlayerModule } from '@content-platform/reusable-ui/video-player';
import { LoadingSpinnerModule } from '@content-platform/reusable-ui/loading-spinner';
import { ApplicationApiModule, PermissionsModule } from '@content-platform/application-api';
import { ErrorHandlingModule } from '@content-platform/error-handling';
import { StompRService } from '@stomp/ng2-stompjs';
import { TermsOfUseModule, TermsAndConditionsModule } from '@content-platform/terms-of-use';
import { AwsModule } from '@content-platform/aws';
import { InterceptorsModule } from '@content-platform/interceptors';
import { TimelineModule } from '@content-platform/reusable-ui/timeline';
import { PreferencesApiModule } from '@content-platform/preferences-api';
import { ConfigurationModule } from '@content-platform/configuration';
import { ShareApiModule } from '@content-platform/reusable-ui/share';
import { ReusableUiFeatureFlagsModule } from '@content-platform/reusable-ui/feature-flags';
import { ScrollDispatchModule } from '@angular/cdk/scrolling';
import {
  APP_DATE_FORMATS,
  AppDateAdapter
} from '@content-platform/reusable-ui/dynamic-form-builder';
import { DatePipe } from '@angular/common';
import { PreloadingStrategyService } from './services/preloading-strategy.service';
import { SubmissionsApiModule } from '@content-platform/submissions-api';
import { KeywordsSearchService } from './submission/form/services/keywords-search.service';
import { DynamicFormsApiModule } from '@content-platform/dynamic-forms-api';
import { guards } from './submission/form/guards';

@NgModule({
  imports: [
    environment.disableAnimations ? NoopAnimationsModule : BrowserAnimationsModule,
    NxModule.forRoot(),
    StoreModule.forRoot(reducers),
    EffectsModule.forRoot([]),
    ConfigurationModule,
    !environment.production ? StoreDevtoolsModule.instrument({}) : [],
    environment.qa ? AutoLoginModule.forRoot(environment.skipAutomaticLogin) : [],
    AuthModule,
    NavigationModule.forRoot({
      production: environment.production
    }),
    ApplicationApiModule.forRoot({
      appName: 'Global Entry',
      production: environment.production
    }),
    PermissionsModule,
    AwsModule,
    TimelineModule,
    PreferencesApiModule.forRoot({
      useLocalStorage: false
    }),
    ShareApiModule.forRoot({
      useLocalStorage: false
    }),
    ErrorHandlingModule.forRoot({ handleAllFailActions: true }),
    VideoPreviewModule,
    ToasterModule,
    MatListModule,
    MatToolbarModule,
    LoggingModule.forRoot({ production: environment.production, version: environment.version }),
    LoadingSpinnerModule.withNavigationLoading(),
    AppRoutingModule,
    StoreRouterConnectingModule.forRoot({
      navigationActionTiming: NavigationActionTiming.PostActivation
    }),
    VideoPlayerModule,
    MatIconModule,
    MatCardModule,
    DevelopmentModule.forRoot(environment.production, [
      { name: NOTIFICATION_DEBUG_FLAG }
    ]),
    MarkdownModule.forRoot(),
    TermsOfUseModule.forRoot({
      title: 'Global Entry Terms Of Use',
      internalTermsMarkdownUrl: 'assets/terms-of-use/internal.md',
      externalTermsMarkdownUrl: 'assets/terms-of-use/external.md',
      version: 'v2',
      lastModifiedDateYYYYMMDD: '2018-03-12'
    }),
    TermsAndConditionsModule.forRoot({
      title: 'Global Entry Terms and Conditions',
      termsOfConditions: {
        'music-video': {
          markdownUrl: 'assets/terms-of-conditions/global-music-video-submission-v3.md',
          version: 'v3'
        }
      }
    }),
    InterceptorsModule,
    ScrollDispatchModule,
    ReusableUiFeatureFlagsModule,
    SubmissionsApiModule.forRoot({
      useLocalStorage: false
    }),
    DynamicFormsApiModule.forRoot({
      customDatasetServices: [KeywordsSearchService]
    })
  ],
  declarations: [AppComponent],
  providers: [
    SubmissionService,
    PreloadingStrategyService,
    DatePipe,
    LocalStorageService,
    KeywordsSearchService,
    {
      provide: DateAdapter,
      useClass: AppDateAdapter
    },
    {
      provide: MAT_DATE_FORMATS,
      useValue: APP_DATE_FORMATS
    },
    StompRService,
    { provide: RouterStateSerializer, useClass: CustomSerializer },
    ...guards
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
