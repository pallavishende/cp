export class MockLocalStorageData {
  public MOCK_DATA: any;
  public MOCK_DATA_CHUNK: any;
  public MOCK_RESPONSE_CHUNK: any;
  public MOCK_DATE_RANGE_DATA: any;
  public MOCK_RESPONSE_RECORD_COUNT: any;
  public MOCK_DATA_STATUS_CHECK: any;
  constructor() {
    this.MOCK_DATA = {
      startRecord: 1,
      resultList: [
        {
          id: 8,
          submissionFormData: {
            isrc: 'ISWSK7899998',
            notes: 'Metadata received',
            artist: 'Hollywood Undead',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Awaiting Elements',
            statusDetail: 'Technical Specification is not verified',
            artists: [
              {
                names: ['Daniel', 'Jenifer'],
                types: ['And', 'Featuring']
              }
            ],
            version: 'version66',
            explicit: true,
            composers: ['Bruise', 'Brenn'],
            directors: ['Murillo'],
            fileItems: [
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'American Tragedy',
            publishers: ['Dan Gilmore'],
            trackTitle: 'Apologize',
            parentLabel: 'Sony Music',
            recordLabel: 'Universal',
            albumReleaseDate: '2017-11-08T18:30:00.000Z',
            originalLanguage: 'Spanish',
            yearOfProduction: '2014',
            countryOfProduction: 'Angola',
            videoCountryOfOrigin: 'Katy On A Mission',
            artistCountryOfOrigin: 'Antarctica',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2018-01-07T18:30:00.000Z',
          modifiedDate: '06/12/2017 00:00:00',
          submittedBy: 'Chris Brizzolara',
          modifiedBy: 'Chris Brizzolara',
          contentType: '1',
          submissionStatus: '5'
        },
        {
          id: 7,
          submissionFormData: {
            isrc: 'LIUYF5678908',
            notes: 'Tech specification - pending',
            artist: 'Kate',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Complete Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Milton', 'James'],
                types: ['Versus', 'And']
              }
            ],
            version: 'version10',
            explicit: true,
            composers: ['Robert'],
            directors: ['Henry'],
            fileItems: [
              {
                filename: 'BET.mxf',
                filetype: 'mxf'
              },
              {
                filename: 'BETDOC.doc',
                filetype: 'doc'
              },
              {
                filename: 'DMI.pdf',
                filetype: 'pdf'
              },
              {
                filename: 'DMISTL.stl',
                filetype: 'stl'
              }
            ],
            albumTitle: 'Wolf- Track',
            publishers: ['Hanks'],
            trackTitle: 'Wolf Feat',
            parentLabel: 'Warner Music Group',
            recordLabel: 'Universal',
            albumReleaseDate: '2017-11-08T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2014',
            countryOfProduction: 'Austria',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'American Samoa',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2018-01-02T18:30:00.000Z',
          modifiedDate: '06/12/2017 00:00:00',
          submittedBy: 'Chris Brizzolara',
          modifiedBy: 'Chris Brizzolara',
          contentType: '1',
          submissionStatus: '8'
        },
        {
          id: 10,
          submissionFormData: {
            isrc: '123456789123',
            notes: 'Pending-QC ',
            artist: 'Kennet',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Pending QC',
            statusDetail: '',
            artists: [
              {
                names: ['Henry'],
                types: ['And']
              }
            ],
            version: 'version1',
            explicit: true,
            composers: ['Jeni'],
            directors: ['Flor'],
            fileItems: [
              {
                filename: 'BET.mxf',
                filetype: 'mxf'
              },
              {
                filename: 'BETDOC.doc',
                filetype: 'doc'
              },
              {
                filename: 'DMI.pdf',
                filetype: 'pdf'
              },
              {
                filename: 'DMISTL.stl',
                filetype: 'stl'
              }
            ],
            albumTitle: 'Alive-Theme',
            publishers: ['Loritha'],
            trackTitle: 'Person alive',
            parentLabel: 'Sony Music',
            recordLabel: 'Universal',
            albumReleaseDate: '2016-11-06T18:30:00.000Z',
            originalLanguage: 'Spanish',
            yearOfProduction: '2016',
            countryOfProduction: 'Åland Islands',
            videoCountryOfOrigin: 'Katy On A Mission',
            artistCountryOfOrigin: 'American Samoa',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2017-01-07T18:30:00.000Z',
          modifiedDate: '06/12/2017 00:00:00',
          submittedBy: 'Chris Brizzolara',
          modifiedBy: 'Chris Brizzolara',
          contentType: '1',
          submissionStatus: '4'
        },
        {
          id: 5,
          submissionFormData: {
            isrc: 'KJHGCV567893',
            notes: 'Metadata review',
            artist: 'Johny',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Pending Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Tom', 'Andrew'],
                types: ['Featuring', 'And']
              }
            ],
            version: 'version091',
            explicit: true,
            composers: ['Karl', 'Kennet'],
            directors: ['Andrew'],
            fileItems: [
              {
                filename: 'BET.mxf',
                filetype: 'mxf'
              },
              {
                filename: 'BETDOC.doc',
                filetype: 'doc'
              },
              {
                filename: 'DMI.pdf',
                filetype: 'pdf'
              },
              {
                filename: 'DMISTL.stl',
                filetype: 'stl'
              }
            ],
            albumTitle: 'Swan Songs',
            publishers: ['Jenney'],
            trackTitle: 'Ode to the Bouncer',
            parentLabel: 'Warner Music Group',
            recordLabel: 'Universal',
            albumReleaseDate: '2016-11-15T18:30:00.000Z',
            originalLanguage: 'Spanish',
            yearOfProduction: '2013',
            countryOfProduction: 'Angola',
            videoCountryOfOrigin: 'Katy On A Mission',
            artistCountryOfOrigin: 'Australia',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2017-04-07T18:30:00.000Z',
          modifiedDate: '06/12/2017 16:00:00',
          submittedBy: 'Ryan john',
          modifiedBy: 'Ryan john',
          contentType: '1',
          submissionStatus: '6'
        },
        {
          id: 6,
          submissionFormData: {
            isrc: 'IUYTRD567891',
            notes: 'Delivered to mediator',
            artist: 'Jenifer',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Failed',
            statusDetail: 'Metadata is Incorrect',
            artists: [
              {
                names: ['Kevin'],
                types: ['Featuring']
              }
            ],
            version: 'version19',
            explicit: true,
            composers: ['Harris'],
            directors: ['Lawrence'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Kann- Release',
            publishers: ['Matt', 'Demon'],
            trackTitle: 'Ein Herz Kann',
            parentLabel: 'Sony Music',
            recordLabel: 'Universal',
            albumReleaseDate: '2016-11-15T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2013',
            countryOfProduction: 'Algeria',
            videoCountryOfOrigin: 'Katy On A Mission',
            artistCountryOfOrigin: 'American Samoa',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2017-01-01T18:30:00.000Z',
          modifiedDate: '06/12/2017 00:00:00',
          submittedBy: 'Ryan john',
          modifiedBy: 'Ryan john',
          contentType: '1',
          submissionStatus: '9'
        },
        {
          id: 15,
          submissionFormData: {
            isrc: '12345678901j-',
            notes: 'Tech specification - ok',
            artist: 'Selena Gomez',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'In Progress Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Kygo'],
                types: ['And', 'Featuring']
              }
            ],
            version: 'Version2.2',
            explicit: false,
            composers: ['vevo music'],
            directors: ['Albert'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Stargazing',
            publishers: ['James', 'Kennet'],
            trackTitle: 'It aint me',
            parentLabel: 'Universal Music Group',
            recordLabel: 'Universal',
            albumReleaseDate: '2016-11-08T18:30:00.000Z',
            originalLanguage: 'Bahasa Malay',
            yearOfProduction: '2003',
            countryOfProduction: 'Austria',
            artistCountryOfOrigin: 'Australia',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2017-08-19T18:30:00.000Z',
          modifiedDate: '06/12/2017 00:00:00',
          submittedBy: 'Ryan john',
          modifiedBy: 'Ryan john',
          contentType: '1',
          submissionStatus: '7'
        },
        {
          id: 9,
          submissionFormData: {
            isrc: 'DFG46789F67B',
            notes: 'QC is Pending',
            artist: 'Rannie',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Pending QC',
            statusDetail: '',
            artists: [
              {
                names: ['Kevin'],
                types: ['Featuring']
              }
            ],
            version: 'version1256',
            explicit: true,
            composers: ['Cammeron', 'Hanks'],
            directors: ['Jenney'],
            fileItems: [
              {
                filename: 'BET.mxf',
                filetype: 'mxf'
              },
              {
                filename: 'BETDOC.doc',
                filetype: 'doc'
              },
              {
                filename: 'DMI.pdf',
                filetype: 'pdf'
              },
              {
                filename: 'DMISTL.stl',
                filetype: 'stl'
              }
            ],
            albumTitle: 'Winter flower- Theme',
            publishers: ['David'],
            trackTitle: 'Winter flower',
            parentLabel: 'Universal Music Group',
            recordLabel: 'Universal',
            albumReleaseDate: '2016-11-07T18:30:00.000Z',
            originalLanguage: 'Spanish',
            yearOfProduction: '2002',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2017-07-09T18:30:00.000Z',
          modifiedDate: '06/12/2017 00:00:00',
          submittedBy: 'Ryan john',
          modifiedBy: 'Ryan john',
          contentType: '1',
          submissionStatus: '4'
        },
        {
          id: 11,
          submissionFormData: {
            isrc: '1234567890KL',
            notes: 'Failed',
            artist: 'James',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'In Progress Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Kevin'],
                types: ['Featuring']
              }
            ],
            version: 'version98',
            explicit: true,
            composers: ['Canny', 'Albert'],
            directors: ['Cameron'],
            fileItems: [
              {
                filename: 'BET.mxf',
                filetype: 'mxf'
              },
              {
                filename: 'BETDOC.doc',
                filetype: 'doc'
              },
              {
                filename: 'DMI.pdf',
                filetype: 'pdf'
              },
              {
                filename: 'DMISTL.stl',
                filetype: 'stl'
              }
            ],
            albumTitle: 'Viacom Theme ',
            publishers: ['Kennet'],
            trackTitle: 'Viacom Music',
            parentLabel: 'Universal Music Group',
            recordLabel: 'Universal',
            albumReleaseDate: '2016-11-15T18:30:00.000Z',
            originalLanguage: 'Spanish',
            yearOfProduction: '2015',
            countryOfProduction: 'Albania',
            videoCountryOfOrigin: '',
            artistCountryOfOrigin: 'Albania',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2017-08-10T18:30:00.000Z',
          modifiedDate: '06/12/2017 00:00:00',
          submittedBy: 'Ryan john',
          modifiedBy: 'Ryan john',
          contentType: '1',
          submissionStatus: '7'
        },
        {
          id: 16,
          submissionFormData: {
            isrc: '12344fffffg-0',
            notes: 'Ingest is Pending',
            artist: 'Henry',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Pending Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Kevin'],
                types: ['Featuring']
              }
            ],
            version: 'version181',
            explicit: false,
            composers: ['Musaib'],
            directors: ['Dan'],
            fileItems: [
              {
                filename: 'BET.mxf',
                filetype: 'mxf'
              },
              {
                filename: 'BETDOC.doc',
                filetype: 'doc'
              },
              {
                filename: 'DMI.pdf',
                filetype: 'pdf'
              },
              {
                filename: 'DMISTL.stl',
                filetype: 'stl'
              }
            ],
            albumTitle: 'Loser- Theme',
            publishers: ['Kann'],
            trackTitle: 'Loser',
            parentLabel: 'Sony Music',
            recordLabel: 'Universal',
            albumReleaseDate: '2016-11-15T18:30:00.000Z',
            originalLanguage: 'Albanian',
            yearOfProduction: '2017',
            countryOfProduction: 'American Samoa',
            artistCountryOfOrigin: 'American Samoa',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2017-11-11T18:30:00.000Z',
          modifiedDate: '06/12/2017 00:00:00',
          submittedBy: 'Micheal Aldana',
          modifiedBy: 'Micheal Aldana',
          contentType: '1',
          submissionStatus: '6'
        },
        {
          id: 3,
          submissionFormData: {
            isrc: 'EDTFY456789',
            notes: 'Asset upload Failed',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Failed',
            statusDetail: 'Metadata is Incorrect',
            artists: [
              {
                names: ['Harris', 'James', 'Dan'],
                types: ['Versus', 'And', 'Versus']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Basketball-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Basketball wives la season 3 episode 2',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2015-11-16T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2017-12-20T18:30:00.000Z',
          modifiedDate: '09/12/2017 12:00:00',
          submittedBy: 'Micheal Aldana',
          modifiedBy: 'Micheal Aldana',
          contentType: '1',
          submissionStatus: '4'
        },
        {
          id: 1,
          submissionFormData: {
            isrc: 'JIMFY456789',
            notes: 'Asset upload complete',
            artist: 'Karthik',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Complete Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Harris', 'James', 'Dan'],
                types: ['Versus', 'And', 'Versus']
              }
            ],
            version: 'version121',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Deas-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Dead war',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2015-11-16T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2012',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2017-05-19T18:30:00.000Z',
          modifiedDate: '06/12/2017 12:00:00',
          submittedBy: 'Micheal Aldana',
          modifiedBy: 'Micheal Aldana',
          contentType: '1',
          submissionStatus: '3'
        },
        {
          id: 2,
          submissionFormData: {
            isrc: 'UIHJY456781',
            notes: 'Asset upload complete',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Complete Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Harris', 'James', 'Dan'],
                types: ['Versus', 'And', 'Versus']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Evil-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Evil Dead',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2015-11-16T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2017-02-19T18:30:00.000Z',
          modifiedDate: '06/12/2017 12:00:00',
          submittedBy: 'Jason Fresta',
          modifiedBy: 'Jason Fresta',
          contentType: '1',
          submissionStatus: '9'
        },
        {
          id: 4,
          submissionFormData: {
            isrc: 'LDTFY456783',
            notes: 'Asset upload complete',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Complete Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Harris', 'James', 'Dan'],
                types: ['Versus', 'And', 'Versus']
              }
            ],
            version: 'version101',
            explicit: false,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Amen #509 miracles to happen-Teaser',
            publishers: ['James'],
            trackTitle: 'Amen #509 miracles to happen',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2014-11-13T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2017-01-12T18:30:00.000Z',
          modifiedDate: '12/12/2017 12:00:00',
          submittedBy: 'Jason Fresta',
          modifiedBy: 'Jason Fresta',
          contentType: '1',
          submissionStatus: '4'
        },
        {
          id: 12,
          submissionFormData: {
            isrc: 'NITFY456789',
            notes: 'Awaiting Elements',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Awaiting Elements',
            statusDetail: 'Technical Specification is not verified',
            artists: [
              {
                names: ['Harris', 'James', 'Dan'],
                types: ['Versus', 'And', 'Versus']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra', 'Daniel'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Dhoni-Teaser',
            publishers: ['Karl'],
            trackTitle: 'Dhoni- The unbeatable man',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2014-11-19T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2017-10-16T18:30:00.000Z',
          modifiedDate: '13/12/2017 12:00:00',
          submittedBy: 'Jason Fresta',
          modifiedBy: 'Jason Fresta',
          contentType: '1',
          submissionStatus: '8'
        },
        {
          id: 13,
          submissionFormData: {
            isrc: 'KJIOY456780',
            notes: 'Pending QC',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Pending QC',
            statusDetail: '',
            artists: [
              {
                names: ['Harris', 'James', 'Dan'],
                types: ['Versus', 'And', 'Versus']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Terminator-Teaser',
            publishers: ['Jeni'],
            trackTitle: '16 and pregnant season 1 where are they now',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2014-11-16T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2017-04-21T18:30:00.000Z',
          modifiedDate: '06/12/2017 12:00:00',
          submittedBy: 'Jason Fresta',
          modifiedBy: 'Jason Fresta',
          contentType: '1',
          submissionStatus: '8'
        },
        {
          id: 14,
          submissionFormData: {
            isrc: 'JIOFY456789',
            notes: 'Asset upload complete',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Complete Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Harris', 'James', 'Dan'],
                types: ['Versus', 'And', 'Versus']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Titanic-Teaser',
            publishers: ['James'],
            trackTitle: 'Titanic',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-02T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-11-19T18:30:00.000Z',
          modifiedDate: '14/12/2017 12:00:00',
          submittedBy: 'Licogo Pulido',
          modifiedBy: 'Licogo Pulido',
          contentType: '1',
          submissionStatus: '6'
        },
        {
          id: 17,
          submissionFormData: {
            isrc: 'TYUIY456789',
            notes: 'Asset upload complete',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Complete Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Harris', 'James', 'Dan'],
                types: ['Versus', 'And', 'Versus']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Sheep-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'I see sheep fall from the sky',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-16T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-11-19T18:30:00.000Z',
          modifiedDate: '06/12/2017 12:00:00',
          submittedBy: 'Licogo Pulido',
          modifiedBy: 'Licogo Pulido',
          contentType: '1',
          submissionStatus: '8'
        },
        {
          id: 18,
          submissionFormData: {
            isrc: 'WYIDN456773',
            notes: 'Asset upload pending',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'In Progress Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Harris', 'James', 'Dan'],
                types: ['Versus', 'And', 'Versus']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Exam-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Exam',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-16T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-11-21T18:30:00.000Z',
          modifiedDate: '06/12/2017 12:00:00',
          submittedBy: 'Licogo Pulido',
          modifiedBy: 'Licogo Pulido',
          contentType: '1',
          submissionStatus: '4'
        },
        {
          id: 19,
          submissionFormData: {
            isrc: 'PYUIY456712',
            notes: 'Asset upload Failed',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Failed',
            statusDetail: 'Metadata is Incorrect',
            artists: [
              {
                names: ['James'],
                types: ['Versus']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Batman-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Batman',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-01T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-11-21T18:30:00.000Z',
          modifiedDate: '10/12/2017 12:00:00',
          submittedBy: 'Licogo Pulido',
          modifiedBy: 'Licogo Pulido',
          contentType: '1',
          submissionStatus: '9'
        },
        {
          id: 20,
          submissionFormData: {
            isrc: 'NJKIY456789',
            notes: 'Asset upload Failed',
            artist: 'Harris',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Failed',
            statusDetail: 'Metadata is Incorrect',
            artists: [
              {
                names: ['James'],
                types: ['Versus']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Superman-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Superman',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-06T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: true
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-11-21T18:30:00.000Z',
          modifiedDate: '11/12/2017 12:00:00',
          submittedBy: 'Licogo Pulido',
          modifiedBy: 'Licogo Pulido',
          contentType: '1',
          submissionStatus: '5'
        },
        {
          id: 21,
          submissionFormData: {
            isrc: 'TYUIY456711',
            notes: 'Pending Ingest',
            artist: 'Imman',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Pending Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['James'],
                types: ['Versus']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Spiderman-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Spiderman',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-19T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-01T18:30:00.000Z',
          modifiedDate: '16/12/2017 12:00:00',
          submittedBy: 'Licogo Pulido',
          modifiedBy: 'Licogo Pulido',
          contentType: '1',
          submissionStatus: '3'
        },
        {
          id: 22,
          submissionFormData: {
            isrc: 'QYNIY456789',
            notes: 'Asset upload pending',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Pending QC',
            statusDetail: '',
            artists: [
              {
                names: ['James'],
                types: ['Versus']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Power Rangers-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Power Rangers',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-12T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-01T18:30:00.000Z',
          modifiedDate: '11/12/2017 12:00:00',
          submittedBy: 'Licogo Pulido',
          modifiedBy: 'Licogo Pulido',
          contentType: '1',
          submissionStatus: '5'
        },
        {
          id: 23,
          submissionFormData: {
            isrc: 'MYUIY456701',
            notes: 'Asset upload complete',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Complete Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['James'],
                types: ['Versus']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Love the pain-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Love the pain',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2014-11-16T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-01T18:30:00.000Z',
          modifiedDate: '16/12/2017 12:00:00',
          submittedBy: 'Media services workflow',
          modifiedBy: 'Media services workflow',
          contentType: '1',
          submissionStatus: '8'
        },
        {
          id: 24,
          submissionFormData: {
            isrc: 'ASUIY456789',
            notes: 'Pending QC',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Pending QC',
            statusDetail: '',
            artists: [
              {
                names: ['James'],
                types: ['Versus']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Interstellar-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Interstellar',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2013-11-21T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-01T18:30:00.000Z',
          modifiedDate: '11/12/2017 12:00:00',
          submittedBy: 'Media services workflow',
          modifiedBy: 'Media services workflow',
          contentType: '1',
          submissionStatus: '6'
        },
        {
          id: 25,
          submissionFormData: {
            isrc: 'JKUIY456789',
            notes: 'Asset upload complete',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Complete Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['James'],
                types: ['Versus']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Inception-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Inception',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-27T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-01T18:30:00.000Z',
          modifiedDate: '08/12/2017 12:00:00',
          submittedBy: 'Media services workflow',
          modifiedBy: 'Media services workflow',
          contentType: '1',
          submissionStatus: '7'
        },
        {
          id: 26,
          submissionFormData: {
            isrc: 'JKLIY456789',
            notes: 'Asset upload complete',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Complete Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['James'],
                types: ['Versus']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Conjuring-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Conjuring',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2014-11-11T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-01T18:30:00.000Z',
          modifiedDate: '09/12/2017 12:00:00',
          submittedBy: 'Media services workflow',
          modifiedBy: 'Media services workflow',
          contentType: '1',
          submissionStatus: '7'
        },
        {
          id: 27,
          submissionFormData: {
            isrc: 'LKLIY456789',
            notes: 'Asset upload complete',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Complete Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Andrea'],
                types: ['And']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Conjuring-2-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Conjuring-2',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-12T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-01T18:30:00.000Z',
          modifiedDate: '19/11/2017 12:00:00',
          submittedBy: 'Media services workflow',
          modifiedBy: 'Media services workflow',
          contentType: '1',
          submissionStatus: '7'
        },
        {
          id: 28,
          submissionFormData: {
            isrc: 'MIOIY456789',
            notes: 'Asset upload complete',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Complete Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Andrea'],
                types: ['And']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Despicable-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Despicable',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2014-11-28T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-01T18:30:00.000Z',
          modifiedDate: '09/12/2017 12:00:00',
          submittedBy: 'Media services workflow',
          modifiedBy: 'Media services workflow',
          contentType: '1',
          submissionStatus: '7'
        },
        {
          id: 28,
          submissionFormData: {
            isrc: 'OPLIY456789',
            notes: 'In Progress Ingest',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'In Progress Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Andrea'],
                types: ['And']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Despicable-2-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Despicable-2',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-11T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-14T18:30:00.000Z',
          modifiedDate: '10/12/2017 12:00:00',
          submittedBy: 'John Wolowoski',
          modifiedBy: 'John Wolowoski',
          contentType: '1',
          submissionStatus: '6'
        },
        {
          id: 29,
          submissionFormData: {
            isrc: 'PKLIY456789',
            notes: 'In Progress Ingest',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'In Progress Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Andrea'],
                types: ['And']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Journey to the land-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Journey to the land',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-11T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-14T18:30:00.000Z',
          modifiedDate: '10/12/2017 12:00:00',
          submittedBy: 'John Wolowoski',
          modifiedBy: 'John Wolowoski',
          contentType: '1',
          submissionStatus: '6'
        },
        {
          id: 30,
          submissionFormData: {
            isrc: 'ALLIY456789',
            notes: 'Asset upload Failed',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Failed',
            statusDetail: 'Metadata is Incorrect',
            artists: [
              {
                names: ['Andrea'],
                types: ['And']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Plan-A-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Plan-A',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-11T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-14T18:30:00.000Z',
          modifiedDate: '09/12/2017 12:00:00',
          submittedBy: 'John Wolowoski',
          modifiedBy: 'John Wolowoski',
          contentType: '1',
          submissionStatus: '6'
        },
        {
          id: 31,
          submissionFormData: {
            isrc: 'FGGJY456789',
            notes: 'Asset upload Failed',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Failed',
            statusDetail: 'Metadata is Incorrect',
            artists: [
              {
                names: ['Andrea'],
                types: ['And']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'War Land-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'War Land',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-11T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-14T18:30:00.000Z',
          modifiedDate: '06/12/2017 12:00:00',
          submittedBy: 'John Wolowoski',
          modifiedBy: 'John Wolowoski',
          contentType: '1',
          submissionStatus: '7'
        },
        {
          id: 32,
          submissionFormData: {
            isrc: 'GJLIY456789',
            notes: 'Asset upload pending',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'In Progress Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Kennet'],
                types: ['Featuring']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'War and Peace-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'War and Peace',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-17T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-14T18:30:00.000Z',
          modifiedDate: '09/12/2017 12:00:00',
          submittedBy: 'John Wolowoski',
          modifiedBy: 'John Wolowoski',
          contentType: '1',
          submissionStatus: '7'
        },
        {
          id: 33,
          submissionFormData: {
            isrc: 'H8LIY456789',
            notes: 'Asset upload Failed',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Failed',
            statusDetail: 'Metadata is Incorrect',
            artists: [
              {
                names: ['Kennet'],
                types: ['Featuring']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Greater America-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Greater America',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-11T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-14T18:30:00.000Z',
          modifiedDate: '09/12/2017 12:00:00',
          submittedBy: 'John Wolowoski',
          modifiedBy: 'John Wolowoski',
          contentType: '1',
          submissionStatus: '4'
        },
        {
          id: 34,
          submissionFormData: {
            isrc: 'FTUIY456789',
            notes: 'Asset upload complete',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Complete Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Kennet'],
                types: ['Featuring']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Odd Love-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Odd Love',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-11T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-14T18:30:00.000Z',
          modifiedDate: '07/12/2017 12:00:00',
          submittedBy: 'John Wolowoski',
          modifiedBy: 'John Wolowoski',
          contentType: '1',
          submissionStatus: '7'
        },
        {
          id: 35,
          submissionFormData: {
            isrc: 'POLIY456757',
            notes: 'Asset upload complete',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Failed',
            statusDetail: 'Metadata is Incorrect',
            artists: [
              {
                names: ['Kennet'],
                types: ['Featuring']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Peace-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Peace',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-11T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-14T18:30:00.000Z',
          modifiedDate: '09/12/2017 12:00:00',
          submittedBy: 'John Wolowoski',
          modifiedBy: 'John Wolowoski',
          contentType: '1',
          submissionStatus: '7'
        },
        {
          id: 36,
          submissionFormData: {
            isrc: 'LISIY456757',
            notes: 'Asset upload complete',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Failed',
            statusDetail: 'Metadata is Incorrect',
            artists: [
              {
                names: ['Kennet'],
                types: ['Featuring']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Happy Doll-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Happy Doll',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-14T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-27T18:30:00.000Z',
          modifiedDate: '09/12/2017 12:00:00',
          submittedBy: 'Justin T',
          modifiedBy: 'Justin T',
          contentType: '1',
          submissionStatus: '7'
        },
        {
          id: 37,
          submissionFormData: {
            isrc: 'MNHIY456757',
            notes: 'Asset upload complete',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Failed',
            statusDetail: 'Metadata is Incorrect',
            artists: [
              {
                names: ['Kennet'],
                types: ['Featuring']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Godfather-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Godfather',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-25T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-27T18:30:00.000Z',
          modifiedDate: '04/12/2017 12:00:00',
          submittedBy: 'Justin T',
          modifiedBy: 'Justin T',
          contentType: '1',
          submissionStatus: '3'
        },
        {
          id: 38,
          submissionFormData: {
            isrc: 'RTLIY456757',
            notes: 'Asset upload complete',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'In Progress Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Kennet'],
                types: ['Featuring']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Animal Kingdom-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Animal Kingdom',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-01T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-27T18:30:00.000Z',
          modifiedDate: '07/12/2017 12:00:00',
          submittedBy: 'Justin T',
          modifiedBy: 'Justin T',
          contentType: '1',
          submissionStatus: '4'
        },
        {
          id: 39,
          submissionFormData: {
            isrc: 'HISIY456757',
            notes: 'Asset upload Pending',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Pending Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['David'],
                types: ['Featuring']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Superman Vs Batman-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Superman Vs Batman',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-11T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-27T18:30:00.000Z',
          modifiedDate: '10/12/2017 12:00:00',
          submittedBy: 'Sony Music',
          modifiedBy: 'Sony Music',
          contentType: '1',
          submissionStatus: '3'
        },
        {
          id: 40,
          submissionFormData: {
            isrc: 'GUIDY456757',
            notes: 'Asset upload complete',
            artist: 'Yuvan',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Failed',
            statusDetail: 'Metadata is Incorrect',
            artists: [
              {
                names: ['Kennet'],
                types: ['Featuring']
              }
            ],
            version: 'version101',
            explicit: true,
            composers: ['Kindra'],
            directors: ['James Cameron'],
            fileItems: [
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              },
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'Surviva-Teaser',
            publishers: ['Wolf fEAT'],
            trackTitle: 'Midnight with chris hardwick - Series | Comedy Central',
            parentLabel: 'Universal Music Group',
            recordLabel: 'UniversalLabel',
            albumReleaseDate: '2017-11-23T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2004',
            countryOfProduction: 'Bahamas',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'Algeria',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2016-12-27T18:30:00.000Z',
          modifiedDate: '10/12/2017 12:00:00',
          submittedBy: 'Sony Music',
          modifiedBy: 'Sony Music',
          contentType: '1',
          submissionStatus: '4'
        }
      ]
    };
    this.MOCK_DATA_CHUNK = {
      startRecord: 1,
      resultList: [
        {
          id: 8,
          submissionFormData: {
            isrc: 'ISWSK7899998',
            notes: 'Metadata received',
            artist: 'Hollywood Undead',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Awaiting Elements',
            statusDetail: 'Technical Specification is not verified',
            artists: [
              {
                names: ['Daniel', 'Jenifer'],
                types: ['And', 'Featuring']
              }
            ],
            version: 'version66',
            explicit: true,
            composers: ['Bruise', 'Brenn'],
            directors: ['Murillo'],
            fileItems: [
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'American Tragedy',
            publishers: ['Dan Gilmore'],
            trackTitle: 'Apologize',
            parentLabel: 'Sony Music',
            recordLabel: 'Universal',
            albumReleaseDate: '2017-11-08T18:30:00.000Z',
            originalLanguage: 'Spanish',
            yearOfProduction: '2014',
            countryOfProduction: 'Angola',
            videoCountryOfOrigin: 'Katy On A Mission',
            artistCountryOfOrigin: 'Antarctica',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '2017-09-27T18:30:00.000Z',
          modifiedDate: '06/12/2017 00:00:00',
          submittedBy: 'Chris Brizzolara',
          modifiedBy: 'Chris Brizzolara',
          contentType: '1',
          submissionStatus: '5'
        }
      ]
    };
    this.MOCK_RESPONSE_CHUNK = {
      startRecord: 1,
      resultList: [
        {
          id: 8,
          submissionFormData: {
            isrc: 'ISWSK7899998',
            notes: 'Metadata received',
            artist: 'Hollywood Undead',
            rights: [
              {
                platform: [['', 'TVVOD', 'LTV'], ''],
                availableOn: ['2017-11-15T18:30:00.000Z', ''],
                territories: [['', 'WW', 'NT'], '']
              }
            ],
            status: 'Awaiting Elements',
            statusDetail: 'Technical Specification is not verified',
            artists: [
              {
                names: ['Daniel', ''],
                types: ['And', '']
              }
            ],
            version: 'version66',
            explicit: true,
            composers: ['Bruise', 'Brenn'],
            directors: ['Murillo'],
            fileItems: [
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'American Tragedy',
            publishers: ['Dan Gilmore'],
            trackTitle: 'Apologize',
            parentLabel: 'Sony Music',
            recordLabel: 'Universal',
            albumReleaseDate: '2017-11-08T18:30:00.000Z',
            originalLanguage: 'Spanish',
            yearOfProduction: '2014',
            countryOfProduction: 'Angola',
            videoCountryOfOrigin: 'Katy On A Mission',
            artistCountryOfOrigin: 'Antarctica',
            allowViacomComplianceEdit: false
          },
          submittedDate: '06/12/2017 00:00:00',
          modifiedDate: '06/12/2017 00:00:00',
          submittedBy: 'Admin',
          modifiedBy: 'Admin',
          contentType: '1',
          submissionStatus: 'AWAITINGELEMENTS'
        }
      ]
    };
    this.MOCK_DATE_RANGE_DATA = {
      startRecord: 1,
      resultList: [
        {
          id: 8,
          submissionFormData: {
            isrc: 'ISWSK7899998',
            notes: 'Metadata received',
            artist: 'Hollywood Undead',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Awaiting Elements',
            statusDetail: 'Technical Specification is not verified',
            artists: [
              {
                names: ['Daniel', 'Jenifer'],
                types: ['And', 'Featuring']
              }
            ],
            version: 'version66',
            explicit: true,
            composers: ['Bruise', 'Brenn'],
            directors: ['Murillo'],
            fileItems: [
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'American Tragedy',
            publishers: ['Dan Gilmore'],
            trackTitle: 'Apologize',
            parentLabel: 'Sony Music',
            recordLabel: 'Universal',
            albumReleaseDate: '2017-11-08T18:30:00.000Z',
            originalLanguage: 'Spanish',
            yearOfProduction: '2014',
            countryOfProduction: 'Angola',
            videoCountryOfOrigin: 'Katy On A Mission',
            artistCountryOfOrigin: 'Antarctica',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '06/12/2017 00:00:00',
          modifiedDate: '06/12/2017 00:00:00',
          submittedBy: 'Chris Brizzolara',
          modifiedBy: 'Chris Brizzolara',
          contentType: '1',
          submissionStatus: '5'
        },
        {
          id: 7,
          submissionFormData: {
            isrc: 'LIUYF5678908',
            notes: 'Tech specification - pending',
            artist: 'Kate',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Complete Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Milton', 'James'],
                types: ['Versus', 'And']
              }
            ],
            version: 'version10',
            explicit: true,
            composers: ['Robert'],
            directors: ['Henry'],
            fileItems: [
              {
                filename: 'BET.mxf',
                filetype: 'mxf'
              },
              {
                filename: 'BETDOC.doc',
                filetype: 'doc'
              },
              {
                filename: 'DMI.pdf',
                filetype: 'pdf'
              },
              {
                filename: 'DMISTL.stl',
                filetype: 'stl'
              }
            ],
            albumTitle: 'Wolf- Track',
            publishers: ['Hanks'],
            trackTitle: 'Wolf Feat',
            parentLabel: 'Warner Music Group',
            recordLabel: 'Universal',
            albumReleaseDate: '2017-11-08T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2014',
            countryOfProduction: 'Austria',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'American Samoa',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '06/12/2017 00:00:00',
          modifiedDate: '06/12/2017 00:00:00',
          submittedBy: 'Chris Brizzolara',
          modifiedBy: 'Chris Brizzolara',
          contentType: '1',
          submissionStatus: '8'
        },
        {
          id: 6,
          submissionFormData: {
            isrc: 'LIUYF5678908',
            notes: 'Tech specification - pending',
            artist: 'Kate',
            rights: [
              {
                platform: [['TVVOD', 'LTV'], ['WIVOD']],
                availableOn: ['2017-11-15T18:30:00.000Z', '2017-11-17T18:30:00.000Z'],
                territories: [['WW', 'NT'], ['DZ']]
              }
            ],
            status: 'Complete Ingest',
            statusDetail: '',
            artists: [
              {
                names: ['Milton', 'James'],
                types: ['Versus', 'And']
              }
            ],
            version: 'version10',
            explicit: true,
            composers: ['Robert'],
            directors: ['Henry'],
            fileItems: [
              {
                filename: 'BET.mxf',
                filetype: 'mxf'
              },
              {
                filename: 'BETDOC.doc',
                filetype: 'doc'
              },
              {
                filename: 'DMI.pdf',
                filetype: 'pdf'
              },
              {
                filename: 'DMISTL.stl',
                filetype: 'stl'
              }
            ],
            albumTitle: 'Wolf- Track',
            publishers: ['Hanks'],
            trackTitle: 'Wolf Feat',
            parentLabel: 'Warner Music Group',
            recordLabel: 'Universal',
            albumReleaseDate: '2014-11-08T18:30:00.000Z',
            originalLanguage: 'English',
            yearOfProduction: '2014',
            countryOfProduction: 'Austria',
            videoCountryOfOrigin: 'Cuba',
            artistCountryOfOrigin: 'American Samoa',
            allowViacomComplianceEdit: false
          },
          trackUrl: 'http://techslides.com/demos/sample-videos/small.mp4',
          submittedDate: '06/12/2017 00:00:00',
          modifiedDate: '06/12/2017 00:00:00',
          submittedBy: 'Chris Brizzolara',
          modifiedBy: 'Chris Brizzolara',
          contentType: '1',
          submissionStatus: '8'
        }
      ]
    };
    this.MOCK_RESPONSE_RECORD_COUNT = {
      startRecord: 1,
      resultList: [
        {
          id: 8,
          submissionFormData: {
            isrc: 'ISWSK7899998',
            notes: 'Metadata received',
            artist: 'Hollywood Undead',
            rights: [
              {
                platform: [['', 'TVVOD', 'LTV'], ''],
                availableOn: ['2017-11-15T18:30:00.000Z', ''],
                territories: [['', 'WW', 'NT'], '']
              }
            ],
            status: 'Awaiting Elements',
            statusDetail: 'Technical Specification is not verified',
            artists: [
              {
                names: ['Daniel', ''],
                types: ['And', '']
              }
            ],
            version: 'version66',
            explicit: true,
            composers: ['Bruise', 'Brenn'],
            directors: ['Murillo'],
            fileItems: [
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'American Tragedy',
            publishers: ['Dan Gilmore'],
            trackTitle: 'Apologize',
            parentLabel: 'Sony Music',
            recordLabel: 'Universal',
            albumReleaseDate: '2017-11-08T18:30:00.000Z',
            originalLanguage: 'Spanish',
            yearOfProduction: '2014',
            countryOfProduction: 'Angola',
            videoCountryOfOrigin: 'Katy On A Mission',
            artistCountryOfOrigin: 'Antarctica',
            allowViacomComplianceEdit: false
          },
          submittedDate: '06/12/2017 00:00:00',
          modifiedDate: '06/12/2017 00:00:00',
          submittedBy: 'Admin',
          modifiedBy: 'Admin',
          contentType: '1',
          submissionStatus: 'AWAITINGELEMENTS'
        }
      ]
    };
    this.MOCK_DATA_STATUS_CHECK = {
      startRecord: 1,
      resultList: [
        {
          id: 8,
          submissionFormData: {
            isrc: 'ISWSK7899998',
            notes: 'Metadata received',
            artist: 'Hollywood Undead',
            rights: [
              {
                platform: [['', 'TVVOD', 'LTV'], ''],
                availableOn: ['2017-11-15T18:30:00.000Z', ''],
                territories: [['', 'WW', 'NT'], '']
              }
            ],

            artists: [
              {
                names: ['Daniel', ''],
                types: ['And', '']
              }
            ],
            version: 'version66',
            explicit: true,
            composers: ['Bruise', 'Brenn'],
            directors: ['Murillo'],
            fileItems: [
              {
                filename: 'Too_Original.stl',
                filetype: 'stl'
              },
              {
                filename: 'Too_Original_subtitiles.doc.doc',
                filetype: 'doc'
              },
              {
                filename: 'I am Shasha Fierce.doc',
                filetype: 'doc'
              }
            ],
            albumTitle: 'American Tragedy',
            publishers: ['Dan Gilmore'],
            trackTitle: 'Apologize',
            parentLabel: 'Sony Music',
            recordLabel: 'Universal',
            albumReleaseDate: '2017-11-08T18:30:00.000Z',
            originalLanguage: 'Spanish',
            yearOfProduction: '2014',
            countryOfProduction: 'Angola',
            videoCountryOfOrigin: 'Katy On A Mission',
            artistCountryOfOrigin: 'Antarctica',
            allowViacomComplianceEdit: false
          },
          submittedDate: '06/12/2017 00:00:00',
          modifiedDate: '06/12/2017 00:00:00',
          submittedBy: 'Admin',
          modifiedBy: 'Admin',
          contentType: '1',
          submissionStatus: {
            code: 'PENDINGAPPROVAL',
            description: 'Pending Approval',
            longDescription: 'Pending Approval.',
            contentType: 'music-video'
          },
          statusDetail: 'Metadata is Incorrect'
        }
      ]
    };
  }
}
