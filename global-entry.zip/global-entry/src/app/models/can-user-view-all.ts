export interface CanUserViewAll {
  userInfo: adal.User;
  canViewAll: boolean;
}
