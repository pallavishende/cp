export interface ContentTypeStatusCount {
  code: string;
  description: string;
  count: string;
}
