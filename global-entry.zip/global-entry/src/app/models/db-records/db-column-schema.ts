import { DbGroupSchema } from './';

export interface DbColumnSchema {
  name: string;
  groups: DbGroupSchema[];
  columnWidth: number;
}
