import { DbValidatorSchema } from './';

export interface DbFieldSchema {
  name: string;
  type?: string;
  label?: string;
  order?: number;
  value?: string | { [key: string]: string }[];
  required?: boolean;
  validators?: DbValidatorSchema[];
  description?: string;
  placeholder?: string;
  options?: { key: string; value: string }[];
  columnWidth?: number;
  multiSelect?: boolean;
}
