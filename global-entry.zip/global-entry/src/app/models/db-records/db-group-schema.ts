import { DbFieldSchema } from './';

export interface DbGroupSchema {
  name: string;
  order: number;
  fields: DbFieldSchema[];
  collapseable: boolean;
}
