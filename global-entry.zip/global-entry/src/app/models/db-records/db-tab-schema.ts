import { DbColumnSchema } from './';

export interface DbTabSchema {
  name: string;
  columns: DbColumnSchema[];
}
