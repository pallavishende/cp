export interface DbValidatorSchema {
  pattern: string;
  required: boolean;
  maxLength: number;
  minLength: number;
}
