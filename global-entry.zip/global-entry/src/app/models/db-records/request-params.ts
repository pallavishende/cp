export interface RequestParams {
  contentType: string;
  page: number;
  size: number;
  status: string;
  sortColumn: string;
  sortDirection: string;
  fromDate: string;
  toDate: string;
  searchTerm: string;
  shared: string;
  email: string;
  region?: string[];
  admin: Boolean;
}
