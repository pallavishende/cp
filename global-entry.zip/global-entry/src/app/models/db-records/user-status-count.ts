export interface UserStatusCount {
  contentType: string;
  email: string;
  shared: string;
  admin?: Boolean;
}
