export interface CommentsListSchema {
  actionCode: string;
  commentId: string;
  commentText: string;
  createdDate: string;
  id: string;
  submissionId: string;
}

export interface CommentResponseSchema {
  resultList: CommentsListSchema[];
}
