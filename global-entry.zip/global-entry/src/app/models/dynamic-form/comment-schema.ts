export interface CommentSchema {
  commentText: string;
  actionCode: string;
  reviewedBy: string;
  reviewedUserEmail: string;
  metadataOnly?: boolean;
}
