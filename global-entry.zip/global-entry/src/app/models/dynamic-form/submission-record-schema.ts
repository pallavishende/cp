import { SubmissionStatus } from '@content-platform/submissions-api';
import { KeyValue } from '@content-platform/dynamic-forms-api';

export interface SubmissionRecordSchema {
  id: number;
  submissionFormData: KeyValue;
  submittedDate: string;
  modifiedDate: string;
  submittedBy: string;
  modifiedBy: string;
  contentType: string;
  submissionStatus: SubmissionStatus;
  metadata?: any;
}
