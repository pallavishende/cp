import { SortDirection } from '@angular/material';

export interface PageSortInput {
  type: string;
  status?: string;
  filterValue?: string;
  pageValue?: number;
  sortValue?: SortDirection;
}
