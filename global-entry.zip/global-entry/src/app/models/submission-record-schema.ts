import { SubmissionStatusSchema } from './submission-status-schema';

export interface SubmissionRecordSchema {
  id: number;
  submissionFormData: any;
  submittedDate: string;
  modifiedDate: string;
  submittedBy: string;
  modifiedBy: string;
  contentType: string;
  submissionStatus: SubmissionStatusSchema;
  previewUrl: string;
  metadata?: any;
  reviewed: boolean;
}
