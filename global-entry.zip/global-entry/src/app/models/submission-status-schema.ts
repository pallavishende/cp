export interface SubmissionStatusSchema {
  code: string;
  description: string;
  longDescription: string;
  contentType: string;
}
