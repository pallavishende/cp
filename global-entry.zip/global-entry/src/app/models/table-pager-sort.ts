export interface TablePagerSort {
  sortActive: string;
  sortDirection: string;
  pageIndex: number;
  pageSize: number;
}
