export interface ArtistsSchema {
  names: string[];
  types: string[];
}
