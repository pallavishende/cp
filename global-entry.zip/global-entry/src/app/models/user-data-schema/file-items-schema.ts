export interface FileItemsSchema {
  filename: string;
  filetype: string;
}
