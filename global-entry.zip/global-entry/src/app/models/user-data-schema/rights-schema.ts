export interface RightsSchema {
  platform: string[];
  availableOn: string[];
  territories: string[][];
}
