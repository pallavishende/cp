import { RightsSchema, ArtistsSchema, FileItemsSchema } from './';

export interface SubmissionFormDataSchema {
  isrc: string;
  notes: string;
  artist: string;
  rights: RightsSchema[];
  status: string;
  statusDetail: string;
  artists: ArtistsSchema[];
  version: string;
  explicit: boolean;
  composers: string[];
  directors: string[];
  fileItems: FileItemsSchema[];
  albumTitle: string;
  publishers: string[];
  trackTitle: string;
  parentLabel: string;
  recordLabel: string;
  albumReleaseDate: string;
  originalLanguage: string;
  yearOfProduction: string;
  countryOfProduction: string;
  videoCountryOfOrigin: string;
  artistCountryOfOrigin: string;
  allowViacomComplianceEdit: boolean;
}
