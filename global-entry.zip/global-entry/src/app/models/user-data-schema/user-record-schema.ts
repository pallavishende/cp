import { SubmissionFormDataSchema } from './';

export interface UserRecordSchema {
  id: number;
  submissionFormData: SubmissionFormDataSchema;
  trackUrl: string;
  submittedDate: string;
  modifiedDate: string;
  submittedBy: string;
  modifiedBy: string;
  contentType: string;
  submissionStatus: string;
}
