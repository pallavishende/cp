import { CanUserViewAll } from './can-user-view-all';
import { PermissionMetadata } from '@content-platform/application-api';

export interface UserRouteDetail {
  regions: PermissionMetadata[];
  canUserViewAll: CanUserViewAll;
  contentTypes: PermissionMetadata[];
}
