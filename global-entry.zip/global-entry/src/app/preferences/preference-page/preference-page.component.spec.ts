import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreferencePageComponent } from './preference-page.component';
import { MockComponent, MaterialMockModule } from '@content-platform/unit-test-helpers';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { StoreModule, combineReducers } from '@ngrx/store';
import { SubmissionService } from '../../services/submission.service';
import { ActivatedRoute } from '@angular/router';
import { dashboardReducer } from '../../submission/dashboard/store';
import { ContentHeaderBarService } from '@content-platform/navigation';
import { RouterTestingModule } from '@angular/router/testing';

describe('PreferencePageComponent', () => {
  let component: PreferencePageComponent;
  let fixture: ComponentFixture<PreferencePageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        MaterialMockModule,
        ReactiveFormsModule,
        FormsModule,
        RouterTestingModule,
        StoreModule.forRoot({ dashboard: combineReducers(dashboardReducer) })
      ],
      declarations: [
        PreferencePageComponent,
        MockComponent({ selector: 'app-content-header-bar', inputs: ['title'] })
      ],
      providers: [
        {
          provide: SubmissionService,
          useValue: {
            getOtherDate: () => new Date()
          }
        },
        {
          provide: ContentHeaderBarService,
          useValue: { setButtons: jest.fn() }
        },
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: {
              data: {
                userPreferences: {},
                userDetail: {
                  canUserViewAll: {
                    canViewAll: true
                  }
                }
              }
            }
          }
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreferencePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
