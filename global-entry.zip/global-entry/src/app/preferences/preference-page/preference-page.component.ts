import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ContentHeaderBarService, ContentHeaderButton } from '@content-platform/navigation';
import { UserPreferenceActions, userPreferenceSelectors } from '@content-platform/preferences-api';
import { SubmissionStatus } from '@content-platform/submissions-api';
import { Store, select } from '@ngrx/store';
import { isEqual, sortBy, orderBy, cloneDeep } from 'lodash';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';
import { UserStatusCount } from '../../models/db-records';
import { DashboardPreferences } from '../../submission/dashboard/dashboard-preferences.service';
import * as fromStore from '../../submission/dashboard/store';
import { LoadSubmissionStatus } from '../../submission/dashboard/store';
import { notificationActions, NotificationType } from '@content-platform/notifications';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';

export const EMAIL_NOTIFICATION_PREFERENCE_KEY = 'email-preferences';

@Component({
  selector: 'app-preference-page',
  templateUrl: './preference-page.component.html',
  styleUrls: ['./preference-page.component.scss']
})
export class PreferencePageComponent implements OnInit, OnDestroy {
  filteredSubmissionTypes$: Observable<SubmissionStatus[]>;
  submissionTypes: SubmissionStatus[] = [];
  originalSelectedSubmissionStatusTypes = [];
  selectedSubmissionStatusTypes = [];
  availableColumns = [];
  originalSelectedColumns = [];
  selectedColumns = [];
  allColumnsSelected = false;
  allTypesSelected = false;

  allEmailPreferencesSelected = false;
  savedEmailPreferences: Array<any> = [];
  emailPreferences: Array<any> = [];

  private saveDisabled = new BehaviorSubject<boolean>(true);
  private onDestroy = new Subject<void>();

  constructor(
    private store: Store<fromStore.DashboardState>,
    private actRoute: ActivatedRoute,
    private contentHeaderBarService: ContentHeaderBarService,
    private router: Router
  ) {
    // Dispatching LoadSubmissionStatus action
    this.store
      .pipe(
        select(userPreferenceSelectors.getCurrentUserAppPreferences),
        takeUntil(this.onDestroy)
      )
      .subscribe(userPreferences => {
        this.originalSelectedColumns = [
          ...(userPreferences[DashboardPreferences.ColumnFilters] || [])
        ];
        this.selectedColumns = [...this.originalSelectedColumns];
        this.availableColumns = [
          ...(userPreferences[DashboardPreferences.AvailableTableColumns] || [])
        ];
        this.originalSelectedSubmissionStatusTypes = [
          ...(userPreferences[DashboardPreferences.StatusFilters].filter(
            preference => preference !== 'APPROVED'
          ) || [])
        ];
        this.savedEmailPreferences = [...userPreferences[EMAIL_NOTIFICATION_PREFERENCE_KEY]];
        this.selectedSubmissionStatusTypes = [...this.originalSelectedSubmissionStatusTypes];
        this.allColumnsSelected = this.selectedColumns.length === this.availableColumns.length;
        this.allTypesSelected =
          this.submissionTypes.length === this.selectedSubmissionStatusTypes.length;
        this.emailPreferences = cloneDeep(this.savedEmailPreferences);
        this.checkChanges();
        this.calculateOverallEmailPreferenceValue();
      });
    this.store
      .pipe(
        select(fromStore.getRecordsSubmissionStatusState),
        filter(statuses => !!statuses && statuses.mySubmissions.length > 0),
        takeUntil(this.onDestroy)
      )
      .subscribe(statuses => {
        // Temp fix to ignore APPROVED status in preferences
        this.submissionTypes = [...statuses.mySubmissions].filter(
          status => status.code !== 'APPROVED'
        ) as SubmissionStatus[];
        this.allTypesSelected =
          this.submissionTypes.length === this.selectedSubmissionStatusTypes.length;
        this.checkChanges();
        this.calculateOverallEmailPreferenceValue();
      });
  }

  ngOnInit() {
    if (this.submissionTypes.length === 0) {
      const loggedInUser = this.actRoute.snapshot.data.userDetail.canUserViewAll.canViewAll;
      const submissionCountData: UserStatusCount = {
        contentType: 'music-video',
        email: loggedInUser,
        shared: ''
      };
      this.store.dispatch(new LoadSubmissionStatus(submissionCountData));
    }

    const contentHeaderButtons = [
      {
        name: 'CANCEL',
        onClick: () => {
          this.router.navigate(['..'], { relativeTo: this.actRoute });
        }
      },
      {
        name: 'SAVE',
        color: 'accent',
        type: 'flat',
        disabled$: this.saveDisabled.asObservable(),
        onClick: () => {
          this.savePreferences();
        }
      }
    ] as ContentHeaderButton[];
    this.contentHeaderBarService.setButtons(contentHeaderButtons);
  }

  isEditable(preference) {
    if (preference.hasOwnProperty('editable') && preference.editable === false) {
      return false;
    } else {
      return true;
    }
  }

  submissionDisplayFn(submission?: SubmissionStatus): string | undefined {
    if (!submission) {
      return '';
    }
    return submission.description;
  }
  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.availableColumns, event.previousIndex, event.currentIndex);
    this.availableColumns = this.availableColumns.map(entry => {
      return {
        name: entry.name,
        label: entry.label,
        order: this.availableColumns.indexOf(entry)
      };
    });
    this.saveDisabled.next(false);
  }
  updateStore(data) {
    this.store.dispatch(new UserPreferenceActions.Update(data));
  }

  getUserPref(key: string): any {
    return this.actRoute.snapshot.data.userPreferences[key];
  }

  isSelectedColumn(column: { name: string; label: string }): boolean {
    return !!this.selectedColumns.find(
      selColumn => selColumn.toLowerCase() === column.name.toLowerCase()
    );
  }

  selectingColumn(column: { name: string; label: string }): void {
    if (this.isSelectedColumn(column)) {
      this.selectedColumns = this.selectedColumns.filter(
        selColumn => selColumn.toLowerCase() !== column.name.toLowerCase()
      );
    } else {
      this.selectedColumns.push(column.name);
    }
    const columns = this.selectedColumns.map(element => {
      return this.availableColumns.find(column1 => column1.name === element);
    });
    this.selectedColumns = orderBy(columns, 'order', 'asc').map(column1 => column1.name);
    this.allColumnsSelected = this.selectedColumns.length === this.availableColumns.length;
    this.checkChanges();
  }

  selectingStatus(submission: SubmissionStatus): void {
    if (this.isSelectedStatus(submission)) {
      this.selectedSubmissionStatusTypes = this.selectedSubmissionStatusTypes.filter(
        status => status !== submission.code
      );
    } else {
      this.selectedSubmissionStatusTypes.push(submission.code);
    }
    this.allTypesSelected =
      this.submissionTypes.length === this.selectedSubmissionStatusTypes.length;
    this.checkChanges();
  }

  isSelectedStatus(submission: SubmissionStatus) {
    return !!this.selectedSubmissionStatusTypes.find(status => status === submission.code);
  }

  selectAllStatuses() {
    if (this.allTypesSelected) {
      this.selectedSubmissionStatusTypes = [];
    } else {
      this.selectedSubmissionStatusTypes = [...this.submissionTypes.map(type => type.code)];
    }
    this.allTypesSelected = !this.allTypesSelected;
    this.checkChanges();
  }

  selectAllColumns() {
    if (this.allColumnsSelected) {
      this.selectedColumns = [];
    } else {
      this.selectedColumns = [...this.availableColumns.map(c => c.name)];
    }
    this.allColumnsSelected = !this.allColumnsSelected;
    this.checkChanges();
  }

  checkChanges() {
    if (!isEqual(sortBy(this.originalSelectedColumns), sortBy(this.selectedColumns))) {
      this.saveDisabled.next(false);
    } else if (
      !isEqual(
        sortBy(this.originalSelectedSubmissionStatusTypes),
        sortBy(this.selectedSubmissionStatusTypes)
      )
    ) {
      this.saveDisabled.next(false);
    } else {
      this.saveDisabled.next(true);
    }
  }

  savePreferences() {
    // saving data in local till api is ready
    const data = {};
    if (this.selectedColumns.length > 0 && this.selectedSubmissionStatusTypes.length > 0) {
      data[DashboardPreferences.AvailableTableColumns] = this.availableColumns;
      data[DashboardPreferences.StatusFilters] = this.selectedSubmissionStatusTypes;
      data[DashboardPreferences.ColumnFilters] = this.selectedColumns;
      data[EMAIL_NOTIFICATION_PREFERENCE_KEY] = this.emailPreferences;
      this.updateStore(data);
    } else {
      this.store.dispatch(
        new notificationActions.Open({
          type: NotificationType.Error,
          inputs: {
            props: {
              message: 'Please select one or more available columns or statuses.',
              button: {
                label: 'Dismiss'
              }
            }
          }
        })
      );
    }
  }

  toggleEmailPreferences() {
    this.emailPreferences = this.emailPreferences.map(preference => {
      if (this.isEditable(preference)) {
        preference.value = this.allEmailPreferencesSelected;
      }
      return preference;
    });
    this.checkEmailChanges();
  }

  selectEmailPreference(preference) {
    preference.value = !preference.value;
    this.calculateOverallEmailPreferenceValue();
    this.checkEmailChanges();
  }

  calculateOverallEmailPreferenceValue() {
    this.allEmailPreferencesSelected = this.emailPreferences.reduce((a, b) => a && b.value, true);
  }

  checkEmailChanges() {
    let flag = true;
    this.savedEmailPreferences.forEach(email => {
      const edited = this.emailPreferences.find(pref => pref.name === email.name);
      if (edited.value !== email.value) {
        flag = false;
      }
    });
    this.saveDisabled.next(flag);
  }

  ngOnDestroy() {
    this.onDestroy.next();
  }
}
