import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AdAuthGuard } from '@content-platform/auth';
import { TermsOfUseGuard } from '@content-platform/terms-of-use';
import { PreferencePageComponent } from './preference-page/preference-page.component';
import { UserPermissionListGuard } from '@content-platform/application-api';
import { UserDetailResolver } from '../resolvers/user-detail.resolver';
import { UserPreferencesGuard } from '@content-platform/preferences-api';

const PREFERENCES_ROUTES: Routes = [
  {
    path: '',
    component: PreferencePageComponent,
    canActivate: [AdAuthGuard, TermsOfUseGuard, UserPermissionListGuard, UserPreferencesGuard],
    resolve: {
      userDetail: UserDetailResolver
    }
  }
];

@NgModule({
  imports: [CommonModule, RouterModule.forChild(PREFERENCES_ROUTES)],
  exports: [RouterModule]
})
export class PreferencesRoutingModule { }
