import { PreferencesModule } from './preferences.module';

describe('PreferencesModule', () => {
  let preferencesModule: PreferencesModule;

  beforeEach(() => {
    preferencesModule = new PreferencesModule();
  });

  it('should create an instance', () => {
    expect(preferencesModule).toBeTruthy();
  });
});
