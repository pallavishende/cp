import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PreferencePageComponent } from './preference-page/preference-page.component';
import { PreferencesRoutingModule } from './preferences-routing.module';
import { NavigationModule } from '@content-platform/navigation';
import {
  MatInputModule,
  MatAutocompleteModule,
  MatFormFieldModule,
  MatDatepickerModule,
  MatIconModule,
  MatCardModule,
  MatTabsModule,
  MatListModule,
  MatCheckboxModule
} from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { UserDetailResolver } from '../resolvers/user-detail.resolver';
import { PreferencesApiModule } from '@content-platform/preferences-api';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import * as fromStore from '../submission/dashboard/store';
import { DragDropModule } from '@angular/cdk/drag-drop';

@NgModule({
  imports: [
    CommonModule,
    DragDropModule,
    PreferencesRoutingModule,
    NavigationModule,
    MatInputModule,
    MatIconModule,
    MatAutocompleteModule,
    MatCardModule,
    MatListModule,
    MatIconModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatDatepickerModule,

    MatTabsModule,
    ReactiveFormsModule,
    FormsModule,
    PreferencesApiModule,
    StoreModule.forFeature('dashboard', fromStore.dashboardReducer),
    EffectsModule.forFeature(fromStore.dashboardEffects)
  ],
  declarations: [PreferencePageComponent],
  providers: [UserDetailResolver]
})
export class PreferencesModule {}
