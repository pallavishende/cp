import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { Auth, authSelectors } from '@content-platform/auth';
import { Store, select } from '@ngrx/store';
import { map, take } from 'rxjs/operators';
import { Observable, zip } from 'rxjs';
import { UserPermissionsService } from '@content-platform/application-api';
import { globalEntryFeature, globalEntryMetadataKeys } from '../../constants';
import { UserRouteDetail } from '../models';

@Injectable()
export class UserDetailResolver implements Resolve<Observable<UserRouteDetail>> {
  constructor(
    private authStore: Store<Auth>,
    private userPermissionsService: UserPermissionsService
  ) {}

  resolve(): Observable<UserRouteDetail> {
    return zip(
      this.userPermissionsService.getFeatureMetadataListAsync(globalEntryMetadataKeys.REGION).pipe(
        map(
          regionMetaDatas =>
            regionMetaDatas
              .map(metadata => {
                // In case it is a string based meta data, and only the name is populated
                return { description: metadata.description || metadata.name, name: metadata.name };
              })
              .sort((a, b) => a.description.localeCompare(b.description)) // sort by description
        )
      ),
      this.userPermissionsService
        .getFeatureMetadataListAsync(globalEntryMetadataKeys.CONTENT_TYPE)
        .pipe(
          map(
            contentTypeMetadatas =>
              contentTypeMetadatas
                .map(metadata => {
                  // In case it is a string based meta data, and only the name is populated
                  return {
                    description: metadata.description || metadata.name,
                    name: metadata.name
                  };
                })
                .sort((a, b) => a.description.localeCompare(b.description)) // sort by description
          )
        ),
      this.userPermissionsService.hasFeatureAsync(globalEntryFeature.VIEW_ALL_SUB),
      this.authStore.pipe(select(authSelectors.getADUser)),
      (regions, contentTypes, viewAllSub, user) => {
        return {
          regions: regions || [],
          contentTypes: contentTypes || [],
          canUserViewAll: { userInfo: user, canViewAll: viewAllSub }
        };
      }
    ).pipe(take(1));
  }
}
