import { from as observableFrom } from 'rxjs';
import { Injectable } from '@angular/core';

import { MusicParams } from '../submission/dashboard/constant/constant.enum';
import { HttpClient } from '@angular/common/http';
import { MockLocalStorageData } from '../mockLocalStorageData';
import { scan, map } from 'rxjs/operators';

@Injectable()
export class LocalStorageService {
  order: any;

  status: string;
  statusList;
  dashboardData: any;
  dashboard;
  musicData: MusicParams;
  statusMusicData: MusicParams;
  filterMusicData: MusicParams;
  filterMusicDataValue: string;
  filterByStatusFlag = false;
  filterByTrackTitle: boolean;
  storageData;
  getSubmissionValueApiUrl;
  dashboardHeaders;
  submissionDetail;
  isStatusFilter = false;
  isTitleFilter = false;
  filterStartDate: Date;
  filterEndDate: Date;

  constructor(private http: HttpClient) {}

  lS_filterByStatus(status: string, sort: string, _page: number, pageSize: number) {
    const sortFn = (a, b) => {
      return a.submissionFormData[sort].localeCompare(b.submissionFormData[sort]);
    };
    const items = this.ls_filterByStatusDate(status);
    // const resultCount = items.length;
    if (status !== 'All') {
      this.filterByStatusFlag = true;
    } else {
      this.filterByStatusFlag = false;
    }
    items.sort(sortFn);
    const parsedItems = items.slice(0, pageSize);
    this.musicData = { items: parsedItems, total_count: items.length };
    return (this.statusMusicData = { items: items, total_count: items.length });
  }

  ls_filterByStatusDate(
    status: string = 'All',
    startDate: Date = this.filterStartDate,
    endDate: Date = this.filterEndDate
  ) {
    let statusDateFilteredItems;
    const items = this.ls_getAllSubmissions().resultList;
    const statusFilteredItems =
      status !== 'All' ? items.filter(item => item.submissionFormData.status === status) : items;
    if (startDate && endDate) {
      const effStartDateTime = startDate.getTime();
      const effEndDateTime = endDate.getTime();
      statusDateFilteredItems = statusFilteredItems.filter(item => {
        const itemTime = new Date(item.submissionFormData.albumReleaseDate).getTime();
        return itemTime >= effStartDateTime && itemTime < effEndDateTime;
      });
    } else {
      statusDateFilteredItems = statusFilteredItems;
    }
    return statusDateFilteredItems;
  }

  ls_getAllSubmissions() {
    const storedToken = localStorage.getItem('submissionValue');
    const parsedToken = JSON.parse(storedToken);
    if (!parsedToken || parsedToken === '') {
      const mockData = new MockLocalStorageData();
      localStorage.setItem('submissionValue', JSON.stringify(mockData.MOCK_DATA));
      return JSON.parse(localStorage.getItem('submissionValue'));
    } else {
      return parsedToken;
    }
  }

  // This method is use to get json data
  ls_getFolderData() {
    return this.http.get('assets/data/fileExplorer.json');
  }

  ls_getSubmissionById(submissionId) {
    const sub = JSON.parse(localStorage.getItem('submissionValue')).resultList;
    if (sub !== null && sub.length > 0) {
      for (let i = 0; i < sub.length; i++) {
        if (sub[i].submissionFormData.isrc === submissionId) {
          return sub[i];
        } else {
          console.log('No ID matched');
        }
      }
    }
  }
  // This method is use to set created submission in local storage
  ls_createSubmission(submittedSubmission) {
    localStorage.setItem('submissionValue', JSON.stringify(submittedSubmission));
  }
  ls_getStatusCount() {
    const submissionDetail = this.ls_getAllSubmissions();
    const storageData = submissionDetail.resultList;
    if (storageData !== null) {
      const submissionData = storageData.valueOf();
      const objToArray = obj => {
        const keys = Object.keys(obj);
        return keys.reduce((acc, curr) => [...acc, obj[curr]], []);
      };
      return observableFrom(submissionData).pipe(
        scan((acc, curr) => {
          const status = curr['submissionFormData']['status'];
          if (status === 'Awaiting Elements') {
            this.order = 1;
          } else if (status === 'All') {
            this.order = 7;
          } else if (status === 'Complete Ingest') {
            this.order = 5;
          } else if (status === 'Pending QC') {
            this.order = 2;
          } else if (status === 'Pending Ingest') {
            this.order = 3;
          } else if (status === 'Failed') {
            this.order = 6;
          } else if (status === 'In Progress Ingest') {
            this.order = 4;
          }
          const count = acc[status] ? acc[status].count : 0;
          const total = submissionData.length;
          return Object.assign(acc, {
            [status]: { status, count: count + 1, order: this.order },
            ['All']: { status: 'All', count: total, order: 7 }
          });
        }, {}),
        map(objToArray)
      );
    }
  }
  ls_getSubmissionForFilterText(
    sort: string,
    searchText: string,
    _page: number,
    _pageSize: number
  ) {
    const sortFn = (a, b) => {
      return a.submissionFormData[sort].localeCompare(b.submissionFormData[sort]);
    };
    const submissions = this.ls_getAllSubmissions().resultList;
    const filtertoken: any[] = [];
    for (let i = 0; i < submissions.length; i++) {
      const title = submissions[i].submissionFormData.trackTitle.toLowerCase().search(searchText);
      if (title !== -1) {
        filtertoken.push(submissions[i]);
      }
    }
    filtertoken.sort(sortFn);
    return filtertoken;
  }

  ls_filterByDateRange(startDate, endDate) {
    const items = this.ls_getAllSubmissions().resultList;
    const result = items.filter(d => {
      const time = new Date(d.submissionFormData.albumReleaseDate).getTime();
      return startDate <= time && endDate >= time;
    });
    return result;
  }
  ls_getSubmissions(sort: string, order: string, page: number, pageSize: number) {
    const sortFn = function(a, b) {
      if (order === 'asc') {
        return a.submissionFormData[sort].localeCompare(b.submissionFormData[sort]);
      } else {
        return b.submissionFormData[sort].localeCompare(a.submissionFormData[sort]);
      }
    };
    const submissions = this.ls_getAllSubmissions().resultList;
    if (this.isStatusFilter) {
      if (!this.filterByStatusFlag) {
        this.storageData = submissions;
      } else {
        this.storageData = submissions.filter(
          dataValue => dataValue.submissionFormData.status === this.status
        );
      }
    } else if (this.isTitleFilter) {
      if (this.filterMusicDataValue) {
        const filtertoken: any[] = [];
        for (let i = 0; i < submissions.length; i++) {
          const title = submissions[i].submissionFormData.trackTitle
            .toLowerCase()
            .search(this.filterMusicDataValue);
          if (title !== -1) {
            filtertoken.push(submissions[i]);
          }
        }
        this.storageData = filtertoken;
      } else {
        this.storageData = submissions;
      }
    } else {
      this.storageData = submissions;
    }
    this.storageData.sort(sortFn);
    const parsedToken = this.storageData.slice(page * pageSize, (page + 1) * pageSize);
    return parsedToken;
  }
}
