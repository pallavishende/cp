import { TestBed } from '@angular/core/testing';

import { PreloadingStrategyService } from './preloading-strategy.service';
import { RouterTestingModule } from '@angular/router/testing';
import { LayoutSchemaWithFieldsGuard } from '@content-platform/dynamic-forms-api';
import { of } from 'rxjs';

describe('PreloadingStrategyService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        PreloadingStrategyService,
        {
          provide: LayoutSchemaWithFieldsGuard,
          useValue: {
            checkStore: () => of(true)
          }
        }
      ]
    });
  });

  it('should be created', () => {
    const service: PreloadingStrategyService = TestBed.get(PreloadingStrategyService);
    expect(service).toBeTruthy();
  });
});
