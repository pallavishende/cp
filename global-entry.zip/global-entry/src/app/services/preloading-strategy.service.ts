import { Injectable } from '@angular/core';
import { Route, Router, NavigationEnd } from '@angular/router';
import { Observable, concat } from 'rxjs';
import { take, filter } from 'rxjs/operators';
import { LayoutSchemaWithFieldsGuard } from '@content-platform/dynamic-forms-api';

@Injectable({
  providedIn: 'root'
})
export class PreloadingStrategyService {
  static loadInitiated = false;
  private schemaToLoad = ['music-video', 'episodic', 'commercial'];

  constructor(
    private layoutSchemaWithFieldsGuard: LayoutSchemaWithFieldsGuard,
    private router: Router
  ) {
    this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(() => {
      const currentRoute = this.router.url;
      const routeConfig = router.config.find(d => currentRoute.indexOf(d.path) !== -1);
      if (routeConfig['data'] && routeConfig.data.preload) {
        this.loadSchemas();
      }
    });
  }

  preload(route: Route, load: () => Observable<any>): Observable<any> {
    if (route) {
      return load();
    }
  }

  private loadSchemas() {
    if (!PreloadingStrategyService.loadInitiated) {
      PreloadingStrategyService.loadInitiated = true;
      const schemaObservables = [];
      this.schemaToLoad.forEach(contentType => {
        schemaObservables.push(
          this.layoutSchemaWithFieldsGuard.checkStore(contentType).pipe(take(1))
        );
      });
      concat(...schemaObservables).subscribe();
    }
  }
}
