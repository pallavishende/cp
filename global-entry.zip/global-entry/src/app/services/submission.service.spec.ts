import { TestBed, async } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { SubmissionService } from './submission.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MockLocalStorageData } from '../mockLocalStorageData';
import { fromAuth } from '@content-platform/auth';
import { StoreModule } from '@ngrx/store';
import { LoggerService } from '@content-platform/logging';

describe('SubmissionService', () => {
  let submissionService: SubmissionService;
  let mockData: MockLocalStorageData;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientModule,
        HttpClientTestingModule,
        StoreModule.forRoot({
          auth: fromAuth.authReducer
        })
      ],
      providers: [
        SubmissionService,
        {
          provide: LoggerService,
          useValue: {
            instance: () => {
              return { log: () => {} };
            }
          }
        }
      ]
    });

    submissionService = TestBed.get(SubmissionService);
    mockData = new MockLocalStorageData();
  });

  it('should be created', () => {
    expect(submissionService).toBeTruthy();
  });

  it('should call getAllSubmissions method on calling filterByStatus method', () => {
    // Arrange
    const status = mockData.MOCK_DATA.resultList[0]['submissionFormData']['status'];
    spyOn(submissionService, 'getAllSubmissions').and.callFake(() => {
      const storedToken = mockData.MOCK_DATA;
      return storedToken;
    });

    // Act
    submissionService.filterByStatus(status, 'isrc', 1, 5);

    // Assert
    expect(submissionService.getAllSubmissions).toHaveBeenCalled();
  });

  it('should call setObservable method on calling filterByStatus method', () => {
    // Arrange
    const status = mockData.MOCK_DATA.resultList[0]['submissionFormData']['status'];
    spyOn(submissionService, 'getAllSubmissions').and.callFake(() => {
      const storedToken = mockData.MOCK_DATA;
      return storedToken;
    });

    spyOn(submissionService, 'setObservable');

    // Act
    submissionService.filterByStatus(status, 'isrc', 1, 5);

    // Assert
    expect(submissionService.setObservable).toHaveBeenCalled();
  });

  it('filterByStatusFlag should become true value if input status is other than All', () => {
    // Arrange
    const status = mockData.MOCK_DATA.resultList[0]['submissionFormData']['status'];
    const filterByStatusFlagTest: boolean = status !== 'All' ? true : false;
    spyOn(submissionService, 'getAllSubmissions').and.callFake(() => {
      const storedToken = mockData.MOCK_DATA;
      return storedToken;
    });

    // Act
    submissionService.filterByStatus(status, 'isrc', 1, 5);

    // Assert
    expect(submissionService.filterByStatusFlag).toBe(filterByStatusFlagTest);
  });

  it('should call getAllSubmissions method on calling getSubmissionForFilterText method', () => {
    // Arrange
    spyOn(submissionService, 'getAllSubmissions').and.callFake(() => {
      const storedToken = mockData.MOCK_DATA;
      return storedToken;
    });

    // Act
    submissionService.getSubmissionForFilterText('isrc', 'glo', 1, 5);

    // Assert
    expect(submissionService.getAllSubmissions).toHaveBeenCalled();
  });

  it('should call setObservable method on calling getSubmissionForFilterText method', () => {
    // Arrange
    spyOn(submissionService, 'getAllSubmissions').and.callFake(() => {
      const storedToken = mockData.MOCK_DATA;
      return storedToken;
    });

    spyOn(submissionService, 'setObservable');

    // Act
    submissionService.getSubmissionForFilterText('isrc', 'glo', 1, 5);

    // Assert
    expect(submissionService.setObservable).toHaveBeenCalled();
  });

  it('should store data to localStorage', () => {
    // Arrange
    localStorage.setItem('submissionValue', JSON.stringify(''));

    // Act
    const result = submissionService.getAllSubmissions();

    // Assert
    expect(result).toEqual(JSON.parse(localStorage.getItem('submissionValue')));
  });

  it('should call filterByDate when filterByStatusDate is called', () => {
    // Arrange
    spyOn(submissionService, 'getAllSubmissions').and.callFake(() => {
      const storedToken = mockData.MOCK_DATA;
      return storedToken;
    });

    submissionService.filterStartDate = new Date(2017, 10, 7);
    submissionService.filterEndDate = new Date(2017, 10, 23);

    spyOn(submissionService, 'filterByDate').and.returnValue([]);

    // Act
    submissionService.filterByStatusDate('All');

    // Assert
    async(() => {
      expect(submissionService.filterByDate()).toHaveBeenCalled();
    });
  });

  it('should check filterByDate', () => {
    // Arrange
    spyOn(submissionService, 'getAllSubmissions').and.callFake(() => {
      const storedToken = mockData.MOCK_DATA;
      return storedToken;
    });
    // Arrange
    const items = mockData.MOCK_DATA_CHUNK.resultList;
    submissionService.filterStartDate = new Date(2013, 10, 7);
    submissionService.filterEndDate = new Date(2018, 10, 23);

    // Act
    const result = submissionService.filterByDate(
      items,
      submissionService.filterStartDate,
      submissionService.filterEndDate
    );

    // Assert
    expect(result).toEqual(mockData.MOCK_DATA_CHUNK.resultList);
  });

  it('should call filterByStatusDate when filterByStatus is called', () => {
    // Arrange
    spyOn(submissionService, 'getAllSubmissions').and.callFake(() => {
      const storedToken = mockData.MOCK_DATA;
      return storedToken;
    });

    spyOn(submissionService, 'filterByStatusDate').and.returnValue([]);

    // Act
    submissionService.filterByStatus('All', 'isrc', 0, 10);

    // Assert
    async(() => {
      expect(submissionService.filterByStatusDate).toHaveBeenCalled();
    });
  });

  it('should check filterByStatusDate', () => {
    // Arrange
    spyOn(submissionService, 'getAllSubmissions').and.callFake(() => {
      const storedToken = mockData.MOCK_DATA_CHUNK;
      return storedToken;
    });

    submissionService.filterStartDate = new Date(2013, 10, 7);
    submissionService.filterEndDate = new Date(2018, 10, 23);

    // Act
    const recordStatus = mockData.MOCK_DATA_CHUNK.resultList[0].submissionFormData.status;
    const result = submissionService.filterByStatusDate(
      recordStatus,
      submissionService.filterStartDate,
      submissionService.filterEndDate
    );

    // Assert
    expect(result).toEqual(mockData.MOCK_DATA_CHUNK.resultList);
  });

  it('should filter the list with the selected date range', () => {
    // Arrange
    const MOCK_DATE_RANGE_DATA = mockData.MOCK_DATE_RANGE_DATA;

    spyOn(submissionService, 'getAllSubmissions').and.callFake(() => {
      const storedToken = MOCK_DATE_RANGE_DATA;
      return storedToken;
    });

    const startDate = new Date(2017, 10, 7);
    const endDate = new Date(2017, 10, 23);

    // Act
    submissionService.filterByDateRange(startDate, endDate);
    const result = submissionService.musicData.items.filter(d => {
      const time = new Date(d.submissionFormData.albumReleaseDate).getTime();
      return startDate.getTime() <= time && endDate.getTime() >= time;
    });

    // Assert
    expect(submissionService.musicData.items).toEqual(result);
  });
});
