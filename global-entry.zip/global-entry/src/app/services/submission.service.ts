import { from as observableFrom, throwError, Observable, Subject, BehaviorSubject, of } from 'rxjs';

import { scan, map, catchError } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { FormControl } from '@angular/forms';
import { Auth, authSelectors } from '@content-platform/auth';
import { NotificationType, notificationActions } from '@content-platform/notifications';

import { PageSortInput, TablePagerSort, ContentTypeStatusCount } from '../models';
import { MusicParams } from '../submission/dashboard/constant/constant.enum';
import { HttpClient, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { MockLocalStorageData } from '../mockLocalStorageData';
import { PermissionMetadata } from '@content-platform/application-api';
import { Environments } from '@content-platform/configuration';

@Injectable()
export class SubmissionService {
  order;
  status: string;
  selectedStatusCode = 'ALL';
  statusList;
  dashboardData: any;
  dashboard;
  musicData: MusicParams;
  statusMusicData: MusicParams;
  filterMusicData: MusicParams;
  filterMusicDataValue: string;
  filterByStatusFlag = false;
  filterByTrackTitle: boolean;
  storageData;
  getSubmissionValueApiUrl;
  dashboardHeaders;
  submissionDetail;
  isStatusFilter = false;
  isTitleFilter = false;
  filterStartDate: Date;
  filterEndDate: Date;
  filterRegionValue: PermissionMetadata[];
  sortPagerDetails: TablePagerSort;
  configUrl: string;
  user$: Observable<adal.User>;
  searchTermSubject: BehaviorSubject<string>;
  observableValue = new Observable();
  private subject = new Subject<MusicParams>();
  private headerSubject = new Subject<any>();
  private pageSortSubject = new Subject<PageSortInput>();
  public loadSpinner$$ = new BehaviorSubject<boolean>(false);
  public loadSpinner = this.loadSpinner$$.asObservable();
  public commentsSubject$$ = new BehaviorSubject<boolean>(false);
  videoPlayerSubject = new Subject<any>();

  constructor(private http: HttpClient, private authStore: Store<Auth>) {}

  setFilterStartDate(): string {
    return this.filterStartDate ? this.filterStartDate.toISOString() : '';
  }

  setFilterEndDate() {
    return this.filterEndDate ? this.filterEndDate.toISOString() : '';
  }
  setRegionSelected(): string[] {
    return this.filterRegionValue ? this.filterRegionValue.map(region => region.name) : undefined;
  }
  setStatusParam() {
    return this.selectedStatusCode === 'ALL' || undefined ? '' : this.selectedStatusCode;
  }

  setPageSortInput(pageSortInput: PageSortInput) {
    this.pageSortSubject.next(pageSortInput);
  }

  getPageSortInput() {
    return this.pageSortSubject;
  }

  // This method is use to get json data
  getFolderData() {
    return this.http.get('assets/data/fileExplorer.json');
  }

  // This method is use to get the created submission from local storage
  getAllSubmissions() {
    const storedToken = localStorage.getItem('submissionValue');

    const parsedToken = JSON.parse(storedToken);
    if (!storedToken || storedToken === '') {
      const mockData = new MockLocalStorageData();
      localStorage.setItem('submissionValue', JSON.stringify(mockData.MOCK_DATA));
      return JSON.parse(localStorage.getItem('submissionValue'));
    } else {
      return parsedToken;
    }
  }

  // This method is to get filtered items by date
  filterByDate(
    items = this.getAllSubmissions().resultList,
    startDate: Date = this.filterStartDate,
    endDate: Date = this.filterEndDate
  ) {
    const effStartDateTime = startDate
      ? startDate.getTime()
      : new Date(-8640000000000000).getTime();
    const effEndDateTime = endDate ? endDate.getTime() : new Date(8640000000000000).getTime();
    const dateFilterItems = items.filter(item => {
      const itemTime = new Date(item.submittedDate).getTime();
      return itemTime >= effStartDateTime && itemTime <= effEndDateTime;
    });
    return dateFilterItems;
  }

  filterFromDateInput(sort: string, page: number, pageSize: number) {
    const sortFn = (a, b) => {
      if (sort === 'submittedBy' || sort === 'submittedDate') {
        return a[sort].localeCompare(b[sort]);
      } else {
        return a.submissionFormData[sort].localeCompare(b.submissionFormData[sort]);
      }
    };
    const filteredDataItems = this.filterByDate();
    filteredDataItems.sort(sortFn);
    const parsedFilteredDataItems = filteredDataItems.slice(page * pageSize, (page + 1) * pageSize);
    this.musicData = { items: parsedFilteredDataItems, total_count: filteredDataItems.length };
    this.setObservable(this.musicData);
  }

  getAllSubmissionsContentType(contentType: string) {
    const configUrl = Environments.getUrl('submissionEndpoint') + '/submissions';
    return this.http
      .get(configUrl, {
        params: new HttpParams().set('contentType', contentType)
      })
      .pipe(map(res => res['resultList']));
  }

  loadAllMusicSubmissions(
    page = 0,
    size = 30,
    status = '',
    sortColumn = '',
    sortDirection = '',
    fromDate = '',
    toDate = '',
    searchTerm = ''
  ) {
    const configUrl = Environments.getUrl('submissionEndpoint') + '/submissions';
    const effPage = page + 1;
    return this.http
      .get(configUrl, {
        observe: 'response',
        params: new HttpParams()
          .set('contentType', 'music-video')
          .set('searchTerm', searchTerm)
          .set('status', status)
          .set('page', effPage.toString())
          .set('size', size.toString())
          .set('sortColumn', sortColumn)
          .set('sortDirection', sortDirection)
          .set('fromDate', fromDate)
          .set('toDate', toDate)
      })
      .subscribe(dashboardData => {
        if (dashboardData.body) {
          this.dashboardHeaders = parseInt(dashboardData.headers.get('X-Total-Count'), 10);
          this.storageData = dashboardData.body['resultList'];
          this.musicData = { items: this.storageData, total_count: this.dashboardHeaders };
          this.setObservable(this.musicData);
        } else {
          this.setObservable({ items: null, total_count: 0 });
        }
      });
  }
  loadContentTypeData(
    contentType,
    page,
    size,
    status = '',
    sortColumn,
    sortDirection,
    fromDate = '',
    toDate = '',
    searchTerm = '',
    shared,
    submittedUserEmail,
    region,
    admin
  ) {
    const configUrl = Environments.getUrl('submissionEndpoint') + '/submissions';
    const effPage = page + 1;
    return this.http
      .get(configUrl, {
        observe: 'response',
        params: new HttpParams()
          .set('contentType', contentType)
          .set('searchTerm', searchTerm)
          .set('status', status)
          .set('page', effPage.toString())
          .set('size', size.toString())
          .set('sortColumn', sortColumn)
          .set('sortDirection', sortDirection)
          .set('fromDate', fromDate)
          .set('toDate', toDate)
          .set('shared', shared)
          .set('email', submittedUserEmail)
          .set('region', region)
          .set('admin', admin)
      })
      .pipe(
        map(res => {
          if (res.status === 200) {
            const itemsCount = parseInt(res.headers.get('X-Total-Count'), 10);
            return { records: res.body['resultList'], itemsCount };
          } else if (res.status === 204) {
            return { records: [], itemsCount: 0 };
          }
        }),
        catchError((error: HttpErrorResponse | any) => of(this.handleError(error)))
      );
  }

  handleError(error: HttpErrorResponse | any) {
    if (error && error.status ? error.status === 500 : false) {
      return { records: [], itemsCount: 0 };
    }
    throwError(error);
  }

  getContentTypeStatusCount({ contentType, email, shared, region, admin }) {
    const configUrl = Environments.getUrl('submissionEndpoint') + '/submissions/status/count/all';
    return this.http.get<ContentTypeStatusCount[]>(configUrl, {
      params: new HttpParams()
        .set('contentType', contentType)
        .set('email', email)
        .set('region', region)
        .set('shared', shared)
        .set('admin', admin)
    });
  }

  getStatusCount() {
    const submissionDetail = this.getAllSubmissions();
    const storageData = submissionDetail.resultList;
    if (storageData !== null) {
      const submissionData = storageData.valueOf();
      const objToArray = obj => {
        const keys = Object.keys(obj);
        return keys.reduce((acc, curr) => [...acc, obj[curr]], []);
      };
      return observableFrom(submissionData).pipe(
        scan((acc, curr) => {
          const status = curr['submissionFormData']['status'];
          if (status === 'Awaiting Elements') {
            this.order = 1;
          } else if (status === 'All') {
            this.order = 7;
          } else if (status === 'Complete Ingest') {
            this.order = 5;
          } else if (status === 'Pending QC') {
            this.order = 2;
          } else if (status === 'Pending Ingest') {
            this.order = 3;
          } else if (status === 'Failed') {
            this.order = 6;
          } else if (status === 'In Progress Ingest') {
            this.order = 4;
          }
          const count = acc[status] ? acc[status].count : 0;
          const total = submissionData.length;
          return Object.assign(acc, {
            [status]: { status, count: count + 1, order: this.order },
            ['All']: { status: 'All', count: total, order: 7 }
          });
        }, {}),
        map(objToArray)
      );
    }
  }

  getAllDynamicSubmissions() {
    const storedToken = localStorage.getItem('dynamicSubmissionValue');

    const parsedToken = JSON.parse(storedToken);
    if (!storedToken || storedToken === '') {
      return JSON.parse(localStorage.getItem('dynamicSubmissionValue'));
    } else {
      return parsedToken;
    }
  }
  // To filter the results by status and date
  filterByStatusDate(
    status: string = 'All',
    startDate: Date = this.filterStartDate,
    endDate: Date = this.filterEndDate
  ) {
    const items = this.getAllSubmissions().resultList;
    const statusFilteredItems =
      status !== 'All' ? items.filter(item => item.submissionFormData.status === status) : items;
    return this.filterByDate(statusFilteredItems, startDate, endDate);
  }

  filterByStatus(status: string, sort: string, _page: number, pageSize: number) {
    const sortFn = (a, b) => {
      if (sort === 'submittedBy' || sort === 'submittedDate') {
        return a[sort].localeCompare(b[sort]);
      } else {
        return a.submissionFormData[sort].localeCompare(b.submissionFormData[sort]);
      }
    };
    const items = this.filterByStatusDate(status);
    if (status !== 'All') {
      this.filterByStatusFlag = true;
    } else {
      this.filterByStatusFlag = false;
    }
    items.sort(sortFn);
    const parsedItems = items.slice(0, pageSize);
    this.musicData = { items: parsedItems, total_count: items.length };
    this.statusMusicData = { items: items, total_count: items.length };
    this.setObservable(this.musicData);
  }

  getSubmissionForFilterText(sort: string, searchText: string, page: number, pageSize: number) {
    const sortFn = (a, b) => {
      if (sort === 'submittedBy' || sort === 'submittedDate') {
        return a[sort].localeCompare(b[sort]);
      } else {
        return a.submissionFormData[sort].localeCompare(b.submissionFormData[sort]);
      }
    };
    const submissions = this.getAllSubmissions().resultList;
    const filtertoken: any[] = [];
    for (let i = 0; i < submissions.length; i++) {
      const title = submissions[i].submissionFormData.trackTitle.toLowerCase().search(searchText);
      if (title !== -1) {
        filtertoken.push(submissions[i]);
      }
    }
    filtertoken.sort(sortFn);
    const parsedFilterToken = filtertoken.slice(page * pageSize, (page + 1) * pageSize);
    this.musicData = { items: parsedFilterToken, total_count: filtertoken.length };
    this.setObservable(this.musicData);
    return filtertoken;
  }

  setObservable(submissions: MusicParams) {
    this.subject.next(submissions);
  }

  getObservable(): Observable<MusicParams> {
    return this.subject.asObservable();
  }

  setHeaderName(headerName: string) {
    this.headerSubject.next(headerName);
  }

  getHeaderName(): Observable<any> {
    return this.headerSubject.asObservable();
  }

  filterByDateRange(startDate, endDate) {
    const items = this.getAllSubmissions().resultList;
    const result = items.filter(d => {
      const time = new Date(d.submissionFormData.albumReleaseDate).getTime();
      return startDate <= time && endDate >= time;
    });
    this.musicData = { items: result, total_count: result.length };
    this.setObservable(this.musicData);
  }

  stringToDate(_date, _format, _delimiter) {
    const formatLowerCase = _format.toLowerCase();
    const formatItems = formatLowerCase.split(_delimiter);
    const dateItems = _date.split(_delimiter);
    const monthIndex = formatItems.indexOf('mm');
    const dayIndex = formatItems.indexOf('dd');
    const yearIndex = formatItems.indexOf('yyyy');
    let month = parseInt(dateItems[monthIndex], 10);
    month -= 1;
    const formatedDate = new Date(dateItems[yearIndex], month, dateItems[dayIndex]);
    return formatedDate;
  }

  getAuthUserInfo() {
    return (this.user$ = this.authStore.pipe(select(authSelectors.getADUser)));
  }

  reserveOnPristine(formControl: FormControl) {
    if (formControl.pristine) {
      const reservedComment = formControl.value;
      formControl.setValue('');
      return reservedComment;
    }
  }

  clearOnPristine(formControl: FormControl, reservedComment) {
    if (formControl.pristine) {
      formControl.setValue(reservedComment);
      reservedComment = '';
    }
  }

  showRejectButton(formControl: FormControl) {
    return !formControl.pristine && formControl.status === 'VALID' && formControl.value !== ''
      ? false
      : true;
  }

  goForComment(fieldNotes: FormControl, fieldValue: string): boolean {
    const isComment = !fieldNotes.pristine && fieldValue ? true : false;
    return isComment;
  }

  openToasterNotification(message: string) {
    this.authStore.dispatch(
      new notificationActions.Open({
        type: NotificationType.Success,
        inputs: {
          props: {
            message
          }
        }
      })
    );
  }
}
