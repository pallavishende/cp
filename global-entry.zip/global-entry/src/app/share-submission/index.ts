export * from './share-submission/share-submission.component';
export * from './share-submission.module';
