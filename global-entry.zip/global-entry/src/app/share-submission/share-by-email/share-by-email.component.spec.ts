import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';

import { ShareByEmailComponent } from './share-by-email.component';
import { ClipboardService } from '@content-platform/common-helpers';
import { GraphApi } from '@content-platform/graph-api';
import { of } from 'rxjs';
import { MaterialMockModule } from '@content-platform/unit-test-helpers';
import { StoreModule } from '@ngrx/store';
import { fromAuth } from '@content-platform/auth';

describe('ShareByEmailComponent', () => {
  let component: ShareByEmailComponent;
  let fixture: ComponentFixture<ShareByEmailComponent>;

  class MockClipboardService {
    copyToClipboard() {}
  }

  class MockGraphApi {
    usersData = [
      {
        givenName: 'name',
        mail: 'name@name.com',
        surname: 'surname'
      },
      {
        givenName: 'abc',
        mail: 'abc@name.com',
        surname: 'abc'
      },
      {
        givenName: 'def',
        mail: 'def@name.com',
        surname: 'def'
      },
      {
        givenName: 'qqq',
        mail: 'qqq@name.com',
        surname: 'qqq'
      },
      {
        givenName: 'zzz',
        mail: 'zzz@name.com',
        surname: 'zzz'
      }
    ];
    searchUsers(query) {
      const regEx = new RegExp(`/${query}/i`);
      return of(this.usersData.filter(user => user.givenName.search(regEx) > 0));
    }
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        MaterialMockModule,
        StoreModule.forRoot({ auth: fromAuth.authReducer })
      ],
      declarations: [ShareByEmailComponent],
      providers: [
        { provide: GraphApi, useClass: MockGraphApi },
        { provide: ClipboardService, useClass: MockClipboardService }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShareByEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
