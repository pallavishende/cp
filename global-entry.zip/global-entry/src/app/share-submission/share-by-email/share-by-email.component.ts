import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, Optional } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, ValidationErrors } from '@angular/forms';
import { Observable, of, timer, Subject } from 'rxjs';
import { switchMap, debounceTime, skipWhile, map, switchMapTo, takeUntil } from 'rxjs/operators';
import { Auth, authSelectors } from '@content-platform/auth';
import { GraphApi, UserProfile } from '@content-platform/graph-api';
import { Store, select } from '@ngrx/store';
import { notificationActions, NotificationType } from '@content-platform/notifications';
import { shareActions, SharePayload } from '@content-platform/submissions-api';
import {
  UserFeature,
  Share,
  CurrentChanges,
  shareSubmissionsSelectors
} from '@content-platform/submissions-api';
import { ClipboardService } from '@content-platform/common-helpers';
import { AuthDebugFlagNames } from '@content-platform/auth';
import { DebugFlagsService } from '@content-platform/development';

@Component({
  selector: 'app-share-by-email',
  templateUrl: './share-by-email.component.html',
  styleUrls: ['./share-by-email.component.scss']
})
export class ShareByEmailComponent implements OnInit, OnDestroy {
  @Input()
  url: string;
  @Input()
  submissionId: string;
  @Input()
  sharedUserData: any[];
  @Output()
  cancelled = new EventEmitter();
  @Output()
  shared = new EventEmitter();
  loginUser$: Observable<adal.User>;
  sharingInfoForm: FormGroup;
  notesForm: FormGroup;
  users$: Observable<UserProfile[]>;
  userDetail: UserProfile;
  sharedUser: UserFeature;
  private onDestroy = new Subject<void>();
  sharedByName: string;
  sharedByEmail: string;
  sharedList: UserFeature[];
  showHint = false;
  constructor(
    private formBuilder: FormBuilder,
    private graphApi: GraphApi,
    private authStore: Store<Auth>,
    private clipboardService: ClipboardService,
    @Optional() private debugFlagService: DebugFlagsService
  ) {
    this.loginUser$ = authStore.pipe(select(authSelectors.getADUser));
  }

  get fieldLabels() {
    return {
      url: 'Link',
      email: 'Share submission with',
      permission: 'Permissions',
      addOrEditMetadata: 'Add/Edit Metadata',
      addFiles: 'Add Files',
      downloadFiles: 'Download Files',
      note: 'Add a note'
    };
  }

  ngOnInit() {
    if (this.sharedUserData) {
      this.sharedList = this.sharedUserData;
    } else {
      this.sharedList = [];
    }
    this.notesForm = this.formBuilder.group({
      note: new FormControl(
        '',
        Validators.compose([Validators.required, Validators.maxLength(500)])
      )
    });
    this.sharingInfoForm = this.formBuilder.group({
      email: new FormControl('', Validators.compose([Validators.required, Validators.email]), [
        this.validateEmail.bind(this)
      ]),
      permission: new FormGroup(
        {
          addOrEditMetadata: new FormControl(false, []),
          addFiles: new FormControl(false, []),
          downloadFiles: new FormControl(false, [])
        },
        this.validatePermissionGroup
      )
    });
    this.loginUser$.subscribe(({ profile }) => {
      if (this.debugFlagService) {
        if (this.debugFlagService.hasDebugFlag(AuthDebugFlagNames.Impersonate)) {
          this.sharedByName = `${profile.givenName} ${profile.surname}`;
          this.sharedByEmail = profile.mail;
        } else {
          this.sharedByName = `${profile.given_name} ${profile.family_name}`;
          this.sharedByEmail = profile.unique_name;
        }
      }
    });
    this.users$ = this.sharingInfoForm.get('email').valueChanges.pipe(
      skipWhile(val => val === ''),
      debounceTime(300),
      switchMap(state => this.graphApi.searchUsers(state.trim() as string)),
      map(res => res.filter(output => output.mail !== this.sharedByEmail))
    );
    this.users$.pipe(takeUntil(this.onDestroy)).subscribe(data => {
      for (const key of data) {
        if (key) {
          this.userDetail = key;
        }
      }
    });
    this.authStore
      .pipe(select(shareSubmissionsSelectors.getShareUploadedState))
      .subscribe(uploaded => {
        if (uploaded) {
          this.authStore.dispatch(
            new notificationActions.Open({
              type: NotificationType.Success,
              inputs: {
                props: {
                  message: `Success! Your record has been shared successfully with ${this.userDetail
                    .givenName +
                    ' ' +
                    this.userDetail.surname}`,
                  action: () => {
                    this.resetValues();
                  }
                }
              }
            })
          );
          this.authStore.dispatch(new shareActions.ShareReset());
        }
      });
  }

  onBlur() {
    this.showHint = false;
  }

  onFocus() {
    this.showHint = true;
  }

  validatePermissionGroup(permissionFormGroup: FormGroup) {
    const addOrEditMetadata = permissionFormGroup.get('addOrEditMetadata').value;
    const addFiles = permissionFormGroup.get('addFiles').value;
    const downloadFiles = permissionFormGroup.get('downloadFiles').value;
    if (addOrEditMetadata || addFiles || downloadFiles) {
      return null;
    } else {
      return {
        permission: {
          valid: false
        }
      };
    }
  }

  validateEmail(emailControl: FormControl): Observable<ValidationErrors> {
    const email = emailControl.value;
    if (emailControl.value && !emailControl.hasError('email')) {
      return timer(500).pipe(
        switchMapTo(this.graphApi.searchUsers(email as string)),
        map(state => {
          if (email.trim().toLowerCase() === this.sharedByEmail.toLowerCase()) {
            return {
              loggedUserFound: 'logged in user found'
            };
          } else if (state.length === 1 && state[0].mail.toLowerCase() === email.toLowerCase()) {
            return null;
          } else {
            return {
              userNotFound: 'user not found'
            };
          }
        })
      );
    }
    return of(null);
  }

  resetValues() {
    this.sharingInfoForm.controls['permission'].setValue({
      addOrEditMetadata: false,
      addFiles: false,
      downloadFiles: false
    });
  }

  share() {
    const shareDetails = this.prepareShareRequestBody(true);
    this.authStore.dispatch(new shareActions.ShareDetails(shareDetails));
    this.shared.emit();
  }

  copy() {
    const shareDetails = this.prepareShareRequestBody(false);
    this.clipboardService.copyToClipboard(this.url);
    this.authStore.dispatch(new shareActions.UpdatePermission(shareDetails));
    this.shared.emit();
  }

  prepareShareRequestBody(sendEmail: boolean) {
    const userDetail: UserFeature = {
      name: this.userDetail.givenName + ' ' + this.userDetail.surname,
      email: this.userDetail.mail,
      sharedBy: this.sharedByName,
      features: this.sharingInfoForm.get('permission').value
    };
    const index = this.sharedList.findIndex(sharedUser => sharedUser.email === userDetail.email);
    if (index > -1) {
      this.sharedList[index] = userDetail;
    } else {
      this.sharedList.push(userDetail);
    }
    const shareDetails: Share = {
      from: { name: this.sharedByName, email: this.sharedByEmail },
      sharedUsers: this.sharedList,
      link: this.url
    };
    if (sendEmail) {
      const currentChangeDetails: CurrentChanges = {
        name: this.userDetail.givenName + ' ' + this.userDetail.surname,
        email: this.userDetail.mail,
        action: 'Added',
        notes: this.notesForm.get('note').value
      };
      shareDetails.changes = [currentChangeDetails];
    }
    const sharePayload: SharePayload = {
      id: this.submissionId,
      payload: shareDetails
    };
    return sharePayload;
  }

  cancel() {
    this.cancelled.emit();
  }

  ngOnDestroy() {
    this.onDestroy.next();
  }
}
