import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShareByUrlComponent } from './share-by-url.component';

describe('ShareByUrlComponent', () => {
  let component: ShareByUrlComponent;
  let fixture: ComponentFixture<ShareByUrlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShareByUrlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShareByUrlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
