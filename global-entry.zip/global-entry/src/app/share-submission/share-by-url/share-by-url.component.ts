import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ClipboardService } from '@content-platform/common-helpers';

@Component({
  selector: 'app-share-by-url',
  templateUrl: './share-by-url.component.html',
  styleUrls: ['./share-by-url.component.scss']
})
export class ShareByUrlComponent implements OnInit {
  @Input()
  url: string;
  @Output()
  cancelled = new EventEmitter();
  @Output()
  copied = new EventEmitter();
  title = 'Copy this url to share';

  constructor(private clipboardService: ClipboardService) {}

  ngOnInit() {}

  cancel() {
    this.cancelled.emit();
  }

  copy() {
    this.clipboardService.copyToClipboard(this.url);
    this.copied.emit();
  }
}
