import { ShareSubmissionModule } from './share-submission.module';

describe('ShareSubmissionModule', () => {
  let shareSubmissionModule: ShareSubmissionModule;

  beforeEach(() => {
    shareSubmissionModule = new ShareSubmissionModule();
  });

  it('should create an instance', () => {
    expect(shareSubmissionModule).toBeTruthy();
  });
});
