import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import {
  MatFormFieldModule,
  MatCheckboxModule,
  MatInputModule,
  MatAutocompleteModule,
  MatButtonModule,
  MatTabsModule,
  MatStepperModule,
  MatIconModule,
  MatTooltipModule
} from '@angular/material';

import { GraphApiModule } from '@content-platform/graph-api';
import { CommonHelpersModule } from '@content-platform/common-helpers';

import { ShareByEmailComponent } from './share-by-email/share-by-email.component';
import { ShareByUrlComponent } from './share-by-url/share-by-url.component';
import { ShareSubmissionComponent } from './share-submission/share-submission.component';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    MatCheckboxModule,
    MatButtonModule,
    MatTabsModule,
    MatStepperModule,
    MatIconModule,
    MatTooltipModule,
    GraphApiModule,
    CommonHelpersModule
  ],
  declarations: [ShareByEmailComponent, ShareByUrlComponent, ShareSubmissionComponent],
  entryComponents: [ShareSubmissionComponent]
})
export class ShareSubmissionModule {}
