import { Component, NgModule, Input } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShareSubmissionComponent } from './share-submission.component';
import { MaterialMockModule } from '@content-platform/unit-test-helpers';
import { MatDialog, MatDialogModule } from '@angular/material';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-test',
  template: `
    <div>Test</div>
  `
})
export class AppTestComponent {
  constructor(private dialog: MatDialog) {}

  open() {
    this.dialog.open(ShareSubmissionComponent, {
      width: '500px',
      data: {
        url: 'www.google.com'
      }
    });
  }
}

@Component({
  selector: 'app-share-by-email',
  template: `
    <div>Test</div>
  `
})
export class ShareByEmailComponent {
  @Input()
  url;
  @Input()
  submissionId;
  @Input()
  sharedUserData;
}

@Component({
  selector: 'app-share-by-url',
  template: `
    <div>Test</div>
  `
})
export class ShareByUrlComponent {
  @Input()
  url;
}

@NgModule({
  imports: [CommonModule, MaterialMockModule, MatDialogModule],
  declarations: [ShareSubmissionComponent, ShareByUrlComponent, ShareByEmailComponent],
  entryComponents: [ShareSubmissionComponent]
})
export class ShareSubmissionModule {}

describe('ShareSubmissionComponent', () => {
  let component: AppTestComponent;
  let fixture: ComponentFixture<AppTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ShareSubmissionModule],
      declarations: [AppTestComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
