import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-share-submission',
  templateUrl: './share-submission.component.html',
  styleUrls: ['./share-submission.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ShareSubmissionComponent implements OnInit {
  title = 'Share Submission';

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<ShareSubmissionComponent>
  ) {}

  ngOnInit() {}

  cancel() {
    this.dialogRef.close();
  }

  share() {
    this.dialogRef.close();
  }
}
