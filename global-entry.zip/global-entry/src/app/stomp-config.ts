import { StompConfig } from '@stomp/ng2-stompjs';
import * as SockJS from 'sockjs-client';
import { Environments } from '@content-platform/configuration';

export const socketProvider = () => {
  return new SockJS(Environments.getUrl('pushNotificationEndpoint'));
};

export const stompConfig: StompConfig = {
  url: socketProvider,

  headers: {
    username: ''
  },

  heartbeat_in: 0, // Typical value 0 - disabled
  heartbeat_out: 20000, // Typical value 20000 - every 20 seconds

  reconnect_delay: 5000,

  // Will log diagnostics on console
  debug: false
};
