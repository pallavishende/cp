import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { DashboardContainerComponent } from './dashboard-container.component';
import { MatTabsModule } from '@angular/material';
import { DashboardPreferencesService } from '../dashboard-preferences.service';
import { of } from 'rxjs';
import { StoreModule, combineReducers } from '@ngrx/store';
import * as fromStore from '../store';

describe('DashboardContainerComponent', () => {
  let component: DashboardContainerComponent;
  let fixture: ComponentFixture<DashboardContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DashboardContainerComponent],
      imports: [
        RouterTestingModule,
        MatTabsModule,
        StoreModule.forRoot({ dashboard: combineReducers(fromStore.dashboardReducer) })
      ],
      providers: [
        {
          provide: DashboardPreferencesService,
          useValue: {
            displayedSubmissionStatuses$: of({})
          }
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
