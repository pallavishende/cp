import { Component } from '@angular/core';
import * as fromStore from '../store';
import { Store, select } from '@ngrx/store';
import { SubmissionStatusCount } from '../store';

@Component({
  selector: 'app-dashboard-container',
  templateUrl: './dashboard-container.component.html',
  styleUrls: ['./dashboard-container.component.scss']
})
export class DashboardContainerComponent {
  statusCount: SubmissionStatusCount;

  constructor(private store: Store<fromStore.DashboardState>) {
    this.store.pipe(select(fromStore.getRecordsSubmissionStatusCountState)).subscribe(value => {
      this.statusCount = value;
    });
  }
}
