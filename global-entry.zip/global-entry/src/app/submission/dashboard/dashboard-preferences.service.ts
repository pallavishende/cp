import { Injectable } from '@angular/core';
import {
  Preference,
  userPreferenceSelectors,
  UserPreferenceActions
} from '@content-platform/preferences-api';
import { Store, select } from '@ngrx/store';
import { orderBy } from 'lodash';
import { Observable, combineLatest, Subject } from 'rxjs';
import { map, withLatestFrom, filter } from 'rxjs/operators';
import * as fromStore from './store';
import { SubmissionStatus } from './store';
import { SubmissionTypes } from './store/states/submission-status.state';

export enum DashboardPreferences {
  AvailableTableColumns = 'dashboard-all-columns',
  ColumnFilters = 'dashboard-shown-column-filters',
  SharedByColumnFilters = 'dashboard-shown-shared-by-column-filters',
  SharedWithColumnFilters = 'dashboard-shown-shared-with-column-filters',
  StatusFilters = 'dashboard-shown-status-filters',
  SubmissionsPerPage = 'dashboard-submissions-per-page',
  DefaultStatusFilter = 'dashboard-quick-filter-selection',
  StartDate = 'dashboard-start-date',
  EndDate = 'dashboard-end-date'
}

@Injectable()
export class DashboardPreferencesService {
  private userPreferences$: Observable<Preference>;
  private contentStatusListSample$: Observable<SubmissionTypes>;
  displayedColumns$: Observable<string[]>;
  displayedSubmissionStatuses$: Observable<SubmissionStatus[]>;
  defaultSubmissionStatus$: Observable<SubmissionStatus>;
  startDate$: Observable<string>;
  endDate$: Observable<string>;
  pageSize = 50;
  sharedType: string;
  sharedTypeSubject = new Subject<string>();
  filterType: string;
  availableColumns = [];

  constructor(private store: Store<fromStore.DashboardState>) {
    this.sharedTypeSubject.subscribe(sharedType => {
      this.sharedType = sharedType;
      this.filterType = DashboardPreferences.ColumnFilters;
    });
    this.userPreferences$ = this.store.pipe(
      select(userPreferenceSelectors.getCurrentUserAppPreferences)
    );
    this.userPreferences$.subscribe(
      pref => (this.availableColumns = pref[DashboardPreferences.AvailableTableColumns])
    );
    this.displayedColumns$ = this.userPreferences$.pipe(
      map(preferences => preferences[this.filterType]),
      map(columnNames => {
        let columns = columnNames.map(name =>
          this.availableColumns.find(column => column.name === name)
        );
        columns = columns.filter(column => !!column);
        if (this.sharedType === 'me' && !columns.find(col => col.name === 'sharedBy')) {
          columns.push({ name: 'sharedBy', label: 'Shared By', order: 6 });
        }
        if (this.sharedType === 'others' && !columns.find(col => col.name === 'sharedWith')) {
          columns.push({ name: 'sharedWith', label: 'Shared With', order: 6 });
        }
        return orderBy(columns, 'order', 'asc').map(column => column.name);
      })
    );

    this.startDate$ = this.store.pipe(
      select(userPreferenceSelectors.getCurrentUserPreference(DashboardPreferences.StartDate))
    );
    this.endDate$ = this.store.pipe(
      select(userPreferenceSelectors.getCurrentUserPreference(DashboardPreferences.EndDate))
    );

    this.contentStatusListSample$ = this.store.pipe(
      select(fromStore.getRecordsSubmissionStatusState)
    );
    this.displayedSubmissionStatuses$ = this.contentStatusListSample$.pipe(
      withLatestFrom(
        this.userPreferences$.pipe(map(pref => pref[DashboardPreferences.StatusFilters]))
      ),
      map(([statuses, chosenStatuses]) => {
        if (this.sharedType !== undefined) {
          if (this.sharedType === 'me') {
            return statuses.sharedWithMe.filter(status => chosenStatuses.includes(status.code));
          } else if (this.sharedType === 'others') {
            return statuses.sharedSubmissions.filter(status =>
              chosenStatuses.includes(status.code)
            );
          } else {
            return statuses.mySubmissions.filter(status => chosenStatuses.includes(status.code));
          }
        }
      })
    );

    this.defaultSubmissionStatus$ = combineLatest(
      this.userPreferences$,
      this.displayedSubmissionStatuses$
    ).pipe(
      filter(([, statuses]) => {
        return statuses && statuses.length > 0;
      }),
      map(([preferences, statuses]) => {
        const defaultStatus: string = preferences[DashboardPreferences.DefaultStatusFilter];
        const defaultInSelected = statuses.find(
          statusFilter => statusFilter.code === defaultStatus
        );
        if (defaultInSelected) {
          return defaultInSelected;
        }
        return (preferences[DashboardPreferences.StatusFilters] || [])[0];
      })
    );

    this.store
      .pipe(
        select(
          userPreferenceSelectors.getCurrentUserPreference(DashboardPreferences.SubmissionsPerPage)
        )
      )
      .subscribe(subPerPage => (this.pageSize = subPerPage));
  }

  private updateStore(data) {
    this.store.dispatch(new UserPreferenceActions.Update(data));
  }

  updatePageSize(newPageSize: number) {
    const data = {};
    data[DashboardPreferences.SubmissionsPerPage] = newPageSize;
    this.updateStore(data);
  }

  setDefaultStatus(status: SubmissionStatus) {
    const data = {};
    data[DashboardPreferences.DefaultStatusFilter] = status;
    this.updateStore(data);
  }

  updateStartDate(date: string) {
    const data = {};
    data[DashboardPreferences.StartDate] = date;
    this.updateStore(data);
  }

  updateEndDate(date: string) {
    const data = {};
    data[DashboardPreferences.EndDate] = date;
    this.updateStore(data);
  }

  showDashboardColumn(name: string): Observable<boolean> {
    return this.displayedColumns$.pipe(
      map((columnList: string[]) => {
        if (columnList && columnList.includes(name)) {
          return true;
        }
        return false;
      })
    );
  }
}
