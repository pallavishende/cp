import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { UserPermissionListGuard } from '@content-platform/application-api';
import { UserDetailResolver } from '../../resolvers/user-detail.resolver';
import { UserPreferencesGuard } from '@content-platform/preferences-api';
import { DashboardContainerComponent } from './dashboard-container/dashboard-container.component';

const DASHBOARD_ROUTES: Routes = [
  {
    path: '',
    component: DashboardContainerComponent,
    canActivate: [UserPermissionListGuard, UserPreferencesGuard],
    resolve: {
      userDetail: UserDetailResolver
    },
    children: [
      {
        path: '',
        component: DashboardComponent,
        canActivate: [UserPermissionListGuard, UserPreferencesGuard],
        resolve: {
          userDetail: UserDetailResolver
        },
        data: { sharedType: '' }
      },
      {
        path: 'sharedWithMe',
        component: DashboardComponent,
        canActivate: [UserPermissionListGuard, UserPreferencesGuard],
        resolve: {
          userDetail: UserDetailResolver
        },
        data: { sharedType: 'me' }
      },
      {
        path: 'others',
        component: DashboardComponent,
        canActivate: [UserPermissionListGuard, UserPreferencesGuard],
        resolve: {
          userDetail: UserDetailResolver
        },
        data: { sharedType: 'others' }
      }
    ]
  }
];
@NgModule({
  imports: [RouterModule.forChild(DASHBOARD_ROUTES)],
  exports: [RouterModule]
})
export class DashboardRoutingModule {}
