import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute } from '@angular/router';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { DashboardComponent } from './dashboard.component';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { CdkTableModule } from '@angular/cdk/table';
import {
  MatIconModule,
  MatInputModule,
  MatPaginatorModule,
  MatSortModule,
  MatTableModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatButtonModule,
  MatProgressSpinnerModule,
  MatDialog
} from '@angular/material';
import { LoggerService } from '@content-platform/logging';
import { SubmissionService } from '../../services/submission.service';
import { ConfigurationService } from '@content-platform/configuration';
import { NavigationHelperService } from '@content-platform/common-helpers';
import { ClickOutsideDirective } from '@content-platform/reusable-ui/directives';
import { MockComponent, MaterialServiceMocks } from '@content-platform/unit-test-helpers';
import { StoreModule, combineReducers } from '@ngrx/store';
import * as fromStore from './store';
import { BehaviorSubject, of } from 'rxjs';
import { DashboardPreferencesService } from './dashboard-preferences.service';

import {
  PerfectScrollbarModule,
  PERFECT_SCROLLBAR_CONFIG,
  PerfectScrollbarConfigInterface
} from 'ngx-perfect-scrollbar';
import { DebugFlagsService } from '@content-platform/development';
import { UserPermissionsService } from '@content-platform/application-api';

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;

  const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {};

  const MockActivatedRoute = {
    snapshot: {
      data: {
        userDetail: {
          regions: ['LatAm'],
          canUserViewAll: {
            userInfo: {
              userName: 'xyz@viacomcontractor.com',
              profile: {}
            },
            canViewAll: true
          }
        }
      }
    },
    data: of({
      sharedType: ''
    })
  };
  class MockSubmissionService {
    loadSpinner$$ = new BehaviorSubject(false);
    searchTermSubject = new BehaviorSubject('page_load');

    setHeaderName(headerName: string) {
      return headerName;
    }
    setStatusParam() {}
    setFilterStartDate() {}
    setFilterEndDate() {}
    setRegionSelected() {}
  }
  const mockDebugFlags = {
    hasDebugFlag: () => {}
  };

  const state = {
    dashboard: {
      submissionRecordsState: {
        records: [],
        itemsCount: 0,
        response: null,
        loaded: false,
        loading: true
      },
      submissionStatusState: {
        records: [],
        response: 'success'
      }
    }
  };

  class UserPreferenceServiceMock {
    getFeatureMetadataList() {
      return [
        {
          name: 'ASIA'
        }
      ];
    }
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        DashboardComponent,
        ClickOutsideDirective,
        MockComponent({ selector: 'app-filter-input' }),
        MockComponent({ selector: 'app-status-aggregation' }),
        MockComponent({
          selector: 'app-filter-date',
          inputs: ['defaultStartDate', 'defaultEndDate']
        }),
        MockComponent({ selector: 'app-filter-dropdown' }),
        MockComponent({ selector: 'app-spinner-dialog' })
      ],
      imports: [
        CommonModule,
        RouterTestingModule,
        NoopAnimationsModule,
        StoreModule.forRoot(
          { dashboard: combineReducers(fromStore.dashboardReducer) },
          { initialState: <any>state }
        ),
        FormsModule,
        ReactiveFormsModule,
        CdkTableModule,
        MatIconModule,
        MatInputModule,
        MatPaginatorModule,
        MatSortModule,
        MatTableModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatButtonModule,
        MatProgressSpinnerModule,
        PerfectScrollbarModule
      ],
      providers: [
        { provide: APP_BASE_HREF, useValue: '/' },
        { provide: SubmissionService, useClass: MockSubmissionService },
        {
          provide: LoggerService,
          useValue: {
            instance: () => {
              return { log: () => {} };
            }
          }
        },
        { provide: MatDialog, useValue: new MaterialServiceMocks.MatDialog() },
        { provide: ActivatedRoute, useValue: MockActivatedRoute },
        {
          provide: DashboardPreferencesService,
          useValue: {
            showDashboardColumn: () => {
              return of(true);
            },
            startDate$: of(new Date()),
            endDate$: of(new Date()),
            displayedColumns$: of([]),
            defaultSubmissionStatus$: of({})
          }
        },
        {
          provide: PERFECT_SCROLLBAR_CONFIG,
          useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
        },
        { provide: ConfigurationService, useValue: {} },
        { provide: NavigationHelperService, useValue: {} },
        { provide: DebugFlagsService, useValue: mockDebugFlags },
        {
          provide: UserPermissionsService,
          useClass: UserPreferenceServiceMock
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should compile', () => {
    expect(component).toBeTruthy();
  });
});
