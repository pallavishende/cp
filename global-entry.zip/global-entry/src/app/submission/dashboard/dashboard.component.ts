import {
  of as observableOf,
  merge as observableMerge,
  Observable,
  BehaviorSubject,
  Subscription,
  Subject
} from 'rxjs';

import {
  switchMap,
  throttleTime,
  distinctUntilChanged,
  take,
  map,
  skip,
  delay,
  takeUntil,
  withLatestFrom
} from 'rxjs/operators';
import { Component, AfterViewInit, ViewChild, OnInit, OnDestroy } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';

import { SubmissionService } from '../../services/submission.service';

import {
  MatDialog,
  MatPaginator,
  MatSort,
  MatTableDataSource,
  MatInput,
  MatDialogConfig,
  MatDialogRef,
  PageEvent
} from '@angular/material';
import { VideoPreviewComponent } from '../shared/video-preview/video-preview.component';
import { Store, select } from '@ngrx/store';
import * as fromStore from './store';
import { LoadSubmissionStatus } from './store/actions';
import { UserStatusCount } from '../../models/db-records';
import { STATUS_CHANGE } from './status-aggregation/status-aggregation.component';
import { START_FILTER_TEXT } from '../shared/filter-controls/filter-input/filter-input.component';
import {
  SET_START_FILTER_DATE,
  SET_END_FILTER_DATE
} from '../shared/filter-controls/filter-date/filter-date.component';
import { SET_REGION_SELECTED } from '../shared/filter-controls/filter-dropdown/filter-dropdown.component';
import { LoggerService } from '@content-platform/logging';
import { SpinnerDialogComponent } from '@content-platform/reusable-ui/loading-spinner';
import { DashboardPreferencesService } from './dashboard-preferences.service';
import { getFilteredRegions } from './store/reducers';
import { ClipboardService } from '@content-platform/common-helpers';
import { ShareSubmissionComponent } from '../../share-submission';
import { ApplicationApiConstants, UserPermissionsService } from '@content-platform/application-api';
import { ConfigurationService } from '@content-platform/configuration';
import { NavigationHelperService } from '@content-platform/common-helpers';
import { DebugFlagsService } from '@content-platform/development';
import { AuthDebugFlagNames } from '@content-platform/auth';
import {
  submissionActions,
  SubmissionLoadRequest,
  submissionSelectors,
  Submission
} from '@content-platform/submissions-api';
import { globalEntryMetadataKeys } from '../../../constants';
const PAGE_LOAD = 'page_load';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements AfterViewInit, OnInit, OnDestroy {
  dashboardRecords$: Observable<Submission[]>;
  dashboardLoading$: Observable<boolean>;
  dashboardStatusRecords$: Observable<any>;
  dashboardRecordsCount$: Observable<number>;
  recordsResponse$: Observable<boolean>;
  regionChanged$: Observable<string>;
  private refresh$ = new Subject<void>();
  user$: Observable<adal.User>;
  loggedInUser;
  userName: string;
  isLoggedIn$: Observable<boolean>;
  defaultPageSize = 50;
  defaultPageIndex = 0;
  defaultPagesizeOptions: Array<number> = [50, 100, 200];
  sharedType: string;
  dataSource = new MatTableDataSource();
  resultsLength = 0;
  isLoadingResults = true;
  isRateLimitReached = false;
  statusCount;
  dashboardData;
  dashboardDataSample;
  showNoRecord = false;
  videos;
  dialogSubmissionData;
  editable = false;
  @ViewChild(MatPaginator)
  paginator: MatPaginator;
  @ViewChild(MatSort)
  sort: MatSort;
  @ViewChild(MatInput)
  input: MatInput;
  loadingSpinnerSubscription: Subscription;
  spinnerDialogConfig: MatDialogConfig;
  dialogRef: MatDialogRef<SpinnerDialogComponent>;
  admin: boolean;
  private logger: LoggerService;
  urlData: SubmissionLoadRequest;
  private onDestroy$ = new Subject<void>();
  currentRoute = '';
  private regions = [];

  constructor(
    private submissionService: SubmissionService,
    public dialog: MatDialog,
    private store: Store<fromStore.DashboardState>,
    private actRoute: ActivatedRoute,
    public dashboardPref: DashboardPreferencesService,
    public clipboardService: ClipboardService,
    private configurationService: ConfigurationService,
    private navHelperService: NavigationHelperService,
    loggerService: LoggerService,
    private debugFlagService: DebugFlagsService,
    private router: Router,
    private userPermissionsService: UserPermissionsService
  ) {
    this.spinnerDialogConfig = new MatDialogConfig();
    this.spinnerDialogConfig.disableClose = true;
    this.spinnerDialogConfig.panelClass = 'loading-spinner-wrapper';
    this.submissionService.setHeaderName('Dashboard');
    this.logger = loggerService.instance('Dashboard');
  }

  ngOnInit() {
    this.store
      .pipe(
        select(fromStore.getRecordsSubmissionStatusCountState),
        withLatestFrom(this.actRoute.data),
        takeUntil(this.onDestroy$),
        map(([statusCount, data]) => {
          this.sharedType = data.sharedType;
          this.dashboardPref.sharedTypeSubject.next(this.sharedType);
          if (
            (statusCount.sharedWithMe === 0 && this.sharedType === 'me') ||
            (statusCount.sharedSubmissions === 0 && this.sharedType === 'others')
          ) {
            return true;
          } else {
            return false;
          }
        })
      )
      .subscribe(value => {
        if (value) {
          this.router.navigate(['/dashboard']);
        }
      });
    this.regions = this.userPermissionsService
      .getFeatureMetadataList(globalEntryMetadataKeys.REGION)
      .map(region => region.name);
    if (this.debugFlagService) {
      const userData = this.actRoute.snapshot.data.userDetail.canUserViewAll.userInfo;
      if (this.debugFlagService.hasDebugFlag(AuthDebugFlagNames.Impersonate)) {
        this.userName = userData.profile.mail;
      } else {
        this.userName = userData.userName;
      }
    }
    // get logged in user
    this.loggedInUser =
      this.actRoute.snapshot.data.userDetail.canUserViewAll.canViewAll && this.sharedType === ''
        ? ''
        : this.userName;
    this.admin = this.actRoute.snapshot.data.userDetail.canUserViewAll.canViewAll ? true : false;
    // Initialising Search Term Subject
    this.submissionService.searchTermSubject = this.getDashboardSubject();

    // getting submission records data
    this.dashboardRecords$ = this.store.pipe(select(submissionSelectors.getAllSubmissionItems));

    // getting loading value from the state
    this.dashboardLoading$ = this.store.pipe(select(submissionSelectors.getSubmissionsLoading));

    // getting submission status data
    this.dashboardStatusRecords$ = this.store.pipe(
      select(fromStore.getRecordsSubmissionStatusState)
    );

    // Items count
    this.dashboardRecordsCount$ = this.store.pipe(select(submissionSelectors.getSubmissionsCount));

    // response
    this.recordsResponse$ = this.store.pipe(
      select(submissionSelectors.getAllSubmissionItems),
      map(response => response.length === 0)
    );

    this.regionChanged$ = this.store.pipe(
      select(getFilteredRegions),
      distinctUntilChanged(),
      takeUntil(this.onDestroy$),
      skip(1),
      map(() => SET_REGION_SELECTED)
    );

    // show/hide loading spinner
    this.loadingSpinnerSubscription = this.dashboardLoading$
      .pipe(
        skip(1),
        throttleTime(500, undefined, { leading: true, trailing: true }),
        distinctUntilChanged()
      )
      .subscribe(res => {
        Promise.resolve().then(() => {
          res ? this.showSpinner() : this.hideSpinner();
        });
      });
    this.defaultPageSize = this.dashboardPref.pageSize;
  }

  get columnHeaderClass() {
    return { 'column-header-row': true };
  }

  getDashboardSubject(): BehaviorSubject<string> {
    const resSub = new BehaviorSubject<string>(PAGE_LOAD);
    return resSub;
  }

  getStatusClasses(submissionStatus) {
    return {
      completeingest: submissionStatus === 'INGESTCOMPLETED',
      rejected: submissionStatus === 'REJECTED',
      archived: submissionStatus === 'ARCHIVED',
      pendingapproval: submissionStatus === 'PENDINGAPPROVAL',
      pendingqc: submissionStatus === 'PENDINGQC',
      awaitingelements: submissionStatus === 'AWAITINGELEMENTS'
    };
  }

  getArtistsName(musicVideoSubmission) {
    if (musicVideoSubmission.submissionFormData.artists) {
      return musicVideoSubmission.submissionFormData.artists.map(artist => artist.name).join(',');
    }
    return '';
  }
  getSharedBy(musicVideoSubmission) {
    const sharedArray = musicVideoSubmission.sharedUsers;
    if (sharedArray && sharedArray.length > 0) {
      return sharedArray[sharedArray.length - 1].sharedBy;
    }
  }
  getTrackTitle(musicVideoSubmission) {
    const titleField = musicVideoSubmission.submissionFormData.trackTitle;
    return titleField ? titleField : '';
  }
  setParamsOnPageLoad() {
    this.paginator.pageIndex = this.defaultPageIndex;
    this.sort.direction = 'desc';
    this.sort.active = 'created_date';
    this.submissionService.filterMusicDataValue = '';
    this.submissionService.filterStartDate = undefined;
    this.submissionService.filterEndDate = undefined;
  }

  openDialog(id) {
    this.dialog.open(VideoPreviewComponent, {
      data: { id, editable: true },
      panelClass: 'modalPopup',
      width: '672px',
      height: '610px'
    });
  }

  clickedSubmissionId(submission: fromStore.SubmissionRecords) {
    this.logger.log('Viewing Submission', { submissionId: submission.id });
  }

  showPlayer(statusCode: string): boolean {
    return statusCode === 'AWAITINGELEMENTS' ? false : true;
  }

  ngAfterViewInit() {
    const submissionCountData: UserStatusCount = {
      contentType: 'all',
      email: this.userName,
      shared: this.sharedType,
      admin: this.admin
    };
    // Dispatching LoadSubmissionStatus action
    this.store.dispatch(new LoadSubmissionStatus(submissionCountData));
    this.dashboardPref.defaultSubmissionStatus$.pipe(take(1)).subscribe(defaultSub => {
      this.submissionService.selectedStatusCode = defaultSub.code;
      this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));
      observableMerge(
        this.sort.sortChange,
        this.paginator.page,
        this.regionChanged$,
        this.submissionService.searchTermSubject.asObservable(),
        this.refresh$
      )
        .pipe(
          delay(0),
          withLatestFrom(this.store.pipe(select(getFilteredRegions))),
          switchMap(([res, filteredRegions]) => {
            if (
              res === START_FILTER_TEXT ||
              res === STATUS_CHANGE ||
              res === SET_START_FILTER_DATE ||
              res === SET_END_FILTER_DATE ||
              res === SET_REGION_SELECTED
            ) {
              this.paginator.pageIndex = 0;
            } else if (res === PAGE_LOAD) {
              this.setParamsOnPageLoad();
            } else if (
              res &&
              (<PageEvent>res).pageSize &&
              (<PageEvent>res).pageSize !== this.defaultPageSize
            ) {
              this.dashboardPref.updatePageSize((<PageEvent>res).pageSize);
            }
            if (res === SET_REGION_SELECTED) {
              this.store.dispatch(new LoadSubmissionStatus(submissionCountData));
            }
            this.urlData = {
              contentType: 'all',
              page: this.paginator.pageIndex + 1,
              size: this.paginator.pageSize,
              status: this.submissionService.setStatusParam(),
              sortColumn: this.sort.active,
              sortDirection: this.sort.direction,
              shared: this.sharedType,
              fromDate: this.submissionService.setFilterStartDate(),
              toDate: this.submissionService.setFilterEndDate(),
              searchTerm: this.submissionService.filterMusicDataValue || '',
              submittedUserEmail: this.loggedInUser,
              region: filteredRegions.length === 0 ? this.regions : filteredRegions,
              admin: this.admin
            };
            if (this.sort.active === 'createdBy') {
              this.urlData.sortColumn = 'created_by';
            }
            if (this.sort.active === 'createdDate') {
              this.urlData.sortColumn = 'created_date';
            }
            if (this.sort.active === 'submissionStatusCode') {
              this.urlData.sortColumn = 'submission_status_code';
            }
            if (this.sort.active === 'statusDetail') {
              this.urlData.sortColumn = 'status_detail';
            }
            if (this.sort.active === 'submittedToRegion') {
              this.urlData.sortColumn = 'region';
            }
            if (this.sort.active === 'artistName') {
              this.urlData.sortColumn = 'name';
            }
            if (this.sort.active === 'sharedBy') {
              this.urlData.sortColumn = 'shared_by';
            }
            if (this.sort.active === 'sharedWith') {
              this.urlData.sortColumn = 'shared_with';
            }
            if (this.sort.active === 'id') {
              this.urlData.sortColumn = 'submission_id';
            }
            // Dispatching LoadSubmissionRecords action
            this.store.dispatch(new submissionActions.Load(this.urlData));

            if (res !== PAGE_LOAD) {
              this.logger.log('Filtered Submissions', { filterType: res, ...this.urlData });
            }

            return observableOf([]);
          }),
          takeUntil(this.onDestroy$)
        )
        .subscribe(() => {});
    });
  }

  filterByDates(startDate, endDate) {
    this.submissionService.filterByDateRange(startDate, endDate);
  }

  refreshData(): void {
    this.refresh$.next();
  }

  showSpinner() {
    this.isLoadingResults = true;
  }

  hideSpinner() {
    this.isLoadingResults = false;
  }

  getShareLink(musicVideoSubmission) {
    const domain =
      location.protocol + '//' + location.hostname + (location.port ? ':' + location.port : '');
    const appUrlName = this.navHelperService.getUrlSanitizedString(
      ApplicationApiConstants.activeAppName
    );
    const app = this.configurationService.isRunningLocally() ? '' : '/' + appUrlName;

    return `${domain}${app}/submission/${musicVideoSubmission.contentType}/view/${
      musicVideoSubmission.id
    }`;
  }

  showShareOptionsModal(musicVideoSubmission) {
    const ref = this.dialog.open(ShareSubmissionComponent, {
      width: '500px',
      data: {
        id: musicVideoSubmission.id,
        url: this.getShareLink(musicVideoSubmission),
        sharedUsers: musicVideoSubmission.sharedUsers,
        showOnlyEmail: true
      }
    });
    ref.afterClosed().subscribe(() => {
      // TODO after closing modal, should open up notification based on the response
    });
  }

  ngOnDestroy() {
    if (this.submissionService.searchTermSubject) {
      this.submissionService.searchTermSubject.complete();
    }
    if (this.loadingSpinnerSubscription) {
      this.loadingSpinnerSubscription.unsubscribe();
    }
    this.onDestroy$.next();
  }
}
