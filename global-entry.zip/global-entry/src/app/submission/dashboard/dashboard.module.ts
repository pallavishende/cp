import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { DashboardComponent } from './dashboard.component';
import { FilterInputComponent } from '../shared/filter-controls/filter-input/filter-input.component';
import { StatusAggregationModule } from './status-aggregation/status-aggregation.module';
import { FilterDateComponent } from '../shared/filter-controls/filter-date/filter-date.component';
import { FilterDropdownComponent } from '../shared/filter-controls/filter-dropdown/filter-dropdown.component';
import { ClipboardService } from '@content-platform/common-helpers';
import { CdkTableModule } from '@angular/cdk/table';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import * as fromStore from './store';
import { ShareSubmissionModule } from '../../share-submission';
import { ConfigurationService } from '@content-platform/configuration';
import { NavigationHelperService } from '@content-platform/common-helpers';
import { DirectivesModule } from '@content-platform/reusable-ui/directives';

import {
  MatIconModule,
  MatInputModule,
  MatPaginatorModule,
  MatSortModule,
  MatTableModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatButtonModule,
  MatProgressSpinnerModule,
  MatSelectModule,
  MatTooltipModule,
  MatTabsModule,
  MAT_DATE_FORMATS,
  DateAdapter
} from '@angular/material';
import { UserDetailResolver } from '../../resolvers/user-detail.resolver';
import { DashboardPreferencesService } from './dashboard-preferences.service';
import { DashboardContainerComponent } from './dashboard-container/dashboard-container.component';

import {
  PerfectScrollbarModule,
  PERFECT_SCROLLBAR_CONFIG,
  PerfectScrollbarConfigInterface
} from 'ngx-perfect-scrollbar';
import {
  AppDateAdapter,
  APP_DATE_FORMATS
} from '@content-platform/reusable-ui/dynamic-form-builder';
import { LoadingSpinnerModule } from '@content-platform/reusable-ui/loading-spinner';
import { PipesModule } from '@content-platform/pipes';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {};

@NgModule({
  declarations: [
    DashboardContainerComponent,
    DashboardComponent,
    FilterInputComponent,
    FilterDateComponent,
    FilterDropdownComponent
  ],
  imports: [
    CommonModule,
    StoreModule.forFeature('dashboard', fromStore.dashboardReducer),
    EffectsModule.forFeature(fromStore.dashboardEffects),
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    CdkTableModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    StatusAggregationModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatButtonModule,
    MatProgressSpinnerModule,
    MatSelectModule,
    DashboardRoutingModule,
    MatTooltipModule,
    ShareSubmissionModule,
    PerfectScrollbarModule,
    DirectivesModule,
    LoadingSpinnerModule,
    PipesModule
  ],
  providers: [
    UserDetailResolver,
    DashboardPreferencesService,
    ConfigurationService,
    NavigationHelperService,
    ClipboardService,
    {
      provide: DateAdapter,
      useClass: AppDateAdapter
    },
    {
      provide: MAT_DATE_FORMATS,
      useValue: APP_DATE_FORMATS
    },
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    },
    ShareSubmissionModule
  ],
  exports: []
})
export class DashboardModule {}
