import { async } from '@angular/core/testing';
import { OrderStatusPipe } from './order-status.pipe';

describe('OrderStatusPipe', () => {
  const pipe = new OrderStatusPipe();

  const currentString = [
    { status: 'Awaiting Elements', count: 2, order: 1 },
    { status: 'All', count: 41, order: 7 },
    { status: 'Complete Ingest', count: 12, order: 5 },
    { status: 'Pending QC', count: 5, order: 2 },
    { status: 'Pending Ingest', count: 4, order: 3 },
    { status: 'Failed', count: 11, order: 6 },
    { status: 'In Progress Ingest', count: 7, order: 4 }
  ];

  const orderedString = [
    { status: 'Awaiting Elements', count: 2, order: 1 },
    { status: 'Pending QC', count: 5, order: 2 },
    { status: 'Pending Ingest', count: 4, order: 3 },
    { status: 'In Progress Ingest', count: 7, order: 4 },
    { status: 'Complete Ingest', count: 12, order: 5 },
    { status: 'Failed', count: 11, order: 6 },
    { status: 'All', count: 41, order: 7 }
  ];
  it('OrderStatusTilePipe should sort the array in the given specific order', async(() => {
    expect(pipe.transform(currentString)).toEqual(orderedString);
  }));
});
