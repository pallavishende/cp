import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderStatusBy'
})
export class OrderStatusPipe implements PipeTransform {
  transform(array: any[]) {
    if (array === null) {
      return [];
    }
    array.sort((a: any, b: any) => {
      if (a.order < b.order) {
        return -1;
      } else if (a.order > b.order) {
        return 1;
      }
    });
    return array;
  }
}
