import { of as observableOf, Subject } from 'rxjs';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatCardModule } from '@angular/material';

import { StatusAggregationComponent } from './status-aggregation.component';
import { PageSortInput, ContentTypeStatusCount } from '../../../models';
import { OrderStatusPipe } from './pipes/order-status.pipe';
import { SubmissionService } from '../../../services/submission.service';
import * as fromStore from '../store';

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

describe('StatusAggregationComponent', () => {
  let fixture: ComponentFixture<StatusAggregationComponent>;
  let component: StatusAggregationComponent;

  const pageSortInputValue: PageSortInput = { type: 'filterInput', pageValue: 0 };
  const contentStatusCount: ContentTypeStatusCount[] = [
    { code: 'AWAITINGELEMENTS', description: 'Awaiting Elements', count: '3' },
    { code: 'INGESTINPROGRESS', description: 'Ingest In Progress', count: '2' }
  ];

  class SubmissionServiceStub {
    status: string;
    selectedStatusCode: string;
    private pageSortSubject = new Subject<PageSortInput>();
    private searchTermSubject = new Subject<string>();
    setPageSortInput(pageSortInput: PageSortInput) {
      return this.pageSortSubject.next(pageSortInput);
    }
    getPageSortInput() {
      return observableOf(pageSortInputValue);
    }
    getStatusCount() {
      this.searchTermSubject.next('');
    }

    getContentTypeStatusCount() {
      return observableOf(contentStatusCount);
    }
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [StatusAggregationComponent, OrderStatusPipe],
      imports: [
        BrowserAnimationsModule,
        MatCardModule,
        StoreModule.forRoot(
          { dashboard: fromStore.dashboardReducer },
          { initialState: { dashboard: { submissionsStatusState: { records: [] } } } }
        ),
        EffectsModule.forRoot([])
      ],
      providers: [{ provide: SubmissionService, useClass: SubmissionServiceStub }]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StatusAggregationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create the component', async(() => {
    expect(component).toBeTruthy();
  }));
});
