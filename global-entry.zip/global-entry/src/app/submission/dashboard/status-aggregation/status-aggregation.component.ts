import { Component, OnDestroy, OnInit } from '@angular/core';

import { SubmissionService } from '../../../services/submission.service';
import { ContentTypeStatusCount } from '../../../models';
import { Observable, Subject } from 'rxjs';
import { SubmissionStatus } from '../store';
import { DashboardPreferencesService } from '../dashboard-preferences.service';
import { takeUntil } from 'rxjs/operators';

export const STATUS_CHANGE = 'status change';
@Component({
  selector: 'app-status-aggregation',
  templateUrl: './status-aggregation.component.html',
  styleUrls: ['./status-aggregation.component.scss']
})
export class StatusAggregationComponent implements OnInit, OnDestroy {
  selectedItem = 'All';
  style;
  contentStatusListSample$: Observable<SubmissionStatus[]>;
  private onDestroy$ = new Subject<void>();

  constructor(
    private submissionService: SubmissionService,
    public dashboardPref: DashboardPreferencesService
  ) {}

  ngOnInit() {
    this.dashboardPref.defaultSubmissionStatus$
      .pipe(takeUntil(this.onDestroy$))
      .subscribe(defaultSub => (this.selectedItem = defaultSub.description));
  }

  getClass(status, suffix) {
    return status.description
      .replace(/ +/g, '')
      .toLowerCase()
      .concat(suffix);
  }

  getColor(status: ContentTypeStatusCount, colorIf: string, colorElse: string) {
    return status.description === this.selectedItem ? colorIf : colorElse;
  }

  getStatusCount(count: number) {
    return count > -1 ? count : '--';
  }

  onStatusClick(status: ContentTypeStatusCount) {
    let statusCode;
    if (status.description === this.selectedItem) {
      statusCode = 'ALL';
      this.selectedItem = 'All';
    } else {
      status.code === 'ALL' ? (statusCode = 'ALL') : (statusCode = status.code);
      this.selectedItem = status.description;
    }
    this.submissionService.selectedStatusCode = statusCode;
    this.submissionService.searchTermSubject.next(STATUS_CHANGE);
    this.dashboardPref.setDefaultStatus(statusCode);
  }

  ngOnDestroy() {
    this.onDestroy$.next();
  }
}
