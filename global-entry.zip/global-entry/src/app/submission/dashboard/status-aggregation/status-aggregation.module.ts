import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material';

import { OrderStatusPipe } from './pipes/order-status.pipe';
import { StatusAggregationComponent } from './status-aggregation.component';

@NgModule({
  imports: [CommonModule, MatCardModule],
  declarations: [OrderStatusPipe, StatusAggregationComponent],
  exports: [StatusAggregationComponent]
})
export class StatusAggregationModule {}
