import { Action } from '@ngrx/store';
import { NotificationMessageData } from '../states';

export enum PushNotificationActiontypes {
  GET_PUSH_NOTIFICATION_DATA = '[Push Notification] Push Notification Data',
  GET_PUSH_NOTIFICATION_MESSAGE = '[Push Notification] Push Notification Message'
}

export class NotificationDataAction implements Action {
  readonly type = PushNotificationActiontypes.GET_PUSH_NOTIFICATION_DATA;
  constructor(public payload: NotificationMessageData) {}
}

export class NotificationMessageAction implements Action {
  readonly type = PushNotificationActiontypes.GET_PUSH_NOTIFICATION_MESSAGE;
  constructor(public payload: string) {}
}

export type NotificationActions = NotificationDataAction | NotificationMessageAction;
