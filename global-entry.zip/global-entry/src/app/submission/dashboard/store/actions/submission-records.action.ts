import { Action } from '@ngrx/store';
import * as fromDashboardState from '../states';
import { RequestParams } from '../../../../models/db-records';

export const LOAD_SUBMISSION_RECORDS = 'Load Submission Records';
export const LOAD_SUBMISSION_RECORDS_FAIL = 'Load Submission Records Fail';
export const LOAD_SUBMISSION_RECORDS_SUCCESS = 'Load Submission Records Success';
export const SET_FILTERED_REGIONS = 'Set Filtered Submission Regions';

export class LoadSubmissionRecords implements Action {
  readonly type = LOAD_SUBMISSION_RECORDS;
  constructor(public payload: RequestParams) {}
}

export class LoadSubmissionRecordsFail implements Action {
  readonly type = LOAD_SUBMISSION_RECORDS_FAIL;
  constructor(public payload: any) {}
}

export class LoadSubmissionRecordsSuccess implements Action {
  readonly type = LOAD_SUBMISSION_RECORDS_SUCCESS;
  constructor(
    public payload: { records: fromDashboardState.SubmissionRecords[]; itemsCount: number }
  ) {}
}

export class SetFilteredRegions {
  readonly type = SET_FILTERED_REGIONS;
  constructor(public payload: string[]) {}
}

export type SubmissionRecordsActions =
  | LoadSubmissionRecords
  | LoadSubmissionRecordsFail
  | LoadSubmissionRecordsSuccess
  | SetFilteredRegions;
