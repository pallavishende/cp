import { Action } from '@ngrx/store';
import { UserStatusCount } from '../../../../models/db-records';
import { SubmissionTypes } from '../states/submission-status.state';

export const LOAD_SUBMISSION_STATUS = 'Load Submission Status';
export const LOAD_SUBMISSION_STATUS_FAIL = 'Load Submission Status Fail';
export const LOAD_SUBMISSION_STATUS_SUCCESS = 'Load Submission Status Success';

export class LoadSubmissionStatus implements Action {
  readonly type = LOAD_SUBMISSION_STATUS;
  constructor(public payload: UserStatusCount) {}
}

export class LoadSubmissionStatusFail implements Action {
  readonly type = LOAD_SUBMISSION_STATUS_FAIL;
  constructor(public payload: any) {}
}

export class LoadSubmissionStatusSuccess implements Action {
  readonly type = LOAD_SUBMISSION_STATUS_SUCCESS;
  constructor(public payload: { records: SubmissionTypes }) {}
}

export type SubmissionStatusActions =
  | LoadSubmissionStatus
  | LoadSubmissionStatusFail
  | LoadSubmissionStatusSuccess;
