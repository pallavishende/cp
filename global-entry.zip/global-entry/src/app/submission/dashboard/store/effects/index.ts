import { SubmissionRecordsEffect } from './submission-records.effect';
import { SubmissionStatusEffect } from './submission-status.effect';
import { NotificationMessageEffect } from './notification-message.effect';

export * from './submission-records.effect';
export * from './submission-status.effect';

export const dashboardEffects = [
  SubmissionRecordsEffect,
  SubmissionStatusEffect,
  NotificationMessageEffect
];
