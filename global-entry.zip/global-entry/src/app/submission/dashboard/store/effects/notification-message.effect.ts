import { Injectable } from '@angular/core';
import { Effect, Actions, ofType } from '@ngrx/effects';
import {
  PushNotificationActiontypes,
  NotificationDataAction,
  NotificationMessageAction
} from '../actions';
import { SubmissionService } from '../../../../services/submission.service';

import { switchMap } from 'rxjs/operators';
import { of } from 'rxjs';

@Injectable()
export class NotificationMessageEffect {
  constructor(private actions$: Actions, private submissionService: SubmissionService) {}

  @Effect()
  loadNotificationMessages$ = this.actions$.pipe(
    ofType(PushNotificationActiontypes.GET_PUSH_NOTIFICATION_DATA),
    switchMap((action: NotificationDataAction) => {
      // create notification message
      const statusMsg = action.payload.submissionFormData.metadata;
      const notificationMessage = `New updates are available for ID ${statusMsg.isrc} with title ${
        statusMsg.trackTitle
      }`;

      // open toaster notification
      this.submissionService.openToasterNotification(notificationMessage);

      // call to action
      return of(new NotificationMessageAction(notificationMessage));
    })
  );
}
