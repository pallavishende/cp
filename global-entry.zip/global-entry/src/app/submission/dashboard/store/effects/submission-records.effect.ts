import { Injectable } from '@angular/core';
import { Effect } from '@ngrx/effects';
import * as submissionAction from '../actions';
import { SubmissionService } from '../../../../services/submission.service';

import { map, catchError } from 'rxjs/operators';
import { RequestParams } from '../../../../models/db-records';
import { of } from 'rxjs';
import {
  LoadSubmissionRecordsSuccess,
  LoadSubmissionRecords,
  LoadSubmissionRecordsFail
} from '../actions';
import { DataPersistence } from '@nrwl/nx';
import { UserPermissionsService } from '@content-platform/application-api';
import { globalEntryMetadataKeys } from '../../../../../constants/global-entry-feature';
import { DashboardState } from '../states/dashboard.state';
import { getFilteredRegions } from '../reducers';
import { SubmissionRecords } from '../states/submission-records.state';

@Injectable()
export class SubmissionRecordsEffect {
  constructor(
    private submissionService: SubmissionService,
    private dataPersistence: DataPersistence<DashboardState>,
    private userPermissionsService: UserPermissionsService
  ) {}

  @Effect()
  loadSubmissionRecords$ = this.dataPersistence.fetch(submissionAction.LOAD_SUBMISSION_RECORDS, {
    run: (action: LoadSubmissionRecords, state) => {
      const filteredRegions = getFilteredRegions(state);
      const allRegions = this.userPermissionsService
        .getFeatureMetadataList(globalEntryMetadataKeys.REGION)
        .map(region => region.name);
      const reqParams: RequestParams = action.payload;
      const {
        contentType,
        page,
        size,
        status,
        sortColumn,
        sortDirection,
        fromDate,
        toDate,
        searchTerm,
        shared,
        email,
        admin
      } = reqParams;
      return this.submissionService
        .loadContentTypeData(
          contentType,
          page,
          size,
          status,
          sortColumn,
          sortDirection,
          fromDate,
          toDate,
          searchTerm,
          shared,
          email,
          filteredRegions.length > 0 ? filteredRegions : allRegions,
          admin
        )
        .pipe(
          map((res: { records: SubmissionRecords[]; itemsCount: number }) => {
            return new LoadSubmissionRecordsSuccess(res);
          }),
          catchError(err => of(new LoadSubmissionRecordsFail(err)))
        );
    }
  });
}
