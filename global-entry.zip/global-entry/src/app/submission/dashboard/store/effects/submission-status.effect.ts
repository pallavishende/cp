import { Injectable } from '@angular/core';
import { DataPersistence } from '@nrwl/nx';
import { UserPermissionsService } from '@content-platform/application-api';
import { Effect } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { globalEntryMetadataKeys } from '../../../../../constants/global-entry-feature';
import { SubmissionService } from '../../../../services/submission.service';
import * as submissionAction from '../actions';
import {
  LoadSubmissionStatusFail,
  LoadSubmissionStatusSuccess,
  SubmissionStatusActions
} from '../actions/submission-status.action';
import { DashboardState } from '../states/dashboard.state';
import { getFilteredRegions } from '../reducers';

@Injectable()
export class SubmissionStatusEffect {
  constructor(
    private submissionService: SubmissionService,
    private dataPersistence: DataPersistence<DashboardState>,
    private userPermissionsService: UserPermissionsService
  ) {}

  @Effect()
  loadSubmissionStatus$ = this.dataPersistence.fetch(submissionAction.LOAD_SUBMISSION_STATUS, {
    run: (action: SubmissionStatusActions, state) => {
      const filteredRegions = getFilteredRegions(state);
      const allRegions = this.userPermissionsService
        .getFeatureMetadataList(globalEntryMetadataKeys.REGION)
        .map(region => region.name);
      const { contentType, email, shared, admin } = action.payload;
      return this.submissionService
        .getContentTypeStatusCount({
          contentType,
          email,
          shared,
          region: filteredRegions.length > 0 ? filteredRegions : allRegions,
          admin
        })
        .pipe(
          map((records: any) => {
            const payload = {
              records: records
            };
            return new LoadSubmissionStatusSuccess(payload);
          }),
          catchError(err => of(new LoadSubmissionStatusFail(err)))
        );
    }
  });
}
