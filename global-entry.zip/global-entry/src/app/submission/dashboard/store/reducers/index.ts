import { ActionReducerMap, createFeatureSelector, createSelector } from '@ngrx/store';
import { DashboardState } from '../';
import * as fromSubmissionRecordsReducer from './submission-records.reducer';
import * as fromSubmissionStatusReducer from './submission-status.reducer';
import * as fromNotificationMessageReducer from './notification-message.reducer';
import { getNotificationMessage } from './notification-message.reducer';

export const dashboardReducer: ActionReducerMap<DashboardState> = {
  submissionRecordsState: fromSubmissionRecordsReducer.submissionRecordsReducer,
  submissionStatusState: fromSubmissionStatusReducer.submissionStatusReducer,
  notificationMessageState: fromNotificationMessageReducer.NotificationReducer
};

export const getDashboardState = createFeatureSelector<DashboardState>('dashboard');

// get Submission Records State
export const getSubmissionRecordsState = createSelector(
  getDashboardState,
  (state: DashboardState) => state.submissionRecordsState
);

// get records from Submission Records State
export const getRecordsSubmissionRecordsState = createSelector(
  getSubmissionRecordsState,
  fromSubmissionRecordsReducer.getSubmissionRecords
);

// get loading from Submission records state
export const getLoadingSubmissionRecordsState = createSelector(
  getSubmissionRecordsState,
  fromSubmissionRecordsReducer.getLoadingSubmissionRecords
);

export const getFilteredRegions = createSelector(
  getSubmissionRecordsState,
  fromSubmissionRecordsReducer.getFilteredRegions
);

// get items count from Submission records state
export const getItemsCountSubmissionRecordsState = createSelector(
  getSubmissionRecordsState,
  fromSubmissionRecordsReducer.getSubmissionRecordsItemsCount
);

// get response from Submission records state
export const getResponseSubmissionRecordsState = createSelector(
  getSubmissionRecordsState,
  fromSubmissionRecordsReducer.getSubmissionRecordsResponse
);

// get Submission Status State
export const getSubmissionStatusState = createSelector(
  getDashboardState,
  (state: DashboardState) => state.submissionStatusState
);

// get records from Submission Status State
export const getRecordsSubmissionStatusState = createSelector(
  getSubmissionStatusState,
  fromSubmissionStatusReducer.getSubmissionStatus
);

// get record count for Submission statuses
export const getRecordsSubmissionStatusCountState = createSelector(
  getSubmissionStatusState,
  fromSubmissionStatusReducer.getSubmissionStatusCount
);

// get Notification Message State from Dashboard State
export const getNotificationMessageState = createSelector(
  getDashboardState,
  (state: DashboardState) => state.notificationMessageState
);

// get Notification Message from Notification Message State
export const getNotificationMessageContent = createSelector(
  getNotificationMessageState,
  getNotificationMessage
);
