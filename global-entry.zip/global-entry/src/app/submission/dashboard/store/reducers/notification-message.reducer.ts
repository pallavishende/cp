import { NotificationMessageState, NotificationMessageData } from '../states';

import * as pushNotificationActions from '../actions';

export const InitialNotificationMessageState: NotificationMessageState = {
  notificationData: undefined,
  notificationMessage: undefined
};

export function NotificationReducer(
  state: NotificationMessageState = InitialNotificationMessageState,
  action: pushNotificationActions.NotificationActions
): NotificationMessageState {
  switch (action.type) {
    case pushNotificationActions.PushNotificationActiontypes.GET_PUSH_NOTIFICATION_DATA: {
      const notificationData: NotificationMessageData = action.payload;
      return {
        ...state,
        notificationData
      };
    }
    case pushNotificationActions.PushNotificationActiontypes.GET_PUSH_NOTIFICATION_MESSAGE: {
      const notificationMessage = action.payload;
      return {
        ...state,
        notificationMessage
      };
    }
  }
  return state;
}

export const getNotificationMessage = (state: NotificationMessageState) =>
  state.notificationMessage;
