import { intialSubmissionRecordsState, SubmissionRecordsState } from '../states';
import {
  SubmissionRecordsActions,
  LOAD_SUBMISSION_RECORDS,
  LOAD_SUBMISSION_RECORDS_FAIL,
  LOAD_SUBMISSION_RECORDS_SUCCESS,
  SET_FILTERED_REGIONS
} from '../actions';

export function submissionRecordsReducer(
  state: SubmissionRecordsState = intialSubmissionRecordsState,
  action: SubmissionRecordsActions
): SubmissionRecordsState {
  switch (action.type) {
    case LOAD_SUBMISSION_RECORDS: {
      return {
        ...state,
        response: null,
        loading: true
      };
    }
    case LOAD_SUBMISSION_RECORDS_FAIL: {
      return {
        ...state,
        response: false,
        loading: false,
        loaded: true
      };
    }
    case LOAD_SUBMISSION_RECORDS_SUCCESS: {
      const records = action.payload.records || [];
      const itemsCount = action.payload.itemsCount;
      const response = records.length === 0 ? true : false;
      return {
        ...state,
        loading: false,
        loaded: false,
        response,
        records,
        itemsCount
      };
    }
    case SET_FILTERED_REGIONS: {
      const regions: string[] = action.payload;
      return {
        ...state,
        filterByRegions: regions
      };
    }
  }
  return state;
}

export const getSubmissionRecords = (state: SubmissionRecordsState) => state.records;
export const getSubmissionRecordsItemsCount = (state: SubmissionRecordsState) => state.itemsCount;
export const getLoadingSubmissionRecords = (state: SubmissionRecordsState) => state.loading;
export const getSubmissionRecordsResponse = (state: SubmissionRecordsState) => state.response;
export const getFilteredRegions = (state: SubmissionRecordsState) => state.filterByRegions;
