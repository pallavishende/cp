import { SubmissionStatusState, initialSubmissionStatusState } from '../states';
import {
  SubmissionStatusActions,
  LOAD_SUBMISSION_STATUS,
  LOAD_SUBMISSION_STATUS_FAIL,
  LOAD_SUBMISSION_STATUS_SUCCESS
} from '../actions';

export function submissionStatusReducer(
  state: SubmissionStatusState = initialSubmissionStatusState,
  action: SubmissionStatusActions
): SubmissionStatusState {
  switch (action.type) {
    case LOAD_SUBMISSION_STATUS: {
      return {
        ...state,
        response: null
      };
    }
    case LOAD_SUBMISSION_STATUS_FAIL: {
      return {
        ...state,
        response: 'fail'
      };
    }
    case LOAD_SUBMISSION_STATUS_SUCCESS: {
      const records = action.payload.records;
      return {
        ...state,
        response: 'success',
        records
      };
    }
  }
  return state;
}

export const getSubmissionStatusCount = (state: SubmissionStatusState) => {
  const statusCount = state.records;
  const mySubmissionsCount = statusCount.mySubmissions.find(status => status.code === 'ALL').count;
  const sharedWithMeCount = statusCount.sharedWithMe.find(status => status.code === 'ALL').count;
  const sharedSubmissionsCount = statusCount.sharedSubmissions.find(status => status.code === 'ALL')
    .count;
  const allStatusCount = {
    mySubmissions: mySubmissionsCount,
    sharedWithMe: sharedWithMeCount,
    sharedSubmissions: sharedSubmissionsCount
  };
  return allStatusCount;
};
export const getSubmissionStatus = (state: SubmissionStatusState) => state.records;
