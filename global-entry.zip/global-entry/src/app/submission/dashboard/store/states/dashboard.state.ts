import { SubmissionRecordsState, SubmissionStatusState, NotificationMessageState } from './';

export interface DashboardState {
  submissionRecordsState: SubmissionRecordsState;
  submissionStatusState: SubmissionStatusState;
  notificationMessageState: NotificationMessageState;
}
