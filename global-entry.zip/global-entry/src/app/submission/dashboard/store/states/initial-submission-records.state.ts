import { SubmissionRecords, SubmissionRecordsState } from './submission-records.state';

export const intialSubmissionRecords: SubmissionRecords[] = [];

export const intialSubmissionRecordsState: SubmissionRecordsState = {
  records: intialSubmissionRecords,
  filterByRegions: [],
  itemsCount: 0,
  response: null,
  loaded: false,
  loading: true
};
