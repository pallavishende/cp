import { SubmissionStatusState, SubmissionTypes } from './submission-status.state';

export const initialSubmissionStatus: SubmissionTypes = {
  mySubmissions: [
    {
      code: 'AWAITINGELEMENTS',
      description: 'Awaiting Elements',
      count: -1
    },
    {
      code: 'PENDINGQC',
      description: 'Pending QC',
      count: -1
    },
    {
      code: 'PENDINGAPPROVAL',
      description: 'Pending Approval',
      count: -1
    },
    {
      code: 'REJECTED',
      description: 'Rejected',
      count: -1
    },
    {
      code: 'ARCHIVED',
      description: 'Archived',
      count: -1
    },
    {
      code: 'ALL',
      description: 'All',
      count: -1
    }
  ],
  sharedSubmissions: [
    {
      code: 'AWAITINGELEMENTS',
      description: 'Awaiting Elements',
      count: -1
    },
    {
      code: 'PENDINGQC',
      description: 'Pending QC',
      count: -1
    },
    {
      code: 'PENDINGAPPROVAL',
      description: 'Pending Approval',
      count: -1
    },
    {
      code: 'REJECTED',
      description: 'Rejected',
      count: -1
    },
    {
      code: 'ARCHIVED',
      description: 'Archived',
      count: -1
    },
    {
      code: 'ALL',
      description: 'All',
      count: -1
    }
  ],
  sharedWithMe: [
    {
      code: 'AWAITINGELEMENTS',
      description: 'Awaiting Elements',
      count: -1
    },
    {
      code: 'PENDINGQC',
      description: 'Pending QC',
      count: -1
    },
    {
      code: 'PENDINGAPPROVAL',
      description: 'Pending Approval',
      count: -1
    },
    {
      code: 'REJECTED',
      description: 'Rejected',
      count: -1
    },
    {
      code: 'ARCHIVED',
      description: 'Archived',
      count: -1
    },
    {
      code: 'ALL',
      description: 'All',
      count: -1
    }
  ]
};

export const initialSubmissionStatusState: SubmissionStatusState = {
  records: initialSubmissionStatus,
  activeStatus: { code: 'ALL', description: 'All', count: 0 },
  response: 'success'
};
