interface MetaData {
  isrc: string;
  trackTitle: string;
}
interface SubmissionFormData {
  metadata: MetaData;
  rawFormData: string;
  tabs?: any[];
  useTabs?: boolean;
}

interface SubmissionStatus {
  code: string;
  description: string;
  longDescription: string;
  contentType: string;
}

export interface NotificationMessageData {
  id: number;
  submissionFormData: SubmissionFormData;
  submittedDate: string;
  modifiedDate: string;
  submittedBy: string;
  modifiedBy: string;
  contentType: string;
  submissionStatus: SubmissionStatus;
  fileDetails: object;
  previewUrl: string;
  submittedUserEmail: string;
  submittedUserPhone: string;
}

export interface NotificationMessageState {
  notificationData: NotificationMessageData;
  notificationMessage: string;
}
