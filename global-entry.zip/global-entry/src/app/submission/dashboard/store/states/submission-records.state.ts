export interface SubmissionRecords {
  id: number;
  // submissionFormData: DbRecordsSchema;
  submittedDate: string;
  modifiedDate: string;
  submittedBy: string;
  modifiedBy: string;
  contentType: string;
  submissionStatus: SubmissionRecordStatus;
  metadata?: any;
}

export interface SubmissionRecordStatus {
  code: string;
  description: string;
  longDescription: string;
  contentType: string;
}

export interface SubmissionRecordsState {
  records: SubmissionRecords[];
  filterByRegions: string[];
  itemsCount: number;
  response: boolean | null;
  loaded: boolean;
  loading: boolean;
}
