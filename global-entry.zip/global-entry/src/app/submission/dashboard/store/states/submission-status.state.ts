export interface SubmissionTypes {
  mySubmissions: SubmissionStatus[];
  sharedSubmissions: SubmissionStatus[];
  sharedWithMe: SubmissionStatus[];
}
export interface SubmissionStatus {
  code: string;
  description: string;
  longDescription?: string; // are these being used?
  contentType?: string; // are these being used?
  count: number;
}
export interface SubmissionStatusCount {
  mySubmissions: number;
  sharedWithMe: number;
  sharedSubmissions: number;
}
export interface SubmissionStatusState {
  records: SubmissionTypes;
  activeStatus?: SubmissionStatus;
  response: null | string;
}
