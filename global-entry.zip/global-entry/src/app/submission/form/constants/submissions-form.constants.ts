export const EDIT_FORM_FIELD_KEYS = [
  'previewUrl',
  'submissionStatus',
  'submittedBy',
  'submittedDate',
  'comments',
  'createdBy',
  'createdDate'
];

export interface SubmissionDatasetData {
  [key: string]: string[];
}

export const REGION_DATASET_LOOKUP = {
  contentType: 'content-platform',
  fieldKeys: ['global-entry-regions']
};

export enum SUBMISSION_STATUS {
  PENDINGQC_CODE = 'PENDINGQC',
  AWAITINGELEMENTS_CODE = 'AWAITINGELEMENTS',
  PENDINGAPPROVAL_CODE = 'PENDINGAPPROVAL',
  ARCHIVED_CODE = 'ARCHIVED',
  REJECTED_CODE = 'REJECTED',
  APPROVED_CODE = 'APPROVED'
}
