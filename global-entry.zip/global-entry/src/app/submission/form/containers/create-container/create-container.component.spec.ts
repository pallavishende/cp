import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateContainerComponent } from './create-container.component';
import { ActivatedRoute } from '@angular/router';
import { FormFacadeService } from '../../services/form-facade.service';
import { MockComponent, MockDirective, MockPipe } from '@content-platform/unit-test-helpers';
import {
  MatDialog,
  MatIconModule,
  MatSelectModule,
  MatDividerModule,
  MatTooltipModule
} from '@angular/material';
import { StoreModule, combineReducers } from '@ngrx/store';
import * as fromStore from '../../store';
import { FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DynamicFormService } from '@content-platform/reusable-ui/dynamic-form-builder';
import { ContentHeaderBarService } from '@content-platform/navigation';
import { RouterTestingModule } from '@angular/router/testing';
import { MatSelectSearchModule } from '@content-platform/reusable-ui/dynamic-form-builder';

describe('CreateContainerComponent', () => {
  let component: CreateContainerComponent;
  let fixture: ComponentFixture<CreateContainerComponent>;

  class ActivatedRouteMock {
    snapshot = {
      data: {
        schema: { layout: {}, fieldsByMode: { create: {} } },
        region: { name: 'US' },
        userDetail: { regions: [{ name: 'US' }] }
      },
      params: {
        contentType: 'Episodic'
      }
    };
  }

  class FormServiceMock {
    form;
    datasets;
    createForm() {}
    provideDatasets() {}
    loadKeywords() {}
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot({ dynamicforms: combineReducers(fromStore.SubmissionPageReducers) }),
        MatIconModule,
        MatSelectModule,
        MatDividerModule,
        MatTooltipModule,
        FormsModule,
        RouterTestingModule,
        MatSelectSearchModule,
        ReactiveFormsModule
      ],
      declarations: [
        MockComponent({
          selector: 'app-dynamic-layout',
          inputs: [
            'layoutSchema',
            'formInfo',
            'fieldSchemaMapByMode',
            'mode',
            'form',
            'datasetContainer'
          ]
        }),
        MockComponent({
          selector: 'app-content-header-bar',
          inputs: ['title', 'headerTemplate']
        }),
        MockComponent({
          selector: 'app-file-explorer',
          inputs: ['editMode', 'fileValidator'],
          outputs: ['fileUploaded']
        }),
        MockDirective({
          selector: '[appIfFeatureAsync]',
          inputs: ['appIfFeatureAsync']
        }),
        CreateContainerComponent,
        MockComponent({
          selector: '[app-mat-select-search]'
        }),
        MockPipe('sort')
      ],
      providers: [
        { provide: ActivatedRoute, useClass: ActivatedRouteMock },
        { provide: FormFacadeService, useClass: FormServiceMock },
        {
          provide: DynamicFormService,
          useValue: {
            createNewForm: () => new FormGroup({}),
            createNewFormWithNestedSchemas: () => new FormGroup({})
          }
        },
        {
          provide: MatDialog,
          useValue: { open: () => {} }
        },
        {
          provide: ContentHeaderBarService,
          useValue: { clearButtons: () => {}, setButtons: () => {} }
        }
      ]
    })
      .overrideComponent(CreateContainerComponent, {
        set: {
          providers: [{ provide: FormFacadeService, useClass: FormServiceMock }]
        }
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
