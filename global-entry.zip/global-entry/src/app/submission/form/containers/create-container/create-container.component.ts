import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material';
import { DynamicFormService } from '@content-platform/reusable-ui/dynamic-form-builder';

import { FormFacadeService } from '../../services/form-facade.service';
import { DialogComponent } from '../../../../toaster/toaster.component';
import { FormContainerComponent } from '../../shared';

import { ContentHeaderBarService } from '@content-platform/navigation';
import { PermissionMetadata } from '@content-platform/application-api';
import { MatSelect, MatSelectChange } from '@angular/material';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-create-container',
  templateUrl: '../../shared/form-container.component.html',
  styleUrls: ['./create-container.component.scss', '../../common-styles.scss'],
  providers: [FormFacadeService]
})
export class CreateContainerComponent extends FormContainerComponent implements OnInit, OnDestroy {
  regionList: PermissionMetadata[] = [];
  showRegionSelection: boolean;
  regionSearch: FormControl;
  filteredOptions$: Observable<PermissionMetadata[]>;

  constructor(
    activatedRoute: ActivatedRoute,
    formService: FormFacadeService,
    dynamicFormService: DynamicFormService,
    contentHeaderBarService: ContentHeaderBarService,
    router: Router,
    private dialog: MatDialog
  ) {
    super(activatedRoute, formService, dynamicFormService, contentHeaderBarService, router);
  }

  ngOnInit() {
    super.ngOnInit();
    this.initialize();
  }

  initialize() {
    super.initialize();
    this.showRegionSelection = false;
    this.activeRegion = null;
    if (this.formLayoutHasRegionOption) {
      this.regionList = this.activatedRoute.snapshot.data.userDetail.regions;
      this.showRegionSelection = true;
      if (this.regionList && this.regionList.length === 1) {
        this.activeRegion = this.regionList[0];
      } else {
        this.regionSearch = new FormControl();
        this.filteredOptions$ = this.regionSearch.valueChanges.pipe(
          startWith(''),
          map(value => {
            return this.filterFunction(value);
          })
        );
      }
    }
    this.contentTypes = this.activatedRoute.snapshot.data.userDetail.contentTypes;
    this.setSelectedContentType(this.contentType);
  }

  protected setHeaderButtons(): void {
    this.contentHeaderBarService.clearButtons();
    this.contentHeaderBarService.setButtons([
      {
        name: 'Clear',
        onClick: () => this.clear()
      },
      {
        name: 'Submit',
        type: 'raised',
        color: 'accent',
        disabled$: this.submitDisabled$,
        onClick: () => this.create()
      }
    ]);
  }

  /**
   * Hands off the Form content to the service handling creation, opens popup to redirect user
   *
   * @memberof CreateContainerComponent
   */
  create() {
    this.formService.create(this.form, this.contentType, this.activeRegion);
    this.openConfirmPopup();
  }

  /**
   * Clears the curent form, opens popup to redirect user
   *
   * @memberof CreateContainerComponent
   */
  clear() {
    this.form.reset();
    this.openConfirmPopup();
  }

  /**
   * Open the confirmation window to chnage the route to create or dashboard
   *
   * @private
   * @memberof CreateContainerComponent
   */
  private openConfirmPopup(): void {
    this.dialog.open(DialogComponent, {
      width: '380px',
      data: { msg: 'confirmPopup' },
      position: { top: '0%' },
      panelClass: 'cancelNotify',
      disableClose: false
    });
  }

  setSelectedContentType(contentTypeValue: String) {
    if (this.contentTypes) {
      this.selectedContentType = this.contentTypes.find(
        itemType => itemType.name === contentTypeValue
      );
    }
  }

  onSelectedContentTypeChanged(event: MatSelectChange, select: MatSelect) {
    let newContentType: String;
    newContentType = event.value.name;
    if (this.contentType !== newContentType) {
      this.router.navigate(['./submission', newContentType, 'create']).then(() => {
        const currentContentType = this.activatedRoute.snapshot.params['contentType'];
        if (currentContentType !== newContentType) {
          this.setSelectedContentType(currentContentType);
          select.writeValue(this.selectedContentType);
        }
      });
    }
  }

  onSelectedRegionChanged() {
    this.form.updateValueAndValidity({ onlySelf: false, emitEvent: true });
  }

  filterFunction(value: string): PermissionMetadata[] {
    const filterValue = value || '';
    return this.regionList.filter(option =>
      option.description.toLowerCase().includes(filterValue.toLowerCase())
    );
  }

  ngOnDestroy() {
    super.ngOnDestroy();
  }
}
