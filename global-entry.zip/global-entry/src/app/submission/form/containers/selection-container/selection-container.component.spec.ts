import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectionContainerComponent } from './selection-container.component';
import { RouterTestingModule } from '@angular/router/testing';
import { MatDialog } from '@angular/material';
import { of } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { SelectionRouteService } from './selection-route.service';

describe('SelectionContainerComponent', () => {
  let component: SelectionContainerComponent;
  let fixture: ComponentFixture<SelectionContainerComponent>;

  class MatDialogMock {
    open() {
      return {
        afterClosed: () => of('episode')
      };
    }
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [SelectionContainerComponent],
      providers: [
        {
          provide: MatDialog,
          useClass: MatDialogMock
        },
        {
          provide: ActivatedRoute,
          useValue: { snapshot: { data: { userDetail: { regions: ['X', 'Y'] } } } }
        },
        {
          provide: SelectionRouteService,
          useValue: {}
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectionContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
