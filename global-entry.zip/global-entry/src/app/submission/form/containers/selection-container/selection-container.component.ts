import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { PermissionMetadata } from '@content-platform/application-api';
import { ActivatedRoute } from '@angular/router';
import { CreateNewDropdownComponent } from '../../create-new-dropdown/create-new-dropdown.component';
import { SelectionRouteService } from './selection-route.service';

@Component({
  selector: 'app-selection-container',
  templateUrl: './selection-container.component.html'
})
export class SelectionContainerComponent implements OnInit, OnDestroy {
  contentTypeList: PermissionMetadata[];
  dialogRef: MatDialogRef<CreateNewDropdownComponent>;
  selectedContentType: string;
  constructor(
    private matDialog: MatDialog,
    private route: ActivatedRoute,
    private selectionRouteService: SelectionRouteService
  ) {}

  ngOnInit() {
    this.contentTypeList = this.route.snapshot.data.userDetail.contentTypes;
    // getting around runtime exception
    setTimeout(() => this.init());
  }

  private init() {
    // Take to the route directly if user has a single content type otherwise show dialog
    if (
      this.contentTypeList &&
      this.contentTypeList.length === 1 
    ) {
      this.selectionRouteService.switchRoute(this.contentTypeList[0]);
    } else {
      this.openDialog();
    }
  }

  private openDialog() {
    const dialogConfig = new MatDialogConfig();
    // Dialog Configuration
    dialogConfig.width = '320px';
    dialogConfig.data = this.contentTypeList;
    dialogConfig.disableClose = true;
    dialogConfig.backdropClass = 'region-backdrop';
    this.dialogRef = this.matDialog.open(CreateNewDropdownComponent, dialogConfig);
  }

  ngOnDestroy() {
    if (this.dialogRef) {
      this.dialogRef.close();
    }
  }
}
