import { Injectable } from '@angular/core';
import { PermissionMetadata } from '@content-platform/application-api';
import { Router, ActivatedRoute } from '@angular/router';

@Injectable()
export class SelectionRouteService {
  constructor(
    private router: Router,
    private route: ActivatedRoute
  ) {}

  switchRoute(contentType: PermissionMetadata) {
    this.router.navigate(['./submission', contentType.name, 'create'], {
      relativeTo: this.route
    });
  }
}
