import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewContainerComponent } from './view-container.component';
import {
  MockComponent,
  MockDirective,
  MaterialServiceMocks,
  MockPipe
} from '@content-platform/unit-test-helpers';
import { ActivatedRoute } from '@angular/router';
import { FormFacadeService } from '../../services/form-facade.service';
import {
  DynamicFormService,
  DynamicFormEventHandlerService
} from '@content-platform/reusable-ui/dynamic-form-builder';
import { TimelineService } from '@content-platform/reusable-ui/timeline';
import { DebugFlagsService } from '@content-platform/development';
import { StoreModule, combineReducers } from '@ngrx/store';
import * as fromStore from '../../store';
import { fromAuth } from '@content-platform/auth';
import { FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatDialog,
  MatIconModule,
  MatSelectModule,
  MatDividerModule,
  MatTooltipModule
} from '@angular/material';
import { LoggerService } from '@content-platform/logging';
import { ContentHeaderBarService } from '@content-platform/navigation';
import { UserPermissionsService } from '@content-platform/application-api';
import { of } from 'rxjs';
import { RouterTestingModule } from '@angular/router/testing';
import { MatSelectSearchModule } from '@content-platform/reusable-ui/dynamic-form-builder';

describe('ViewContainerComponent', () => {
  let component: ViewContainerComponent;
  let fixture: ComponentFixture<ViewContainerComponent>;

  class ActivatedRouteMock {
    snapshot = {
      data: {
        schema: { layout: {}, fieldsByMode: { view: {}, edit: {} } },
        region: { name: 'US' },
        userDetail: { regions: [{ name: 'US' }] }
      },
      params: {
        contentType: 'Episodic'
      }
    };
  }

  class FormServiceMock {
    form;
    datasets;
    createForm() {}
    provideDatasets() {}
    loadKeywords() {}
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot({ dynamicforms: combineReducers(fromStore.SubmissionPageReducers) }),
        StoreModule.forRoot({ auth: fromAuth.authReducer }),
        MatIconModule,
        MatSelectModule,
        MatDividerModule,
        MatTooltipModule,
        FormsModule,
        RouterTestingModule,
        MatSelectSearchModule,
        ReactiveFormsModule
      ],
      declarations: [
        ViewContainerComponent,
        MockComponent({
          selector: 'app-review-form-header'
        }),
        MockComponent({
          selector: 'app-dynamic-layout',
          inputs: [
            'layoutSchema',
            'formInfo',
            'fieldSchemaMapByMode',
            'mode',
            'form',
            'datasetContainer'
          ]
        }),
        MockComponent({
          selector: 'app-content-header-bar',
          inputs: ['title', 'headerTemplate']
        }),
        MockComponent({
          selector: 'app-file-explorer',
          inputs: ['editMode', 'fileValidator'],
          outputs: ['fileUploaded']
        }),
        MockDirective({
          selector: '[appIfFeatureAsync]',
          inputs: ['appIfFeatureAsync']
        }),
        MockDirective({
          selector: '[appIfDebugFlagAsync]',
          inputs: ['appIfDebugFlagAsync']
        }),
        MockComponent({
          selector: '[app-mat-select-search]',
          inputs: ['placeHolderLabel', 'noEntriesFoundLabel']
        }),
        MockPipe('sort')
      ],
      providers: [
        { provide: ActivatedRoute, useClass: ActivatedRouteMock },
        { provide: FormFacadeService, useClass: FormServiceMock },
        { provide: MatDialog, useValue: new MaterialServiceMocks.MatDialog<boolean>(true) },
        {
          provide: DynamicFormService,
          useValue: { createNewForm: () => new FormGroup({}) }
        },
        { provide: TimelineService, useValue: {} },
        {
          provide: DebugFlagsService,
          useValue: { hasDebugFlag: () => false }
        },
        {
          provide: LoggerService,
          useValue: {
            instance: () => {
              return { info: () => {}, log: () => {} };
            }
          }
        },
        {
          provide: DynamicFormEventHandlerService,
          useValue: {
            onEvent: { next: () => {} }
          }
        },
        {
          provide: ContentHeaderBarService,
          useValue: { clearButtons: () => {}, setButtons: () => {} }
        },
        { provide: UserPermissionsService, useValue: { hasFeatureAsync: () => of(true) } }
      ]
    })
      .overrideComponent(ViewContainerComponent, {
        set: {
          providers: [{ provide: FormFacadeService, useClass: FormServiceMock }]
        }
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
