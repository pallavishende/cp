import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { FormControl } from '@angular/forms';
import { LoggerService } from '@content-platform/logging';
import {
  Submission,
  Feature,
  UserFeature,
  commentActions,
  commentSelectors,
  submissionSelectors,
  CommentSchema
} from '@content-platform/submissions-api';
import {
  DynamicFormService,
  DynamicLayoutFormEvent,
  DynamicFormEventHandlerService
} from '@content-platform/reusable-ui/dynamic-form-builder';
import { AuthDebugFlagNames, Auth, authSelectors } from '@content-platform/auth';
import { ActivatedRoute, Router } from '@angular/router';
import { BehaviorSubject, Observable, combineLatest } from 'rxjs';
import { cloneDeep, flatten } from 'lodash';
import { MatDialog } from '@angular/material';
import {
  takeUntil,
  withLatestFrom,
  map,
  take,
  filter,
  distinctUntilKeyChanged
} from 'rxjs/operators';
import { DatasetValue, UserPermissionsService } from '@content-platform/application-api';
import { globalEntryFeature } from '../../../../../constants';

import { environment } from '../../../../../environments/environment';

import { LayoutMode, DatasetOptions } from '@content-platform/dynamic-forms-api';
import { FormFacadeService } from '../../services/form-facade.service';
import { FormContainerComponent } from '../../shared';
import { ContentHeaderButton, ContentHeaderBarService } from '@content-platform/navigation';
import { SUBMISSION_STATUS } from '../../constants/submissions-form.constants';
import * as fromSelectors from '../../store/selectors';
import {
  SubmissionPageState,
  getCurrentSubmissionStatus,
  SubmissionStatusState,
  SubmissionStatusAction
} from '../../store';
import { DialogComponent } from '../../../../toaster/toaster.component';
import { ShareSubmissionComponent } from '../../../../share-submission/share-submission/share-submission.component';
import { DebugFlagsService } from '@content-platform/development';

const REJECT_TOOLTIP = 'Notes are required for rejection';

/**
 * This is view container to display the submission record in "View" and "Edit" Mode
 *
 * @export
 * @class ViewContainerComponent
 * @extends {FormContainerComponent}
 * @implements {OnInit}
 */
@Component({
  selector: 'app-view-container',
  templateUrl: '../../shared/form-container.component.html',
  styleUrls: ['./view-container.component.scss', '../../common-styles.scss'],
  providers: [FormFacadeService]
})
export class ViewContainerComponent extends FormContainerComponent implements OnInit, OnDestroy {
  displayContentType: string;
  loggedInUserEmail: string;
  submissionId: number;
  isResubmitted = false;
  currentSubmissionData: Submission;
  originalSubmissionData: Submission;
  sharedFeature: Feature;

  private currentlyEditing$ = new BehaviorSubject<boolean>(false);
  private sharedForEditing$ = new BehaviorSubject<boolean>(false);
  private statusAllowsEditing$ = new BehaviorSubject<boolean>(false);
  private allowedToEdit$: Observable<boolean>;
  private showEdit$: Observable<boolean>;

  private disableApprove$ = new BehaviorSubject<boolean>(true);
  private disableReject$ = new BehaviorSubject<boolean>(false);
  private showApproveReject$ = new BehaviorSubject<boolean>(false);
  private isSubmitting$ = new BehaviorSubject<boolean>(false);

  private updateResubmitButton: ContentHeaderButton = {
    name: this.isResubmitted ? 'RESUBMIT' : 'UPDATE',
    color: 'accent',
    type: 'raised',
    visible$: this.currentlyEditing$,
    disabled$: combineLatest(this.submitDisabled$, this.isSubmitting$, this.modeChanged$).pipe(
      map(([disabled, submitting, currentMode]) => {
        return currentMode === 'edit' && (disabled || submitting);
      })
    ),
    onClick: () => this.updateRecord()
  };

  private rejectButton: ContentHeaderButton = {
    separator: true,
    name: 'Reject',
    visible$: this.showApproveReject$,
    disabled$: this.disableReject$,
    tooltip: REJECT_TOOLTIP,
    onClick: () => this.onApproveClick(SUBMISSION_STATUS.REJECTED_CODE),
    appearAsDisabled: true
  };

  private logger: LoggerService;

  constructor(
    activatedRoute: ActivatedRoute,
    formService: FormFacadeService,
    dynamicFormService: DynamicFormService,
    contentHeaderBarService: ContentHeaderBarService,
    router: Router,
    private debugFlagService: DebugFlagsService,
    private viewStore: Store<SubmissionPageState>,
    private authStore: Store<Auth>,
    public dialog: MatDialog,
    logger: LoggerService,
    private dynamicFormEventHandlerService: DynamicFormEventHandlerService,
    private permissionsService: UserPermissionsService
  ) {
    super(activatedRoute, formService, dynamicFormService, contentHeaderBarService, router);
    this.logger = logger.instance('ViewContainerComponent');
    this.formChanges$
      .pipe(
        withLatestFrom(this.disableApprove$, this.showApproveReject$),
        takeUntil(this.onDestroy$)
      )
      .subscribe(([, disabled, visible]) => {
        if (visible) {
          this.disableReject$.next(disabled);
        }
      });
    this.disableReject$
      .pipe(
        withLatestFrom(this.showApproveReject$),
        takeUntil(this.onDestroy$)
      )
      .subscribe(([disabled, visible]) => {
        if (visible && this.notesField) {
          const appearDisabled = !disabled && this.isNotesFieldEmpty;
          this.rejectButton.tooltip = appearDisabled ? REJECT_TOOLTIP : undefined;
          this.rejectButton.appearAsDisabled = appearDisabled;
        }
      });

    // Check for "EDIT" Button disabled state
    this.allowedToEdit$ = combineLatest(
      this.permissionsService.hasFeatureAsync(globalEntryFeature.EDIT_SUB),
      this.statusAllowsEditing$
    ).pipe(
      map(([hasEditPermission, statusAllowsEditing]) => hasEditPermission && statusAllowsEditing)
    );

    // Check for "EDIT" Button visible state
    this.showEdit$ = combineLatest(this.currentlyEditing$, this.sharedForEditing$).pipe(
      map(([currentlyEditing, sharedForEditing]) => {
        return !currentlyEditing && sharedForEditing;
      })
    );

    this.currentlyEditing$.pipe(takeUntil(this.onDestroy$)).subscribe(() => {
      this.updateResubmitButton.name = this.isResubmitted ? 'RESUBMIT' : 'UPDATE';
    });
  }

  ngOnInit() {
    super.ngOnInit();
    // gets user name from auth store
    this.isSubmitting$.next(false);
    this.authStore
      .pipe(
        select(authSelectors.getADUser),
        takeUntil(this.onDestroy$)
      )
      .subscribe(({ profile }) => {
        if (this.debugFlagService) {
          if (this.debugFlagService.hasDebugFlag(AuthDebugFlagNames.Impersonate)) {
            this.loggedInUserEmail = profile.mail;
          } else {
            this.loggedInUserEmail = profile.unique_name;
          }
        }
      });

    if (environment.EDIT_MODE === false) {
      this.submissionId = this.activatedRoute.snapshot.params.id;
      this.viewRecord(this.activatedRoute.snapshot.data.activeSubmission);
      this.logger.log('Viewing Submission', { submissionId: this.submissionId });
    }

    // Submission Status from View store
    this.viewStore
      .pipe(
        select(getCurrentSubmissionStatus),
        distinctUntilKeyChanged('currentStatus'),
        takeUntil(this.onDestroy$)
      )
      .subscribe(
        (data: SubmissionStatusState) => (this.isResubmitted = data.currentStatus === 'Rejected')
      );

    // When Submission is Successful
    this.viewStore
      .pipe(
        select(submissionSelectors.getSubmissionsUpdateSuccess),
        withLatestFrom(this.viewStore.pipe(select(fromSelectors.getActiveSubmission))),
        takeUntil(this.onDestroy$)
      )
      .subscribe(([isUpdated, submission]) => {
        if (isUpdated) {
          // Making sure we update the Submission Status State after the submission is updated
          const submissionStatusState: SubmissionStatusState = {
            currentStatus: submission.submissionStatus.description,
            submissionId: submission.id,
            statusCode: submission.submissionStatus.code
          };
          this.viewStore.dispatch(new SubmissionStatusAction(submissionStatusState));

          this.viewRecord(submission);
          this.isSubmitting$.next(false);
        }
      });

    // When Submission is failed
    this.viewStore
      .pipe(
        select(submissionSelectors.getSubmissionsUpdateFailed),
        takeUntil(this.onDestroy$)
      )
      .subscribe(failed => {
        if (failed) {
          this.reset();
          this.isSubmitting$.next(false);
        }
      });
  }

  protected setHeaderButtons(): void {
    this.contentHeaderBarService.clearButtons();
    this.contentHeaderBarService.setButtons([
      this.updateResubmitButton,
      {
        name: 'Cancel',
        visible$: this.currentlyEditing$,
        onClick: () => this.cancelUpdate()
      },
      {
        name: 'Share',
        icon: 'share',
        type: 'raised',
        onClick: () => this.share()
      },
      {
        name: 'Edit',
        type: 'raised',
        visible$: this.showEdit$,
        disabled$: this.allowedToEdit$.pipe(map(allowed => !allowed)),
        onClick: () => this.editRecord()
      },
      this.rejectButton,
      {
        name: 'Approve',
        color: 'accent',
        type: 'raised',
        visible$: this.showApproveReject$,
        disabled$: this.disableApprove$,
        onClick: () => this.onApproveClick(SUBMISSION_STATUS.APPROVED_CODE)
      }
    ] as ContentHeaderButton[]);
  }

  private checkEmail(email1: string, email2: string): boolean {
    return email1.toLocaleLowerCase() === email2.toLocaleLowerCase();
  }

  /**
   * This method gets the submission data from the store and displays the data in the layout form
   *
   * @memberof ViewContainerComponent
   */
  viewRecord(activeSubmission: Submission) {
    if (!activeSubmission) {
      return;
    }

    this.currentlyEditing$.next(false);
    this.isSubmitting$.next(false);
    this.currentSubmissionData = activeSubmission;
    this.originalSubmissionData = cloneDeep(activeSubmission);

    let sharedUser: UserFeature;
    this.sharedForEditing$.next(true);
    if (activeSubmission.sharedUsers) {
      sharedUser = activeSubmission.sharedUsers.find(user =>
        this.checkEmail(user.email, this.loggedInUserEmail)
      );
      if (sharedUser) {
        this.sharedFeature = sharedUser.features;
        this.sharedForEditing$.next(
          this.sharedFeature &&
            (this.sharedFeature.addFiles || this.sharedFeature.addOrEditMetadata)
        );
      }
    }

    this.activeRegion = this.getRegionDataset(activeSubmission.region);
    this.setRecordData(activeSubmission);
    this.disableApprove$.next(!this.showApproveReject());
    this.showApproveReject$.next(this.showApproveReject());
    const userOwnsSubmission = this.checkEmail(activeSubmission.email, this.loggedInUserEmail);

    const userDetail = this.activatedRoute.snapshot.data.userDetail;
    const canViewAll =
      userDetail && userDetail.canUserViewAll && userDetail.canUserViewAll.canViewAll;
    if (!canViewAll) {
      // User doesn't have permission to view all submissions
      // is this the creator of the submission, or is this submission shared with this user?
      if (!userOwnsSubmission && !sharedUser) {
        setTimeout(() => {
          this.router.navigate(['/access-denied']);
        });
      }
    }
  }

  /**
   * Gets the corresponding Dataset for the given name from the Datasets included on the route data
   *
   * @private
   * @param {string} regionName
   * @returns {DatasetValue}
   * @memberof ViewContainerComponent
   */
  private getRegionDataset(regionName: string): DatasetValue {
    const datasetOptions = this.activatedRoute.snapshot.data.datasetRegions as DatasetOptions[];
    const foundRegion = flatten(datasetOptions.map(datasetOption => datasetOption.values)).find(
      (datasetValue: DatasetValue) => datasetValue.name.toLowerCase() === regionName.toLowerCase()
    );
    return foundRegion;
  }

  /**
   * Set the submission record data to be passed to the layout
   *
   * @private
   * @param {Submission} submissionDetails
   * @memberof ViewContainerComponent
   */
  private setRecordData(submissionDetails: Submission, mode: LayoutMode = 'view'): void {
    const retrievedData = {
      ...submissionDetails.submissionFormData,
      createdBy: submissionDetails.createdBy,
      createdDate: submissionDetails.createdDate,
      submittedBy: submissionDetails.submittedBy,
      submittedDate: submissionDetails.submittedDate,
      submissionStatus: submissionDetails.submissionStatus.code,
      previewUrl: submissionDetails.previewUrl,
      fileExplorer: submissionDetails.fileDetails ? submissionDetails.fileDetails.groups : []
    };
    if (submissionDetails.createdBy === null || submissionDetails.createdDate === null) {
      retrievedData.createdBy = submissionDetails.submittedBy;
      retrievedData.createdDate = submissionDetails.submittedDate;
    }

    // Initialize the form once submission data has been retrieved
    this.initialize(mode, retrievedData);
    this.displayContentType = this.contentType.replace('-', ' ');
    this.checkStatusForActions(submissionDetails.submissionStatus.code);
  }

  /**
   * Making sure to restric edit in case submission code is either of mentioned
   *
   * @private
   * @param {string} statusCode
   * @memberof ViewContainerComponent
   */
  private checkStatusForActions(statusCode: string) {
    this.statusAllowsEditing$.next(
      statusCode === SUBMISSION_STATUS.AWAITINGELEMENTS_CODE ||
        statusCode === SUBMISSION_STATUS.PENDINGQC_CODE ||
        statusCode === SUBMISSION_STATUS.PENDINGAPPROVAL_CODE ||
        statusCode === SUBMISSION_STATUS.REJECTED_CODE
    );
  }

  /**
   * Enable or disable the approve button
   *
   * @readonly
   * @memberof ViewContainerComponent
   */
  get disableSubmit() {
    return (
      (this.sharedFeature &&
        !this.sharedFeature.addOrEditMetadata &&
        this.sharedFeature.addFiles) ||
      this.form.invalid ||
      this.form.pending
    );
  }

  /**
   * This gets called when the edit button is clicked to enable or disable the record
   *
   * @memberof ViewContainerComponent
   */
  editRecord() {
    if (this.sharedFeature && !this.sharedFeature.addOrEditMetadata) {
      return;
    }

    this.currentlyEditing$.next(true);

    // Making the mode of the dynamic form to edit
    this.setRecordData(this.currentSubmissionData, 'edit');
  }

  /**
   * This gets called when the cancel button is pressed to reset the record to original state
   *
   * @memberof ViewContainerComponent
   */
  cancelUpdate() {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '380px',
      data: { msg: 'cancelUpdate' },
      position: { top: '0%' },
      panelClass: 'cancelNotify'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'leavePage') {
        this.reset();
      }
    });
  }

  private reset() {
    this.currentlyEditing$.next(false);
    this.currentSubmissionData = cloneDeep(this.originalSubmissionData);
    this.setRecordData(this.currentSubmissionData);
  }

  /**
   * This gets called when the share button is clicked to share the submission with other users.
   *
   * @memberof ViewContainerComponent
   */
  share() {
    const ref = this.dialog.open(ShareSubmissionComponent, {
      width: '500px',
      data: {
        id: this.submissionId,
        url: window.location.href,
        sharedUsers: this.currentSubmissionData.sharedUsers
      }
    });
    ref.afterClosed().subscribe(() => {});
  }

  /**
   * This method is called when approve button is clicked
   *
   * @param {string} actionCode
   * @memberof ViewContainerComponent
   */
  onApproveClick(actionCode: string) {
    const submissionId = this.submissionId;
    const commentText = this.notesField.value;
    const comment = {
      commentText,
      actionCode
    } as CommentSchema;
    if (this.isNotesFieldEmpty && actionCode === SUBMISSION_STATUS.REJECTED_CODE) {
      this.dynamicFormEventHandlerService.onEvent.next({
        type: 'addValidator',
        value: 'required'
      } as DynamicLayoutFormEvent);
    } else {
      this.viewStore.dispatch(
        new commentActions.Create({
          comment,
          submissionId
        })
      );
    }

    this.checkStatusForActions(actionCode);

    this.viewStore
      .pipe(
        select(commentSelectors.isCommentCreated(submissionId)),
        filter(created => !!created),
        take(1),
        takeUntil(this.onDestroy$)
      )
      .subscribe(created => {
        if (created) {
          // disable approve/reject button and change comment disability
          this.disableApprove$.next(true);
          this.logger.log('Comment Created Successfully', {
            submissionId: this.submissionId,
            commentText: commentText,
            actionCode: actionCode
          });
        }
      });
  }

  get isNotesFieldEmpty(): boolean {
    return (
      this.notesField !== undefined &&
      (this.notesField.value === '' ||
        this.notesField.value === null ||
        !this.notesField.value.replace(/\s/g, '').length)
    );
  }

  get notesField(): FormControl {
    return this.form && this.form.controls && <FormControl>this.form.controls['comments'];
  }

  showApproveReject(): boolean {
    return (
      this.currentSubmissionData &&
      this.currentSubmissionData.submissionStatus.code === SUBMISSION_STATUS.PENDINGAPPROVAL_CODE &&
      !this.currentSubmissionData.reviewed
    );
  }

  /**
   * This method when the update button is clicked to update the submission with the changes
   *
   * @memberof ViewContainerComponent
   */
  updateRecord() {
    this.isSubmitting$.next(true);
    this.formService.updateFormData(
      this.contentType,
      this.form,
      this.currentSubmissionData,
      this.isResubmitted
    );
  }

  ngOnDestroy() {
    super.ngOnDestroy();
  }
}
