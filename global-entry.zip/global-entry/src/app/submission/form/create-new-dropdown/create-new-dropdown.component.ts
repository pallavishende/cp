import { Component, Inject } from '@angular/core';
import { FormControl } from '@angular/forms';
import { PermissionMetadata } from '@content-platform/application-api';

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SelectionRouteService } from '../containers/selection-container/selection-route.service';

@Component({
  selector: 'app-create-new-dropdown',
  templateUrl: './create-new-dropdown.component.html',
  styleUrls: ['./create-new-dropdown.component.scss']
})
export class CreateNewDropdownComponent {
  contentTypes: PermissionMetadata[];
  contentTypeDropdown: FormControl;

  constructor(
    public dialogRef: MatDialogRef<CreateNewDropdownComponent>,
    @Inject(MAT_DIALOG_DATA) public contentTypeList: PermissionMetadata[],
    private selectionRouteService: SelectionRouteService
  ) {
    this.contentTypeDropdown = new FormControl();
    this.contentTypes = this.contentTypeList || [];

    // Default selected value to first item in case 1 value is there
    if (this.contentTypes.length === 1){
      this.contentTypeDropdown.setValue(this.contentTypes[0]);
    }
  }

  onSelect() {
    this.selectionRouteService.switchRoute(this.contentTypeDropdown.value);
    this.dialogRef.close();
  }

  get isValid():boolean{
    if (this.contentTypeDropdown.value){
      return true;
    }
    return false;
  }
}
