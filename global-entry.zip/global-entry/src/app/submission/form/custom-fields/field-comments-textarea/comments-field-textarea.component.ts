import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { takeUntil, filter } from 'rxjs/operators';
import { Validators } from '@angular/forms';
import { Submission } from '@content-platform/submissions-api';
import { AbstractControl } from '@angular/forms';

import {
  DynamicFormEventHandlerService,
  FieldTextareaComponent
} from '@content-platform/reusable-ui/dynamic-form-builder';
import { SubmissionPageState } from '../../store';
import * as fromSelectors from '../../store/selectors';
import { Store, select } from '@ngrx/store';
import { CommentsListSchema } from '../../../../models/dynamic-form';
import { LoggerService } from '@content-platform/logging';
import { SUBMISSION_STATUS } from '../../constants/submissions-form.constants';

export const validators = {
  required: Validators.required
};

@Component({
  selector: 'app-comments-field-textarea',
  templateUrl: './comments-field-textarea.component.html',
  styleUrls: ['./comments-field-textarea.component.scss']
})
export class CommentsFieldTextareaComponent extends FieldTextareaComponent
  implements OnInit, OnDestroy {
  private logger: LoggerService;
  constructor(
    cdr: ChangeDetectorRef,
    protected dynamicFormEventHandlerService: DynamicFormEventHandlerService,
    private viewStore: Store<SubmissionPageState>,
    logger: LoggerService
  ) {
    super(cdr);
    this.logger = logger.instance('CommentsFieldTextareaComponent');
  }

  ngOnInit() {
    super.ngOnInit();
    this.initComments();
  }

  ngOnDestroy() {
    super.ngOnDestroy();
  }

  /**
   * Overriding so we get the latest from the parent
   *
   * @readonly
   * @type {AbstractControl}
   * @memberof CommentsFieldTextareaComponent
   */
  get fieldControl(): AbstractControl {
    return this.parentFormGroup.get(this.field.name);
  }

  initComments() {
    // userComment on notes
    this.viewStore
      .pipe(
        select(fromSelectors.getActiveSubmissionComments),
        filter(comments => !!comments),
        takeUntil(this.componentDestroyed$)
      )
      .subscribe((res: CommentsListSchema[]) => {
        const allComments = res.map(comment => comment.commentText).join('\n');
        this.fieldControl.setValue(allComments);
        this.cdr.markForCheck();
      });

    // disable/enable notes section
    this.viewStore
      .pipe(
        select(fromSelectors.getActiveSubmission),
        filter(data => !!data),
        takeUntil(this.componentDestroyed$)
      )
      .subscribe((data: Submission) => {
        this.forcedEnabled = this.getPending(data);
        if (this.getPending(data)) {
          this.fieldControl.markAsTouched();
          this.fieldControl.enable();
          this.cdr.markForCheck();
        } else {
          this.fieldControl.disable();
          this.cdr.markForCheck();
        }
      });

    this.dynamicFormEventHandlerService.onEvent
      .pipe(takeUntil(this.componentDestroyed$))
      .subscribe(event => {
        if (event.type === 'addValidator') {
          this.fieldControl.setValidators([validators[event.value]]);
          this.fieldControl.markAsTouched();
          this.fieldControl.enable();
          this.logger.log(`Notes are required when rejecting a submission`);
        }
      });
  }

  private getPending(activeSubmission: Submission): boolean {
    return (
      activeSubmission &&
      activeSubmission.submissionStatus.code === SUBMISSION_STATUS.PENDINGAPPROVAL_CODE &&
      !activeSubmission.reviewed
    );
  }
}
