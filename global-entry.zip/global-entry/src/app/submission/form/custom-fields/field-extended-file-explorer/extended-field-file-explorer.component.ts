import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import {
  DynamicFormEventHandlerService,
  FieldFileExplorerComponent
} from '@content-platform/reusable-ui/dynamic-form-builder';
import { FileUploadService } from '@content-platform/aws';
import { takeUntil, withLatestFrom } from 'rxjs/operators';
import { Store, select } from '@ngrx/store';
import { Submission, Feature } from '@content-platform/submissions-api';
import { authSelectors, AuthDebugFlagNames } from '@content-platform/auth';
import { DebugFlagsService } from '@content-platform/development';
import { ActivatedRoute } from '@angular/router';

import { SubmissionPageState } from '../../store';
import * as fromSelectors from '../../store/selectors';

@Component({
  selector: 'app-extended-field-file-explorer',
  templateUrl: './extended-field-file-explorer.component.html',
  styleUrls: ['./extended-field-file-explorer.component.scss']
})
export class ExtendedFieldFileExplorerComponent extends FieldFileExplorerComponent
  implements OnInit, OnDestroy {
  canAddFiles: boolean;
  canDownloadFiles: boolean;
  canDeleteFiles: boolean;

  isPendingState: boolean;

  @ViewChild('fileExplorer')
  fileExplorer;

  constructor(
    protected dynamicFormEventHandlerService: DynamicFormEventHandlerService,
    protected fileUploadService: FileUploadService,
    private store: Store<SubmissionPageState>,
    private debugFlagService: DebugFlagsService,
    private activatedRoute: ActivatedRoute
  ) {
    super(fileUploadService);
  }

  ngOnInit() {
    super.ngOnInit();
    this.canAddFiles = !this.readonly;
    this.canDeleteFiles = !this.readonly;
    this.canDownloadFiles = false;
    this.init();
  }

  ngOnDestroy() {
    super.ngOnDestroy();
  }

  init() {
    this.store
      .pipe(
        select(authSelectors.getADUser),
        withLatestFrom(this.store.pipe(select(fromSelectors.getActiveSubmission))),
        takeUntil(this.componentDestroyed$)
      )
      .subscribe(([{ profile }, submission]) => {
        let loggedInUserEmail;
        if (this.debugFlagService) {
          if (this.debugFlagService.hasDebugFlag(AuthDebugFlagNames.Impersonate)) {
            loggedInUserEmail = profile.mail;
          } else {
            loggedInUserEmail = profile.unique_name;
          }
        }

        if (submission) {
          let canDownloadFiles = false;
          let sharedFeature: Feature;
          const statusCode = submission.submissionStatus.code;
          if (submission.sharedUsers) {
            const sharedUser = submission.sharedUsers.find(
              user => user.email === loggedInUserEmail
            );
            if (sharedUser) {
              sharedFeature = sharedUser.features;
              canDownloadFiles = sharedFeature ? sharedFeature.downloadFiles : false;
            } else {
              canDownloadFiles = this.getDownloadPermission(submission, loggedInUserEmail);
            }
          } else {
            canDownloadFiles = this.getDownloadPermission(submission, loggedInUserEmail);
          }
          this.addCustomValidators(statusCode, sharedFeature, canDownloadFiles);
        }
      });
  }

  /**
   * Add the validators for add, remove and disable files.
   *
   * @private
   * @param {string} statusCode
   * @param {any} sharedFeature
   * @param {boolean} downloadFiles
   * @memberof ExtendedFieldFileExplorerComponent
   */
  private addCustomValidators(statusCode: string, sharedFeature, downloadFiles: boolean) {
    this.isPendingState = statusCode === 'PENDINGQC' || statusCode === 'PENDINGAPPROVAL';
    this.canAddFiles = sharedFeature
      ? sharedFeature.addFiles
        ? this.checkIfFilesCanBeAdded()
        : false
      : this.checkIfFilesCanBeAdded();

    this.canDeleteFiles = this.checkIfFilesCanBeDeleted(sharedFeature);
    this.canDownloadFiles = downloadFiles;
    this.fileValidator.disableCategorySelector = (fileType: string) => {
      return this.checkFilesToDisable(fileType);
    };
  }

  /**
   * If file can be added
   *
   * @private
   * @returns {boolean}
   * @memberof ExtendedFieldFileExplorerComponent
   */
  private checkIfFilesCanBeAdded(): boolean {
    if (this.isPendingState) {
      return false;
    } else {
      if (!this.readonly) {
        // create and edit mode
        return true;
      } else {
        // view mode
        return false;
      }
    }
  }

  /**
   * Looking for download permission for the files.
   *
   * @private
   * @param {Submission} activeSubmission
   * @param {string} loggedInUserEmail
   * @returns {boolean}
   * @memberof ExtendedFieldFileExplorerComponent
   */
  private getDownloadPermission(activeSubmission: Submission, loggedInUserEmail: string): boolean {
    let canDownloadFiles = false;
    const viewAllPermission = this.activatedRoute.snapshot.data.userDetail.canUserViewAll
      .canViewAll;
    if (loggedInUserEmail === activeSubmission.email && activeSubmission.submissionType !== 'FTP') {
      canDownloadFiles = true;
    } else if (
      loggedInUserEmail !== activeSubmission.email &&
      viewAllPermission &&
      activeSubmission.submissionType !== 'FTP'
    ) {
      canDownloadFiles = true;
    }
    return canDownloadFiles;
  }

  /**
   * If files can be deleted
   *
   * @private
   * @param {any} sharedFeature
   * @returns
   * @memberof ExtendedFieldFileExplorerComponent
   */
  private checkIfFilesCanBeDeleted(sharedFeature) {
    if (sharedFeature && sharedFeature.addFiles) {
      if (!this.readonly && !this.isPendingState) {
        return true;
      } else {
        return false;
      }
    } else if (sharedFeature && !sharedFeature.addFiles) {
      return false;
    } else if (!sharedFeature && !this.readonly && !this.isPendingState) {
      return true;
    }
  }

  /**
   * If file card to be disabled
   *
   * @private
   * @param {String} filetype
   * @returns {boolean}
   * @memberof ExtendedFieldFileExplorerComponent
   */
  private checkFilesToDisable(filetype: String): boolean {
    if (this.readonly) {
      // view mode
      return true;
    } else {
      // edit mode
      if (this.isPendingState) {
        return true;
      } else {
        const isVideo = filetype === 'mxf' || filetype === 'mov';
        if (isVideo) {
          return true;
        } else {
          return false;
        }
      }
    }
  }
}
