import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FieldSharedUsersComponent } from './field-shared-users.component';
import { MatTooltipModule, MatIconModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ActivatedRoute } from '@angular/router';
import { StoreModule } from '@ngrx/store';
import { of } from 'rxjs';
import { fromAuth } from '@content-platform/auth';
import { UserThumbnailComponent } from '@content-platform/reusable-ui/user-thumbnail';

describe('FieldSharedUsersComponent', () => {
  let component: FieldSharedUsersComponent;
  let fixture: ComponentFixture<FieldSharedUsersComponent>;
  let routeStub;
  beforeEach(async(() => {
    routeStub = {
      params: of({ id: 3 })
    };
    TestBed.configureTestingModule({
      imports: [
        MatTooltipModule,
        MatIconModule,
        FlexLayoutModule,
        StoreModule.forRoot({
          auth: fromAuth.authReducer
        })
      ],
      declarations: [FieldSharedUsersComponent, UserThumbnailComponent],
      providers: [{ provide: ActivatedRoute, useValue: routeStub }]
    }).compileComponents();
    window.matchMedia = _query => <any>{};
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FieldSharedUsersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
