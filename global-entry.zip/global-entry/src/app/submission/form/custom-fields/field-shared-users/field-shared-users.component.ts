import { Component, OnInit, OnDestroy } from '@angular/core';

import {
  UserFeature,
  SharePayload,
  Share,
  CurrentChanges,
  shareActions
} from '@content-platform/submissions-api';
import { globalEnvironment } from '@environments/environment';
import { Store, select } from '@ngrx/store';
import { Auth, authSelectors } from '@content-platform/auth';
import * as fromSelectors from '../../store/selectors';
import { filter, takeUntil } from 'rxjs/operators';
import { DynamicFormField } from '@content-platform/reusable-ui/dynamic-form-builder';

@Component({
  selector: 'app-field-shared-users',
  templateUrl: './field-shared-users.component.html',
  styleUrls: ['./field-shared-users.component.scss']
})
export class FieldSharedUsersComponent extends DynamicFormField implements OnInit, OnDestroy {
  submissionId: string;
  edittedByName: string;
  edittedByEmail: string;
  sharedUsers: UserFeature[];
  removedUsers: CurrentChanges[] = [];

  constructor(private store: Store<Auth>) {
    super();
  }

  ngOnInit() {
    this.sharedUsers = [];
    this.removedUsers = [];

    this.store
      .pipe(
        select(authSelectors.getADUser),
        takeUntil(this.componentDestroyed$)
      )
      .subscribe(({ profile }) => {
        this.edittedByName = profile.given_name;
        this.edittedByEmail = profile.unique_name;
      });

    this.store
      .pipe(
        select(fromSelectors.getActiveSubmission),
        filter(data => !!data),
        takeUntil(this.componentDestroyed$)
      )
      .subscribe((data: any) => {
        this.submissionId = data.id;
        if (data.sharedUsers) {
          this.sharedUsers = data.sharedUsers;
        }
      });
  }

  deleteUser(_a, index) {
    const currentChangeDetails: CurrentChanges = {
      name: this.sharedUsers[index].name,
      email: this.sharedUsers[index].email,
      action: 'Removed',
      notes: ''
    };
    this.removedUsers.push(currentChangeDetails);
    this.sharedUsers.splice(index, 1);
    this.updateUserList();
  }

  get production() {
    return globalEnvironment.production;
  }

  updateUserList() {
    const shareDetails: Share = {
      from: { name: this.edittedByName, email: this.edittedByEmail },
      sharedUsers: this.sharedUsers && this.sharedUsers.length > 0 ? this.sharedUsers : null,
      changes: this.removedUsers,
      link: window.location.href
    };
    const sharePayload: SharePayload = {
      id: this.submissionId,
      payload: shareDetails
    };
    this.store.dispatch(new shareActions.RemoveUser(sharePayload));
  }

  ngOnDestroy() {
    super.ngOnDestroy();
  }
}
