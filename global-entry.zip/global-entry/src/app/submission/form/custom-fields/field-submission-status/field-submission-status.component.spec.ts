import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FieldSubmissionStatusComponent } from './field-submission-status.component';
import { FormGroup, FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatChipsModule } from '@angular/material';

import { StoreModule, combineReducers } from '@ngrx/store';
import { ActivatedRoute } from '@angular/router';

describe('FieldSubmissionStatusComponent', () => {
  let component: FieldSubmissionStatusComponent;
  let fixture: ComponentFixture<FieldSubmissionStatusComponent>;

  class ActivatedRouteMock {
    snapshot = {
      data: {
        schema: { layout: {}, fieldsByMode: { view: {}, edit: {} } },
        region: { name: 'US' },
        userDetail: { regions: [{ name: 'US' }] }
      },
      params: {
        contentType: 'Episodic',
        id: 123
      }
    };
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        MatChipsModule,
        ReactiveFormsModule,
        StoreModule.forRoot({
          submissionApi: combineReducers({
            submissionRecord: () => {
              return {
                ids: ['1234'],
                entities: {
                  '1234': { submissionStatus: { code: 'ARCHIVED' } }
                }
              };
            }
          }),
          routerReducer: combineReducers({ params: { id: '1234' } })
        })
      ],
      providers: [{ provide: ActivatedRoute, useClass: ActivatedRouteMock }],
      declarations: [FieldSubmissionStatusComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FieldSubmissionStatusComponent);
    component = fixture.componentInstance;
    component.parentFormGroup = new FormGroup({
      title: new FormControl('ARCHIVED')
    });
    component.field = { name: 'title', type: 'status' };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return class name as archived', () => {
    expect(component.getStatusClasses()).toBe('archived');
  });

  it('should return class name as rejected', () => {
    component.parentFormGroup.get('title').setValue('REJECTED');
    expect(component.getStatusClasses()).toBe('rejected');
  });

  it('should return class name as pendingapproval', () => {
    component.parentFormGroup.get('title').setValue('PENDINGAPPROVAL');
    expect(component.getStatusClasses()).toBe('pendingapproval');
  });

  it('should return class name as pendingqc', () => {
    component.parentFormGroup.get('title').setValue('PENDINGQC');
    expect(component.getStatusClasses()).toBe('pendingqc');
  });

  it('should return class name as awaitingelements', () => {
    component.parentFormGroup.get('title').setValue('AWAITINGELEMENTS');
    expect(component.getStatusClasses()).toBe('awaitingelements');
  });
});
