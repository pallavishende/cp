import { Component, OnInit, OnDestroy } from '@angular/core';
import { DynamicFormField } from '@content-platform/reusable-ui/dynamic-form-builder';
import { AbstractControl } from '@angular/forms';

import { Store, select } from '@ngrx/store';
import { takeUntil } from 'rxjs/operators';
import { SubmissionPageState } from '../../store';
import * as fromSelectors from '../../store/selectors';
import { Submission } from '@content-platform/submissions-api';

export enum SUBMISSION_STATUS {
  PENDINGQC = 'PENDING QC',
  AWAITINGELEMENTS = 'AWAITING ELEMENTS',
  PENDINGAPPROVAL = 'PENDING APPROVAL',
  ARCHIVED = 'ARCHIVED',
  REJECTED = 'REJECTED',
  APPROVED = 'APPROVED'
}

@Component({
  selector: 'app-field-submission-status',
  templateUrl: './field-submission-status.component.html',
  styleUrls: ['./field-submission-status.component.scss']
})
export class FieldSubmissionStatusComponent extends DynamicFormField implements OnInit, OnDestroy {
  constructor(private store: Store<SubmissionPageState>) {
    super();
  }

  /**
   * Overriding so we get the latest from the parent
   *
   * @readonly
   * @type {AbstractControl}
   * @memberof FieldSubmissionStatusComponent
   */
  get fieldControl(): AbstractControl {
    return this.parentFormGroup.get(this.field.name);
  }

  ngOnInit() {
    super.ngOnInit();
    this.store
      .pipe(
        select(fromSelectors.getActiveSubmission),
        takeUntil(this.componentDestroyed$)
      )
      .subscribe((activeSubmission: Submission) => {
        if (activeSubmission) {
          this.fieldControl.setValue(activeSubmission.submissionStatus.code);
        }
      });
  }

  get status() {
    return this.fieldControl.value;
  }

  get statusValue() {
    return SUBMISSION_STATUS[this.status];
  }

  getStatusClasses() {
    switch (this.statusValue) {
      case SUBMISSION_STATUS.ARCHIVED:
        return 'archived';
      case SUBMISSION_STATUS.REJECTED:
        return 'rejected';
      case SUBMISSION_STATUS.PENDINGAPPROVAL:
        return 'pendingapproval';
      case SUBMISSION_STATUS.PENDINGQC:
        return 'pendingqc';
      case SUBMISSION_STATUS.AWAITINGELEMENTS:
        return 'awaitingelements';
    }
  }

  ngOnDestroy() {
    super.ngOnDestroy();
  }
}
