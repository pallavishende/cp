import {
  FieldRegistryData,
  DynamicFormService,
  CreateFieldData
} from '@content-platform/reusable-ui/dynamic-form-builder';
import { CommentsFieldTextareaComponent } from './field-comments-textarea/comments-field-textarea.component';
import { Validators } from '@angular/forms';

export {
  CommentsFieldTextareaComponent
} from './field-comments-textarea/comments-field-textarea.component';

import { ExtendedFieldFileExplorerComponent } from './field-extended-file-explorer/extended-field-file-explorer.component';
export {
  ExtendedFieldFileExplorerComponent
} from './field-extended-file-explorer/extended-field-file-explorer.component';

import { FieldSharedUsersComponent } from './field-shared-users/field-shared-users.component';
export { FieldSharedUsersComponent } from './field-shared-users/field-shared-users.component';

import { FieldSubmissionStatusComponent } from './field-submission-status/field-submission-status.component';
export { FieldSubmissionStatusComponent } from './field-submission-status/field-submission-status.component';

export function createField(fieldConfig: CreateFieldData, dynamicFormService: DynamicFormService) {
  const { field } = fieldConfig;
  const validators = dynamicFormService.setValidators(field, {
    defaultValidator: Validators.required,
    ...(fieldConfig.options || {})
  });
  return dynamicFormService.createFormControl(field, validators);
}

const FormRegistryFieldData: FieldRegistryData[] = [
  {
    type: 'comments-textarea',
    component: CommentsFieldTextareaComponent,
    createField: createField
  },
  {
    type: 'fileExplorer',
    component: ExtendedFieldFileExplorerComponent,
    createField: createField
  },
  {
    type: 'sharedList',
    component: FieldSharedUsersComponent,
    createField: createField
  },
  {
    type: 'submission-status',
    component: FieldSubmissionStatusComponent,
    createField: createField
  }
];

export { FormRegistryFieldData };
