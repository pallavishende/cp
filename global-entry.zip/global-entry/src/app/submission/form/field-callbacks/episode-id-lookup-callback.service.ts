import {
  DynamicFormService,
  CustomCallbackProvider
} from '@content-platform/reusable-ui/dynamic-form-builder';
import { FormGroup, AbstractControl, AsyncValidatorFn } from '@angular/forms';
import { tap, map, debounceTime, switchMap, take, distinctUntilChanged } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { VmsContentApiService } from '@content-platform/vms-api';
import { Store } from '@ngrx/store';
import { SubmissionPageState } from '../store/reducers/index';
import { notificationActions, NotificationType } from '@content-platform/notifications';
import { FieldSchema } from '@content-platform/dynamic-forms-api';
import { Observable, of } from 'rxjs';

@Injectable()
export class EpisodeIdLookupCallback implements CustomCallbackProvider {
  private autoCompleteFieldsForDSID = [
    'episodicTitle',
    'channel',
    'series',
    'season',
    'episode',
    'episodeVersion',
    'version',
    'premiereDate'
  ];

  constructor(
    private vmsContentApi: VmsContentApiService,
    private store: Store<SubmissionPageState>
  ) {}

  useThisProvider(contentType: string, fieldKey: string): boolean {
    return contentType === 'ge-finished' && fieldKey === 'findEpisodeId';
  }

  setCallback(
    _dynamicFormService: DynamicFormService,
    dynamicForm: FormGroup,
    _field: FieldSchema
  ): void {
    this.disableDSIDRelatedFields(dynamicForm);
    const idField = dynamicForm.get('findEpisodeId');

    if (!idField) {
      return;
    }
    idField.setAsyncValidators(this.asyncEpisodeIdLookupValidator(dynamicForm));
  }

  private asyncEpisodeIdLookupValidator(dynamicForm: FormGroup): AsyncValidatorFn {
    return (control: AbstractControl) => {
      if (!control.value) {
        return of({ required: true });
      }
      return control.valueChanges.pipe(
        debounceTime(800),
        distinctUntilChanged(),
        switchMap(() => this.getDetailsFromDSID(dynamicForm, control.value, 'PTS')),
        map(success => {
          return success ? null : { required: true };
        }),
        take(1)
      );
    };
  }

  private resetDSIDRelatedFields(form: FormGroup) {
    this.autoCompleteFieldsForDSID.forEach(fieldName => {
      this.resetField(form, fieldName);
    });
  }

  private disableDSIDRelatedFields(form: FormGroup) {
    this.autoCompleteFieldsForDSID.forEach(fieldName => {
      this.disableField(form, fieldName);
    });
  }

  private disableField(form: FormGroup, fieldName: string) {
    const field = form.get(fieldName);
    if (field) {
      field.disable();
    }
  }

  private resetField(form: FormGroup, fieldName: string) {
    const field = form.get(fieldName);
    if (field) {
      field.reset();
    }
  }

  private updateFormField(form: FormGroup, fieldName: string, value: any) {
    const field = form.get(fieldName);
    if (value && field) {
      field.setValue(value);
    }
  }

  private getDetailsFromDSID(
    form: FormGroup,
    id: string,
    systemOfOrigin: string
  ): Observable<boolean> {
    return this.vmsContentApi.showDetailsByDsid(id, <'PTS' | 'Alias'>systemOfOrigin).pipe(
      tap(value => {
        if (value && value.Season) {
          this.resetDSIDRelatedFields(form);
          this.updateFormField(form, 'episodicTitle', value.Episode);
          this.updateFormField(form, 'channel', value.Channels[0].ChannelName);
          this.updateFormField(form, 'series', value.Series);
          this.updateFormField(form, 'season', value.Season);
          this.updateFormField(form, 'episode', value.Episode);
          this.updateFormField(form, 'episodeVersion', value.VersionId);

          this.disableDSIDRelatedFields(form);
        } else {
          this.throwDSIDNotFoundError();
        }
      }),
      map(value => value && !!value.Season)
    );
  }

  private throwDSIDNotFoundError() {
    this.store.dispatch(
      new notificationActions.Open({
        type: NotificationType.Error,
        durationMs: 2000,
        inputs: {
          props: {
            message: 'Content record details could not be found',
            button: {
              label: 'Dismiss'
            }
          }
        }
      })
    );
  }
}
