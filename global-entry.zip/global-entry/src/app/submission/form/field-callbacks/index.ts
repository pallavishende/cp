import { IsrcFieldCallback } from './isrc-callback.service';
import { SystemOfOriginCallback } from './system-of-origin-callback.service';
import { EpisodeIdLookupCallback } from './episode-id-lookup-callback.service';

const fieldCallbacks = [IsrcFieldCallback, SystemOfOriginCallback, EpisodeIdLookupCallback];

export { fieldCallbacks };
