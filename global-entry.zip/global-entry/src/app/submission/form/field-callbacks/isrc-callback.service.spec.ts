import { FormControl, ValidatorFn, Validators, FormGroup } from '@angular/forms';
import { FieldSchema, ValidatorSchema } from '@content-platform/dynamic-forms-api';
import { TestBed } from '@angular/core/testing';
import { IsrcFieldCallback } from './isrc-callback.service';

describe('ISRC calback', () => {
  let service: IsrcFieldCallback;
  beforeEach(() =>
    TestBed.configureTestingModule({
      imports: [],
      providers: [IsrcFieldCallback]
    })
  );

  beforeEach(() => {
    service = TestBed.get(IsrcFieldCallback);
  });

  class DynamicServiceMock {
    setCustomValidators(
      _field: FieldSchema,
      customValidators,
      fieldValidator: ValidatorSchema
    ): ValidatorFn {
      let result: ValidatorFn;
      const { required, pattern } = fieldValidator;

      const validatorArr = [customValidators, Validators.pattern(pattern)];
      if (required) {
        validatorArr.push(Validators.required);
      }
      result = Validators.compose(validatorArr);
      return result;
    }
  }

  it('should add required validator to isrc field', () => {
    const dynamicForm = new FormGroup({
      recordCompany: new FormControl(''),
      isrc: new FormControl('')
    });
    const dynamicService = <any>new DynamicServiceMock();
    const field: FieldSchema = {
      name: 'isrc',
      type: 'textbox',
      validators: [
        {
          required: true
        }
      ]
    };
    service.setCallback(dynamicService, dynamicForm, field);
    dynamicForm.controls['recordCompany'].setValue('TEST');
    const validators = dynamicForm.controls['isrc'].validator(dynamicForm.controls['isrc']);
    expect(validators.required).toBeTruthy();
  });

  it('should remove required validator for isrc field', () => {
    const dynamicForm = new FormGroup({
      recordCompany: new FormControl(''),
      isrc: new FormControl('')
    });
    const dynamicService = <any>new DynamicServiceMock();
    const field: FieldSchema = {
      name: 'isrc',
      type: 'textbox',
      validators: [
        {
          required: true
        }
      ]
    };
    service.setCallback(dynamicService, dynamicForm, field);
    dynamicForm.controls['recordCompany'].setValue('TEST');
    let validators = dynamicForm.controls['isrc'].validator(dynamicForm.controls['isrc']);
    expect(validators.required).toBeTruthy();
    dynamicForm.controls['recordCompany'].setValue('Unsigned');
    validators = dynamicForm.controls['isrc'].validator(dynamicForm.controls['isrc']);
    expect(validators).toBeNull();
  });
});
