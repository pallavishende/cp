import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import {
  CustomCallbackProvider,
  DynamicFormService,
  CustomValidators
} from '@content-platform/reusable-ui/dynamic-form-builder';
import { FieldSchema } from '@content-platform/dynamic-forms-api';

@Injectable()
export class IsrcFieldCallback implements CustomCallbackProvider {
  constructor() {}

  useThisProvider(contentType: string, fieldKey: string): boolean {
    return contentType === 'music-video' && fieldKey === 'isrc';
  }

  setCallback(
    dynamicFormService: DynamicFormService,
    dynamicForm: FormGroup,
    field: FieldSchema
  ): void {
    dynamicForm.controls['recordCompany'].valueChanges.subscribe(form => {
      const isrcField = dynamicForm.controls['isrc'];
      if (form === 'Unsigned' || form === 'Independent') {
        // Unsigned
        field.validators[0].required = false;
        if (isrcField) {
          const newValidators = {
            ...field.validators[0],
            required: false
          };
          isrcField.setValidators(
            dynamicFormService.setCustomValidators(
              field,
              CustomValidators.exactLength(field.validators[0].exactLength),
              newValidators
            )
          );
          isrcField.updateValueAndValidity();
        }
      } else {
        field.validators[0].required = true;
        isrcField.setValidators(
          dynamicFormService.setCustomValidators(
            field,
            CustomValidators.exactLength(field.validators[0].exactLength),
            field.validators[0]
          )
        );
        isrcField.updateValueAndValidity();
      }
    });
  }
}
