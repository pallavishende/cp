import {
  DynamicFormService,
  CustomCallbackProvider
} from '@content-platform/reusable-ui/dynamic-form-builder';
import { FormGroup } from '@angular/forms';
import { distinctUntilChanged } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { VmsContentApiService } from '@content-platform/vms-api';
import { Store } from '@ngrx/store';
import { SubmissionPageState } from '../store/reducers/index';
import { notificationActions, NotificationType } from '@content-platform/notifications';
import { FieldSchema } from '@content-platform/dynamic-forms-api';

@Injectable()
export class SystemOfOriginCallback implements CustomCallbackProvider {
  private autoCompleteFieldsForDSID = [
    'episodicTitle',
    'channel',
    'series',
    'season',
    'episode',
    'episodeVersion',
    'version',
    'premiereDate'
  ];

  constructor(
    private vmsContentApi: VmsContentApiService,
    private store: Store<SubmissionPageState>
  ) {}

  useThisProvider(contentType: string, fieldKey: string): boolean {
    return contentType === 'episodic' && fieldKey === 'systemOfOrigin';
  }

  setCallback(
    _dynamicFormService: DynamicFormService,
    dynamicForm: FormGroup,
    _field: FieldSchema
  ): void {
    this.disableDSIDRelatedFields(dynamicForm);
    const systemOfOriginField = dynamicForm.get('systemOfOrigin');
    const idField = dynamicForm.get('id');

    if (!systemOfOriginField || !idField) {
      return;
    }

    systemOfOriginField.valueChanges.subscribe(value => {
      if (value) {
        idField.reset();
        idField.enable();
        this.resetDSIDRelatedFields(dynamicForm);
      } else {
        idField.disable();
      }
    });

    idField.disable();
    /*
    if (!systemOfOriginField.value) {
      dynamicForm.get('contentType').disable();
      dynamicForm.get('episodicTitle').disable();
      dynamicForm.get('channel').disable();
    }
   */
    systemOfOriginField.valueChanges.subscribe(value => {
      if (value) {
        if (value === 'PTS') {
          this.updateFormField(dynamicForm, 'contentType', 'Finished');
          this.disableField(dynamicForm, 'contentType');
        }
      } else {
        this.disableField(dynamicForm, 'contentType');
        this.disableField(dynamicForm, 'episodicTitle');
        this.disableField(dynamicForm, 'channel');
      }
    });
    idField.valueChanges.pipe(distinctUntilChanged()).subscribe(value => {
      if (value) {
        this.resetDSIDRelatedFields(dynamicForm);
        this.getDetailsFromDSID(dynamicForm, value, systemOfOriginField.value);
      }
    });
  }

  private resetDSIDRelatedFields(form: FormGroup) {
    this.autoCompleteFieldsForDSID.forEach(fieldName => {
      this.resetField(form, fieldName);
    });
  }

  private disableDSIDRelatedFields(form: FormGroup) {
    this.autoCompleteFieldsForDSID.forEach(fieldName => {
      this.disableField(form, fieldName);
    });
  }

  private disableField(form: FormGroup, fieldName: string) {
    const field = form.get(fieldName);
    if (field) {
      field.disable();
    }
  }

  private resetField(form: FormGroup, fieldName: string) {
    const field = form.get(fieldName);
    if (field) {
      field.reset();
    }
  }

  private updateFormField(form: FormGroup, fieldName: string, value: any) {
    const field = form.get(fieldName);
    if (value && field) {
      field.setValue(value);
    }
  }

  private getDetailsFromDSID(form: FormGroup, id: string, systemOfOrigin: string) {
    this.vmsContentApi.showDetailsByDsid(id, <'PTS' | 'Alias'>systemOfOrigin).subscribe(value => {
      if (value && value.Season) {
        this.updateFormField(form, 'episodicTitle', value.Episode);
        this.updateFormField(form, 'channel', value.Channels[0].ChannelName);
        this.updateFormField(form, 'series', value.Series);
        this.updateFormField(form, 'season', value.Season);
        this.updateFormField(form, 'episode', value.Episode);
        this.updateFormField(form, 'episodeVersion', value.VersionId);

        this.disableDSIDRelatedFields(form);
      } else {
        this.throwDSIDNotFoundError();
      }
    });
  }

  private throwDSIDNotFoundError() {
    this.store.dispatch(
      new notificationActions.Open({
        type: NotificationType.Error,
        durationMs: 2000,
        inputs: {
          props: {
            message: 'Content record details could not be found',
            button: {
              label: 'Dismiss'
            }
          }
        }
      })
    );
  }
}
