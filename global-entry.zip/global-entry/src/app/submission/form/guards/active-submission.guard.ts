import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate } from '@angular/router';
import { submissionActions, submissionSelectors } from '@content-platform/submissions-api';
import { Store, select } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { catchError, filter, map, withLatestFrom } from 'rxjs/operators';
import { SubmissionPageState } from '../store/reducers';

@Injectable()
export class ActiveSubmissionGuard implements CanActivate {
  constructor(protected store: Store<SubmissionPageState>) {}

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    return this.checkStore(route.params.id).pipe(catchError(() => of(false)));
  }

  checkStore(submissionId): Observable<boolean> {
    return this.store.pipe(
      select(submissionSelectors.getSubmissionsLoadByIdLoading),
      withLatestFrom(this.store.pipe(select(submissionSelectors.getSubmissionsLoadByIdLoaded))),
      filter(([loading, loaded], index) => {
        if (!loaded && !loading && index === 0) {
          this.store.dispatch(new submissionActions.LoadById({ id: submissionId }));
          return false;
        }
        return !loading;
      }),
      map(([, loaded]) => loaded as boolean)
    );
  }
}
