import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import { PageNavigationComponent } from '@content-platform/reusable-ui/components';

@Injectable()
export class NavigationGuard implements CanDeactivate<PageNavigationComponent> {
  canDeactivate(component: PageNavigationComponent): boolean {
    if (component.canDeactivate()) {
      if (confirm('Are you sure you want to leave without saving submission?')) {
        return true;
      } else {
        return false;
      }
    }
    return true;
  }
}
