import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import {
  DatasetGuard,
  CustomDatasetProviderRegistry,
  fromFieldSchema
} from '@content-platform/dynamic-forms-api';

import { Store } from '@ngrx/store';
import { Observable, of } from 'rxjs';

import { catchError } from 'rxjs/operators';
import { REGION_DATASET_LOOKUP } from '../constants/submissions-form.constants';

@Injectable()
export class RegionsDatasetGuard extends DatasetGuard implements CanActivate {
  constructor(store: Store<fromFieldSchema.State>, customDatasets: CustomDatasetProviderRegistry) {
    super(store, customDatasets);
  }

  canActivate(): Observable<boolean> {
    return this.checkStore(REGION_DATASET_LOOKUP.contentType, REGION_DATASET_LOOKUP.fieldKeys).pipe(
      catchError(() => of(false))
    );
  }
}
