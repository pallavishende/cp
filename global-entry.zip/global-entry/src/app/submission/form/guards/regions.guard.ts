import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError, map, switchMap, tap, withLatestFrom } from 'rxjs/operators';
import { UserPermissionsService, UserPermissionListGuard } from '@content-platform/application-api';
import { CanActivate, Router, ActivatedRouteSnapshot } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { SubmissionPageState } from '../store/reducers';
import { globalEntryMetadataKeys, createErrorAction } from '../../../../constants';

import {
  layoutSchemaSelectors,
  SchemaHelper,
  LayoutSchemaWithFieldsGuard
} from '@content-platform/dynamic-forms-api';

@Injectable()
export class RegionsGuard implements CanActivate {
  constructor(
    private store: Store<SubmissionPageState>,
    private userPermissionsService: UserPermissionsService,
    private userPermissionsListGuard: UserPermissionListGuard,
    private router: Router,
    private layoutSchemaWithFieldsGuard: LayoutSchemaWithFieldsGuard
  ) {}

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    return this.checkStore(route).pipe(catchError(() => of(false)));
  }

  checkStore(route: ActivatedRouteSnapshot): Observable<boolean> {
    const contentType = route.data['contentType'] || route.params['contentType'];
    return this.layoutSchemaWithFieldsGuard.checkStore(contentType).pipe(
      withLatestFrom(this.userPermissionsListGuard.checkStore()),
      switchMap(([schemaLoaded, permLoaded]) => {
        return this.userPermissionsService
          .getFeatureMetadataListAsync(globalEntryMetadataKeys.REGION)
          .pipe(
            map(regionMetaDatas => regionMetaDatas.length > 0),
            withLatestFrom(
              this.store.pipe(
                select(
                  layoutSchemaSelectors.getLayoutSchemaByContentTypeWithFieldSchemaMap(contentType)
                ),
                map(response => {
                  return {
                    layout: response.layoutSchema,
                    fieldsByMode: response.fieldSchemaMapByMode
                  };
                })
              )
            ),
            tap(([hasRegions, schema]) => {
              // If user has not region configured for the specific content types do not load the
              // create instead redirect him to dashboard
              if (SchemaHelper.getFormLayoutOption(schema.layout, 'regionRequired') && !hasRegions) {
                this.router.navigate(['/'], { skipLocationChange: true });

                this.store.dispatch(
                  createErrorAction(
                    'You cannot submit the submission without a region, currently no region ' +
                      'is assigned to you, please contact your administrator.'
                  )
                );
              }
            }),
            map(() => {
              return permLoaded && schemaLoaded;
            })
          );
      })
    );
  }
}
