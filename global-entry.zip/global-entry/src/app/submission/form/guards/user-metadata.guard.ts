import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError, switchMap, map } from 'rxjs/operators';
import { UserPermissionsService, UserPermissionListGuard } from '@content-platform/application-api';
import { CanActivate, Router, ActivatedRouteSnapshot } from '@angular/router';
import { SubmissionPageState } from '../store/reducers';
import { createErrorAction, globalEntryMetadataKeys } from '../../../../constants';
import { Store } from '@ngrx/store';

@Injectable()
export class UserMetadataGuard implements CanActivate {
  constructor(
    private store: Store<SubmissionPageState>,
    private userPermissionsService: UserPermissionsService,
    private userPermissionsListGuard: UserPermissionListGuard,
    private router: Router
  ) {}

  canActivate(activatedRoute: ActivatedRouteSnapshot): Observable<boolean> {
    return this.checkStore(activatedRoute).pipe(catchError(() => of(false)));
  }

  checkStore(activatedRoute: ActivatedRouteSnapshot): Observable<boolean> {
    return this.userPermissionsListGuard.checkStore().pipe(
      switchMap(loaded => {
        if (loaded) {
          return this.userPermissionsService
            .getFeatureMetadataListAsync(globalEntryMetadataKeys.CONTENT_TYPE)
            .pipe(
              map(contentTypeMetaDatas => {
                const hasContentType = contentTypeMetaDatas.length > 0;

                if (!hasContentType) {
                  // If route is coming from a diffent path than dashboard re-route user to dashboard
                  if (!activatedRoute.data.isDashboard) {
                    this.router.navigate(['/'], { skipLocationChange: true });
                  } else {
                    this.store.dispatch(
                      createErrorAction(
                        'There is no content type assigned to you, please contact your administrator.'
                      )
                    );
                  }
                }

                if (hasContentType && activatedRoute.params && activatedRoute.params.contentType) {
                  const ct = contentTypeMetaDatas.find(
                    contentType => contentType.name === activatedRoute.params.contentType
                  );

                  // if route is coming from a content-type that user has not defined in his roles,
                  // reroute to dashboard and show notification
                  if (!ct) {
                    this.router.navigate(['/'], { skipLocationChange: true });
                    this.store.dispatch(
                      createErrorAction(
                        activatedRoute.params.contentType +
                          ' is not ' +
                          'assigned to you, please contact the administrator'
                      )
                    );
                  }
                }
                return true;
              })
            );
        }
        return of(loaded);
      })
    );
  }
}
