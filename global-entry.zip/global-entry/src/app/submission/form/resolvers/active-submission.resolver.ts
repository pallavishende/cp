import { Submission, submissionSelectors } from '@content-platform/submissions-api';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { map, take, tap } from 'rxjs/operators';
import * as fromStore from '../store';
import { SubmissionStatusState, SubmissionStatusAction } from '../store';
import { LoadTimelineData, TimelineService } from '@content-platform/reusable-ui/timeline';

@Injectable()
export class ActiveSubmissionResolver implements Resolve<Observable<Submission>> {
  constructor(
    private store: Store<fromStore.SubmissionPageState>,
    private timelineService: TimelineService
  ) {}

  resolve(route: ActivatedRouteSnapshot): Observable<Submission> {
    return this.store.pipe(
      select(submissionSelectors.getSubmissionEntities),
      map(submissions => {
        return submissions[route.params.id];
      }),
      tap(activeSubmission => {
        const submissionStatusState: SubmissionStatusState = {
          currentStatus: activeSubmission.submissionStatus.description,
          submissionId: activeSubmission.id,
          statusCode: activeSubmission.submissionStatus.code
        };
        // dispatch all init events
        this.store.dispatch(new SubmissionStatusAction(submissionStatusState));
        this.store.dispatch(new LoadTimelineData(activeSubmission.id));
        this.timelineService.setSubmissionId(activeSubmission.id);
      }),
      take(1)
    );
  }
}
