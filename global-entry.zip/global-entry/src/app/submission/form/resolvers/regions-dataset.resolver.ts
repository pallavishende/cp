import { REGION_DATASET_LOOKUP } from '../constants/submissions-form.constants';
import { DatasetOptions, datasetSelectors } from '@content-platform/dynamic-forms-api';

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Resolve } from '@angular/router';
import * as fromStore from '../store';
import { Store, select } from '@ngrx/store';
import { take, map } from 'rxjs/operators';

@Injectable()
export class RegionsDatasetResolver implements Resolve<Observable<DatasetOptions[]>> {
  constructor(private store: Store<fromStore.SubmissionPageState>) {}

  resolve(): Observable<DatasetOptions[]> {
    return this.store.pipe(
      select(
        datasetSelectors.getDatasetOptions(
          REGION_DATASET_LOOKUP.contentType,
          REGION_DATASET_LOOKUP.fieldKeys
        )
      ),
      map(datasetValues => {
        return datasetValues;
      }),
      take(1)
    );
  }
}
