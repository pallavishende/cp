import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import {
  LayoutSchema,
  FieldSchema,
  Dataset,
  layoutSchemaSelectors,
  datasetSelectors
} from '@content-platform/dynamic-forms-api';
import { map, withLatestFrom, take } from 'rxjs/operators';
import { Store, select } from '@ngrx/store';

export interface SchemaData {
  layout: LayoutSchema | LayoutSchema[];
  fieldsByMode: { [mode: string]: { [key: string]: FieldSchema } };
  datasets: Dataset[];
}

@Injectable()
export class SchemaResolver implements Resolve<SchemaData> {
  constructor(private store: Store<any>) {}

  resolve(route: ActivatedRouteSnapshot): Observable<SchemaData> {
    const contentType = route.data['contentType'] || route.params['contentType'];
    return this.store.pipe(
      select(layoutSchemaSelectors.getLayoutSchemaByContentTypeWithFieldSchemaMap(contentType)),
      map(response => {
        return {
          layout: response.layoutSchema,
          fieldsByMode: response.fieldSchemaMapByMode
        };
      }),
      withLatestFrom(
        this.store.pipe(select(datasetSelectors.getDatasetsByContentType(contentType)))
      ),
      map(([response, datasets]) => {
        return {
          ...response,
          datasets
        };
      }),
      take(1)
    );
  }
}
