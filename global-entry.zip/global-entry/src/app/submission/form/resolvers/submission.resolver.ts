import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Resolve } from '@angular/router';

@Injectable()
export class SubmissionResolver implements Resolve<any> {
  constructor() {}

  resolve(): Observable<any> {
    return of({});
  }
}
