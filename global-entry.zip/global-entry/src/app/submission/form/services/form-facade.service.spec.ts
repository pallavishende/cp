import { TestBed } from '@angular/core/testing';

import { FormFacadeService } from './form-facade.service';
import { FormGroup } from '@angular/forms';
import { DynamicFormService } from '@content-platform/reusable-ui/dynamic-form-builder';
import { of } from 'rxjs';
import { Store } from '@ngrx/store';
import { HttpClient } from '@angular/common/http';

class DynamicFormServiceMock {
  createNewForm() {
    return new FormGroup({});
  }
}

class StoreMock {
  dispatch() {}
  select() {
    return of({});
  }
}

describe('FormFacadeService', () => {
  beforeEach(() =>
    TestBed.configureTestingModule({
      imports: [],
      providers: [
        FormFacadeService,
        { provide: DynamicFormService, useClass: DynamicFormServiceMock },
        { provide: HttpClient, useValue: { get: () => of({}) } },
        { provide: Store, useClass: StoreMock }
      ]
    })
  );

  it('should be created', () => {
    const service: FormFacadeService = TestBed.get(FormFacadeService);
    expect(service).toBeTruthy();
  });
});
