import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { DatasetProvider, DatasetContainer } from '../shared/dataset-provider';
import { DynamicFormService } from '@content-platform/reusable-ui/dynamic-form-builder';
import {
  SubmissionFormData,
  submissionActions,
  Submission
} from '@content-platform/submissions-api';
import { DatasetValue } from '@content-platform/application-api';
import { Store } from '@ngrx/store';
import * as fromStore from '../store';

import { EDIT_FORM_FIELD_KEYS } from '../constants/submissions-form.constants';
import { Dataset } from '@content-platform/dynamic-forms-api';

@Injectable()
export class FormFacadeService {
  datasetProvider: DatasetProvider;
  constructor(
    protected dynamicFormService: DynamicFormService,
    private store: Store<fromStore.SubmissionPageState>
  ) {}

  viewSubmission() {
    this.initViewMode();
  }

  private initViewMode() {}

  get datasets(): DatasetContainer {
    return this.datasetProvider.datasets;
  }

  provideDatasets(datasets: Dataset[]) {
    datasets.forEach(dataset => {
      this.datasetProvider.addDataset(dataset.fieldKey, dataset.value);
    });
  }

  create(form: FormGroup, contentType: string, selectedUserRegion: DatasetValue) {
    if (form.status !== 'VALID') {
      return;
    }
    const { fileExplorer, ...submissionFormData } = form.getRawValue();

    const formData: SubmissionFormData = {
      submissionFormData,
      contentType,
      fileDetails: {
        groups: fileExplorer
      },
      submittedUserPhone: '',
      region: selectedUserRegion && selectedUserRegion.name
    };

    this.parseFormData(formData);

    this.store.dispatch(
      new submissionActions.CreateWithFileUpload({
        submission: formData,
        filedata: fileExplorer,
        multipart: true
      })
    );
    form.markAsPristine();
  }

  private parseFormData(formData: SubmissionFormData) {
    if (formData.submissionFormData.termsAndConditions) {
      this.setTermsAndConditions(formData);
    }
  }

  private setTermsAndConditions(formData: SubmissionFormData) {
    // Once we have the backend support we can get rid of this condition
    if (
      formData.submissionFormData.termsAndConditions &&
      typeof formData.submissionFormData.termsAndConditions === 'string'
    ) {
      formData.termsAndConditionsVersion = formData.submissionFormData.termsAndConditions;
    }

    // Not passing this value in submission request body
    delete formData.submissionFormData.termsAndConditions;
  }

  updateFormData(
    contentType: string,
    form: FormGroup,
    currentSubmission: Submission,
    isResubmitted: boolean
  ) {
    const { fileExplorer, ...submissionFormData } = form.getRawValue();
    EDIT_FORM_FIELD_KEYS.forEach(key => {
      delete submissionFormData[key];
    });

    const formData: Submission = {
      submissionFormData: submissionFormData,
      id: currentSubmission.id,
      contentType,
      fileDetails: {
        groups: fileExplorer
      },
      modifiedDate: new Date().toISOString(),
      submittedUserPhone: '',
      submittedDate: currentSubmission.submittedDate,
      submitterEmail: currentSubmission.email,
      submissionStatus: currentSubmission.submissionStatus,
      submittedBy: currentSubmission.submittedBy,
      createdBy: currentSubmission.createdBy,
      email: currentSubmission.email,
      resubmission: isResubmitted,
      link: window.location.href,
      region: currentSubmission.region,
      previewUrl: currentSubmission.previewUrl,
      submissionType: currentSubmission.submissionType
    };

    this.store.dispatch(
      new submissionActions.UpdateWithFileUpload({
        submission: formData,
        filedata: fileExplorer
      })
    );
    form.markAsPristine();
  }
}
