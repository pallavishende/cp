import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Environments } from '@content-platform/configuration';
import { CustomDatasetSearchProvider, DatasetOptions } from '@content-platform/dynamic-forms-api';
import { map } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

@Injectable()
export class KeywordsSearchService implements CustomDatasetSearchProvider {
  constructor(private http: HttpClient) {}

  private getKeywordSearchURL(): string {
    return Environments.getUrl('gegatewayEndpoint') + '/vms/alias/venus/ContentKeywords';
  }

  useThisProvider(_contentType: string, fieldKey: string): boolean {
    return fieldKey === 'keywords';
  }

  search(searchString: string): Observable<DatasetOptions[]> {
    if (!searchString || searchString.length < 3) {
      return of([
        {
          values: []
        }
      ]);
    }
    const filterParam =
      `((KeywordType eq 'L') or (KeywordType eq null))` +
      ` and (substringof('${searchString}',ContentKeywordDesc) eq true)`;
    return this.http
      .get<any>(this.getKeywordSearchURL(), {
        params: {
          $filter: filterParam,
          $orderby: 'ContentKeywordDesc',
          $select: 'ContentKeywordDesc,ContentKeywordId'
        }
      })
      .pipe(
        map(response => {
          if (response && response.value) {
            return response.value.map(keyword => {
              return {
                name: keyword.ContentKeywordDesc,
                description: keyword.ContentKeywordDesc
              };
            });
          } else {
            return [];
          }
        }),
        map(keywordArray => {
          return [
            {
              values: keywordArray
            }
          ] as DatasetOptions[];
        })
      );
  }
}
