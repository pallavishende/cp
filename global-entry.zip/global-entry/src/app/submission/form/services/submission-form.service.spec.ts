import { TestBed } from '@angular/core/testing';
import { SubmissionFormService } from './submission-form.service';
import { Store } from '@ngrx/store';

fdescribe('SubmissionFormService', () => {
  class StoreMock {
    dispatch() {}
  }

  beforeEach(() =>
    TestBed.configureTestingModule({
      providers: [
        SubmissionFormService,
        {
          provide: Store,
          useClass: StoreMock
        }
      ]
    })
  );

  it('should be created', () => {
    const service: SubmissionFormService = TestBed.get(SubmissionFormService);
    expect(service).toBeTruthy();
  });
});
