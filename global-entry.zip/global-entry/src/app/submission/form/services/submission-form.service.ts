import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { submissionActions } from '@content-platform/submissions-api';

@Injectable()
export class SubmissionFormService {
  contentType: string;

  constructor(private store: Store<any>) {}

  setContentType(contentType: string) {
    this.contentType = contentType;
  }

  create(formData: any, filedata?: any) {
    this.store.dispatch(
      new submissionActions.CreateWithFileUpload({
        submission: formData,
        filedata: filedata,
        multipart: true
      })
    );
  }
}
