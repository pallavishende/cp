import { BehaviorSubject, Observable } from 'rxjs';

export interface DatasetContainer {
  [key: string]: {
    subject: BehaviorSubject<any>;
    value$?: Observable<any>;
  };
}

export class DatasetProvider {
  datasets: DatasetContainer = {};

  addDataset(key: string, initialValue?: any) {
    this.datasets[key] = {
      subject: new BehaviorSubject(initialValue)
    };
    this.datasets[key].value$ = this.datasets[key].subject.asObservable();
  }

  getDataset(key: string) {
    return this.datasets[key] ? this.datasets[key].value$ : null;
  }
}
