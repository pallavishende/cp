import { OnInit, OnDestroy } from '@angular/core';
import { PageNavigationComponent } from '@content-platform/reusable-ui/components';
import { DatasetValue } from '@content-platform/application-api';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { FormFacadeService } from '../services/form-facade.service';
import {
  LayoutSchema,
  Dataset,
  LayoutMode,
  FieldSchemaMap,
  SchemaHelper
} from '@content-platform/dynamic-forms-api';
import { FormGroup } from '@angular/forms';
import { DynamicFormService } from '@content-platform/reusable-ui/dynamic-form-builder';
import { ContentHeaderBarService } from '@content-platform/navigation';
import { DatasetProvider } from './dataset-provider';
import { startCase } from 'lodash';
import { Subject, BehaviorSubject } from 'rxjs';
import { map, takeUntil, switchMap, distinctUntilChanged } from 'rxjs/operators';
import { PermissionMetadata } from '@content-platform/application-api';

/**
 * This is base class to build the form for create and view modes
 *
 * @export
 * @class FormContainerComponent
 * @extends {PageNavigationComponent}
 * @implements {OnInit}
 * @implements {OnDestroy}
 */
export abstract class FormContainerComponent extends PageNavigationComponent
  implements OnInit, OnDestroy {
  layout: LayoutSchema;
  fieldMapByMode: { [key: string]: FieldSchemaMap };
  datasets: Dataset[];
  contentType: string;
  formInfo: any;
  form: FormGroup;
  mode: string;

  modeChanged$ = new BehaviorSubject<string>('view');

  protected onDestroy$ = new Subject<void>();

  /**
   * Subject whose value is the current form
   *
   * @protected
   * @memberof FormContainerComponent
   */
  protected form$ = new Subject<FormGroup>();

  /**
   * Observable for value changes on whatever the current form object is
   *
   * @protected
   * @memberof FormContainerComponent
   */
  protected formChanges$ = this.form$.pipe(
    switchMap(form => {
      return form.statusChanges;
    })
  );

  /**
   * Observable for if the current form is unable to Submit (ie. will be true if Submit shoudl be disabled)
   *
   * @protected
   * @type {BehaviorSubject<boolean>}
   * @memberof FormContainerComponent
   */
  protected submitDisabled$ = new BehaviorSubject<boolean>(true);

  /**
   * Active region
   *
   * @protected
   * @type {DatasetValue}
   * @memberof FormContainerComponent
   */
  protected activeRegion: DatasetValue;

  private _feature: string;
  protected contentTypes: PermissionMetadata[];
  protected selectedContentType: PermissionMetadata;
  protected navigationSubscription;

  constructor(
    protected activatedRoute: ActivatedRoute,
    protected formService: FormFacadeService,
    protected dynamicFormService: DynamicFormService,
    protected contentHeaderBarService: ContentHeaderBarService,
    protected router: Router
  ) {
    super();
    this.formChanges$
      .pipe(
        map(() => this.disableSubmit),
        distinctUntilChanged()
      )
      .pipe(takeUntil(this.onDestroy$))
      .subscribe(disabled => {
        this.submitDisabled$.next(disabled);
      });
    this.navigationSubscription = this.router.events.subscribe((e: any) => {
      if (e instanceof NavigationEnd) {
        this.resetForm();
      }
    });
  }

  get formLayoutHasRegionOption() {
    return SchemaHelper.getFormLayoutOption(this.layout, 'regionRequired');
  }

  get datasetContainer() {
    return this.formService.datasetProvider;
  }

  get feature() {
    return this._feature;
  }

  get disableSubmit() {
    return (
      this.form.invalid ||
      this.form.pending ||
      (this.formLayoutHasRegionOption && !this.activeRegion)
    );
  }

  get activeRegionName(): string {
    return this.activeRegion ? this.activeRegion.description : '';
  }

  get title() {
    if (this.mode === 'create') {
      return '';
    } else {
      return `${this.activeRegionName} ${this.getContentTypeDisplayName()} Submission Form`.trim();
    }
  }

  getContentTypeDisplayName() {
    return startCase(this.contentType);
  }

  canDeactivate(): boolean {
    return this.form.dirty;
  }

  ngOnInit() {
    this.setHeaderButtons();
  }

  protected setHeaderButtons() {
    this.contentHeaderBarService.clearButtons();
  }

  /**
   * This method is called on initialize of the create or view form
   *
   * @param {string} [mode='create']
   * @param {*} [formData]
   * @memberof FormContainerComponent
   */
  initialize(mode: LayoutMode = 'create', formData?: any) {
    if (!this.fieldMapByMode) {
      this.contentType = this.activatedRoute.snapshot.params['contentType'] as string;
      this._feature = this.activatedRoute.snapshot.data['featureGuard'] as string;
      this.formInfo = { contentType: this.contentType };
      const resolvedData = this.activatedRoute.snapshot.data['schema'];
      if (resolvedData) {
        this.layout = resolvedData.layout;
        this.fieldMapByMode = resolvedData.fieldsByMode;
        this.datasets = resolvedData.datasets;
        this.formService.datasetProvider = new DatasetProvider();
        if (this.contentType !== 'music-video') {
          this.formService.provideDatasets(resolvedData.datasets);
        }
      }
    }
    this.mode = mode;
    this.modeChanged$.next(mode);
    this.form = this.dynamicFormService.createNewFormWithNestedSchemas({
      contentType: this.contentType,
      formSchemaData: {
        [this.contentType]: { fieldSchemaMapByMode: { [this.mode]: this.fieldMapByMode[mode] } }
      },
      formData,
      mode: mode
    });

    if (this.form) {
      this.form$.next(this.form);
    }
  }

  protected resetForm() {
    this.fieldMapByMode = null;
    this.setHeaderButtons();
    this.initialize();
  }

 
  ngOnDestroy() {
    this.onDestroy$.next();
    this.onDestroy$.complete();
    if (this.navigationSubscription) {
      this.navigationSubscription.unsubscribe();
    }
  }
}
