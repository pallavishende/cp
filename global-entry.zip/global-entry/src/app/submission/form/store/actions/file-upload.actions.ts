import { Action } from '@ngrx/store';
import { FileUpload } from '@content-platform/aws';

// upload Files
export const FILE_UPLOAD_TO_AMAZON_BUCKET = '[File Upload] File Upload to Amazon Bucket';
export const FILE_UPLOAD_TO_AMAZON_BUCKET_SUCCESS =
  '[File Upload] File Upload to Amazon Bucket Success';
export const FILE_UPLOAD_TO_AMAZON_BUCKET_FAIL = '[File Upload] File Upload to Amazon Bucket Fail';
export const RESET = '[File Upload] Reset Amazon File Upload State';

export class FileUploadToAmazonBucket implements Action {
  readonly type = FILE_UPLOAD_TO_AMAZON_BUCKET;
  constructor(public payload: { fileitem: FileUpload; isLast: boolean }) {}
}

export class FileUploadToAmazonBucketSuccess implements Action {
  readonly type = FILE_UPLOAD_TO_AMAZON_BUCKET_SUCCESS;
  constructor(public payload: { fileitem: FileUpload; isLast: boolean }) {}
}

export class FileUploadToAmazonBucketFail implements Action {
  readonly type = FILE_UPLOAD_TO_AMAZON_BUCKET_FAIL;
  constructor(public payload: any) {}
}

export class ResetStateToInitialState implements Action {
  readonly type = RESET;
  constructor(public payload: any) {}
}
// action types

export type FileUploadAll =
  | FileUploadToAmazonBucket
  | FileUploadToAmazonBucketSuccess
  | FileUploadToAmazonBucketFail
  | ResetStateToInitialState;
