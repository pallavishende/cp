import { Action } from '@ngrx/store';

export const GENERATE_PRESIGNED_URL = '[Generate Url] Generate Presigned Url';
export const GENERATE_PRESIGNED_URL_SUCCESS = '[Generate Url] Generate Presigned Url Success';
export const GENERATE_PRESIGNED_URL_FAIL = '[Generate Url] Generate Presigned Url Fail';

export class GeneratePresignedUrl implements Action {
  readonly type = GENERATE_PRESIGNED_URL;
  constructor(public payload: any) {}
}

export class GeneratePresignedSuccess implements Action {
  readonly type = GENERATE_PRESIGNED_URL_SUCCESS;
  constructor(public payload: any) {}
}

export class GeneratePresignedFail implements Action {
  readonly type = GENERATE_PRESIGNED_URL_FAIL;
  constructor(public payload: any) {}
}

export type GenerateUrlAll =
  | GeneratePresignedUrl
  | GeneratePresignedSuccess
  | GeneratePresignedFail;
