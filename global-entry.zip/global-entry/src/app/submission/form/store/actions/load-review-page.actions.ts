import { Action } from '@ngrx/store';

export const REVIEW_PAGE_LOADING = '[Review Page] Review Page Loading';
export const REVIEW_PAGE_LOAD_SUCCESS = '[Review Page] Review Page Load Success';
export const REVIEW_PAGE_LOAD_FAILED = '[Review Page] Review Page Load Failed';

export class ReviewPageLoading implements Action {
  readonly type = REVIEW_PAGE_LOADING;
  constructor(public payload: any) {}
}

export class ReviewPageLoadSuccess implements Action {
  readonly type = REVIEW_PAGE_LOAD_SUCCESS;
  constructor(public payload: any) {}
}

export class ReviewPageLoadFailed implements Action {
  readonly type = REVIEW_PAGE_LOAD_FAILED;
  constructor(public payload: any) {}
}

export type ReviewPageAll = ReviewPageLoading | ReviewPageLoadSuccess | ReviewPageLoadFailed;
