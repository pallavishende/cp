import { Action } from '@ngrx/store';

export const FILE_UPLOAD_STARTED = '[Monitor Upload] File Upload Started';
export const FILE_UPLOAD_SUCCESS = '[Monitor Upload] File Upload Success';
export const FILE_UPLOAD_FAILED = '[Monitor Upload] File Upload Fail';

export class FileUploadStarted implements Action {
  readonly type = FILE_UPLOAD_STARTED;
  constructor(public payload: any) {}
}

export class FileUploadSuccess implements Action {
  readonly type = FILE_UPLOAD_SUCCESS;
  constructor(public payload: any) {}
}

export class FileUploadFailed implements Action {
  readonly type = FILE_UPLOAD_FAILED;
  constructor(public payload: any) {}
}

// action types
export type MonitorUploadAll = FileUploadStarted | FileUploadSuccess | FileUploadFailed;
