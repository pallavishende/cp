import { Action } from '@ngrx/store';
import { PermissionMetadata } from '@content-platform/application-api';

export const SELECT_REGION = '[SELECT REGION] Region';

export class SelectRegionAction implements Action {
  readonly type = SELECT_REGION;
  constructor(public payload: PermissionMetadata) {}
}
