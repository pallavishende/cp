import { Action } from '@ngrx/store';
import { SubmissionStatusState } from '../states';

export const CURRENT_SUBMISSION_STATUS = '[Submission Status] Current Submission Status';

export class SubmissionStatusAction implements Action {
  readonly type = CURRENT_SUBMISSION_STATUS;
  constructor(public payload: SubmissionStatusState) {}
}
