import { Injectable } from '@angular/core';
import { Effect, Actions, ofType } from '@ngrx/effects';

import { map, catchError, concatMap } from 'rxjs/operators';
import { of } from 'rxjs';

import * as actions from '../actions';
import { FileUploadService } from '@content-platform/aws';

@Injectable()
export class FileUploadEffects {
  constructor(private actions$: Actions, private fileUploadService: FileUploadService) {}

  @Effect()
  FileUploadRes$ = this.actions$.pipe(
    ofType(actions.FILE_UPLOAD_TO_AMAZON_BUCKET),
    concatMap((action: actions.FileUploadToAmazonBucket) => {
      return this.fileUploadService.uploadFileAmazonBucket(action.payload.fileitem).pipe(
        map(_res => {
          action.payload.fileitem.uploadSuccess = true;
          return new actions.FileUploadToAmazonBucketSuccess(action.payload);
        }),
        catchError(error => of(new actions.FileUploadToAmazonBucketFail(error)))
      );
    })
  );
}
