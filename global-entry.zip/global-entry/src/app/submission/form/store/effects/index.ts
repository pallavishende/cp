import { GenerateUrlsEffects } from './presigned-url-genration.effects';
import { FileUploadEffects } from './file-upload-amazon.effects';
import { MonitoFileUploadEffect } from './monitor-upload.effects';

export const effects = [GenerateUrlsEffects, FileUploadEffects, MonitoFileUploadEffect];
