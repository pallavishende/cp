import { Injectable } from '@angular/core';
import { Effect, Actions, ofType } from '@ngrx/effects';

import { notificationActions, NotificationType } from '@content-platform/notifications';

import * as actions from '../actions';
import { globalEntryToaster } from '../../../../../constants/global-entry-toaster-message';
import { mergeMap } from 'rxjs/operators';

@Injectable()
export class MonitoFileUploadEffect {
  constructor(private actions$: Actions) {}

  @Effect()
  monitorFileUpload$ = this.actions$.pipe(
    ofType(actions.FILE_UPLOAD_SUCCESS),
    mergeMap(() => {
      return [
        new notificationActions.Open({
          type: NotificationType.Success,
          inputs: {
            props: {
              message: globalEntryToaster.CREATE_SUCCESS
            }
          }
        })
      ];
    })
  );
}
