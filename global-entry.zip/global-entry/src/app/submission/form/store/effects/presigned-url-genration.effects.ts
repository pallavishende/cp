import { Injectable } from '@angular/core';
import { Effect, Actions, ofType } from '@ngrx/effects';

import { map, catchError, mergeMap } from 'rxjs/operators';
import { of } from 'rxjs';

import * as actions from '../actions';

import { GeneratePresignedUrl } from '../actions';
import { FileUploadService } from '@content-platform/aws';
@Injectable()
export class GenerateUrlsEffects {
  constructor(private actions$: Actions, private fileUploadService: FileUploadService) {}

  @Effect()
  presignedUrls$ = this.actions$.pipe(
    ofType(actions.GENERATE_PRESIGNED_URL),
    mergeMap((action: GeneratePresignedUrl) => {
      return this.fileUploadService.getFileUrl(action.payload, 'PUT').pipe(
        map(url => {
          return new actions.GeneratePresignedSuccess(url);
        }),
        catchError(error => of(new actions.GeneratePresignedFail(error)))
      );
    })
  );
}
