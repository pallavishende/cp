import * as Actions from '../actions/file-upload.actions';
import { FileUploadToAmazonState as State } from '../states/upload-to-amazon-bucket.state';

export const initialState: State = {
  data: undefined,
  fileUploading: false,
  fileUploaded: false,
  isLast: false
};
export function reducer(state = initialState, action: Actions.FileUploadAll): State {
  switch (action.type) {
    case Actions.FILE_UPLOAD_TO_AMAZON_BUCKET: {
      const data = action.payload.fileitem;
      const isLast = action.payload.isLast;
      return {
        ...state,
        fileUploading: true,
        fileUploaded: false,
        data,
        isLast
      };
    }

    case Actions.FILE_UPLOAD_TO_AMAZON_BUCKET_SUCCESS: {
      const data = action.payload.fileitem;
      const isLast = action.payload.isLast;
      return {
        ...state,
        fileUploading: false,
        fileUploaded: true,
        data,
        isLast
      };
    }

    case Actions.FILE_UPLOAD_TO_AMAZON_BUCKET_FAIL: {
      return {
        ...state,
        fileUploaded: false,
        fileUploading: false
      };
    }

    case Actions.RESET: {
      return {
        data: undefined,
        fileUploading: false,
        fileUploaded: false,
        isLast: false
      };
    }

    default: {
      return state;
    }
  }
}
export const fileUploadToAmazonBucketStatus = (state: State) => state.fileUploaded;
export const fileUploadToAmazonBucketResult = (state: State) => state.data;
export const findLastItemFromFileUpload = (state: State) => state.isLast;
