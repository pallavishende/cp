import { ActionReducerMap, createFeatureSelector, createSelector } from '@ngrx/store';

import * as fromPresignedUrlReducer from './presigned-url.reducer';
import * as fromFileUploadReducer from './file-upload-amazon.reducer';
import * as fromUploadMonitorReducer from './monitor-file-upload.reducer';
import * as fromReviewPageReducer from './review-page-load.reducer';
import * as fromSubmissionStatusReducer from './submission-status.reducer';
import * as fromRegionReducer from './region.reducer';

import * as fromPresignedUrlState from '../states/presigned-url.state';
import * as fromFileUploadState from '../states/upload-to-amazon-bucket.state';
import * as fromMonitorUploadState from '../states/monitor-file-upload.state';
import * as fromReviewpageLoadState from '../states/load-review-page.state';

import * as fromSubmissionStatusState from '../states/submission-status.state';
import * as fromRegionState from '../states/region.state';

export interface SubmissionPageState {
  generatePresignedUrl: fromPresignedUrlState.PresignedUrlState;
  fileUploadtoAmazonBucket: fromFileUploadState.FileUploadToAmazonState;
  monitorUpload: fromMonitorUploadState.FileUploadState;
  loadReview: fromReviewpageLoadState.ReviewPageState;
  currentSubmissionStatus: fromSubmissionStatusState.SubmissionStatusState;
  region: fromRegionState.RegionState;
}

export const SubmissionPageReducers: ActionReducerMap<SubmissionPageState> = {
  generatePresignedUrl: fromPresignedUrlReducer.reducer,
  fileUploadtoAmazonBucket: fromFileUploadReducer.reducer,
  monitorUpload: fromUploadMonitorReducer.reducer,
  loadReview: fromReviewPageReducer.reducer,
  currentSubmissionStatus: fromSubmissionStatusReducer.reducer,
  region: fromRegionReducer.reducer
};

export const getSubmissionModuleState = createFeatureSelector<SubmissionPageState>('dynamicforms');

// ******************  Generate Presigned Url *********************** //

export const getPresignedUrlState = createSelector(
  getSubmissionModuleState,
  (state: SubmissionPageState) => state.generatePresignedUrl
);

// selectors
export const getPresignedUrlData = createSelector(
  getPresignedUrlState,
  fromPresignedUrlReducer.getGeneratedPresigenedUrls
);

// ******************  File Upload To Amazon Bucket *********************** //

export const getAmazonFileUploadState = createSelector(
  getSubmissionModuleState,
  (state: SubmissionPageState) => state.fileUploadtoAmazonBucket
);

// Selectors
export const getAmazonFileUploadStatus = createSelector(
  getAmazonFileUploadState,
  fromFileUploadReducer.fileUploadToAmazonBucketStatus
);

export const getAmazonFileUploadedResult = createSelector(
  getAmazonFileUploadState,
  fromFileUploadReducer.fileUploadToAmazonBucketResult
);

export const findLastFileFromUploaded = createSelector(
  getAmazonFileUploadState,
  fromFileUploadReducer.findLastItemFromFileUpload
);

// ********************* Monitor Upload Completion************************//

export const getFileUploadState = createSelector(
  getSubmissionModuleState,
  (state: SubmissionPageState) => state.monitorUpload
);

// Selectors
export const getFileUploadingStatus = createSelector(
  getFileUploadState,
  fromUploadMonitorReducer.fileUploaduploadingStatus
);

export const getFileUploadCompletedStatus = createSelector(
  getFileUploadState,
  fromUploadMonitorReducer.fileUploadUploadCompletedStatus
);

// ******************  monitor review load and update review  *********************** //
export const getViewloadingState = createSelector(
  getSubmissionModuleState,
  (state: SubmissionPageState) => state.loadReview
);

// Selectors
export const getViewLoadingStatus = createSelector(
  getViewloadingState,
  fromReviewPageReducer.reviewLoadPageStatus
);

// Get Current Submission Status
export const getCurrentSubmissionStatus = createSelector(
  getSubmissionModuleState,
  (state: SubmissionPageState) => state.currentSubmissionStatus
);

// ******************  Get Selected Region  *********************** //
export const getSelectedRegion = createSelector(
  getSubmissionModuleState,
  (state: SubmissionPageState) => (state ? state.region : null)
);
