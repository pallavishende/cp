import { FileUploadState as State } from '../states/monitor-file-upload.state';
import * as Actions from '../actions/monitor-file-upload.actions';

export const initialState: State = {
  uploading: false,
  uploaded: false,
  uploadedFailed: false
};

export function reducer(state = initialState, action: Actions.MonitorUploadAll): State {
  switch (action.type) {
    case Actions.FILE_UPLOAD_STARTED: {
      return {
        ...state,
        uploading: true,
        uploaded: false,
        uploadedFailed: false
      };
    }

    case Actions.FILE_UPLOAD_SUCCESS: {
      return {
        ...state,
        uploading: false,
        uploaded: true,
        uploadedFailed: false
      };
    }

    case Actions.FILE_UPLOAD_FAILED: {
      return {
        ...state,
        uploading: false,
        uploaded: false,
        uploadedFailed: true
      };
    }

    default: {
      return state;
    }
  }
}
export const fileUploaduploadingStatus = (state: State) => state.uploading;
export const fileUploadUploadCompletedStatus = (state: State) => state.uploaded;
