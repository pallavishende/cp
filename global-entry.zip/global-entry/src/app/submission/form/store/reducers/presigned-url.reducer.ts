import * as Actions from '../actions/generate-presigned-url.actions';
import { PresignedUrlState as State } from '../states/presigned-url.state';

export const initialState: State = {
  data: null,
  urlsReady: false,
  formValid: false
};
export function reducer(state = initialState, action: Actions.GenerateUrlAll): State {
  switch (action.type) {
    case Actions.GENERATE_PRESIGNED_URL: {
      return {
        ...state,
        urlsReady: false,
        formValid: false
      };
    }

    case Actions.GENERATE_PRESIGNED_URL_SUCCESS: {
      const data = action.payload;
      return {
        ...state,
        urlsReady: false,
        formValid: false,
        data
      };
    }

    case Actions.GENERATE_PRESIGNED_URL_FAIL: {
      return {
        ...state,
        urlsReady: false,
        formValid: false
      };
    }

    default: {
      return state;
    }
  }
}
export const getGeneratedPresigenedUrls = (state: State) => state.data;
export const checkPresignedUrlsReady = (state: State) => state.urlsReady;
export const checkFormValidWithFiles = (state: State) => state.formValid;
