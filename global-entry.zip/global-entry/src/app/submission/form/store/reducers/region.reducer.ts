import * as Actions from '../actions/region.action';
import { RegionState as State } from '../states/region.state';

export const initialState: State = {
  region: undefined
};

export function reducer(state = initialState, action: Actions.SelectRegionAction): State {
  switch (action.type) {
    case Actions.SELECT_REGION: {
      return {
        ...state,
        region: action.payload
      };
    }
  }
  return state;
}
