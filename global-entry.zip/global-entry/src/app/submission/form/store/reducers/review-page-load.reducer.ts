import { ReviewPageState as State } from '../states/load-review-page.state';
import * as Actions from '../actions/load-review-page.actions';

export const initialState: State = {
  loading: false,
  loaded: false,
  loadingFailed: false
};

export function reducer(state = initialState, action: Actions.ReviewPageAll): State {
  switch (action.type) {
    case Actions.REVIEW_PAGE_LOADING: {
      return {
        ...state,
        loading: true,
        loaded: false,
        loadingFailed: false
      };
    }

    case Actions.REVIEW_PAGE_LOAD_SUCCESS: {
      return {
        ...state,
        loading: false,
        loaded: true,
        loadingFailed: false
      };
    }

    case Actions.REVIEW_PAGE_LOAD_FAILED: {
      return {
        ...state,
        loading: false,
        loaded: false,
        loadingFailed: true
      };
    }

    default: {
      return state;
    }
  }
}

export const reviewLoadPageStatus = (state: State) => state.loading;
