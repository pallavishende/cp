import { SubmissionStatusState } from '../states';
import * as Actions from '../actions/submission-status.action';

const initialSubmissionStatusState: SubmissionStatusState = {
  currentStatus: undefined,
  submissionId: undefined,
  statusCode: undefined
};

function checkStatusUpdate(
  currentState: SubmissionStatusState,
  payloadData: SubmissionStatusState
): SubmissionStatusState {
  if (
    currentState.submissionId &&
    currentState.submissionId === payloadData.submissionId &&
    payloadData.currentStatus &&
    payloadData.statusCode
  ) {
    const { currentStatus, statusCode } = payloadData;
    return {
      ...currentState,
      currentStatus,
      statusCode
    };
  } else {
    return {
      ...currentState,
      ...payloadData
    };
  }
}

export function reducer(
  state: SubmissionStatusState = initialSubmissionStatusState,
  action: Actions.SubmissionStatusAction
): SubmissionStatusState {
  switch (action.type) {
    case Actions.CURRENT_SUBMISSION_STATUS:
      return checkStatusUpdate(state, action.payload);
  }
  return { ...state };
}
