import { createSelector } from '@ngrx/store';
import { submissionSelectors, commentSelectors } from '@content-platform/submissions-api';
import { getRouterState } from '../../../../reducers';

export const getActiveSubmission = createSelector(
  submissionSelectors.getSubmissionEntities,
  getRouterState,
  (submissions, router) => {
    return router.state && router.state.params && submissions[router.state.params.id];
  }
);

export const getActiveSubmissionComments = createSelector(
  getActiveSubmission,
  commentSelectors.getCommentEntities,
  (activeSubmission, commentEntities) => {
    return (
      activeSubmission &&
      commentEntities[activeSubmission.id] &&
      commentEntities[activeSubmission.id].resultList
    );
  }
);
