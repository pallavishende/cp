export interface CreateFormState {
  data: any;
  loading: boolean;
  loaded: boolean;
  formReady: boolean;
}
