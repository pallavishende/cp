export interface ReviewPageState {
  loading: boolean;
  loaded: boolean;
  loadingFailed: boolean;
}
