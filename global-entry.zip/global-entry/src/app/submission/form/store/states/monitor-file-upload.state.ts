export interface FileUploadState {
  uploading: boolean;
  uploaded: boolean;
  uploadedFailed: boolean;
}
