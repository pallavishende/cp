export interface PresignedUrlState {
  data: string;
  urlsReady: boolean;
  formValid: boolean;
}
