import { PermissionMetadata } from '@content-platform/application-api';

export interface RegionState {
  region: PermissionMetadata;
}
