export interface SubmissionStatusState {
  currentStatus: string;
  submissionId: number;
  statusCode: string;
}
