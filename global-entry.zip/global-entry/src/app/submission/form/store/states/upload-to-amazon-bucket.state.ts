import { FileUpload } from '@content-platform/aws';

export interface FileUploadToAmazonState {
  data: FileUpload;
  fileUploaded: boolean;
  fileUploading: boolean;
  isLast: boolean;
}
