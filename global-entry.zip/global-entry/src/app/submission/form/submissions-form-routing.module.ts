import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SelectionContainerComponent } from './containers/selection-container/selection-container.component';
import { CreateContainerComponent } from './containers/create-container/create-container.component';
import { ViewContainerComponent } from './containers/view-container/view-container.component';
import { globalEntryFeature } from '../../../constants';
import { UserPermissionListGuard } from '@content-platform/application-api';
import { SchemaResolver } from './resolvers/schema.resolver';
import { UserDetailResolver } from '../../resolvers/user-detail.resolver';
import { ActiveSubmissionResolver } from './resolvers/active-submission.resolver';
import { LayoutSchemaWithFieldsGuard } from '@content-platform/dynamic-forms-api';
import {
  UserMetadataGuard,
  NavigationGuard,
  RegionsDatasetGuard,
  ActiveSubmissionGuard,
  RegionsGuard
} from './guards';
import { RegionsDatasetResolver } from './resolvers/regions-dataset.resolver';

const routes: Routes = [
  {
    path: '',
    component: SelectionContainerComponent,
    data: {
      featureGuard: { key: globalEntryFeature.CREATE_SUB }
    },
    resolve: {
      userDetail: UserDetailResolver
    },
    canActivate: [UserPermissionListGuard, UserMetadataGuard]
  },
  {
    path: ':contentType',
    children: [
      {
        path: 'create',
        component: CreateContainerComponent,
        data: {
          featureGuard: { key: globalEntryFeature.CREATE_SUB }
        },
        resolve: {
          schema: SchemaResolver,
          userDetail: UserDetailResolver
        },
        canActivate: [LayoutSchemaWithFieldsGuard, UserMetadataGuard, RegionsGuard],
        canDeactivate: [NavigationGuard]
      },
      {
        path: 'view/:id',
        component: ViewContainerComponent,
        data: {
          featureGuard: { key: globalEntryFeature.EDIT_SUB }
        },
        resolve: {
          schema: SchemaResolver,
          datasetRegions: RegionsDatasetResolver,
          activeSubmission: ActiveSubmissionResolver
        },
        canActivate: [LayoutSchemaWithFieldsGuard, RegionsDatasetGuard, ActiveSubmissionGuard],
        canDeactivate: [NavigationGuard]
      },
      {
        path: '',
        redirectTo: 'create',
        pathMatch: 'full'
      }
    ],
    canActivate: [UserPermissionListGuard],
    data: {
      featureGuard: { key: globalEntryFeature.CREATE_SUB }
    },
    resolve: {
      userDetail: UserDetailResolver
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SubmissionsFormRoutingModule {}
