import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateContainerComponent } from './containers/create-container/create-container.component';
import { ViewContainerComponent } from './containers/view-container/view-container.component';
import { SelectionContainerComponent } from './containers/selection-container/selection-container.component';
import { SelectionRouteService } from './containers/selection-container/selection-route.service';

import { MatSelectSearchModule } from '@content-platform/reusable-ui/dynamic-form-builder';
import {
  MatFormFieldModule,
  MatSelectModule,
  MatOptionModule,
  MatButtonModule,
  MatDialogModule,
  MatIconModule,
  MatTooltipModule,
  MatChipsModule,
  MatDividerModule
} from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PipesModule } from '@content-platform/pipes';
import { SubmissionsFormRoutingModule } from './submissions-form-routing.module';
import { DynamicFormBuilderModule } from '@content-platform/reusable-ui/dynamic-form-builder';
import { SubmissionFormService } from './services/submission-form.service';
import { NavigationModule } from '@content-platform/navigation';
import { DynamicFormService } from '@content-platform/reusable-ui/dynamic-form-builder';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SchemaResolver } from './resolvers/schema.resolver';
import { UserDetailResolver } from '../../resolvers/user-detail.resolver';
import { ActiveSubmissionResolver } from './resolvers/active-submission.resolver';
import { FileExplorerModule } from '@content-platform/reusable-ui/file-explorer';
import { PermissionsModule } from '@content-platform/application-api';
import { FileUploadProgressModule } from '@content-platform/reusable-ui/file-upload-progress';
import { InterceptorsModule } from '@content-platform/interceptors';
import { ToasterModule } from './../../toaster/toaster.module';
import { DialogComponent } from '../../toaster/toaster.component';
import { CreateNewDropdownComponent } from './create-new-dropdown/create-new-dropdown.component';
import { SubmissionResolver } from './resolvers/submission.resolver';
import { SubmissionPageReducers, effects } from './store';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { guards } from './guards';
import { RegionsDatasetResolver } from './resolvers/regions-dataset.resolver';
import { fieldCallbacks } from './field-callbacks';
import {
  CommentsFieldTextareaComponent,
  FormRegistryFieldData,
  ExtendedFieldFileExplorerComponent,
  FieldSharedUsersComponent,
  FieldSubmissionStatusComponent
} from './custom-fields';
import { ShareSubmissionModule } from '../../share-submission';
import {
  UserThumbnailComponent,
  ReusableUiUserThumbnailModule
} from '@content-platform/reusable-ui/user-thumbnail';
import { DevelopmentModule } from '@content-platform/development';

@NgModule({
  imports: [
    CommonModule,
    StoreModule.forFeature('dynamicforms', SubmissionPageReducers),
    EffectsModule.forFeature(effects),
    SubmissionsFormRoutingModule,
    ReactiveFormsModule,
    DynamicFormBuilderModule.withData({
      customCallbacks: fieldCallbacks,
      customFields: FormRegistryFieldData
    }),
    PermissionsModule,
    FlexLayoutModule,
    MatSelectSearchModule,
    MatFormFieldModule,
    MatSelectModule,
    MatOptionModule,
    MatButtonModule,
    MatDialogModule,
    MatIconModule,
    MatTooltipModule,
    MatDividerModule,
    PipesModule,
    FileExplorerModule,
    FileUploadProgressModule,
    ToasterModule,
    InterceptorsModule,
    ShareSubmissionModule,
    ReusableUiUserThumbnailModule,
    NavigationModule,
    MatChipsModule,
    FormsModule,
    DevelopmentModule
  ],
  declarations: [
    CreateContainerComponent,
    ViewContainerComponent,
    SelectionContainerComponent,
    CreateNewDropdownComponent,
    CommentsFieldTextareaComponent,
    ExtendedFieldFileExplorerComponent,
    FieldSharedUsersComponent,
    FieldSubmissionStatusComponent
  ],
  providers: [
    UserDetailResolver,
    SchemaResolver,
    SubmissionResolver,
    RegionsDatasetResolver,
    ActiveSubmissionResolver,
    SubmissionFormService,
    DynamicFormService,
    ...fieldCallbacks,
    ...guards,
    SelectionRouteService
  ],
  entryComponents: [
    DialogComponent,
    CreateNewDropdownComponent,
    CommentsFieldTextareaComponent,
    ExtendedFieldFileExplorerComponent,
    FieldSharedUsersComponent,
    FieldSubmissionStatusComponent,
    UserThumbnailComponent
  ]
})
export class SubmissionsFormModule {}
