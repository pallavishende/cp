import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {
  MatDatepickerModule,
  MatNativeDateModule,
  MatFormFieldModule,
  MatInputModule,
  MatIconModule,
  MatSelectModule,
  MatOptionModule
} from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FilterDateComponent } from './filter-date.component';
import { FilterDropdownComponent } from '../filter-dropdown/filter-dropdown.component';
import { SubmissionService } from '../../../../services/submission.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Subject } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { DashboardPreferencesService } from '../../../dashboard/dashboard-preferences.service';
import { MockPipe } from '@content-platform/unit-test-helpers';

describe('FilterDateComponent', () => {
  class SubmissionServiceStub {
    searchTermSubject = new Subject<string>();
    sortPagerDetails = {
      sortActive: 'submittedBy',
      sortDirection: 'asc',
      pageIndex: 0,
      pageSize: 30
    };
    getOtherDate(startDate: Date = new Date(), days: number, future: boolean = true): Date {
      let effStartDate = new Date(startDate.getTime());
      const miliSecondsDays = days * 86400000;
      effStartDate = future
        ? new Date(effStartDate.getTime() + miliSecondsDays)
        : new Date(effStartDate.getTime() - miliSecondsDays);
      return effStartDate;
    }
    filterFromDateInput(_sort: string, _page: number, _pageSize: number) {
      console.log('Stub service');
    }
    setFilterStartDate() {
      return 'start date';
    }
    setFilterEndDate() {
      return 'end date';
    }
  }
  const MockActivatedRoute = {
    snapshot: {
      data: {
        userDetail: {
          regions: ['UK', 'BENELUX'],
          canUserViewAll: {
            userInfo: {
              userName: 'xyz@viacomcontractor.com',
              profile: {}
            },
            canViewAll: true
          }
        }
      }
    }
  };
  let component: FilterDateComponent;
  let fixture: ComponentFixture<FilterDateComponent>;
  let submissionService: SubmissionService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FilterDateComponent, FilterDropdownComponent, MockPipe('sort')],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatFormFieldModule,
        MatInputModule,
        MatIconModule,
        BrowserAnimationsModule,
        MatSelectModule,
        MatOptionModule
      ],
      providers: [
        { provide: SubmissionService, useClass: SubmissionServiceStub },
        { provide: ActivatedRoute, useValue: MockActivatedRoute },
        {
          provide: DashboardPreferencesService,
          useValue: { updateEndDate: () => {}, updateStartDate: () => {} }
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilterDateComponent);
    component = fixture.componentInstance;
    submissionService = TestBed.get(SubmissionService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should set the filterEndDate to the start date on selecting a start date', () => {
    // Arrange
    const today: Date = new Date();

    // Act
    component.dateRangeGroup.controls.startDate.patchValue(today);
    fixture.detectChanges();

    // Assert
    expect(component.filterEndDate).toEqual(today);
  });

  it('should set the filterStartDate to end date on selecting a end date', () => {
    // Arrange
    const today: Date = new Date();

    // Act
    component.dateRangeGroup.controls.endDate.patchValue(today);

    // Assert
    expect(component.filterStartDate).toEqual(today);
  });

  it('should show the cancel icon only when start date is defined', () => {
    // Arrange
    const today: Date = new Date();

    // Act
    component.dateRangeGroup.controls.startDate.patchValue(today);

    // Assert
    expect(component.showClearStartDate).not.toBe(false);
  });

  it('should show the cancel icon only when end date is defined', () => {
    // Arrange
    const today: Date = new Date();

    // Act
    component.dateRangeGroup.controls.endDate.patchValue(today);

    // Assert
    expect(component.showClearEndDate).not.toBe(false);
  });

  it('should include the end date in the request', () => {
    // Arrange
    const today: Date = new Date();
    const tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);

    // Act
    component.dateRangeGroup.controls.endDate.patchValue(today);

    // Assert
    expect(submissionService.filterEndDate).not.toEqual(today);
    expect(submissionService.filterEndDate).toEqual(tomorrow);
  });
});
