import { distinctUntilChanged } from 'rxjs/operators';
import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { SubmissionService } from '../../../../services/submission.service';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { DashboardPreferencesService } from '../../../../submission/dashboard/dashboard-preferences.service';
import { MatDatepicker } from '@angular/material';

export const SET_START_FILTER_DATE = 'start filter date';
export const SET_END_FILTER_DATE = 'end filter date';

@Component({
  selector: 'app-filter-date',
  templateUrl: './filter-date.component.html',
  styleUrls: ['./filter-date.component.css']
})
export class FilterDateComponent implements OnInit {
  dateRangeGroup: FormGroup;

  filterStartDate: Date;
  filterEndDate: Date;
  showClearStartDate = false;
  showClearEndDate = false;

  private _defaultStartDate: string;
  private _defaultEndDate: string;

  @ViewChild('fromPicker')
  startdatePicker: MatDatepicker<null>;
  @ViewChild('toPicker')
  enddatePicker: MatDatepicker<null>;
  startYear = 2018;
  /* This is the default year range to be displayed from current year */
  defaultStartYear = 1900;

  /* Selection is restricted from specified year range upto current date*/
  validDatesFilter = (d: Date): boolean => {
    const year = d.getFullYear();
    return year >= this.defaultStartYear && d < new Date() ? true : false;
  };

  @Input()
  set defaultStartDate(value: string) {
    if (
      value &&
      value !== '' &&
      this._defaultStartDate !== value &&
      this.dateRangeGroup &&
      this.dateRangeGroup.get('startDate')
    ) {
      const sDate = new Date(value);
      this.dateRangeGroup.get('startDate').setValue(sDate);
      this.startDateValueChange(sDate);
    }
    this._defaultStartDate = value;
  }

  get defaultStartDate(): string {
    return this._defaultStartDate;
  }

  @Input()
  set defaultEndDate(value: string) {
    if (
      value &&
      value !== '' &&
      this._defaultEndDate !== value &&
      this.dateRangeGroup &&
      this.dateRangeGroup.get('endDate')
    ) {
      const eDate = new Date(value);
      this.dateRangeGroup.get('endDate').setValue(eDate);
      this.endDateValueChange(eDate);
    }
    this._defaultEndDate = value;
  }

  get defaultEndDate(): string {
    return this._defaultEndDate;
  }

  constructor(
    private submissionService: SubmissionService,
    private fb: FormBuilder,
    public dashboardPref: DashboardPreferencesService
  ) {
    this.dateRangeGroup = this.fb.group({
      startDate: new FormControl(''),
      endDate: new FormControl('')
    });
  }
  clearStartDate(event: MouseEvent) {
    this.dateRangeGroup.controls['startDate'].reset();
    event.stopPropagation();
    this.showClearStartDate = false;
    this.filterEndDate = undefined;
  }

  clearEndDate(event: MouseEvent) {
    this.dateRangeGroup.controls['endDate'].reset();
    event.stopPropagation();
    this.showClearEndDate = false;
    this.filterStartDate = undefined;
  }

  ngOnInit() {
    this.dateRangeGroup.controls.startDate.valueChanges
      .pipe(distinctUntilChanged())
      .subscribe((dateValue: Date) => {
        const sDate = dateValue ? dateValue.toDateString() : '';
        if (this._defaultStartDate !== sDate) {
          this._defaultStartDate = sDate;
          this.startDateValueChange(dateValue);
          this.dashboardPref.updateStartDate(this.defaultStartDate);
        }
      });

    this.dateRangeGroup.controls.endDate.valueChanges
      .pipe(distinctUntilChanged())
      .subscribe((dateValue: Date) => {
        const eDate = dateValue ? dateValue.toDateString() : '';
        if (this._defaultEndDate !== eDate) {
          this._defaultEndDate = eDate;
          this.endDateValueChange(dateValue);
          this.dashboardPref.updateEndDate(this.defaultEndDate);
        }
      });
  }

  private startDateValueChange(dateValue: Date) {
    if (dateValue) {
      this.submissionService.filterStartDate = dateValue;
      this.filterEndDate = dateValue;
      this.showClearStartDate = true;
    } else {
      this.submissionService.filterStartDate = undefined;
      this.showClearStartDate = false;
    }
    this.submissionService.searchTermSubject.next(SET_START_FILTER_DATE);
  }

  private endDateValueChange(dateValue: Date) {
    if (dateValue) {
      // Add a day to the end date so everything on that actual day is included
      const dateIncludingEnd = new Date(dateValue.valueOf());
      dateIncludingEnd.setDate(dateValue.getDate() + 1);
      this.submissionService.filterEndDate = dateIncludingEnd;
      this.filterStartDate = dateValue;
      this.showClearEndDate = true;
    } else {
      this.submissionService.filterEndDate = undefined;
      this.showClearEndDate = false;
    }
    this.submissionService.searchTermSubject.next(SET_END_FILTER_DATE);
  }

  openDatePicker(value) {
    if (value === 'fromPicker') {
      this.startdatePicker.open();
    } else if (value === 'toPicker') {
      this.enddatePicker.open();
    }
  }

  getCurrentYear(): number {
    return new Date().getFullYear();
  }
}
