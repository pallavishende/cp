import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FilterInputComponent } from '../filter-input/filter-input.component';
import { FilterDateComponent } from '../filter-date/filter-date.component';
import { FilterDropdownComponent } from './filter-dropdown.component';
import {
  MatNativeDateModule,
  MatFormFieldModule,
  MatSelectModule,
  MatIconModule,
  MatDatepickerModule,
  MatInputModule,
  MatOptionModule
} from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import * as fromStore from '../../../dashboard/store';
import { ActivatedRoute } from '@angular/router';
import { StoreModule, combineReducers } from '@ngrx/store';
import { MockPipe } from '@content-platform/unit-test-helpers';

describe('FilterDropdownComponent', () => {
  let component: FilterDropdownComponent;
  let fixture: ComponentFixture<FilterDropdownComponent>;

  const MockActivatedRoute = {
    snapshot: {
      data: {
        userDetail: {
          regions: ['UK', 'BENELUX'],
          canUserViewAll: {
            userInfo: {
              userName: 'xyz@viacomcontractor.com',
              profile: {}
            },
            canViewAll: true
          }
        }
      }
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        FilterInputComponent,
        FilterDateComponent,
        FilterDropdownComponent,
        MockPipe('sort')
      ],
      imports: [
        BrowserAnimationsModule,
        FormsModule,
        ReactiveFormsModule,
        MatNativeDateModule,
        MatFormFieldModule,
        MatSelectModule,
        MatIconModule,
        MatDatepickerModule,
        MatInputModule,
        MatOptionModule,
        StoreModule.forRoot({ dashboard: combineReducers(fromStore.dashboardReducer) })
      ],
      providers: [{ provide: ActivatedRoute, useValue: MockActivatedRoute }]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilterDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });
  it('should call applyRegionFilter method on change event event', fakeAsync(() => {
    spyOn(component, 'applyRegionFilter');
    fixture = TestBed.createComponent(FilterDropdownComponent);
    fixture.componentInstance.regionSelected.setValue(['UK', 'ASIA']);
    fixture.detectChanges();
    dispatchEvent(new Event('change'));
    tick(300);
    return fixture.whenStable();
  }));
});
