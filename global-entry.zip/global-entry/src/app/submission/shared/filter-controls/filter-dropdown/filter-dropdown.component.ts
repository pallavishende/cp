import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { distinctUntilChanged } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { PermissionMetadata } from '@content-platform/application-api';
import { Store, select } from '@ngrx/store';
import { DashboardState, SetFilteredRegions, getFilteredRegions } from '../../../dashboard/store';

export const SET_REGION_SELECTED = 'set selected region';

@Component({
  selector: 'app-filter-dropdown',
  templateUrl: './filter-dropdown.component.html',
  styleUrls: ['./filter-dropdown.component.css']
})
export class FilterDropdownComponent implements OnInit, OnDestroy {
  regionSelected = new FormControl();
  filterRegionFormGroup: FormGroup;
  loggedInUserRegions: PermissionMetadata[];
  showRegionSelect: Boolean;
  selectedUserRegion: string[];
  filteredRegion: Subscription;
  selectedRegionLabel: string;

  constructor(
    private fb: FormBuilder,
    private actRoute: ActivatedRoute,
    private store: Store<DashboardState>
  ) {}

  ngOnInit() {
    this.filterRegionFormGroup = this.fb.group({
      regionSelected: new FormControl()
    });
    this.loggedInUserRegions = this.actRoute.snapshot.data.userDetail.regions;
    // Show region dropdown only if logged-in user has regions more than one.
    this.showRegionSelect = this.loggedInUserRegions.length > 1 ? true : false;
    // Set the selected dropdown value to filter the submissions
    this.filteredRegion = this.filterRegionFormGroup.controls.regionSelected.valueChanges
      .pipe(distinctUntilChanged())
      .subscribe(filterValue => {
        this.applyRegionFilter(filterValue);
      });
    this.store.pipe(select(getFilteredRegions)).subscribe(v => {
      if (v.length > 0 && v[0]) {
        this.filterRegionFormGroup.controls.regionSelected.setValue(v[0]);
        this.selectedRegionLabel = this.loggedInUserRegions.filter(
          d => d.name === v[0]
        )[0].description;
      }
    });
  }
  applyRegionFilter(filterValue: string) {
    if (filterValue) {
      this.selectedRegionLabel = filterValue;
      this.selectedUserRegion = [filterValue];
    } else {
      this.selectedRegionLabel = '';
      this.selectedUserRegion = [];
    }
    this.store.dispatch(new SetFilteredRegions(this.selectedUserRegion));
  }
  clearRegion() {
    this.filterRegionFormGroup.controls.regionSelected.reset();
  }
  ngOnDestroy() {
    if (this.filteredRegion) {
      this.filteredRegion.unsubscribe();
    }
  }
}
