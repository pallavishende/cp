import { of as observableOf, Subject } from 'rxjs';
import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FilterInputComponent } from './filter-input.component';
import { SubmissionService } from '../../../../services/submission.service';
import { PageSortInput } from '../../../../models';
import { FilterDateComponent } from '../filter-date/filter-date.component';
import { FilterDropdownComponent } from '../filter-dropdown/filter-dropdown.component';
import { ActivatedRoute } from '@angular/router';
import {
  MatDatepickerModule,
  MatNativeDateModule,
  MatFormFieldModule,
  MatInputModule,
  MatIconModule,
  MatSelectModule,
  MatOptionModule
} from '@angular/material';
import { MockPipe } from '@content-platform/unit-test-helpers';
describe('FilterInputComponent', () => {
  let component: FilterInputComponent;
  let fixture: ComponentFixture<FilterInputComponent>;
  let submissionService: SubmissionService;
  const pageSortInputValue: PageSortInput = { type: 'filterInput', pageValue: 0 };
  const MockActivatedRoute = {
    snapshot: {
      data: {
        userDetail: {
          regions: ['UK', 'BENELUX'],
          canUserViewAll: {
            userInfo: {
              userName: 'xyz@viacomcontractor.com',
              profile: {}
            },
            canViewAll: true
          }
        }
      }
    }
  };
  beforeEach(async(() => {
    class SubmissionServiceStub {
      private pageSortSubject = new Subject<PageSortInput>();
      setPageSortInput(pageSortInput: PageSortInput) {
        return this.pageSortSubject.next(pageSortInput);
      }
      getPageSortInput() {
        return observableOf(pageSortInputValue);
      }
    }
    TestBed.configureTestingModule({
      declarations: [
        FilterInputComponent,
        FilterDateComponent,
        FilterDropdownComponent,
        MockPipe('sort')
      ],
      imports: [
        BrowserAnimationsModule,
        FormsModule,
        ReactiveFormsModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatFormFieldModule,
        MatInputModule,
        MatIconModule,
        MatSelectModule,
        MatOptionModule
      ],
      providers: [
        { provide: SubmissionService, useClass: SubmissionServiceStub },
        { provide: ActivatedRoute, useValue: MockActivatedRoute }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilterInputComponent);
    component = fixture.componentInstance;
    submissionService = fixture.debugElement.injector.get(SubmissionService);
    fixture.detectChanges();
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });
  it('should call applyFilter method on keyup event', fakeAsync(() => {
    spyOn(component, 'applyFilter');
    fixture = TestBed.createComponent(FilterInputComponent);
    const input = fixture.debugElement.query(By.css('input[formControlName=filterText]'));
    fixture.detectChanges();
    input.nativeElement.value = 'loser';
    dispatchEvent(new Event('input'));
    tick(300);
    return fixture.whenStable();
  }));

  it('should call setPageSortInput method on invoking applyFilter method', fakeAsync(() => {
    spyOn(submissionService, 'setPageSortInput');
    const input = fixture.debugElement.query(By.css('input[formControlName=filterText]'));
    fixture.detectChanges();
    input.nativeElement.value = 'loser';
    dispatchEvent(new Event('input'));
    tick(300);
    return fixture.whenStable();
  }));
});
