import { distinctUntilChanged, debounceTime, filter } from 'rxjs/operators';
import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { MatInput } from '@angular/material';
import { SubmissionService } from '../../../../services/submission.service';
import { Subscription } from 'rxjs';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

export const START_FILTER_TEXT = 'start text filter';

@Component({
  selector: 'app-filter-input',
  templateUrl: './filter-input.component.html',
  styleUrls: ['./filter-input.component.css']
})
export class FilterInputComponent implements OnInit, OnDestroy {
  @ViewChild(MatInput)
  input: MatInput;
  filterFormGroup: FormGroup;
  filterValues: Subscription;
  showClearFilter = false;
  loggedInUserRegions: string[];
  toggleFilterInputSpace: Boolean;

  constructor(
    private submissionService: SubmissionService,
    private fb: FormBuilder,
    private actRoute: ActivatedRoute
  ) {}

  clearFilter() {
    this.filterFormGroup.controls.filterText.setValue(undefined);
  }

  applyFilter(filterInput) {
    const filterValue = filterInput ? filterInput.trim().toLowerCase() : undefined;
    this.submissionService.isTitleFilter = true;
    this.submissionService.isStatusFilter = false;
    this.submissionService.filterMusicDataValue = filterValue;
    this.submissionService.searchTermSubject.next(START_FILTER_TEXT);
  }

  ngOnInit() {
    this.loggedInUserRegions = this.actRoute.snapshot.data.userDetail.regions;
    this.toggleFilterInputSpace = this.loggedInUserRegions.length > 1 ? true : false;
    this.filterFormGroup = this.fb.group({
      filterText: new FormControl()
    });
    this.filterValues = this.filterFormGroup.controls.filterText.valueChanges
      .pipe(
        filter(val => (val ? val.trim() !== '' : true)),
        debounceTime(400),
        distinctUntilChanged()
      )
      .subscribe(filterInput => {
        // toggling the clear icon
        this.showClearFilter = !!filterInput;

        this.applyFilter(filterInput);
      });
  }

  ngOnDestroy() {
    if (this.filterValues) {
      this.filterValues.unsubscribe();
    }
  }
}
