import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { VideoPreviewComponent } from './video-preview.component';
import { By } from '@angular/platform-browser';
import { APP_BASE_HREF } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FileUploadModule } from 'ng2-file-upload';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  MatInputModule,
  MatButtonModule,
  MatIconModule,
  MAT_DIALOG_DATA,
  MatDialogRef,
  MatProgressSpinnerModule
} from '@angular/material';
import { SubmissionService } from '../../../services/submission.service';
import { fromAuth } from '@content-platform/auth';
import { StoreModule, combineReducers } from '@ngrx/store';
import { MockDirective, MockComponent } from '@content-platform/unit-test-helpers';
import { MockLocalStorageData } from '../../../mockLocalStorageData';
import { of } from 'rxjs';
import { LoggerService } from '@content-platform/logging';
import { SubmissionApiReducers } from '@content-platform/submissions-api';

describe('VideoPreviewComponent', () => {
  let component: VideoPreviewComponent;
  let fixture: ComponentFixture<VideoPreviewComponent>;
  class MockSubmissionService {
    getSubmissionById(submissionId: string) {
      submissionId = submissionId;
      return of(new MockLocalStorageData().MOCK_DATA[0]);
    }
    getUserComments(id: string) {
      id = id;
      return of([]);
    }
    getAuthUserInfo() {
      return of({});
    }
  }
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        VideoPreviewComponent,
        MockDirective({ selector: '[appIfFeatureAsync]', inputs: ['appIfFeatureAsync'] }),
        MockComponent({ selector: 'app-video-player', inputs: ['videoUrl', 'videoType'] })
      ],
      imports: [
        HttpClientModule,
        ReactiveFormsModule,
        MatProgressSpinnerModule,
        MatButtonModule,
        MatInputModule,
        FileUploadModule,
        MatIconModule,
        BrowserAnimationsModule,
        StoreModule.forRoot({
          auth: fromAuth.authReducer,
          submissionApi: combineReducers(SubmissionApiReducers)
        })
      ],
      providers: [
        { provide: APP_BASE_HREF, useValue: '/' },
        { provide: MAT_DIALOG_DATA, useValue: {} },
        { provide: MatDialogRef, useValue: {} },
        { provide: SubmissionService, useClass: MockSubmissionService },
        {
          provide: LoggerService,
          useValue: {
            instance: () => {
              return { log: () => {} };
            }
          }
        }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(VideoPreviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create the component', async(() => {
    expect(component).toBeTruthy();
  }));
  it('Should have Close icon in Review & Approve Modal', async(() => {
    component.loading = false;
    fixture.detectChanges();
    const closeButtonElement = fixture.debugElement.query(By.css('#modal-close-icon'));
    expect(closeButtonElement.attributes.id).toBe('modal-close-icon');
  }));
  it('should close the Review & Approve Modal on click of the close button', async(() => {
    component.loading = false;
    fixture.detectChanges();
    const closeDialog = spyOn(component, 'closeDialog');
    const closeButton = fixture.debugElement.query(By.css('#modal-close-icon'));
    closeButton.triggerEventHandler('click', null);
    fixture.whenStable().then(() => {
      expect(closeDialog).toHaveBeenCalled();
    });
  }));
});
