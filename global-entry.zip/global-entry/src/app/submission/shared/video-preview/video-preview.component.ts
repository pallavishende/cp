import { Component, Inject, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { LoggerService } from '@content-platform/logging';
import {
  commentSelectors,
  commentActions,
  submissionSelectors,
  submissionActions,
  Submission
} from '@content-platform/submissions-api';
import { Store, select } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { map, filter, throttleTime, distinctUntilChanged } from 'rxjs/operators';
import * as fromStore from '../../../submission/form/store';
import { CommentSchema, CommentsListSchema } from '../../../models';
import { SubmissionService } from '../../../services/submission.service';
import { VideoPlayerEvent } from '@content-platform/reusable-ui/video-player';

@Component({
  selector: 'app-video-preview',
  templateUrl: './video-preview.component.html',
  styleUrls: ['./video-preview.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class VideoPreviewComponent implements OnInit, OnDestroy {
  loadingSpinnerSubscription: Subscription;
  detailSubmission$: Observable<Submission>;
  showApproveReject$: Observable<boolean>;
  showButtons = true;
  videoUrl;
  videoType;
  feature;
  // will be replaced by proxy URLS
  mockType = 'application/x-mpegURL';

  authUser: adal.User;
  authUserSubscription$$: Subscription;
  postCommentSubscription$$: Subscription;
  userCommentSubscription$$: Subscription;
  newCommentSubscription$$: Subscription;
  videoFieldNotes: FormControl;
  reservedComment: string;
  newComment: string;
  private logger: LoggerService;
  loading = true;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private submission_service: SubmissionService,
    private store: Store<fromStore.SubmissionPageState>,
    public dialogRef: MatDialogRef<VideoPreviewComponent>,
    loggerService: LoggerService
  ) {
    this.store.dispatch(new submissionActions.LoadById({ id: this.data.id }));
    this.logger = loggerService.instance('VideoPreviewDialog');
  }

  ngOnInit() {
    // getting Submission record data

    this.detailSubmission$ = this.store.pipe(
      select(submissionSelectors.getSubmissionById(this.data.id))
    );
    // show/hide loading spinner
    this.loadingSpinnerSubscription = this.detailSubmission$
      .pipe(
        throttleTime(500, undefined, { leading: true, trailing: true }),
        distinctUntilChanged()
      )
      .subscribe(res => {
        res ? (this.loading = false) : (this.loading = true);
      });
    // show/hide approve reject buttons
    this.showApproveReject$ = this.detailSubmission$.pipe(
      map((res: Submission) => {
        console.log('res.reviewed', res.reviewed);
        if (
          res.submissionStatus.description !== 'Pending Approval' ||
          (res.submissionStatus.description === 'Pending Approval' && res.reviewed)
        ) {
          // disable notes section
          this.videoFieldNotes.disable();
        }
        return res.submissionStatus.description === 'Pending Approval' && !res.reviewed;
      })
    );

    // get logged in user
    this.authUserSubscription$$ = this.submission_service.getAuthUserInfo().subscribe(userData => {
      this.authUser = userData;
    });

    // Initialising Form Control
    this.videoFieldNotes = new FormControl();

    // getting user entered note
    this.newCommentSubscription$$ = this.videoFieldNotes.valueChanges.subscribe(
      value => (this.newComment = value)
    );

    this.userCommentSubscription$$ = this.store
      .pipe(
        select(commentSelectors.getCommentsById(this.data.id)),
        filter(res => !!res)
      )
      .subscribe((res: CommentsListSchema[]) => {
        const allComments = res.map(comment => comment.commentText).join('\n');
        this.videoFieldNotes.setValue(allComments);
      });
  }
  closeDialog() {
    this.dialogRef.close();
  }

  getStatusClasses(submissionStatus) {
    switch (submissionStatus) {
      case 'INGESTCOMPLETED':
        return 'completeingest';
      case 'ARCHIVED':
        return 'archived';
      case 'REJECTED':
        return 'rejected';
      case 'PENDINGAPPROVAL':
        return 'pendingapproval';
      case 'PENDINGQC':
        return 'pendingqc';
      case 'AWAITINGELEMENTS':
        return 'awaitingelements';
    }
  }

  onFocus() {
    // Reserved the form value when its pristine
    this.reservedComment = this.submission_service.reserveOnPristine(this.videoFieldNotes);
  }

  onBlur() {
    this.submission_service.clearOnPristine(this.videoFieldNotes, this.reservedComment);
  }
  // Status of Reject button
  rejectStatus() {
    return this.submission_service.showRejectButton(this.videoFieldNotes);
  }

  get checkNotesValid(): boolean {
    return (
      this.videoFieldNotes.value === '' ||
      this.videoFieldNotes.value === null ||
      !this.videoFieldNotes.value.replace(/\s/g, '').length
    );
  }

  onApproveClick(actionCode: string) {
    const metadataOnly = false;
    const submissionId = this.data.id;
    const commentText = this.newComment;
    const reviewedBy = `${this.authUser.profile.given_name} ${this.authUser.profile.family_name}`;
    const reviewedUserEmail = this.authUser.userName;
    const comment: CommentSchema = {
      commentText,
      reviewedBy,
      reviewedUserEmail,
      actionCode,
      metadataOnly
    };

    this.store.dispatch(
      new commentActions.Create({
        comment,
        submissionId
      })
    );

    this.postCommentSubscription$$ = this.store
      .pipe(select(commentSelectors.isCommentCreated(submissionId)))
      .subscribe(created => {
        if (created) {
          this.videoFieldNotes.reset();
          this.closeDialog();
        }
      });

    // disable approve/reject on view screen

    this.submission_service.commentsSubject$$.next(true);

    switch (actionCode) {
      case 'APPROVED': {
        this.logger.log(`Approved Submission`, { submissionId: this.data.id });
        break;
      }
      case 'REJECTED': {
        this.logger.log(`Rejected Submission`, { submissionId: this.data.id });
        break;
      }
    }
  }

  openToaster(msg) {
    this.submission_service.openToasterNotification(msg);
  }

  onVideoPlayerEvent(event: VideoPlayerEvent) {
    switch (event) {
      case 'play': {
        this.logger.log(`Playing Video`, { submissionId: this.data.id });
        break;
      }
      case 'pause': {
        this.logger.log(`Pausing Video`, { submissionId: this.data.id });
        break;
      }
    }
  }

  ngOnDestroy() {
    this.authUserSubscription$$.unsubscribe();
    this.newCommentSubscription$$.unsubscribe();
    this.userCommentSubscription$$.unsubscribe();
  }

  restrictReject() {
    this.videoFieldNotes.setValidators([Validators.required]);
    this.videoFieldNotes.markAsTouched();
    this.videoFieldNotes.enable();
  }

  onReject() {
    if (this.checkNotesValid && this.videoFieldNotes.enabled) {
      this.restrictReject();
    } else if (!this.checkNotesValid) {
      this.onApproveClick('REJECTED');
    }
  }
}
