import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TechnicalSpecificationsComponent } from './technical-specifications/technical-specifications.component';
import { UserPermissionListGuard } from '@content-platform/application-api';

const TECHSPECIFICATIONS_ROUTES: Routes = [
  {
    path: '',
    component: TechnicalSpecificationsComponent,
    canActivate: [UserPermissionListGuard]
  }
];

@NgModule({
  imports: [CommonModule, RouterModule.forChild(TECHSPECIFICATIONS_ROUTES)],
  exports: [RouterModule]
})
export class TechSpecificationsRoutingModule {}
