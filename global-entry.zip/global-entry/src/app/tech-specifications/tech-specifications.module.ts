import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { TechnicalSpecificationsComponent } from './technical-specifications/technical-specifications.component';
import { TechSpecificationsRoutingModule } from './tech-specifications-routing.module';
import { MatCardModule } from '@angular/material/card';

@NgModule({
  declarations: [TechnicalSpecificationsComponent],
  imports: [CommonModule, FlexLayoutModule, TechSpecificationsRoutingModule, MatCardModule]
})
export class TechSpecificationsModule {}
