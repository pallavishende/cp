import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MaterialMockModule } from '@content-platform/unit-test-helpers';

import { TechnicalSpecificationsComponent } from './technical-specifications.component';

describe('TechnicalSpecificationsComponent', () => {
  let component: TechnicalSpecificationsComponent;
  let fixture: ComponentFixture<TechnicalSpecificationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TechnicalSpecificationsComponent],
      imports: [MaterialMockModule]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TechnicalSpecificationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
