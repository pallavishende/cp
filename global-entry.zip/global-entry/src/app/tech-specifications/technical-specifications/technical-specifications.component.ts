import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technical-specifications',
  templateUrl: './technical-specifications.component.html',
  styleUrls: ['./technical-specifications.component.scss']
})
export class TechnicalSpecificationsComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
