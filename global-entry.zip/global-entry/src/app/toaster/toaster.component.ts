import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { ToasterMessageEnum } from '../../constants/toaster-enum';

@Component({
  selector: 'app-dialog-component',
  templateUrl: './toaster.component.html',
  styleUrls: ['./toaster.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DialogComponent {
  toasterEnum = ToasterMessageEnum;

  constructor(
    public dialogRef: MatDialogRef<DialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private router: Router
  ) {
    this.dialogRef.disableClose = true;
  }

  yes() {
    this.dialogRef.close(this.toasterEnum.LEAVE_PAGE);
  }

  no() {
    this.dialogRef.close(this.toasterEnum.STAY_PAGE);
  }

  routeToDashboard() {
    this.dialogRef.close(this.toasterEnum.LEAVE_PAGE);
    this.router.navigate(['/dashboard']);
  }

  createAnotherSubmission() {
    this.dialogRef.close(this.toasterEnum.CREATE_ANOTHER_SUBMISSION);
    this.router.navigate(['/submission']);
  }
}
