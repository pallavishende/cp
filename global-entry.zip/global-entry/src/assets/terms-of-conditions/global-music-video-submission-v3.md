**Viacom Music Video Submission Terms and Conditions**

**Viacom** means Viacom Media Networks and its parents, subsidiaries, affiliates and related body corporates worldwide (&quot;**VMN**&quot;).

**Record Label** means the Record Label listed in the Submission Form or the Record Label&#39;s distributing label or, in the case of an unsigned artist the artist or owner of the music video (&quot;**Label**&quot;).

By submitting the Music Video and accepting these Terms and Conditions, the Label, acknowledges and agrees that:

1. The Music Video is submitted pursuant to:

a) the terms of a Promotional Video Clip Agreement between VMN and Label ( **Sony, UMG or Warner** ) or, where there is no applicable Promotional Video Clip Agreement, the terms of a Music Video Licensing Organization Agreement between VMN and the music video licensing organization of which the Label is a member or member of an affiliate (eg., **VPL, AIR** ) (collectively &quot;**VMN Music Video Agreement(s)**&quot;); or

b) If such VMN Music Video Agreement(s) are not currently in operation or do not apply then Label hereby grants VMN and its licensees a non-exclusive licence to reproduce, communicate and otherwise use the Music Video submitted and/or excerpts thereof (including audio, visual, and/or audio-visual) for the term of the copyright and any other intellectual property rights in the Music Video, in the Territory selected in the submission form as part of VMN&#39;s worldwide programming services in any media including without limitation on VMN owned and operated websites (and other apps and/or platforms) unless otherwise stated in the submission form.

2. Provided such reformatting does not adversely affect the quality of the Music Video, Label agrees that VMN may reformat the Music Video for the purposes of (without limitation):

a) complying with local censorship and/or classification regulations;

b) communication by way of VMN&#39;s websites and other apps and/or platforms; and

c) programming scheduling;

3. VMN may place advertising in and adjacent to, as well as seek sponsorship of, any programming or programming service within which the Music Video may be included without seeking further permission from Label.

4. Label warrants and represents that:

a) the Music Video is free and clear for reproduction and communication by VMN in accordance with these Terms and Conditions and does not or will not infringe the rights (including without limitation copyright) of any third party;

b) all information in the Submission Form accompanying the Music Video is accurate, complete and true; and

c) it has obtained all necessary licenses, consents, releases and permissions necessary to allow the exhibition, licensing and distribution of the Music Video and any music contained in it from all relevant third parties including without limitation performers, composers, publishers and any other copyright holder.

5. Label indemnifies and will defend VMN from and against any loss, cost, damage, liability, claim or expense arising from any breach or alleged breach of the warranties contained herein.

6. Where any conflict or discrepancy arises between these Terms and Conditions and the terms of a VMN Music Video Agreement(s), the terms of the VMN Music Video Agreement(s) will prevail.

7. The person submitting the Music Video is authorized by Label to do so.