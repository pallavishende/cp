**Last Modified:** **03/12/2018**

IMPORTANT! PLEASE READ CAREFULLY. THIS IS A LEGALLY BINDING CONTRACT. BY CLICKING THE "I AGREE" BUTTON ON THE LOGIN PAGE OR OTHERWISE USING THE WEBSITE, YOU AGREE TO ALL OF THESE TERMS. IF YOU DISAGREE WITH ANY OF THESE TERMS, OR DO NOT AGREE TO BE BOUND BY ALL OF THESE TERMS, DO NOT CLICK "I AGREE" OR USE THIS WEBSITE, AS ANY SUCH USE WILL BE UNAUTHORIZED.

This website or application (individually and collectively, the "**Website**") is owned and operated by Viacom International Inc. (collectively, "**Company**"or "**we**", "**us**", or "**our**"). Your use of this Website is subject to the following terms and conditions of use (the "**Terms**"). You agree to these Terms by accessing this Website and/or by accepting any information or content from this Website.

Except for the terms and conditions set forth in the paragraph labeled "Location – Choice of Law, Submission to Jurisdiction and Venue", we reserve the right in our sole discretion to modify, alter or otherwise change these Terms.  If we make any changes to these Terms, you agree to be bound by such changes. We will post changes here, so check back periodically. Your continued use of this Website after the posting of any change in the Terms constitutes your acceptance of such changes. In the event we make a material change to these Terms, to be determined in our sole and absolute discretion, we may require you to go through the entire acceptance process with the revised Terms. In addition, please also review the Website's [Privacy Policy](http://www.viacom.com/about/pages/privacypolicy.aspx).



This Website is a repository of Company's and its Affiliates' content and/or data and has been created solely to assist you in the creation of materials for Company (the "**Permitted Use**").  The Website is for use only by Company and Company-authorized and approved licensees, vendors, agents and service providers and their employees (each, an "**Authorized User**"). By accessing this Website, you assume the risk that the information on this Website may be incomplete, inaccurate, out of date, or may not meet your needs and requirements. You may access and use this Website only if you are an Authorized User.

**THIS WEBSITE IS NOT INTENDED FOR VIEWING OR ACCESS BY ANYONE OTHER THAN AUTHORIZED USERS.**

Your use of the Website may also be governed by a contract between Company or its Affiliates and you or your employer ("**Agreement**"). As used in these Terms, "**Affiliates**" means our related companies and subsidiaries. In the event of a conflict between these Terms and the Agreement, the Agreement will control.

**Password and Access Rights**

The Website's practices governing your personal information are disclosed in its [Privacy Policy](http://www.viacom.com/about/pages/privacypolicy.aspx). As an Authorized User, you understand and agree that you are responsible for all activities that occur under your account, and agree that you will not sell, transfer or assign your access rights. You also understand that Company and its authorized agents will be entitled to monitor your account and, at its discretion, require you to change it. You understand that you are responsible for maintaining the confidentiality of your account and password and for restricting access to your computer so that others may not access the Website using your user name or password in whole or in part. You will notify Company immediately if you believe your password has been compromised or security of your account is threatened in any way.

When you submit your information to become an Authorized User you represent and warrant to Company that: (i) you are using your actual identity and the information you provide to Company is true, complete, correct and current, and that you will maintain and update that information as circumstances require; (ii) you have the capacity to enter into these Terms (i.e., you are of sufficient legal age and mental capacity); (iii) you are otherwise entitled to be legally bound in contract.

When you submit your information to become an Authorized User you make a continuing covenant to Company that: (i) at all times in connection with your use of the Website you will be acting solely for the benefit of Company as one of Company's licensees, vendors, agents or service providers. Company reserves the right to terminate or suspend your account and deny or refuse access to the Website to you or any person at any time.

**Ownership of Material**

This Website and all of the content it contains, or may in the future contain, such as Company motion pictures, television shows, and other content, articles, opinions, other text, directories, guides, photographs, key-art, illustrations, images, video and audio clips and advertising copy, as well as the trademarks, logos, domain names, trade names, service marks and any and all copyrightable material (including source and object code) and/or any other form of intellectual property (collectively, the "**Material**") are owned by or licensed to Company or other authorized third parties and are protected from unauthorized use, copying and dissemination by copyright, trademark, publicity and other laws and by international treaties. Nothing contained in these Terms or on the Website should be construed as granting, by implication, estoppel or otherwise, any license or right to use any Material in any manner other than in support of the Permitted Use, without the prior written consent of Company or such third party that may own the Material or intellectual property displayed on the Website. **UNAUTHORIZED USE, COPYING, REPRODUCTION, MODIFICATION, PUBLICATION, REPUBLICATION, UPLOADING, FRAMING, DOWNLOADING, POSTING, TRANSMITTING, DISTRIBUTING, DUPLICATING OR ANY OTHER MISUSE OF ANY OF THE MATERIAL IS STRICTLY PROHIBITED.** You agree not to use the Material for any unlawful purposes and not to violate Company's rights or the rights of others. You are advised that Company will aggressively enforce its rights to the fullest extent of the law. Company may add, change, discontinue, remove or suspend any of the Material at any time, without notice and without liability.

**License to View Material**

Subject to these Terms, we grant to you a limited, personal, non-exclusive, non-transferable, non-sublicenseable and revocable license to use the Website for the Permitted Use. Your use of the Website and the Material shall be non-commercial and not for resale or further distribution.

Company retains all right, title, and interest in and to the Website and the Material not expressly granted to you in the limited license above.

The license granted herein expressly forbids you touse, view, post, share or distribute any content on the Website with any third party except in connection with the Permitted Use.  You may not download any content from the Website to any device other than your device use to provide services for Company.  You may not download or copy any content from the Website to your home computer, personal laptop or other device. You may not share or watch any content on the site with friends, family or other third parties.

In the event you are granted the ability to download any Material, you shall at all times keep the Material in a secure location or computer server, taking all security measures to ensure that the Material is not copied, stolen, transmitted or otherwise used, viewed or displayed in an unauthorized manner or by entities/persons not specifically authorized by Company. If you cease to be an Authorized User for any reason, you must destroy any Materials in your possession, whether in electronic or printed format, unless instructed otherwise in writing by Company.

**Disclaimers / Limitations on Liability**

YOU UNDERSTAND AND AGREE THAT THIS WEBSITE AND ALL MATERIAL AND INTELLECTUAL PROPERTY CONTAINED ON IT ARE DISTRIBUTED "AS IS" "AS AVAILABLE" "WITH ALL FAULTS" AND WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, WARRANTIES OF TITLE OR IMPLIED WARRANTIES OF MERCHANTABILITY, NON-INFRINGEMENT OR FITNESS FOR A PARTICULAR PURPOSE OR THOSE ARISING BY STATUTE OR OTHERWISE IN LAW OR FROM A COURSE OF DEALING OR USAGE OF TRADE.SOME JURISDICTIONS DO NOT PERMIT THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSION MAY NOT APPLY TO YOU. YOU MAY HAVE OTHER RIGHTS WHICH VARY BY JURISDICTION.

YOU AGREE THAT COMPANY AND ITS PARENTS, AFFILIATES, SUBSIDIARIES, LICENSORS AND ASSIGNS, AND EACH OF THEIR RESPECTIVE EMPLOYEES, OFFICERS AND DIRECTORS (COLLECTIVELY, THE "**RELEASED PARTIES**"), ARE NOT LIABLE TO YOU FOR DAMAGES OF ANY KIND, WHETHER BASED IN TORT, CONTRACT, STRICT LIABILITY OR OTHERWISE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT, SPECIAL, INDIRECT, INCIDENTAL, CONSEQUENTIAL OR PUNITIVE DAMAGES ARISING OR RESULTING IN ANY WAY FROM OR IN CONNECTION WITH THIS WEBSITE, THE MATERIAL, OR ANY ERRORS OR OMISSIONS IN ITS TECHNICAL OPERATION OR THE MATERIAL, EVEN IF WE HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES, WHETHER CAUSED IN WHOLE OR IN PART BY NEGLIGENCE, ACTS OF GOD, TELECOMMUNICATIONS FAILURE, THEFT OR DESTRUCTION OF, OR UNAUTHORIZED ACCESS TO, THIS WEBSITE OR ITS RELATED INFORMATION OR PROGRAMS.NOTWITHSTANDING ANY OTHER PROVISION IN THESE TERMS, IN NO EVENT AND UNDER NO CIRCUMSTANCES WILL THE RELEASED PARTIES BE LIABLE TO YOU FOR ANY REASON OR ANY CAUSE OF ACTION WHATSOEVER IN AN AMOUNT GREATER THAN FIFTY DOLLARS ($50). SOME JURISDICTIONS DO NOT ALLOW THE LIMITATION OR EXCLUSION OF CERTAIN WARRANTIES AND CONDITIONS, AND/OR THE DISCLAIMER OF SOME TYPES OF DAMAGES, SO SOME OF THE ABOVE MIGHT NOT APPLY TO YOU.

BY ACCESSING THIS WEBSITE, YOU UNDERSTAND THAT YOU MAY BE WAIVING RIGHTS WITH RESPECT TO CLAIMS THAT ARE AT THIS TIME UNKNOWN OR UNSUSPECTED, AND IN ACCORDANCE WITH SUCH WAIVER, YOU ACKNOWLEDGE THAT TO THE EXTENT IT APPLIES YOU HAVE READ AND UNDERSTAND, AND HEREBY EXPRESSLY WAIVE, THE BENEFITS OF SECTION 1542 OF THE CIVIL CODE OF CALIFORNIA, AND ANY SIMILAR LAW OF ANY STATE OR TERRITORY, WHICH PROVIDES IN SUBSTANCE AS FOLLOWS: "A GENERAL RELEASE DOES NOT EXTEND TO CLAIMS WHICH THE CREDITOR DOES NOT KNOW OR SUSPECT TO EXIST IN HIS OR HER FAVOR AT THE TIME OF EXECUTING THE RELEASE, WHICH IF KNOWN BY HIM OR HER MUST HAVE MATERIALLY AFFECTED HIS OR HER SETTLEMENT WITH THE DEBTOR."

Company makes no representation or warranty whatsoever regarding the completeness, accuracy, currency or adequacy of any information, facts, views, opinions, statements or recommendations contained on this Website and/or the Material. Reference to any product, process, publication or service of any third party by trade name, domain name, trademark, service mark, logo, manufacturer or otherwise does not constitute or imply its endorsement or recommendation by Company. Views and opinions of users of this Website do not necessarily state or reflect those of Company.

The Internet may be subject to breaches of security. Company is not responsible for any resulting damage to any user's computer from any such security breach, or from any virus, bugs, tampering, unauthorized intervention, fraud, error, omission, interruption, deletion, defect, delay in operation or transmission, computer line failure or any other technical or other malfunction. You should also be aware that email submissions over the Internet may not be secure, and you should consider this before emailing Company any information. Company makes no representation or warranty whatsoever regarding the suitability, functionality, availability or operation of this Website. This Website may be temporarily unavailable due to maintenance or malfunction of computer equipment.

**Indemnification**

BY USING THIS WEBSITE YOU AGREE TO INDEMNIFY, DEFEND AND HOLD COMPANY AND ITS PARENTS, AFFILIATES, SUBSIDIARIES, LICENSORS AND ASSIGNS AND EACH OF THEIR RESPECTIVE EMPLOYEES, OFFICER AND DIRECTORS HARMLESS FROM AND AGAINST ANY THIRD PARTY CLAIMS, ALLEGED CLAIMS, DEMANDS, CAUSES OF ACTION, JUDGMENTS, DAMAGES, LOSSES, LIABILITIES, AND ALL COSTS AND EXPENSES OF DEFENSE, INCLUDING, WITHOUT LIMITATION, REASONABLE ATTORNEYS' FEES, ARISING OUT OF OR RELATING TO: YOUR BREACH OF YOUR REPRESENTATIONS, WARRANTIES, COVENANTS OR AGREEMENTS HEREUNDER; YOUR VIOLATION OF THESE TERMS OR ANY LAW; AND/OR YOUR USE OF THIS WEBSITE AND/OR THE MATERIAL IN VIOLATION OF THESE TERMS. YOU WILL COOPERATE AS FULLY AND AS REASONABLY REQUIRED IN COMPANY'S DEFENSE OF ANY CLAIM.COMPANY RESERVES THE RIGHT, AT ITS OWN EXPENSE, TO ASSUME THE EXCLUSIVE DEFENSE AND CONTROL OF ANY MATTER OTHERWISE SUBJECT TO INDEMNIFICATION BY YOU, AND YOU SHALL NOT IN ANY EVENT SETTLE ANY SUCH MATTER WITHOUT THE WRITTEN CONSENT OF COMPANY.

**Remedies**

You agree that a breach by you of any of your undertakings hereunder would cause Company damage which could not readily be remedied by an action at law and might, in addition, constitute an infringement of copyright and/or trademark and/or other applicable laws. You acknowledge and agree that any such breach would, therefore, entitle Company to equitable remedies, costs and attorneys' fees in addition to any other rights and remedies provided for herein or by law.

**Linking Policy**

You may not link to this Website.  You may not "frame" this Website or alter its intellectual property or Material in any other way.

**Location – Choice of Law, Submission to Jurisdiction and Venue**

These Terms shall be construed and enforced in accordance with the laws of the State of New York, without regard to its conflicts of law principles and will specifically not be governed by the United Nations Conventions on Contracts for the International Sale of Goods, if otherwise applicable. Any cause of action filed by you with respect to the Terms and/or your use of this Website must be filed in the County of New York, State of New York, within ninety (90) days after the occurrence of the facts giving rise to the cause of action, otherwise the cause shall be forever barred.  You hereby consent and submit to the exclusive personal jurisdiction and venue of the courts located in the County of New York, State of New York, for any cause of action relating to or arising under these Terms or the Website.

**Restriction on Export**

No software from the Website may be downloaded, exported or re-exported: (i) into (or to a national or resident of) any countries that are subject to U.S. export restrictions; or (ii) to anyone on the U.S. Treasury Department's list of Specially Designated Nations or the U.S. Commerce Department's Table of Deny Orders. You represent and warrant that you are not located in, under the control of, or a national or resident of any such country on any such list.

**Compliance with Laws**

You agree to comply with all rules, laws and regulations that are applicable to your use of the Website, including, without limitation, all applicable laws, rules and regulations governing your transmission or use of any software or data. Nothing contained in these Terms shall be construed so as to require the commission of any act contrary to statute or law in the relevant jurisdiction, and whenever there is any conflict between any provision of these Terms and any applicable statute or law in the relevant jurisdiction, the applicable statute or law shall prevail. In such event, however, the affected provisions of these Terms shall be curtailed and limited only to the extent required and necessary to bring them within the specifically applicable legal requirements.

**Violations and Additional Policies**

Company will determine your compliance with these Terms in its sole discretion and its decision shall be final and binding. Any violation of these Terms may result in restrictions on your access to all or part of the Website and may be referred to law enforcement authorities. No waiver of any of these Terms shall be of any force or effect unless made in writing and signed by a duly authorized officer of Company. Company reserves the right to modify or discontinue this Website, or any portion thereof without notice to you or any third party. Upon termination of your account or access to the Website, or upon demand by Company, you must destroy all Materials obtained from this Website and all related documentation and all copies and installations thereof. You are advised that Company will aggressively enforce its rights to the fullest extent of the law.

If any provision of these Terms is found to be invalid by any court having competent jurisdiction, the invalidity of such provision will not affect the validity of the remaining provisions of these Terms, which will remain in full force and effect. The section titles in these Terms are for your convenience only and do not have any legal or contractual effect.

**Contact Us**

If you have any questions, comments or concerns about our Website or these Terms, you may contact us at[LegalEaseSupport@viacom.com](mailto:LegalEaseSupport@viacom.com).

The effective date of these Terms is 03/12/2018.

© 2018 Viacom International Inc. All rights reserved.