**Last Modified:** **03/12/2018**

Welcome to the Global Ingest website (the "Site"), a website available for use by certain employees of Viacom International Inc. or one of its affiliates (together, "Viacom").

This Site is a repository of Viacom content and/or data and has been created solely to assist you in the creation of materials for Viacom.  Before you can begin using the Site, there are a few guidelines you should keep in mind, as described in this agreement (the "Site Terms"):

1) This Site is being made available to you only in connection with your employment with Viacom.  Therefore, your employment agreement, the Viacom Employee Handbook, the Viacom Global Business Practices Statement, the Viacom Information Security Policies and all other Viacom policies applicable to you (together, your "Agreement") apply to your use of the Site.  Some of the items described in your Agreement are highlighted in these Site Terms, but the terms of your Agreement apply to your use of the Site whether or not those terms are highlighted in these Site Terms. In addition, use of the Site is subject to the [Privacy Policy](http://www.viacom.com/about/pages/privacypolicy.aspx).

2) In order to use the Site, you must sign into the Viacom network with your Viacom-issued user name and password, and then register with the Site by reviewing and accepting these Site Terms.

3) After registering with the Site, you may be allowed to use a single sign-on to the Site through the Viacom network or you may be required to choose a different user name and password to access the Site.  Your user name and password are sensitive / confidential information under your Agreement and should be treated accordingly.

4) Enjoy using the Site, but remember Viacom owns the Site and all content on the Site.  The Site may only be used in connection with materials that you are creating for Viacom.

5) Please remember you are not allowed to use, view, post, share or distribute any content on the Site with any third party except in connection with your work for Viacom.  You may not download any content from the Site to any device other than your work device.  You may not download or copy any content from the Site to your home computer, personal laptop or other device. You may not share or watch any content on the site with friends, family or other third parties except in connection with your work for Viacom.

6) The Site contains intellectual property of Viacom. Viacom takes protection of intellectual property rights (such as copyrights), both our own and others, very seriously.  We expect all of our employees to share that respect and vigilance. You may not use the Site to use or distribute the content of others.

7) Viacom has the right to monitor your use of the Site.  Also, Viacom has the right to terminate your access to the Site at any time for any reason, including for any violation of these Site Terms or your Agreement.

8) The Site, and all materials on the Site, are intended to be used only by certain Viacom employees. Please be aware that not all Viacom personnel have access to this Site.

9) If you have received access to the Site or a copy of any material from the Site and you are not a Viacom employee who is authorized to access the Site or that material, then you are notified that unauthorized access to and any dissemination or copying of Viacom's intellectual property is strictly prohibited.

10) If you have received access to the Site or any content from the Site in error, please notify Viacom immediately at [LegalEaseSupport@viacom.com](mailto:LegalEaseSupport@viacom.com) and immediately destroy all copies, both electronic and other.

11) Remember, you must agree to and comply with these Site Terms in order to register and use the Site.   These Site Terms were last modified on the date indicated above.  Viacom may modify these Site Terms from time to time for any reason at our sole discretion by posting modified Site Terms without advance notice to you. We shall post or display notices of material changes on the Site's homepage and/or otherwise on the Site and/or e-mail you or notify you upon login about these changes; the form of such notice is at our discretion. Once we post them on the Site, these changes become effective immediately and, if you use the Site after they become effective, it will signify your agreement to be bound by the changes.

© 2018 VIACOM INTERNATIONAL INC.  ALL RIGHTS RESERVED.