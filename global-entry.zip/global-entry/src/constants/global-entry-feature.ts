export const globalEntryFeature = {
  CREATE_SUB: 'create_submission',
  EDIT_SUB: 'edit_submission',
  RESUBMIT: 'resubmit',
  VIEW_ALL_SUB: 'view_all_submissions'
};

export const globalEntryMetadataKeys = {
  REGION: 'ge_region',
  CONTENT_TYPE: 'ge_content_type'
};
