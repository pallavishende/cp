export const globalEntryToaster = {
  CREATE_SUCCESS: 'You have successfully created the record.',
  UPDATE_SUCCESS: 'You have successfully updated the record.'
};
