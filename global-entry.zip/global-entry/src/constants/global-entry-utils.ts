import { notificationActions, NotificationType } from '@content-platform/notifications';

export function createErrorAction(message: string): notificationActions.Open {
  return new notificationActions.Open({
    type: NotificationType.Error,
    inputs: {
      props: {
        message: message,
        button: {
          label: 'Dismiss'
        }
      }
    }
  });
}
