export enum ToasterMessageEnum {
    CANCEL_UPDATE = 'cancelUpdate',
    CONFIRM_POPUP = 'confirmPopup',
    LEAVE_PAGE = 'leavePage',
    STAY_PAGE = 'stayPage',
    CREATE_ANOTHER_SUBMISSION = 'createAnotherSubmission',
    CANCEL_UPDATE_MESSAGE = 'Are you sure you want to close the submission form? Any edits you have made to this submission will be lost.',
    CONFIRM_POPUP_MESSAGE = 'Do you want to go to Dashboard or create another submission?'
}
