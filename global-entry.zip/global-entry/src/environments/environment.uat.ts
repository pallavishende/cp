import { globalEnvironment } from '@environments/environment.uat';

export const environment = {
  ...globalEnvironment,
  version: globalEnvironment.version,
  LOCAL_STORAGE: false,
  EDIT_MODE: false,
  production: globalEnvironment.production
};
