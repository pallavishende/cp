import { Action } from '@ngrx/store';
import { Application } from '../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD = '[Application] LOAD';
export const LOAD_SUCCESS = '[Application] LOAD SUCCESS';
export const LOAD_FAILED = '[Application] LOAD FAILED';
export const UPDATE = '[Application] UPDATE';
export const UPDATE_SUCCESS = '[Application] UPDATE SUCCESS';
export const UPDATE_FAILED = '[Application] UPDATE FAILED';
export const DELETE = '[Application] DELETE';
export const DELETE_SUCCESS = '[Application] DELETE SUCCESS';
export const DELETE_FAILED = '[Application] DELETE FAILED';
export const CREATE = '[Application] CREATE';
export const CREATE_SUCCESS = '[Application] CREATE SUCCESS';
export const CREATE_FAILED = '[Application] CREATE FAILED';

export class Load implements Action {
  readonly type = LOAD;
  constructor(public payload = null) {}
}

export class LoadSuccess implements Action {
  readonly type = LOAD_SUCCESS;
  constructor(public payload: Application[]) {}
}

export class LoadFailed extends errorActions.Fail {
  readonly type = LOAD_FAILED;
}

export class Update implements Action {
  readonly type = UPDATE;
  constructor(public payload: Application) {}
}

export class UpdateSuccess implements Action {
  readonly type = UPDATE_SUCCESS;
  constructor(public payload: Application) {}
}

export class UpdateFailed extends errorActions.Fail {
  readonly type = UPDATE_FAILED;
}

export class Delete implements Action {
  readonly type = DELETE;
  constructor(public payload: number) {}
}

export class DeleteSuccess implements Action {
  readonly type = DELETE_SUCCESS;
  constructor(public payload: number) {}
}

export class DeleteFailed extends errorActions.Fail {
  readonly type = DELETE_FAILED;
}

export class Create implements Action {
  readonly type = CREATE;
  constructor(public payload: Application) {}
}

export class CreateSuccess implements Action {
  readonly type = CREATE_SUCCESS;
  constructor(public payload: Application) {}
}

export class CreateFailed extends errorActions.Fail {
  readonly type = CREATE_FAILED;
}

export type All =
  | Load
  | LoadSuccess
  | LoadFailed
  | Update
  | UpdateSuccess
  | UpdateFailed
  | Create
  | CreateSuccess
  | CreateFailed
  | Delete
  | DeleteSuccess
  | DeleteFailed;
