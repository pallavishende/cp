import { Action } from '@ngrx/store';
import { Role } from '../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD = '[Role] LOAD';
export const LOAD_SUCCESS = '[Role] LOAD SUCCESS';
export const LOAD_FAILED = '[Role] LOAD FAILED';
export const UPDATE = '[Role] UPDATE';
export const UPDATE_SUCCESS = '[Role] UPDATE SUCCESS';
export const UPDATE_FAILED = '[Role] UPDATE FAILED';
export const DELETE = '[Role] DELETE';
export const DELETE_SUCCESS = '[Role] DELETE SUCCESS';
export const DELETE_FAILED = '[Role] DELETE FAILED';
export const CREATE = '[Role] CREATE';
export const CREATE_SUCCESS = '[Role] CREATE SUCCESS';
export const CREATE_FAILED = '[Role] CREATE FAILED';

export class Load implements Action {
  readonly type = LOAD;
  constructor(public payload = null) {}
}

export class LoadSuccess implements Action {
  readonly type = LOAD_SUCCESS;
  constructor(public payload: Role[]) {}
}

export class LoadFailed extends errorActions.Fail {
  readonly type = LOAD_FAILED;
}

export class Update implements Action {
  readonly type = UPDATE;
  constructor(public payload: Role) {}
}

export class UpdateSuccess implements Action {
  readonly type = UPDATE_SUCCESS;
  constructor(public payload: Role) {}
}

export class UpdateFailed extends errorActions.Fail {
  readonly type = UPDATE_FAILED;
}

export class Delete implements Action {
  readonly type = DELETE;
  constructor(public payload: number) {}
}

export class DeleteSuccess implements Action {
  readonly type = DELETE_SUCCESS;
  constructor(public payload: number) {}
}

export class DeleteFailed extends errorActions.Fail {
  readonly type = DELETE_FAILED;
}

export class Create implements Action {
  readonly type = CREATE;
  constructor(public payload: Role) {}
}

export class CreateSuccess implements Action {
  readonly type = CREATE_SUCCESS;
  constructor(public payload: Role) {}
}

export class CreateFailed extends errorActions.Fail {
  readonly type = CREATE_FAILED;
}

export type All =
  | Load
  | LoadSuccess
  | LoadFailed
  | UpdateFailed
  | CreateFailed
  | DeleteFailed
  | Update
  | UpdateSuccess
  | UpdateFailed
  | Create
  | CreateSuccess
  | CreateFailed
  | Delete
  | DeleteSuccess
  | DeleteFailed;
