import { Action } from '@ngrx/store';
import { UserPermissionList } from '../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD_BY_ID = '[UserPermissionList] LOAD BY ID';
export const LOAD_BY_ID_SUCCESS = '[UserPermissionList] LOAD BY ID SUCCESS';
export const LOAD_BY_ID_FAILED = '[UserPermissionList] LOAD BY ID FAILED';

export const UPDATE_FAILED = '[UserPermissionList] UPDATE FAILED';
export const DELETE_FAILED = '[UserPermissionList] DELETE FAILED';
export const CREATE_FAILED = '[UserPermissionList] CREATE FAILED';

export class LoadById implements Action {
  readonly type = LOAD_BY_ID;
  constructor(public payload: string) {}
}

export class LoadByIdSuccess implements Action {
  readonly type = LOAD_BY_ID_SUCCESS;
  constructor(public payload: UserPermissionList) {}
}

export class LoadFailed extends errorActions.Fail {
  readonly type = LOAD_BY_ID_FAILED;
}

export type All = LoadById | LoadByIdSuccess | LoadFailed;
