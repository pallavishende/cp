import { Action } from '@ngrx/store';
import { UserRoleList } from '../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD_BY_ID = '[UserRoleList] LOAD BY ID';
export const LOAD_BY_ID_SUCCESS = '[UserRoleList] LOAD SUCCESS BY ID';
export const LOAD_FAILED = '[UserRoleList] LOAD FAILED';
export const UPDATE = '[UserRoleList] UPDATE';
export const UPDATE_SUCCESS = '[UserRoleList] UPDATE SUCCESS';
export const UPDATE_FAILED = '[UserRoleList] UPDATE FAILED';
export const DELETE_FAILED = '[UserRoleList] DELETE FAILED';
export const CREATE_FAILED = '[UserRoleList] CREATE FAILED';

export class LoadById implements Action {
  readonly type = LOAD_BY_ID;
  constructor(public payload: string) {}
}

export class LoadByIdSuccess implements Action {
  readonly type = LOAD_BY_ID_SUCCESS;
  constructor(public payload: UserRoleList) {}
}

export class LoadFailed extends errorActions.Fail {
  readonly type = LOAD_FAILED;
}

export class Update implements Action {
  readonly type = UPDATE;
  constructor(public payload: UserRoleList) {}
}

export class UpdateSuccess implements Action {
  readonly type = UPDATE_SUCCESS;
  constructor(public payload: UserRoleList) {}
}

export class CreateFailed extends errorActions.Fail {
  readonly type = CREATE_FAILED;
}

export class UpdateFailed extends errorActions.Fail {
  readonly type = UPDATE_FAILED;
}

export class DeleteFailed extends errorActions.Fail {
  readonly type = DELETE_FAILED;
}

export type All =
  | LoadById
  | LoadByIdSuccess
  | LoadFailed
  | UpdateFailed
  | CreateFailed
  | DeleteFailed
  | Update
  | UpdateSuccess;
