import { InjectionToken } from '@angular/core';
export const APPLICATION_API_OPTIONS = new InjectionToken<boolean>('ApplicationApiOptions');

export class ApplicationApiConstants {
  static activeAppName: string;
  static production: boolean;
}

export interface ApplicationApiOptions {
  appName: string;
  apiEndpoint?: string;
  production: boolean;
}
