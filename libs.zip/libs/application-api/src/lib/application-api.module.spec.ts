import { ApplicationApiModule } from './application-api.module';

describe('ApplicationApiModule', () => {
  it('should work', () => {
    const module = ApplicationApiModule.forRoot({
      appName: 'App Name',
      apiEndpoint: '',
      production: false
    }).ngModule;
    expect(new module({ appName: 'App', production: false })).toBeDefined();
  });

  it('should throw an Syntax Error if withApp is not included', () => {
    let module;
    try {
      module = new (ApplicationApiModule.forRoot(null)).ngModule({});
    } catch (e) {
      expect(module).not.toBeDefined();
      expect(e instanceof SyntaxError).toBeTruthy();
      expect(e.message).toMatch('App Name not defined with');
    }
  });
});
