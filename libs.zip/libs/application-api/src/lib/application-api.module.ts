import { CommonModule } from '@angular/common';
import { Inject, ModuleWithProviders, NgModule } from '@angular/core';
import { GraphApiModule } from '@content-platform/graph-api';
import { LoggingModule } from '@content-platform/logging';
import { ErrorHandlingModule } from '@content-platform/error-handling';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import {
  ApplicationApiConstants,
  ApplicationApiOptions,
  APPLICATION_API_OPTIONS
} from './application-api-config';
import {
  ApplicationEffects,
  RoleEffects,
  UserPermissionListEffects,
  UserRoleListEffects
} from './effects';
import { guards } from './guards';
import { ActiveApplicationLoggingTransformer, UserRolesLoggingTransformer } from './transformers';
import { AppReportParamsTransformer } from './transformers';
import { fromApplication, fromRole, fromUserPermissionList, fromUserRoleList } from './reducers';
import { ApplicationRegistry } from './registry/application-registry';
import { resources } from './services';
import { ApiParams } from './services/api-params';

const moduleErrorMessage =
  'App Name not defined with ApplicationApiModule import. Expected: ApplicationApiModule.forRoot({appName: <AppName>})';

/**
 * Registers the application state & reducer, and also adds in the
 * {@link ApplicationEffects } service.
 *
 */
@NgModule({
  imports: [
    CommonModule,
    GraphApiModule,
    StoreModule.forFeature('application', fromApplication.reducer),
    StoreModule.forFeature('role', fromRole.reducer),
    StoreModule.forFeature('userRoleList', fromUserRoleList.reducer),
    StoreModule.forFeature('userPermissionList', fromUserPermissionList.reducer),
    EffectsModule.forFeature([
      ApplicationEffects,
      RoleEffects,
      UserRoleListEffects,
      UserPermissionListEffects
    ]),
    LoggingModule.withExtraParams([
      ActiveApplicationLoggingTransformer,
      UserRolesLoggingTransformer
    ]),
    ErrorHandlingModule.withExtraParams(AppReportParamsTransformer)
  ],
  providers: [ApiParams, ApplicationRegistry, ...resources, guards]
})
export class ApplicationApiModule {
  // injecting as we can't set it inside the withApp function, get this error otherwise:
  // ERROR in Error during template compile of 'AppModule'
  // Function calls are not supported in decorators but 'ApplicationApiModule' was called.
  constructor(@Inject(APPLICATION_API_OPTIONS) options: ApplicationApiOptions) {
    // enforce the use of withApp for the module import
    ApplicationApiConstants.activeAppName = options.appName;
    ApplicationApiConstants.production = options.production;
    if (!ApplicationApiConstants.activeAppName) {
      throw new SyntaxError(moduleErrorMessage);
    }
  }

  static forRoot(options: ApplicationApiOptions): ModuleWithProviders {
    return {
      ngModule: ApplicationApiModule,
      providers: [{ provide: APPLICATION_API_OPTIONS, useValue: options }]
    };
  }
}
