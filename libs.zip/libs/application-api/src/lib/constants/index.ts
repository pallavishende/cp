export const DASHBOARD_APP_NAME = 'Home';
