import { TestBed } from '@angular/core/testing';
import { DOCUMENT } from '@angular/common';

import { Actions } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';

import { TestScheduler } from 'rxjs/testing';
import { Observable, of, empty } from 'rxjs';

import { ApplicationEffects } from './application.effects';
import { ApplicationResource } from '../services';
import { Application } from '../models';
import { fromApplication } from '../reducers';
import { applicationActions } from '../actions';
import { fromAuth } from '@content-platform/auth';
import { ApplicationRegistry } from '../registry';

export class TestActions extends Actions {
  constructor() {
    super(empty());
  }

  set stream(source: Observable<any>) {
    this.source = source;
  }
}

const scheduler = new TestScheduler((actual, expected) => {
  expect(actual).toEqual(expected);
});

export function getActions() {
  return new TestActions();
}

describe('ApplicationEffects', () => {
  let effects: ApplicationEffects;
  let applicationActions$: TestActions;

  const applications: Application[] = [
    {
      name: 'Dashboard',
      id: 1,
      features: []
    },
    {
      name: 'Global Entry',
      id: 2,
      features: []
    }
  ];

  const extraDataForApp = [
    {
      name: 'Dashboard',
      imgUrl: '/assets/dashboard-icon.png',
      url: 'aUrl'
    },
    {
      name: 'Global Entry',
      imgUrl: '/assets/ge-icon.png',
      url: 'test'
    }
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot({
          auth: fromAuth.authReducer,
          application: fromApplication.reducer
        })
      ],
      providers: [
        ApplicationEffects,
        {
          provide: ApplicationResource,
          useValue: {
            query: () => of(applications)
          }
        },
        {
          provide: ApplicationRegistry,
          useValue: {
            get: name => {
              return extraDataForApp.find(app => app.name === name);
            }
          }
        },
        { provide: DOCUMENT, useValue: { location: { href: 'test' } } },
        { provide: Actions, useFactory: getActions }
      ]
    });

    effects = TestBed.get(ApplicationEffects);
    applicationActions$ = TestBed.get(Actions);
  });

  describe('load', () => {
    it('should return a LoadSuccess, with all the applications, and the extra data', () => {
      const action = new applicationActions.Load();
      const completion = new applicationActions.LoadSuccess(
        applications.map((app, index) => {
          return { ...app, ...extraDataForApp[index] };
        })
      );

      scheduler.run(helpers => {
        const { hot, expectObservable } = helpers;
        applicationActions$.stream = hot('-a', { a: action });

        expectObservable(effects.load$).toBe('-b', { b: completion });
      });
    });
  });
});
