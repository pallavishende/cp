import { Injectable } from '@angular/core';
import { Action, Store, select } from '@ngrx/store';
import { Effect, Actions, ofType } from '@ngrx/effects';

import { Observable } from 'rxjs';
import { switchMap, map, catchError, withLatestFrom } from 'rxjs/operators';

import { authSelectors } from '@content-platform/auth';

import { Application } from '../models';
import { applicationActions } from '../actions';
import { ApplicationResource } from '../services';
import { ApplicationRegistry } from '../registry/application-registry';
import { ApplicationsState } from '../reducers';

/**
 * The application effects imported in {@link ApplicationApiModule }
 *
 */
@Injectable()
export class ApplicationEffects {
  constructor(
    private applicationActions$: Actions,
    private api: ApplicationResource,
    private appRegistry: ApplicationRegistry,
    private store: Store<ApplicationsState>
  ) {}

  /**
   * Loads all the availabe applications only when a user is logged in and triggers a LoadSuccess action.
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when all applications are retrieved
   */
  @Effect()
  load$: Observable<Action> = this.applicationActions$.pipe(
    ofType(applicationActions.LOAD),
    switchMap(() =>
      this.api.query().pipe(
        map(apps => this.setExtraAppData(<Application[]>apps)),
        map((apps: Application[]) => new applicationActions.LoadSuccess(apps)),
        catchError(error => [
          new applicationActions.LoadFailed({
            error: error,
            message: 'Unable to load applications'
          })
        ])
      )
    )
  );

  /**
   * Updates the application and triggers a UpdateSuccess action.
   *
   * @returns { Observable<Action> } Observable with UpdateSuccess action with the updated application
   */
  @Effect()
  update$: Observable<Action> = this.applicationActions$.pipe(
    ofType(applicationActions.UPDATE),
    map((action: applicationActions.Update) => action.payload),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([application, userId]) => {
      application.lastModifiedBy = userId;
      return this.api.update(application).pipe(
        map(app => this.setExtraAppData([<Application>app])[0]),
        map((app: Application) => new applicationActions.UpdateSuccess(app)),
        catchError(error => [
          new applicationActions.UpdateFailed({
            error: error,
            message: 'Unable to update application'
          })
        ])
      );
    })
  );

  /**
   * Create new application and CreateSuccess action.
   *
   * @returns { Observable<Action> } Observable with CreateSuccess action with the updated application
   */
  @Effect()
  create$: Observable<Action> = this.applicationActions$.pipe(
    ofType(applicationActions.CREATE),
    map((action: applicationActions.Update) => action.payload),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([app, userId]) => {
      app.lastModifiedBy = userId;
      app.createdBy = userId;
      return this.api.create(app).pipe(
        map(newApp => this.setExtraAppData([<Application>newApp])[0]),
        map((newApp: Application) => new applicationActions.CreateSuccess(newApp)),
        catchError(error => [
          new applicationActions.CreateFailed({
            error: error,
            message: 'Unable to create application'
          })
        ])
      );
    })
  );

  /**
   * Delete application and triggers DeleteSuccess action.
   *
   * @returns { Observable<Action> } Observable with DeleteSuccess action with the deleted app id
   */
  @Effect()
  delete$: Observable<Action> = this.applicationActions$.pipe(
    ofType(applicationActions.DELETE),
    map((action: applicationActions.Delete) => action.payload),
    switchMap((appId: number) =>
      this.api.delete(appId).pipe(
        map(() => new applicationActions.DeleteSuccess(appId)),
        catchError(error => [
          new applicationActions.DeleteFailed({
            error: error,
            message: 'Unable to delete application'
          })
        ])
      )
    )
  );

  /**
   * Uses the appRegistry to add extra data to the app, adding url, icon, ...
   *
   * @param apps
   * @returns apps with the extra data
   */
  private setExtraAppData(apps: Application[]): Application[] {
    return apps.map(app => {
      const appData = app.global ? this.appRegistry.getGlobal() : this.appRegistry.get(app.name);
      if (appData) {
        return { ...appData, ...app };
      }
      return app;
    });
  }
}
