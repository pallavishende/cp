import { TestBed } from '@angular/core/testing';

import { Actions } from '@ngrx/effects';
import { StoreModule, Store } from '@ngrx/store';

import { Observable, of, empty } from 'rxjs';

import { fromAuth, authActions } from '@content-platform/auth';

import { RoleEffects } from './role.effects';
import { RoleResource } from '../services';
import { Role, UserType } from '../models';
import { fromRole } from '../reducers';
import { roleActions } from '../actions';
import { TestScheduler } from 'rxjs/testing';

export class TestActions extends Actions {
  constructor() {
    super(empty());
  }

  set stream(source: Observable<any>) {
    this.source = source;
  }
}

const scheduler = new TestScheduler((actual, expected) => {
  expect(actual).toEqual(expected);
});

export function getActions() {
  return new TestActions();
}

describe('RoleEffects', () => {
  let effects: RoleEffects;
  let roleActions$: TestActions;
  let store: Store<{}>;

  const roles: Role[] = [
    {
      name: 'Admin',
      id: 1,
      userType: UserType.Internal,
      users: [],
      permissions: [],
      applicationAdminPrivileges: []
    },
    {
      name: 'Sys Admin',
      id: 2,
      userType: UserType.Internal,
      users: [],
      permissions: [],
      applicationAdminPrivileges: []
    }
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot({
          role: fromRole.reducer,
          auth: fromAuth.authReducer
        })
      ],
      providers: [
        RoleEffects,
        {
          provide: RoleResource,
          useValue: {
            query: () => of(roles),
            update: role => of(role)
          }
        },
        { provide: Actions, useFactory: getActions }
      ]
    });

    effects = TestBed.get(RoleEffects);
    roleActions$ = TestBed.get(Actions);
    store = TestBed.get(Store);
  });

  describe('load', () => {
    it('should return a LoadSuccess, with all the roles', () => {
      const action = new roleActions.Load();
      const completion = new roleActions.LoadSuccess(roles);
      scheduler.run(helpers => {
        const { hot, expectObservable } = helpers;

        roleActions$.stream = hot('-a', { a: action });

        expectObservable(effects.load$).toBe('-b', { b: completion });
      });
    });
  });

  describe('update', () => {
    it('should return a UpdateSuccess, with the updated role', () => {
      store.dispatch(
        new authActions.LoginSuccess({ userName: 'name', profile: { oid: 'user_id' } })
      );
      const action = new roleActions.Update({ ...roles[0], name: 'Updated' });
      const completion = new roleActions.UpdateSuccess({
        ...roles[0],
        name: 'Updated',
        lastModifiedBy: 'user_id'
      });

      scheduler.run(helpers => {
        const { hot, expectObservable } = helpers;

        roleActions$.stream = hot('-a', { a: action });

        expectObservable(effects.update$).toBe('--b', { b: completion });
      });
    });
  });
});
