import { Injectable } from '@angular/core';
import { authSelectors } from '@content-platform/auth';
import { UserProfile } from '@content-platform/graph-api';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action, Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { catchError, map, switchMap, withLatestFrom, filter } from 'rxjs/operators';
import { roleActions, userRoleListActions, userPermissionListActions } from '../actions';
import { Role } from '../models';
import { fromRole } from '../reducers';
import { userRoleListSelectors, roleSelectors } from '../selectors';
import { RoleResource } from '../services';

/**
 * The role effects imported in {@link RoleApiModule }
 *
 */
@Injectable()
export class RoleEffects {
  constructor(
    private roleActions$: Actions,
    private roleApi: RoleResource,
    private store: Store<fromRole.State>
  ) {}

  /**
   * Loads all the availabe roles only when a user is logged in and triggers a LoadSuccess action.
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when all roles are retrieved
   */
  @Effect()
  load$: Observable<Action | {}> = this.roleActions$.pipe(
    ofType(roleActions.LOAD),
    switchMap(() =>
      this.roleApi.query().pipe(
        map((apps: Role[]) => new roleActions.LoadSuccess(apps)),
        catchError(error => [
          new roleActions.LoadFailed({ error: error, message: 'Unable to load roles' })
        ])
      )
    )
  );

  /**
   * Updates the role and triggers a UpdateSuccess action.
   *
   * @returns { Observable<Action> } Observable with UpdateSuccess action with the updated role
   */
  @Effect()
  update$: Observable<Action> = this.roleActions$.pipe(
    ofType(roleActions.UPDATE),
    map((action: roleActions.Update) => action.payload),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([role, userId]) => {
      role.lastModifiedBy = userId;
      return this.roleApi.update(role).pipe(
        map(updatedRole => new roleActions.UpdateSuccess(<Role>updatedRole)),
        catchError(error => [
          new roleActions.LoadFailed({
            error: error,
            message: 'Unable to update role'
          })
        ])
      );
    })
  );

  /**
   * Forces Update of user Roles when a role is updated

   * @memberof RoleEffects
   */
  @Effect()
  reloadUserProfiles$ = this.roleActions$.pipe(
    ofType(roleActions.UPDATE_SUCCESS),
    map((action: roleActions.UpdateSuccess) => action.payload),
    withLatestFrom(this.store.pipe(select(userRoleListSelectors.getUserRoleListEntities))),
    switchMap(([role, userEntitiesInState]) => {
      const usersWithRole = Object.keys(userEntitiesInState).filter(id => {
        return userEntitiesInState[id].roles.find(r => r.id === role.id);
      });
      const userRoleListUpdates = (<any[]>(role as Role).users)
        .map(user => {
          return typeof user === 'string' ? <string>user : (<UserProfile>user).objectId;
        })
        .filter(id => {
          return !!userEntitiesInState[id] && !usersWithRole.includes(id);
        });
      return userRoleListUpdates
        .concat(usersWithRole)
        .map(userId => new userRoleListActions.LoadById(userId));
    })
  );

  /**
   * Create new role and CreateSuccess action.
   *
   * @returns { Observable<Action> } Observable with CreateSuccess action with the updated role
   */
  @Effect()
  create$: Observable<Action> = this.roleActions$.pipe(
    ofType(roleActions.CREATE),
    map((action: roleActions.Update) => action.payload),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([role, userId]) => {
      role.createdBy = userId;
      role.lastModifiedBy = userId;
      return this.roleApi.create(role).pipe(
        map((newRole: Role) => new roleActions.CreateSuccess(newRole)),
        catchError(error => [
          new roleActions.CreateFailed({
            error: error,
            message: 'Unable to create role'
          })
        ])
      );
    })
  );

  /**
   * Delete role and trigger DeleteSuccess and trigger LoadById for user permissions list, if active user was part of the role.
   *
   * @returns { Observable<Action> } Observable with DeleteSuccess and UpdateSuccess action with deleted role id
   */
  @Effect()
  delete$: Observable<Action> = this.roleActions$.pipe(
    ofType(roleActions.DELETE),
    map((action: roleActions.Delete) => action.payload),
    withLatestFrom(this.store.pipe(select(authSelectors.getADUser))),
    withLatestFrom(this.store.pipe(select(roleSelectors.getAllRoleItems))),
    switchMap(([[roleId, user], roles]) =>
      this.roleApi.delete(<number>roleId).pipe(
        switchMap(() => {
          const actions: Action[] = [new roleActions.DeleteSuccess(<number>roleId)];
          if (this.isUserPartOfUpdatedRole(user, roles, roleId)) {
            actions.push(new userPermissionListActions.LoadById(user.profile.oid));
          }
          return actions;
        }),
        catchError(error => [
          new roleActions.DeleteFailed({
            error: error,
            message: 'Unable to delete role'
          })
        ])
      )
    )
  );

  @Effect()
  deleteSuccess$: Observable<Action> = this.roleActions$.pipe(
    ofType(roleActions.DELETE_SUCCESS),
    map((action: roleActions.DeleteSuccess) => action.payload),
    withLatestFrom(this.store.pipe(select(userRoleListSelectors.getUserRoleListEntities))),
    switchMap(([roleId, userEntitiesInState]) => {
      const usersWithRole = Object.keys(userEntitiesInState).filter(id => {
        return userEntitiesInState[id].roles.find(r => r.id === roleId);
      });
      return usersWithRole.map(userId => new userRoleListActions.LoadById(userId));
    })
  );

  /**
   * Forces Update of user permissions when a role is updated
   *
   */
  @Effect()
  reloadPermissionsAfterRoleUpdate$: Observable<Action> = this.roleActions$.pipe(
    ofType(roleActions.UPDATE_SUCCESS),
    map((action: roleActions.UpdateSuccess) => action.payload),
    withLatestFrom(this.store.pipe(select(authSelectors.getADUser))),
    withLatestFrom(this.store.pipe(select(roleSelectors.getAllRoleItems))),
    filter(([[role, user], roles]) => this.isUserPartOfUpdatedRole(user, roles, role.id, role)),
    map(([[, user]]) => {
      return new userPermissionListActions.LoadById(user.profile.oid);
    })
  );

  private isUserPartOfUpdatedRole(
    user: adal.User,
    roles: Role[],
    updatedRoleId: number,
    updatedRole?: Role
  ): boolean {
    const oldRole = roles.find(r => r.id === updatedRoleId);
    if (oldRole && this.roleContainsUser(oldRole, user)) {
      return true;
    }
    if (updatedRole && this.roleContainsUser(updatedRole, user)) {
      return true;
    }
    return false;
  }

  private roleContainsUser(role: Role, user: adal.User): boolean {
    return !!(<UserProfile[]>role.users).find(u => u.objectId === user.profile.oid);
  }
}
