import { TestBed } from '@angular/core/testing';
import { DOCUMENT } from '@angular/common';

import { Actions } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';

import { Observable, of, empty } from 'rxjs';

import { UserPermissionListEffects } from './user-permission-list.effects';
import { UserPermissionListResource } from '../services';
import { Application, Permission } from '../models';
import { fromUserPermissionList } from '../reducers';
import { userPermissionListActions } from '../actions';
import { fromAuth } from '@content-platform/auth';
import { ApplicationRegistry } from '../registry';
import { TestScheduler } from 'rxjs/testing';

export class TestActions extends Actions {
  constructor() {
    super(empty());
  }

  set stream(source: Observable<any>) {
    this.source = source;
  }
}

const scheduler = new TestScheduler((actual, expected) => {
  expect(actual).toEqual(expected);
});

export function getActions() {
  return new TestActions();
}

describe('UserPermissionListEffects', () => {
  let effects: UserPermissionListEffects;
  let userPermissionListActions$: TestActions;

  const applications: Application[] = [
    {
      name: 'Dashboard',
      id: 1,
      features: []
    },
    {
      name: 'Global Entry',
      id: 2,
      features: []
    }
  ];

  const permissions: Permission[] = [
    {
      id: 1,
      feature: {
        id: 123,
        name: 'Upload videos',
        key: 'upload_videos',
        metadataConfig: null
      },
      metadata: null
    },
    {
      id: 2,
      feature: {
        id: 456,
        name: 'Edit Videos',
        key: 'edit_videos',
        metadataConfig: null
      },
      metadata: null
    }
  ];

  const userPermissionList = { uuid: '1234', applications, permissions };

  const extraDataForApp = [
    {
      name: 'Dashboard',
      imgUrl: '/assets/dashboard-icon.png',
      url: 'aUrl',
      isActive: false
    },
    {
      name: 'Global Entry',
      imgUrl: '/assets/ge-icon.png',
      url: 'test',
      isActive: false
    }
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot({
          auth: fromAuth.authReducer,
          userPermissionList: fromUserPermissionList.reducer
        })
      ],
      providers: [
        UserPermissionListEffects,
        {
          provide: UserPermissionListResource,
          useValue: {
            get: (_id: string) => of(userPermissionList)
          }
        },
        {
          provide: ApplicationRegistry,
          useValue: {
            get: name => {
              return extraDataForApp.find(app => app.name === name);
            }
          }
        },
        { provide: DOCUMENT, useValue: { location: { href: 'test' } } },
        { provide: Actions, useFactory: getActions }
      ]
    });
    effects = TestBed.get(UserPermissionListEffects);
    userPermissionListActions$ = TestBed.get(Actions);
  });

  describe('loadById', () => {
    it('should return all the applications and permissions based out of user', () => {
      const action = new userPermissionListActions.LoadById('1234');
      const completion = new userPermissionListActions.LoadByIdSuccess({
        ...userPermissionList,
        applications: userPermissionList.applications.map((app, index) => {
          return { ...app, ...extraDataForApp[index] };
        })
      });

      scheduler.run(helpers => {
        const { hot, expectObservable } = helpers;
        userPermissionListActions$.stream = hot('-a', { a: action });

        expectObservable(effects.loadById$).toBe('-b', { b: completion });
      });
    });
  });
});
