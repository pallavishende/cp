import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { catchError, map, mergeMap, filter } from 'rxjs/operators';
import { userPermissionListActions } from '../actions';
import { Application, UserPermissionList } from '../models';
import { ApplicationRegistry } from '../registry/application-registry';
import { UserPermissionListResource } from '../services';

@Injectable()
export class UserPermissionListEffects {
  constructor(
    private userPermissionListActions$: Actions,
    private api: UserPermissionListResource,
    private appRegistry: ApplicationRegistry
  ) {}

  @Effect()
  loadById$: Observable<Action> = this.userPermissionListActions$.pipe(
    ofType(userPermissionListActions.LOAD_BY_ID),
    map((action: userPermissionListActions.LoadById) => action.payload),
    filter(id => !!id),
    mergeMap(id =>
      this.api.get(<string>id).pipe(
        map((userPermissionList: UserPermissionList) => {
          return new userPermissionListActions.LoadByIdSuccess({
            ...userPermissionList,
            applications: this.setExtraAppData(userPermissionList.applications)
          });
        })
      )
    ),
    catchError(error =>
      of(
        new userPermissionListActions.LoadFailed({
          error: error,
          message: 'Unable to load user permissions'
        })
      )
    )
  );

  private setExtraAppData(apps: Application[]): Application[] {
    return apps.map(app => {
      const appData = this.appRegistry.get(app.name);
      if (appData) {
        return { ...appData, ...app };
      }
      return app;
    });
  }
}
