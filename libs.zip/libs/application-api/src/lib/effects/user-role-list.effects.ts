import { Injectable } from '@angular/core';
import { authSelectors } from '@content-platform/auth';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action, Store, select } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { catchError, filter, map, mergeMap, switchMap, withLatestFrom } from 'rxjs/operators';
import { roleActions, userPermissionListActions, userRoleListActions } from '../actions';
import { UserRoleList } from '../models';
import { UserRoleListResource } from '../services';
import { ApplicationsState } from '../reducers';

/**
 * The user role list effects
 *
 */
@Injectable()
export class UserRoleListEffects {
  constructor(
    private userRoleListActions$: Actions,
    private api: UserRoleListResource,
    private store: Store<ApplicationsState>
  ) {}

  /**
   * Loads the list of roles for a given user and triggers a LoadSuccess action.
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when all roles are retrieved
   */
  @Effect()
  loadById$: Observable<Action> = this.userRoleListActions$.pipe(
    ofType(userRoleListActions.LOAD_BY_ID),
    map((action: userRoleListActions.LoadById) => action.payload),
    mergeMap(id =>
      this.api.get(id).pipe(
        switchMap((userRoleList: UserRoleList) => {
          if (!userRoleList.uuid) {
            // Create user profile, updating a new user profile doesn't work.
            return this.api.create({ ...userRoleList, uuid: id });
          }
          return of(userRoleList);
        }),
        map((userRoleList: UserRoleList) => new userRoleListActions.LoadByIdSuccess(userRoleList)),
        catchError(error =>
          of(
            new userRoleListActions.LoadFailed({
              error: error,
              message: 'Unable to load user roles'
            })
          )
        )
      )
    )
  );

  /**
   * Updates the list of roles a user has and triggers a UpdateSuccess action.
   *
   * @returns { Observable<Action> } Observable with UpdateSuccess action with the updated role
   */
  @Effect()
  update$: Observable<Action> = this.userRoleListActions$.pipe(
    ofType(userRoleListActions.UPDATE),
    map((action: userRoleListActions.Update) => action.payload),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([userRoleList, userId]) => {
      userRoleList.lastModifiedBy = userId;
      return this.api.update(userRoleList).pipe(
        map(updatedUserRoleList => new userRoleListActions.UpdateSuccess(updatedUserRoleList)),
        catchError(error =>
          of(
            new userRoleListActions.LoadFailed({
              error: error,
              message: 'Unable to update user role'
            })
          )
        )
      );
    })
  );

  /**
   * Forces Update of roles when a user role list is updated
   *
   */
  @Effect()
  reloadRoles$: Observable<Action> = this.userRoleListActions$.pipe(
    ofType(userRoleListActions.UPDATE_SUCCESS),
    map((action: userRoleListActions.UpdateSuccess) => action.payload),
    filter(userRoleList => !!userRoleList.uuid),
    switchMap(() => {
      return [new roleActions.Load()];
    })
  );

  /**
   * Forces Update of user permissions when a user role list is updated for the logged in user
   *
   */
  @Effect()
  reloadPermissions$: Observable<Action> = this.userRoleListActions$.pipe(
    ofType(userRoleListActions.UPDATE_SUCCESS),
    map((action: userRoleListActions.Update) => action.payload),
    filter(userRoleList => !!userRoleList.uuid),
    withLatestFrom(this.store.pipe(select(authSelectors.getADUser))),
    filter(([userRoleList, user]) => userRoleList.uuid === user.profile.oid),
    switchMap(([userRoleList]) => {
      return [new userPermissionListActions.LoadById(userRoleList.uuid)];
    }),
    catchError(error =>
      of(
        new userPermissionListActions.LoadFailed({
          error: error,
          message: 'Unable to load user permissions'
        })
      )
    )
  );
}
