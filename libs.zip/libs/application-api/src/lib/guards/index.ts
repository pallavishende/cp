import { UserPermissionListGuard } from './user-permission-list.guard';

export const guards = [UserPermissionListGuard];

export * from './user-permission-list.guard';
