import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

import { Store, select } from '@ngrx/store';
import { Observable, of } from 'rxjs';

import { switchMap, catchError, withLatestFrom, map, filter, take, tap } from 'rxjs/operators';

import { userPermissionListActions } from '../actions';
import { authSelectors, AdAuthGuard } from '@content-platform/auth';
import { fromUserPermissionList } from '../reducers';
import { userPermissionListSelectors } from '../selectors';

@Injectable()
export class UserPermissionListGuard implements CanActivate {
  constructor(
    protected store: Store<fromUserPermissionList.State>,
    protected router: Router,
    private authGuard: AdAuthGuard
  ) {}

  canActivate(): Observable<boolean> {
    return this.checkLoggedIn().pipe(
      switchMap(loggedIn => {
        if (!loggedIn) {
          return of(false);
        }
        return this.checkStore().pipe(
          switchMap(loadedPermissions => {
            if (loadedPermissions) {
              return this.checkIfUserHasPermissions().pipe(
                tap(hasPermission => {
                  if (!hasPermission) {
                    this.router.navigate(['/access-denied'], { skipLocationChange: true });
                  }
                })
              );
            }
            return of(loadedPermissions);
          }),
          catchError(() => of(false))
        );
      })
    );
  }

  checkLoggedIn(): Observable<boolean> {
    return this.authGuard.canActivate();
  }

  checkStore(): Observable<boolean> {
    return this.store.pipe(
      select(userPermissionListSelectors.getUserPermissionListLoading),
      withLatestFrom(
        this.store.pipe(select(userPermissionListSelectors.getUserPermissionListLoaded))
      ),
      withLatestFrom(this.store.pipe(select(authSelectors.getADUser))),
      filter(([[loading, loaded], user], index) => {
        if (!loaded && !loading && index === 0 && user) {
          this.store.dispatch(new userPermissionListActions.LoadById(user.profile.oid));
          return false;
        }
        return !loading;
      }),
      map(([[, loaded]]) => {
        return loaded;
      }),
      take(1)
    );
  }

  checkIfUserHasPermissions(): Observable<boolean> {
    return this.store.pipe(select(userPermissionListSelectors.hasUserPermission));
  }
}
