import { Feature } from './features';

/**
 * An interface just for the application layout
 */
export interface Application {
  id: number;
  name: string;
  features: Feature[];
  global?: boolean;
  admin?: boolean;
  deletedFeatures?: number[];
  comingSoon?: boolean;
  url?: string;
  icon?: string;
  imgUrl?: string;
  imgUrlLrg?: string;
  isActive?: boolean;
  color?: string;
  lastModifiedBy?: string;
  createdBy?: string;
  modifiedDate?: string;
  createdDate?: string;
  external?: boolean;
}
