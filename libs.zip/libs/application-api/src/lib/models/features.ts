export const FeatureMetadataTypes = ['string', 'dataset'];

export interface FeatureMetadataConfig {
  type: string;
  dataset?: string;
  allowMultiple?: boolean;
}

/**
 * An interface for the different permission types for an application/user
 */
export interface Feature {
  name: string;
  key: string;
  id: number;
  appId?: number;
  metadataConfig: FeatureMetadataConfig;
}
