import { Feature } from './features';

export interface DatasetValue {
  name: string;
  description: string;
}

/**
 * This is the same as the format of options in the Dataset
 */
export type PermissionMetadata = DatasetValue;

/**
 * An interface for the different permission types for an application/user
 */
export interface Permission {
  id: number;
  feature: Feature;
  metadata?: Array<PermissionMetadata>;
}
