import { UserProfile } from '@content-platform/graph-api';
import { Permission } from './permissions';

export enum UserType {
  External = 'External',
  Internal = 'Internal'
}

export interface AppPrivilege {
  id: number;
}

/**
 * An interface just for the application layout
 */
export interface Role {
  id: number;
  name: string;
  userType: UserType;
  users: string[] | UserProfile[];
  permissions: Permission[];
  deletedPermissions?: number[];
  applicationAdminPrivileges: AppPrivilege[];
  lastModifiedBy?: string;
  createdBy?: string;
  modifiedDate?: string;
  createdDate?: string;
}
