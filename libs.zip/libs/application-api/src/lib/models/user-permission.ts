import { Application } from './application';
import { Permission } from './permissions';

export interface UserPermissionList {
  uuid: string; // User's id
  applications: Application[];
  permissions: Permission[];
}
