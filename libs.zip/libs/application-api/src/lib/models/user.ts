import { Role } from './role';

export type User = adal.User;

export interface UserRoleList {
  id: number;
  uuid: string;
  roles: Role[];
  name?: string;
  createdDate?: string;
  modifiedDate?: string;
  lastModifiedBy?: string;
}
