import { TestBed, ComponentFixture } from '@angular/core/testing';
import { Component, Input, DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { IfFeatureAsyncDirective } from './if-feature-async.directive';
import { UserPermissionsService } from '../services/user-permissions.service';
import { Observable, of } from 'rxjs';

@Component({
  template: `<div *appIfFeatureAsync="key">Hello</div>`
})
class TestWrapperComponent {
  @Input()
  key: string;
}

class MockPermService {
  hasFeatureAsync(key: string): Observable<boolean> {
    return of(key === 'good');
  }
}

describe('IfFeatureAsyncDirective', () => {
  let component: TestWrapperComponent;
  let fixture: ComponentFixture<TestWrapperComponent>;
  let testEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestWrapperComponent, IfFeatureAsyncDirective],
      providers: [{ provide: UserPermissionsService, useClass: MockPermService }]
    });
    fixture = TestBed.createComponent(TestWrapperComponent);
    component = fixture.componentInstance;
  });

  it('should create an instance', () => {
    expect(component).toBeDefined();
  });

  it('should include the element if the user has access to the key', () => {
    component.key = 'good';
    fixture.detectChanges();
    testEl = fixture.debugElement.query(By.css('div'));
    expect(testEl.nativeElement.textContent).toEqual('Hello');
  });

  it('should not include the element if the user does not have access to the key', () => {
    component.key = 'bad';
    fixture.detectChanges();
    testEl = fixture.debugElement.query(By.css('div'));
    expect(testEl).toBeFalsy();
  });
});
