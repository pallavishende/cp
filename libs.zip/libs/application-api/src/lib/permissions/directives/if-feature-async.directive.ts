import { Directive, Input, TemplateRef, ViewContainerRef, OnDestroy } from '@angular/core';
import { UserPermissionsService } from '../services/user-permissions.service';
import { enableDisableView } from './if-feature.directive';

import { Subscription } from 'rxjs';

@Directive({
  selector: '[appIfFeatureAsync]'
})
export class IfFeatureAsyncDirective implements OnDestroy {
  private featureKeySubscription: Subscription;
  private hasView = false;

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private permissionsService: UserPermissionsService
  ) {}

  @Input()
  set appIfFeatureAsync(featureKey: string) {
    this.removeSubscription();
    this.featureKeySubscription = this.permissionsService
      .hasFeatureAsync(featureKey)
      .subscribe(hasFeature => {
        this.hasView = enableDisableView(
          hasFeature,
          this.viewContainer,
          this.templateRef,
          this.hasView
        );
      });
  }

  ngOnDestroy() {
    this.removeSubscription();
  }

  private removeSubscription() {
    if (this.featureKeySubscription) {
      this.featureKeySubscription.unsubscribe();
    }
  }
}
