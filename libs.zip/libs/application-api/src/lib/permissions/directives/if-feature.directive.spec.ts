import { TestBed, ComponentFixture } from '@angular/core/testing';
import { Component, Input, DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { IfFeatureDirective } from './if-feature.directive';
import { UserPermissionsService } from '../services/user-permissions.service';

@Component({
  template: `<div *appIfFeature="key">Hello</div>`
})
class TestWrapperComponent {
  @Input()
  key: string;
}

class MockPermService {
  hasFeature(key: string): boolean {
    return key === 'good';
  }
}

describe('IfFeatureDirective', () => {
  let component: TestWrapperComponent;
  let fixture: ComponentFixture<TestWrapperComponent>;
  let testEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestWrapperComponent, IfFeatureDirective],
      providers: [{ provide: UserPermissionsService, useClass: MockPermService }]
    });
    fixture = TestBed.createComponent(TestWrapperComponent);
    component = fixture.componentInstance;
  });

  it('should create an instance', () => {
    expect(component).toBeDefined();
  });

  it('should include the element if the user has access to the key', () => {
    component.key = 'good';
    fixture.detectChanges();
    testEl = fixture.debugElement.query(By.css('div'));
    expect(testEl.nativeElement.textContent).toEqual('Hello');
  });

  it('should not include the element if the user does not have access to the key', () => {
    component.key = 'bad';
    fixture.detectChanges();
    testEl = fixture.debugElement.query(By.css('div'));
    expect(testEl).toBeFalsy();
  });
});
