import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { UserPermissionsService } from '../services/user-permissions.service';

export function enableDisableView(
  enableView: boolean,
  viewContainer: ViewContainerRef,
  templateRef: TemplateRef<any>,
  hasView: boolean
): boolean {
  if (enableView && !hasView) {
    viewContainer.createEmbeddedView(templateRef);
    return true;
  } else if (!enableView && hasView) {
    viewContainer.clear();
    return false;
  }
  return hasView;
}

@Directive({
  selector: '[appIfFeature]'
})
export class IfFeatureDirective {
  private hasView = false;

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private permissionsService: UserPermissionsService
  ) {}

  @Input()
  set appIfFeature(featureKey: string) {
    this.hasView = enableDisableView(
      this.permissionsService.hasFeature(featureKey),
      this.viewContainer,
      this.templateRef,
      this.hasView
    );
  }
}
