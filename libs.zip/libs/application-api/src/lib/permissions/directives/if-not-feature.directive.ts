import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { UserPermissionsService } from '../services/user-permissions.service';
import { enableDisableView } from './if-feature.directive';

@Directive({
  selector: '[appIfNotFeature]'
})
export class IfNotFeatureDirective {
  private hasView = false;

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private permissionsService: UserPermissionsService
  ) {}

  @Input()
  set appIfNotFeature(featureKey: string) {
    this.hasView = enableDisableView(
      !this.permissionsService.hasFeature(featureKey),
      this.viewContainer,
      this.templateRef,
      this.hasView
    );
  }
}
