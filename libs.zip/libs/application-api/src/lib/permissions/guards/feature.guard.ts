import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';

import { Store, select } from '@ngrx/store';
import { Observable, of } from 'rxjs';

import { tap, map, filter, switchMap, combineLatest, take } from 'rxjs/operators';

import { UserPermissionsService } from '../services/user-permissions.service';

import { authSelectors } from '@content-platform/auth';

import { fromUserPermissionList } from '../../reducers';
import { userPermissionListSelectors } from '../../selectors';
import { userPermissionListActions } from '../../actions';

const FEATURE_GUARD_DATA_PROPERTY = 'featureGuard';

export interface FeatureGuardOptions {
  key?: string;
}

/**
 * A Guard that actives a route based on if a feature is accessible
 * Use the data property of the route to define the required feature
 * https://stackoverflow.com/a/42721468
 *
 * @example
 *  const routes: Routes = [{
      path: '',
      component: SomeComponent,
      data: {
        featureGuard: {key: 'some_feature'}
      },
      canActivate: [FeatureGuard]
 *  }];
 * @export
 * @class FeatureGuard
 * @implements {CanActivate}
 */
@Injectable()
export class FeatureGuard implements CanActivate {
  constructor(
    private store: Store<fromUserPermissionList.State>,
    private userPermissionService: UserPermissionsService,
    private router: Router
  ) {} // uses the parent class instance actually, but could in theory take any other deps

  canActivate(route: ActivatedRouteSnapshot, _state: RouterStateSnapshot): Observable<boolean> {
    const options = (route.data[FEATURE_GUARD_DATA_PROPERTY] as FeatureGuardOptions) || {};

    // checks typical activation (auth) + custom features
    return this.store.pipe(
      select(authSelectors.getIsLoggedIn),
      combineLatest(this.checkPermissions(options.key)),
      map(allowedArray => {
        return !allowedArray.includes(false); // not allowed if any result is false
      }),
      tap(allowed => {
        if (!allowed && !this.router.navigated) {
          // If we haven't navigated yet, this is a deeplink. Redirect to base
          // if we have navigated, just don't allow this navigation (ie. do nothing)
          this.router.navigate(['/']);
        }
      })
    );
  }

  checkPermissions(featureKey: string): Observable<boolean> {
    if (!featureKey) {
      return of(true);
    }
    return this.store.pipe(
      select(userPermissionListSelectors.getUserPermissionListLoaded),
      map(permsLoaded => {
        if (!permsLoaded) {
          this.store.pipe(select(authSelectors.getADUser)).pipe(
            map(user => {
              return this.store.dispatch(new userPermissionListActions.LoadById(user.profile.oid));
            })
          );
          return false;
        }
        return true;
      }),
      filter(loaded => !!loaded),
      take(1),
      switchMap(() => this.userPermissionService.hasFeatureAsync(featureKey))
    );
  }
}
