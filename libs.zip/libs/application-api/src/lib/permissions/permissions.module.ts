import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IfFeatureDirective } from './directives/if-feature.directive';
import { UserPermissionsService } from './services/user-permissions.service';
import { IfFeatureAsyncDirective } from './directives/if-feature-async.directive';
import { IfNotFeatureDirective } from './directives/if-not-feature.directive';
import { IfNotFeatureAsyncDirective } from './directives/if-not-feature-async.directive';
import { FeatureGuard } from './guards/feature.guard';
@NgModule({
  imports: [CommonModule],
  providers: [UserPermissionsService, FeatureGuard],
  declarations: [
    IfFeatureDirective,
    IfFeatureAsyncDirective,
    IfNotFeatureDirective,
    IfNotFeatureAsyncDirective
  ],
  exports: [
    IfFeatureDirective,
    IfFeatureAsyncDirective,
    IfNotFeatureDirective,
    IfNotFeatureAsyncDirective
  ]
})
export class PermissionsModule {}
