import { TestBed, inject } from '@angular/core/testing';
import { StoreModule } from '@ngrx/store';
import { fromAuth } from '@content-platform/auth';
import { fromUserPermissionList, fromApplication } from '../../reducers';
import { Permission, Application, Feature } from '../../models';
import { UserPermissionsService } from './user-permissions.service';
import { ApplicationApiConstants } from '../../application-api-config';
import { take } from 'rxjs/operators';

const mockFeatures: Feature[] = [
  { id: 1, name: 'Feature One', key: 'feat_one', metadataConfig: null },
  {
    id: 2,
    name: 'Feature Two',
    key: 'feat_two',
    metadataConfig: { type: 'string', dataset: null, allowMultiple: false }
  },
  { id: 3, name: 'Feature Three', key: 'feat_three', metadataConfig: null }
];

const mockPermissions: Permission[] = [
  { id: 11, feature: mockFeatures[0], metadata: null },
  { id: 12, feature: mockFeatures[1], metadata: [{ name: 'someMetadata', description: '' }] }
];

const mockApps: Application[] = [
  { id: 101, name: 'App 1', features: [mockFeatures[0], mockFeatures[2]] },
  { id: 102, name: 'App 2', features: [mockFeatures[1]] },
  { id: 103, admin: true, name: 'App 3', features: [mockFeatures[0], mockFeatures[2]] },
  { id: 104, admin: false, name: 'App 4', features: [mockFeatures[1]] }
];

describe('UserPermissionsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot(
          {
            auth: fromAuth.authReducer,
            userPermissionList: fromUserPermissionList.reducer,
            application: fromApplication.reducer
          },
          {
            initialState: {
              auth: {
                ...fromAuth.INITIAL_STATE,
                user: { userName: 'test', profile: { objectId: 'userid', oid: 'userid' } }
              },
              userPermissionList: {
                ...fromUserPermissionList.INIT_STATE,
                entities: {
                  userid: { uuid: 'userid', permissions: mockPermissions, applications: mockApps }
                }
              },
              application: fromApplication.INIT_STATE
            }
          }
        )
      ],
      providers: [UserPermissionsService]
    });
    ApplicationApiConstants.activeAppName = 'Test';
  });

  it('should be created', inject([UserPermissionsService], (service: UserPermissionsService) => {
    expect(service).toBeTruthy();
  }));

  it('should be able to check if a feature is accessible ', inject(
    [UserPermissionsService],
    (service: UserPermissionsService) => {
      expect(service.hasFeature('feat_one')).toBeTruthy();
      expect(service.hasFeature('not_a_feat')).toBeFalsy();
    }
  ));

  it('should be able to check if an app is accessible ', inject(
    [UserPermissionsService],
    (service: UserPermissionsService) => {
      expect(service.canAccessApp(101)).toBeTruthy();
      expect(service.canAccessApp(999)).toBeFalsy();
    }
  ));

  it('should be able to check if user is admin on an app', inject(
    [UserPermissionsService],
    (service: UserPermissionsService) => {
      expect(service.canAccessAdminApp(103)).toBeTruthy();
      expect(service.canAccessAdminApp(104)).toBeFalsy();
    }
  ));

  it('should be able to return an observable for a feature', inject(
    [UserPermissionsService],
    (service: UserPermissionsService) => {
      service
        .hasFeatureAsync('feat_one')
        .pipe(take(1))
        .subscribe(accessible => expect(accessible).toBeTruthy());
      service
        .hasFeatureAsync('feat_three')
        .pipe(take(1))
        .subscribe(accessible => expect(accessible).toBeFalsy());
    }
  ));

  it('should be able to return a features metadata', inject(
    [UserPermissionsService],
    (service: UserPermissionsService) => {
      expect(service.getFeatureMetadataList('feat_one')).toEqual([]);
      expect(service.getFeatureMetadataList('feat_two')).toEqual([
        { name: 'someMetadata', description: '' }
      ]);
      expect(service.getFeatureMetadataList('bad_feature_name')).toEqual([]);
    }
  ));

  it('should be able to return a features metadata with an observable', inject(
    [UserPermissionsService],
    (service: UserPermissionsService) => {
      service
        .getFeatureMetadataListAsync('feat_one')
        .pipe(take(1))
        .subscribe(metadata => expect(metadata).toEqual([]));
      service
        .getFeatureMetadataListAsync('feat_two')
        .pipe(take(1))
        .subscribe(metadata =>
          expect(metadata).toEqual([{ name: 'someMetadata', description: '' }])
        );
      service
        .getFeatureMetadataListAsync('bad_feature_name')
        .pipe(take(1))
        .subscribe(metadata => expect(metadata).toEqual([]));
    }
  ));

  describe('admin true with activeApp', () => {
    beforeEach(() => {
      ApplicationApiConstants.activeAppName = 'App 3';
    });

    it('should have access to any feature if the admin is true with the active app', inject(
      [UserPermissionsService],
      (service: UserPermissionsService) => {
        service
          .hasFeatureAsync('feat_one')
          .pipe(take(1))
          .subscribe(accessible => expect(accessible).toBeTruthy());
        service
          .hasFeatureAsync('feat_three')
          .pipe(take(1))
          .subscribe(accessible => expect(accessible).toBeTruthy());
        service
          .hasFeatureAsync('not_a_feat')
          .pipe(take(1))
          .subscribe(accessible => expect(accessible).toBeTruthy());
      }
    ));

    afterEach(() => {
      ApplicationApiConstants.activeAppName = undefined;
    });
  });
});
