import { map, switchMap, combineLatest } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { Store, select } from '@ngrx/store';

import { Permission, PermissionMetadata, Application } from '../../models';
import { userPermissionListSelectors } from '../../selectors';
import { State } from '../../reducers/user-permission-list';

import { Subscription, Observable, of } from 'rxjs';
import { flatten, uniqBy } from 'lodash';

@Injectable()
export class UserPermissionsService {
  private static userPermissions: Permission[];
  private static userApplications: Application[];
  private static userAdminApplications: Application[];
  private static activeApplication: Application;
  private static userPermListSubscription: Subscription;
  private static userAppListSubscription: Subscription;
  private static userAppAdminListSubscription: Subscription;
  private static activeAppSubscription: Subscription;

  constructor(private store: Store<State>) {
    if (!UserPermissionsService.userPermListSubscription) {
      UserPermissionsService.userPermListSubscription = this.store
        .pipe(select(userPermissionListSelectors.getUserPermissions))
        .subscribe(userPerms => (UserPermissionsService.userPermissions = userPerms));
    }
    if (!UserPermissionsService.userAppAdminListSubscription) {
      UserPermissionsService.userAppAdminListSubscription = this.store
        .pipe(select(userPermissionListSelectors.getUserAdminApplications))
        .subscribe(userApps => (UserPermissionsService.userAdminApplications = userApps));
    }
    if (!UserPermissionsService.userAppListSubscription) {
      UserPermissionsService.userAppListSubscription = this.store
        .pipe(select(userPermissionListSelectors.getUserApplications))
        .subscribe(userApps => (UserPermissionsService.userApplications = userApps));
    }
    if (!UserPermissionsService.activeAppSubscription) {
      UserPermissionsService.activeAppSubscription = this.store
        .pipe(select(userPermissionListSelectors.getActiveApplication))
        .subscribe(activeApp => (UserPermissionsService.activeApplication = activeApp));
    }
  }

  hasFeature(featureKey: string): boolean {
    if (UserPermissionsService.activeApplication) {
      return (
        this.canAccessAdminApp(UserPermissionsService.activeApplication.id) ||
        !!UserPermissionsService.userPermissions.find(perm => perm.feature.key === featureKey)
      );
    }
    return !!UserPermissionsService.userPermissions.find(perm => perm.feature.key === featureKey);
  }

  hasFeatureAsync(featureKey: string): Observable<boolean> {
    return this.store.pipe(
      select(userPermissionListSelectors.getUserPermissions),
      combineLatest(this.store.pipe(select(userPermissionListSelectors.getActiveApplication))),
      switchMap(([permissions, activeApp]) => {
        if (activeApp) {
          return this.canAccessAdminAppAsync(activeApp.id).pipe(
            map(accessApp => {
              return (
                accessApp || !!permissions.find(permission => permission.feature.key === featureKey)
              );
            })
          );
        }
        return of(!!permissions.find(permission => permission.feature.key === featureKey));
      })
    );
  }

  /**
   * Gets a condensed (no duplicate) list of permissions, with metadata concatenated together
   *
   * @returns {Observable<Permission[]>}
   * @memberof UserPermissionsService
   */
  condensedUserPermissions(): Observable<Permission[]> {
    return this.store.pipe(
      select(userPermissionListSelectors.getUserPermissions),
      map(permissions => {
        const condensedPermissions: Permission[] = [];
        permissions.forEach(perm => {
          const existingPermission = condensedPermissions.find(
            cPerm => cPerm.feature.id === perm.feature.id
          );
          if (existingPermission) {
            if (existingPermission.metadata && perm.metadata) {
              existingPermission.metadata = [...existingPermission.metadata, ...perm.metadata];
            }
          } else {
            condensedPermissions.push(perm);
          }
        });
        return condensedPermissions;
      })
    );
  }

  private permissionsToMetadataList(
    permissions: Permission[],
    removeDuplicates: boolean = true
  ): PermissionMetadata[] {
    if (!permissions || permissions.length === 0) {
      return [];
    }

    const filteredPermissions =
      permissions.filter(permission => permission.metadata && permission.metadata.length > 0) || [];

    const flatArray = flatten(filteredPermissions.map(permission => permission.metadata)).filter(
      metadata => !!metadata
    );
    if (removeDuplicates) {
      return uniqBy(flatArray, 'name');
    } else {
      return flatArray;
    }
  }

  getFeatureMetadataList(
    featureKey: string,
    removeDuplicates: boolean = true
  ): Array<PermissionMetadata> {
    const permissionsForFeature = UserPermissionsService.userPermissions.filter(
      perm => perm.feature.key === featureKey
    );

    return this.permissionsToMetadataList(permissionsForFeature, removeDuplicates);
  }

  getFeatureMetadataListAsync(
    featureKey: string,
    removeDuplicates: boolean = true
  ): Observable<Array<PermissionMetadata>> {
    return this.store.pipe(
      select(userPermissionListSelectors.getUserPermissions),
      switchMap(permissions => {
        const permissionsForFeature = (permissions as Array<Permission>).filter(
          perm => perm.feature.key === featureKey
        );
        return of(this.permissionsToMetadataList(permissionsForFeature, removeDuplicates));
      })
    );
  }

  canAccessApp(appId: number): boolean {
    return !!UserPermissionsService.userApplications.find(app => app.id === appId);
  }

  canAccessAppAsync(appId: number): Observable<boolean> {
    return this.store.pipe(
      select(userPermissionListSelectors.getUserApplications),
      switchMap(apps => of(!!apps.find(app => app.id === appId)))
    );
  }

  canAccessAdminApp(appId: number): boolean {
    return !!UserPermissionsService.userAdminApplications.find(app => app.id === appId);
  }

  canAccessAdminAppAsync(appId: number): Observable<boolean> {
    return this.store.pipe(
      select(userPermissionListSelectors.getUserAdminApplications),
      switchMap(apps => of(!!apps.find(app => app.id === appId)))
    );
  }
}
