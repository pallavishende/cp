import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { Application } from '../models';
import { applicationActions } from '../actions';
import { APPLICATIONS_DATA } from '../registry/application-data';
import { DASHBOARD_APP_NAME } from '../constants';

export const applicationAdapter = createEntityAdapter<Application>({
  selectId: (item: Application) => item.id,
  sortComparer: sortApplicationsByNameWithHomeFirst
});

export interface State extends EntityState<Application> {
  loading: boolean;
  loaded: boolean;
}

export const INIT_STATE: State = applicationAdapter.getInitialState({
  loading: false,
  loaded: false
});

function getHomeAppFromRegistry(): Application {
  return APPLICATIONS_DATA.find(app => app.name === DASHBOARD_APP_NAME) as Application;
}

export function addHomeAppIfNotThere(apps: Application[]) {
  let userApps: Application[] = apps || [];
  if (!userApps.find(app => app.name === DASHBOARD_APP_NAME)) {
    userApps = [getHomeAppFromRegistry(), ...userApps];
  }
  return userApps;
}

export function sortApplicationsByNameWithHomeFirst(a: Application, b: Application): number {
  if (a.name === DASHBOARD_APP_NAME) {
    return -1;
  }
  if (b.name === DASHBOARD_APP_NAME) {
    return 1;
  }
  return a.name.localeCompare(b.name);
}

export function reducer(state = INIT_STATE, action: applicationActions.All) {
  switch (action.type) {
    case applicationActions.LOAD: {
      return {
        ...state,
        loading: true,
        loaded: false
      };
    }
    case applicationActions.LOAD_SUCCESS: {
      return {
        ...applicationAdapter.addAll(action.payload as Application[], state),
        loading: false,
        loaded: true
      };
    }
    case applicationActions.UPDATE_SUCCESS: {
      return applicationAdapter.updateOne(
        {
          id: action.payload.id,
          changes: action.payload
        },
        state
      );
    }
    case applicationActions.CREATE_SUCCESS: {
      return applicationAdapter.addOne(action.payload, state);
    }
    case applicationActions.DELETE_SUCCESS: {
      return applicationAdapter.removeOne(action.payload, state);
    }
    case applicationActions.LOAD_FAILED: {
      return { ...state, loading: false, loaded: false };
    }
    case applicationActions.CREATE_FAILED:
    case applicationActions.DELETE_FAILED:
    case applicationActions.UPDATE_FAILED: {
      return { ...state, loading: false };
    }
    default: {
      return state;
    }
  }
}
export const getApplicationsLoading = (state: State) => state.loading;
export const getApplicationsLoaded = (state: State) => state.loaded;
