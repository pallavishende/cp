import * as fromApplication from './application';
import * as fromRole from './role';
import * as fromUserRoleList from './user-role-list';
import * as fromUserPermissionList from './user-permission-list';

export interface ApplicationsState {
  application: fromApplication.State;
  role: fromRole.State;
  userRoleList: fromUserRoleList.State;
  userPermissionList: fromUserPermissionList.State;
}

export { fromApplication, fromRole, fromUserRoleList, fromUserPermissionList };
