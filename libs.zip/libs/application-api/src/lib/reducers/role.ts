import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { Role } from '../models';
import { roleActions } from '../actions';

export const roleAdapter = createEntityAdapter<Role>({
  selectId: (item: Role) => item.id,
  sortComparer: sortByName
});

export interface State extends EntityState<Role> {
  loaded: boolean;
  loading: boolean;
}

export const INIT_STATE: State = roleAdapter.getInitialState({
  loaded: false,
  loading: false
});

export function sortByName(a: Role, b: Role): number {
  return a.name.localeCompare(b.name);
}

export function reducer(state = INIT_STATE, action: roleActions.All) {
  switch (action.type) {
    case roleActions.LOAD: {
      return {
        ...state,
        loading: true
      };
    }
    case roleActions.LOAD_SUCCESS: {
      return {
        ...roleAdapter.addAll(action.payload as Role[], state),
        loaded: true,
        loading: false
      };
    }
    case roleActions.LOAD_FAILED: {
      return {
        ...state,
        loaded: false,
        loading: false
      };
    }
    case roleActions.UPDATE_SUCCESS: {
      return roleAdapter.updateOne(
        {
          id: action.payload.id,
          changes: action.payload
        },
        state
      );
    }
    case roleActions.CREATE_SUCCESS: {
      return roleAdapter.addOne(action.payload, state);
    }
    case roleActions.DELETE_SUCCESS: {
      return roleAdapter.removeOne(action.payload, state);
    }
    case roleActions.CREATE_FAILED:
    case roleActions.DELETE_FAILED:
    case roleActions.UPDATE_FAILED: {
      return { ...state, loading: false };
    }
    default: {
      return state;
    }
  }
}

export const getRolesLoaded = (state: State) => state.loaded;
export const getRolesLoading = (state: State) => state.loading;
