import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { UserPermissionList } from '../models';
import { userPermissionListActions } from '../actions';
import { sortApplicationsByNameWithHomeFirst, addHomeAppIfNotThere } from './application';

export const NON_PRODUCTION_APPS = ['Sandbox'];

export const userPermissionListAdapter = createEntityAdapter<UserPermissionList>({
  selectId: (item: UserPermissionList) => item.uuid,
  sortComparer: false
});

export interface State extends EntityState<UserPermissionList> {
  loaded: boolean;
  loading: boolean;
}

export const INIT_STATE: State = userPermissionListAdapter.getInitialState({
  loaded: false,
  loading: false
});

export function reducer(state = INIT_STATE, action: userPermissionListActions.All) {
  switch (action.type) {
    case userPermissionListActions.LOAD_BY_ID: {
      return {
        ...state,
        loading: true
      };
    }
    case userPermissionListActions.LOAD_BY_ID_SUCCESS: {
      const sortedPayload = {
        ...action.payload,
        applications: addHomeAppIfNotThere(
          action.payload.applications.sort(sortApplicationsByNameWithHomeFirst)
        )
      };
      return {
        ...userPermissionListAdapter.upsertOne(sortedPayload, state),
        loaded: true,
        loading: false
      };
    }

    case userPermissionListActions.LOAD_BY_ID_FAILED: {
      return {
        ...state,
        loaded: false,
        loading: false
      };
    }

    default: {
      return state;
    }
  }
}

export const getUserPermissionListLoading = (state: State) => state.loading;
export const getUserPermissionListLoaded = (state: State) => state.loaded;
