import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { UserRoleList } from '../models';
import { userRoleListActions } from '../actions';

export const userRoleListAdapter = createEntityAdapter<UserRoleList>({
  selectId: (item: UserRoleList) => item.uuid,
  sortComparer: false
});

export interface State extends EntityState<UserRoleList> {
  loaded: boolean;
  loading: boolean;
}

export const INIT_STATE: State = userRoleListAdapter.getInitialState({
  loaded: false,
  loading: false
});

export function reducer(state = INIT_STATE, action: userRoleListActions.All) {
  switch (action.type) {
    case userRoleListActions.LOAD_BY_ID: {
      return {
        ...state,
        loading: true
      };
    }
    case userRoleListActions.LOAD_BY_ID_SUCCESS: {
      return {
        ...userRoleListAdapter.upsertOne(action.payload, state),
        loaded: true,
        loading: false
      };
    }
    case userRoleListActions.LOAD_FAILED: {
      return {
        ...state,
        loaded: false,
        loading: false
      };
    }
    case userRoleListActions.UPDATE_SUCCESS: {
      return userRoleListAdapter.updateOne(
        {
          id: action.payload.uuid,
          changes: action.payload
        },
        state
      );
    }
    case userRoleListActions.CREATE_FAILED:
    case userRoleListActions.DELETE_FAILED:
    case userRoleListActions.UPDATE_FAILED: {
      return { ...state, loading: false };
    }
    default: {
      return state;
    }
  }
}

export const getUserRoleListLoaded = (state: State) => state.loaded;
export const getUserRoleListLoading = (state: State) => state.loading;
