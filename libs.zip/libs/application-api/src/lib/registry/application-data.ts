import { DASHBOARD_APP_NAME } from '../constants';

export const APPLICATIONS_DATA = [
  {
    name: DASHBOARD_APP_NAME,
    imgUrl: '/assets/dashboard-icon.png',
    url: '/index.html'
  },
  {
    name: 'Global Entry',
    imgUrl: '/assets/ge-icon.png',
    imgUrlLrg: '/assets/ge-icon-med.png',
    url: '/global-entry/index.html',
    color: '#45617c'
  },
  {
    name: 'Administration',
    imgUrl: '/assets/administration-icon.png',
    imgUrlLrg: '/assets/administration-icon-med.png',
    url: '/administration/index.html',
    color: '#4c7ea3'
  },
  {
    name: 'Sandbox',
    imgUrl: '/assets/sandbox-icon.png',
    url: '/sandbox/index.html',
    color: '#de8c42'
  },
  {
    name: 'Global Application',
    imgUrl: '/assets/global-icon.png',
    url: '',
    color: '#B0B3B5',
    comingSoon: false,
    global: true
  },
  {
    name: 'Endpoint Profile Database',
    imgUrl: '/assets/epd-icon.png',
    url: '/endpoint-profile-db/index.html',
    color: '#45617c'
  },
  {
    name: 'VMS Web',
    imgUrl: '/assets/vms-icon.png',
    url: 'https://mediaservices.viacom.com/',
    color: '#132841',
    external: true
  },
  {
    name: 'ARC Config',
    imgUrl: '/assets/arc-icon.png',
    url: '/arc-config/index.html',
    color: '#5F97FB'
  },
  {
    name: 'Registration & Enrichment Requests',
    imgUrl: '/assets/content-registration-icon.png',
    url: '/content-registration/index.html',
    color: '#01575D'
  },
  {
    name: 'Universal Workflow Dashboard',
    imgUrl: '/assets/uwf-icon.png',
    color: '#58487e',
    url: '/uwf-dashboard/index.html'
  },
  {
    name: 'Partner Distribution Platform',
    imgUrl: '/assets/common-icon.png',
    color: '#4c7ea3',
    url: '/pdp/index.html'
  },
  {
    name: 'Universal Metadata Transformation Service',
    imgUrl: '/assets/common-icon.png',
    color: '#4c7ea3',
    url: '/umts/index.html'
  },
  {
    name: 'Content catalog',
    imgUrl: '/assets/content-catalog.png',
    color: '#673ab7',
    url: '/content-catalog/index.html'
  }
];

/* For future use for other applications colors
  ['Content View']: '#008ba3',
  ['Video Logger']: '#5d616d',
  ['Collections']: '#20496c'
*/
