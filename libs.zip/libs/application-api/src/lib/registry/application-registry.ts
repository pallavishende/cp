import { Injectable } from '@angular/core';
import { Registry } from './registry';
import { APPLICATIONS_DATA } from './application-data';
import { DASHBOARD_APP_NAME } from '../constants';

export interface ExtraApplicationData {
  name: string | RegExp;
  url: string;
  icon?: string;
  imgUrl?: string;
  imgUrlLrg?: string;
  external?: boolean;
  comingSoon?: boolean;
  global?: boolean;
}

@Injectable()
export class ApplicationRegistry extends Registry<ExtraApplicationData> {
  constructor() {
    super(APPLICATIONS_DATA);
  }

  getGlobal(): ExtraApplicationData {
    return APPLICATIONS_DATA.find(app => app.global === true);
  }

  getHomeApp(): ExtraApplicationData {
    return APPLICATIONS_DATA.find(app => app.name === DASHBOARD_APP_NAME);
  }
}
