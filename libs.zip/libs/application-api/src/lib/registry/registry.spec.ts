import { Registry } from './registry';

export class ApplicationRegistry extends Registry<{ name: string | RegExp }> {
  constructor() {
    super([{ name: 'test' }, { name: /regex/ }]);
  }
}

describe('Registry', () => {
  let registry: ApplicationRegistry;

  beforeEach(() => {
    registry = new ApplicationRegistry();
  });

  it('should be created', () => {
    expect(registry).toBeTruthy();
  });

  describe('get', () => {
    it('should get value with matching name as string, case insensitive', () => {
      expect(registry.get('test')).toEqual({ name: 'test' });
      expect(registry.get('Test')).toEqual({ name: 'test' });
      expect(registry.get('Diff Test')).not.toBeDefined();
    });

    it('should get value with matching name using regex as well, case insensitive', () => {
      expect(registry.get('regex')).toBeDefined();
      expect(registry.get('notRgex')).not.toBeDefined();
      expect(registry.get('REGex')).toBeDefined();
    });
  });
});
