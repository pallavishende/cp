import { extend } from 'lodash';

export interface RegistryOptions {
  matchKey: string;
}

const defaultOptions: RegistryOptions = {
  matchKey: 'name'
};

export abstract class Registry<DataType> {
  constructor(private dataList: DataType[], private options?: RegistryOptions) {
    this.options = extend({}, defaultOptions, this.options);
  }

  get(name: string): DataType {
    for (const appData of this.dataList) {
      if (appData[this.options.matchKey] instanceof RegExp) {
        if (this.compareRegExp(<RegExp>appData[this.options.matchKey], name)) {
          return appData;
        }
      } else if (this.compareString(<string>appData[this.options.matchKey], <string>name)) {
        return appData;
      }
    }
    return;
  }

  private compareString(match: string, value: string) {
    return match.toLowerCase() === value.toLowerCase();
  }

  private compareRegExp(match: RegExp, value: string) {
    return RegExp(match, 'i').test(value);
  }
}
