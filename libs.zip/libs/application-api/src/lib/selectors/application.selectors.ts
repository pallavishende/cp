import { createFeatureSelector, createSelector } from '@ngrx/store';
import { fromApplication } from '../reducers';
import { getAllRoleItems } from './role.selectors';
import { UserProfile } from '@content-platform/graph-api';

export const getApplicationRootState = createFeatureSelector<fromApplication.State>('application');
export const getApplicationState = createSelector(
  getApplicationRootState,
  state => state
);

export const {
  selectAll: getAllApplicationItems,
  selectEntities: getApplicationEntities
} = fromApplication.applicationAdapter.getSelectors(getApplicationState);

/**
 * Selector to return the loaded property of the state
 */
export const getApplicationsLoaded = createSelector(
  getApplicationState,
  fromApplication.getApplicationsLoaded
);

/**
 * Selector to return the loading property of the state
 */
export const getApplicationsLoading = createSelector(
  getApplicationState,
  fromApplication.getApplicationsLoading
);

export const getApplicationUsers = id =>
  createSelector(
    getApplicationEntities,
    getAllRoleItems,
    (appEntities, roleItems) => {
      const app = appEntities[id];
      const users: { [type: string]: { userProfile: UserProfile; roleNames: string[] } } = {};
      for (const role of roleItems) {
        const foundAppAsAdmin = role.applicationAdminPrivileges.find(
          appPriviledge => appPriviledge.id === app.id
        );
        const hasPermissions =
          role.permissions.filter(rolePermission =>
            app.features.map(feature => feature.id).includes(rolePermission.feature.id)
          ).length > 0;

        // Does role have admin priviledges on an app or 1 or more permissions, then
        // users would have access to the app (i.e. active user).
        if (foundAppAsAdmin || hasPermissions) {
          for (const userProfile of <UserProfile[]>role.users) {
            users[userProfile.objectId] = users[userProfile.objectId] || {
              userProfile,
              roleNames: []
            };
            users[userProfile.objectId].roleNames.push(role.name);
          }
        }
      }

      return Object.keys(users).map(userId => users[userId]);
    }
  );
