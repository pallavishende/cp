import { createFeatureSelector, createSelector } from '@ngrx/store';

import { fromRole } from '../reducers';

export const getRoleRootState = createFeatureSelector<fromRole.State>('role');
export const getRoleState = createSelector(getRoleRootState, state => state);

export const {
  selectAll: getAllRoleItems,
  selectEntities: getRoleEntities
} = fromRole.roleAdapter.getSelectors(getRoleState);

/**
 * Selector to return the loaded property of the state
 */
export const getRolesLoaded = createSelector(getRoleState, fromRole.getRolesLoaded);
export const getRolesLoading = createSelector(getRoleState, fromRole.getRolesLoading);
