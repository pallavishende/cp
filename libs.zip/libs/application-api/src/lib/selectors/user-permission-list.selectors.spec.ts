import { TestBed } from '@angular/core/testing';
import { Store, StoreModule, select } from '@ngrx/store';
import { userPermissionListActions, applicationActions } from '../actions';
import { Application } from '../models';
import { fromApplication, fromUserPermissionList, fromUserRoleList } from '../reducers';
import { userPermissionListSelectors } from '../selectors';
import { ApplicationApiConstants } from '../application-api-config';

describe('User Permission List Selectors', () => {
  let store: Store<{
    application: fromApplication.State;
    userRoleList: fromUserRoleList.State;
    userPermissionList: fromUserPermissionList.State;
  }>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot(
          {
            application: fromApplication.reducer,
            userRoleList: fromUserRoleList.reducer,
            userPermissionList: fromUserPermissionList.reducer,
            auth: state => state
          },
          {
            initialState: {
              application: fromApplication.INIT_STATE,
              userPermissionList: fromUserPermissionList.INIT_STATE,
              auth: { user: { userName: 'test', profile: { oid: 'uuid' } } },
              userRoleList: fromUserRoleList.INIT_STATE
            }
          }
        )
      ]
    });

    store = TestBed.get(Store);

    spyOn(store, 'dispatch').and.callThrough();
  });

  describe('getActiveApplication', () => {
    it('should return active application if list of user permission apps', () => {
      let result;

      store.pipe(select(userPermissionListSelectors.getActiveApplication)).subscribe(value => {
        result = value;
      });

      expect(result).toEqual(undefined);

      const apps = [{ id: 1, name: 'App' }, { id: 2, name: 'Other App' }] as Application[];

      ApplicationApiConstants.activeAppName = 'Other App';
      expect(result).not.toBeDefined();
      store.dispatch(
        new userPermissionListActions.LoadByIdSuccess({
          uuid: 'uuid',
          permissions: [],
          applications: apps
        })
      );

      expect(result).toEqual(apps[1]);
    });

    it('should return active application if list of applications exists', () => {
      let result;

      store.pipe(select(userPermissionListSelectors.getActiveApplication)).subscribe(value => {
        result = value;
      });

      expect(result).toEqual(undefined);

      const apps = [
        { id: 1, features: [], name: 'App' },
        { id: 2, features: [], name: 'Other App' }
      ] as Application[];

      ApplicationApiConstants.activeAppName = 'Other App';
      expect(result).not.toBeDefined();
      store.dispatch(new applicationActions.LoadSuccess(apps));

      expect(result).toEqual(apps[1]);
    });
  });

  describe('getUserApplications', () => {
    it('should always start with home app...', () => {
      let result;

      store.pipe(select(userPermissionListSelectors.getUserApplications)).subscribe(value => {
        result = value;
      });

      const apps = [
        { id: 1, features: [], name: 'App' },
        { id: 2, features: [], name: 'Other App' }
      ] as Application[];
      store.dispatch(
        new userPermissionListActions.LoadByIdSuccess({
          uuid: 'uuid',
          permissions: [],
          applications: apps
        })
      );
      expect(result.length).toBe(3);
      expect(result[0].name).toEqual('Home');
    });
  });
});
