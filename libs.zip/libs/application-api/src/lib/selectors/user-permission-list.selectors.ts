import { createFeatureSelector, createSelector } from '@ngrx/store';
import { Application, UserPermissionList } from '../models';
import { fromUserPermissionList } from '../reducers';
import { getAllApplicationItems } from './application.selectors';
import { ApplicationApiConstants } from '../application-api-config';
import { authSelectors } from '@content-platform/auth';

export const getUserPermissionListRootState = createFeatureSelector<fromUserPermissionList.State>(
  'userPermissionList'
);
export const getUserPermissionListState = createSelector(
  getUserPermissionListRootState,
  state => state
);

export const {
  selectAll: getAllUserPermissionListItems,
  selectEntities: getUserPermissionListEntities
} = fromUserPermissionList.userPermissionListAdapter.getSelectors(getUserPermissionListState);

export const getUserPermissionListLoading = createSelector(
  getUserPermissionListState,
  fromUserPermissionList.getUserPermissionListLoading
);

/**
 * Selector to return the permission list for the current user
 */
export const getCurrentUserPermissionList = createSelector(
  getUserPermissionListEntities,
  authSelectors.getUserId,
  (userPermissionListEntities, userId) => {
    if (userId) {
      return userPermissionListEntities[userId] as UserPermissionList;
    }
    return undefined;
  }
);

/**
 * Selector to return if the current users permissions list has been loaded
 */
export const getUserPermissionListLoaded = createSelector(
  getCurrentUserPermissionList,
  getUserPermissionListState,
  (permList: UserPermissionList) => !!permList
);

export const getActiveApplicationName = createSelector(
  getUserPermissionListState,
  () => ApplicationApiConstants.activeAppName
);

export const getActiveApplicationId = createSelector(
  getActiveApplicationName,
  appName => {
    return (appName || '').replace(' ', '-').toLowerCase();
  }
);

/**
 * Selector to return the applications that the user can access and set the active application
 */
export const getActiveApplication = createSelector(
  getCurrentUserPermissionList,
  getAllApplicationItems,
  (userPermListEntity, applications: Application[]) => {
    const activeAppName = ApplicationApiConstants.activeAppName;
    let activeApp;
    if (userPermListEntity && userPermListEntity.applications && activeAppName) {
      activeApp = userPermListEntity.applications.find(app => app.name === activeAppName);
    }
    if (!activeApp && applications && activeAppName) {
      activeApp = applications.find(app => app.name === activeAppName);
    }
    return activeApp;
  }
);

/**
 * Selector to return the applications that the user can access and set the active application
 */
export const getUserApplications = createSelector(
  getCurrentUserPermissionList,
  getActiveApplication,
  (userPermListEntity, activeApplication: Application) => {
    if (userPermListEntity) {
      return (userPermListEntity.applications || [])
        .filter(
          app =>
            !(
              fromUserPermissionList.NON_PRODUCTION_APPS.includes(app.name) &&
              ApplicationApiConstants.production
            )
        )
        .map(app => {
          return { ...app, isActive: app === activeApplication };
        });
    }
    return [];
  }
);

/**
 * Selector to return the applications that the user can access and set the active application
 */
export const getDisplayableUserApplications = createSelector(
  getUserApplications,
  getActiveApplication,
  (userApps, activeApplication: Application) => {
    const activeAppName = activeApplication ? activeApplication.name : '';
    return userApps.filter(app => app.name !== activeAppName && !app.comingSoon && !app.global);
  }
);

/**
 * Selector to return the applications that the user can access and set the active application
 */
export const getUserAdminApplications = createSelector(
  getUserApplications,
  (userApplications: Application[]) => {
    if (userApplications) {
      return userApplications.filter(app => {
        if (app) {
          return app.admin;
        }
        return false;
      });
    }
    return [];
  }
);

/**
 * Selector to return the permission that the user can access.
 */
export const getUserPermissions = createSelector(
  getCurrentUserPermissionList,
  userPermListEntity => {
    if (userPermListEntity) {
      return userPermListEntity.permissions;
    }
    return [];
  }
);

/**
 * Selector to return is the user has any available permission(s).
 */
export const hasUserPermission = createSelector(
  getCurrentUserPermissionList,
  getUserApplications,
  (userPermListEntity, userApplications) => {
    if (userPermListEntity) {
      return (
        userPermListEntity.permissions.length > 0 ||
        userApplications.filter(application => application.admin).length > 0
      );
    }
    return false;
  }
);
