import { TestBed } from '@angular/core/testing';
import { StoreModule, Store, select } from '@ngrx/store';

import { fromApplication, fromUserRoleList } from '../reducers';
import { userRoleListActions } from '../actions';
import { userRoleListSelectors } from '../selectors';
import { UserRoleList } from '@content-platform/application-api';

describe('User Selectors', () => {
  let store: Store<{ appliction: fromApplication.State; userRoleList: fromUserRoleList.State }>;

  const userRoleList: UserRoleList = <UserRoleList>{
    uuid: 'userid',
    roles: [
      {
        name: 'Role Alpha',
        id: 1,
        permissions: [{ id: 1, feature: { name: 'feat 1', key: 'feat_1', id: 1 } }]
      },
      {
        name: 'Role Beta',
        id: 2,
        permissions: [{ id: 2, feature: { name: 'feat 3', key: 'feat_3', id: 3 } }]
      },
      {
        name: 'Gamma Role',
        id: 3,
        permissions: [{ id: 3, feature: { name: 'feat 3', key: 'feat_3', id: 3 } }]
      }
    ]
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot(
          {
            application: fromApplication.reducer,
            userRoleList: fromUserRoleList.reducer,
            auth: state => state
          },
          {
            initialState: {
              application: fromApplication.INIT_STATE,
              auth: { user: { userName: 'test', profile: { oid: 'userid' } } },
              userRoleList: fromUserRoleList.INIT_STATE
            }
          }
        )
      ]
    });

    store = TestBed.get(Store);

    spyOn(store, 'dispatch').and.callThrough();
  });

  describe('getPermissions', () => {
    it('should return user permissions', () => {
      let result;

      store.pipe(select(userRoleListSelectors.getUserPermissions)).subscribe(value => {
        result = value;
      });

      expect(result).toEqual(undefined);

      store.dispatch(new userRoleListActions.LoadByIdSuccess(userRoleList));

      expect(result.length).toEqual(3);
      const permIds = result.map(perm => perm.id);

      expect(permIds).toEqual([1, 2, 3]);
    });
  });

  describe('getActiveUserRoleNames', () => {
    it('should return user role names alphabetically', () => {
      let result;

      store.pipe(select(userRoleListSelectors.getActiveUserRoleNames)).subscribe(value => {
        result = value;
      });

      expect(result.length).toEqual(0);
      store.dispatch(new userRoleListActions.LoadByIdSuccess(userRoleList));

      expect(result.length).toEqual(3);

      expect(result).toEqual(['Gamma Role', 'Role Alpha', 'Role Beta']);
    });
  });
});
