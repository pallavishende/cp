import { createFeatureSelector, createSelector } from '@ngrx/store';
import { fromUserRoleList } from '../reducers';
import { authSelectors } from '@content-platform/auth';

import { UserRoleList } from '../models';

export const getUserRoleListRootState = createFeatureSelector<fromUserRoleList.State>(
  'userRoleList'
);
export const getUserRoleListState = createSelector(
  getUserRoleListRootState,
  state => state
);

export const {
  selectAll: getAllUserRoleListItems,
  selectEntities: getUserRoleListEntities
} = fromUserRoleList.userRoleListAdapter.getSelectors(getUserRoleListState);

/**
 * Selector to return the loaded property of the state
 */
export const getUserRoleListLoaded = createSelector(
  getUserRoleListState,
  fromUserRoleList.getUserRoleListLoaded
);
export const getUserRoleListLoading = createSelector(
  getUserRoleListState,
  fromUserRoleList.getUserRoleListLoading
);

export const getActiveUserRoleList = createSelector(
  getUserRoleListEntities,
  authSelectors.getUserId,
  (userRoleListEntities, userId) => {
    return userRoleListEntities[userId];
  }
);

/**
 *  Gets an array of the names of the roles this user was assigned
 */
export const getActiveUserRoleNames = createSelector(
  getActiveUserRoleList,
  roleList =>
    (roleList ? roleList.roles : []).map(role => role.name).sort((a, b) => a.localeCompare(b))
);

/**
 * Selector to get current user permissions
 */
export const getUserPermissions = createSelector(
  getActiveUserRoleList,
  (userRoleList: UserRoleList) => {
    if (!userRoleList || !userRoleList.roles) {
      return undefined;
    }
    return userRoleList.roles
      .map(role => role.permissions)
      .reduce(
        (listSoFar, currentPermissions) =>
          listSoFar.concat(
            currentPermissions.filter(
              currentPermission =>
                !listSoFar
                  .map(existingPermission => existingPermission.id)
                  .includes(currentPermission.id)
            )
          ),
        []
      );
  }
);
