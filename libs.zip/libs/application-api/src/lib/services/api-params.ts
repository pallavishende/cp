import { Environments } from '@content-platform/configuration';

const apiEndpoints = {
  applications: '/applications',
  features: '/features',
  roles: '/roles',
  userRoles: '/user-profiles',
  userApplications: '/user-profiles/applications/:uuid',
  userPermissions: '/user-profiles/permissions/:uuid'
};

/**
 * Class with static methods used to get the urls for the api endpoint
 *
 * @export
 * @class ApiParams
 */
export class ApiParams {
  constructor() {}
  /**
   * Gets the full url for the given endpoint/type, incase there are dynamic values in the url
   * the user can pass in tokens to replace them.
   *
   * @static
   * @param type
   * @param [tokens] optional tokens for the url
   * @returns the endpoint full url
   */
  getUrl(type: string, tokens?: { [key: string]: string }) {
    let pattern = apiEndpoints[type];

    if (pattern) {
      if (tokens) {
        Object.keys(tokens).forEach(tokenKey => {
          const tokenVal = encodeURIComponent(tokens[tokenKey]);
          const tokenStandIn = ':' + tokenKey;
          pattern = pattern.replace(tokenStandIn, tokenVal);
        });
      }

      let url = Environments.getUrl('permissionsEndpoint') + pattern;

      if (url.endsWith('/')) {
        url = url.slice(0, -1);
      }

      return url;
    }
  }
}
