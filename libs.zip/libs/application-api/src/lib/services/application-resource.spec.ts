import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { ApplicationResource } from './application-resource';
import { Application, Feature } from '@content-platform/application-api';
import { LoggerService } from '@content-platform/logging';
import { ApiParams } from './api-params';

function createApp(id: number): Application {
  return {
    name: 'Name ' + id,
    imgUrl: 'imgUrl',
    url: 'aUrl',
    id: id,
    features: []
  };
}

describe('ApplicationResourceService', () => {
  let resource: ApplicationResource;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        ApplicationResource,
        {
          provide: LoggerService,
          useValue: {
            instance: () => {
              return { log: () => {} };
            }
          }
        },
        {
          provide: ApiParams,
          useValue: {
            getUrl: id => id
          }
        }
      ]
    });

    resource = TestBed.get(ApplicationResource);
    httpMock = TestBed.get(HttpTestingController);
  });

  it('should be created', () => {
    expect(resource).toBeTruthy();
  });

  it('should have update/create/get/query/delete functions', () => {
    expect(resource.update).toBeTruthy();
    expect(resource.query).toBeTruthy();
    expect(resource.get).toBeTruthy();
    expect(resource.delete).toBeTruthy();
    expect(resource.create).toBeTruthy();
  });

  it('should pass all features to the PUT request', done => {
    resource['url'] = 'new_url';
    const application = createApp(1);
    application.features = [{ name: 'new' }, { name: 'old', id: 'id' }] as Feature[];
    resource.update(application).subscribe(updatedApp => {
      expect(updatedApp.features.length).toBe(2);
      done();
    });
    const req = httpMock.expectOne(`${resource.getUrl()}`);
    expect(req.request.method).toBe('PUT');
    req.flush(req.request.body);
    httpMock.verify();
  });
});
