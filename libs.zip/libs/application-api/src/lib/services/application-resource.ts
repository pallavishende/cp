import { throwError, Observable, of } from 'rxjs';

import { catchError } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Application } from '../models';
import { Resource } from './resource';
import { ApiParams } from './api-params';
import { LoggerService } from '@content-platform/logging';
import { MOCK_APPLICATION_ACCESS_LIST, USE_MOCK_DATA_ON_ERROR } from './mock-data';

@Injectable()
export class ApplicationResource extends Resource<Application> {
  constructor(http: HttpClient, logger: LoggerService, private apiParams: ApiParams) {
    super(http, logger.instance('ApplicationResource'));
  }

  getUrl() {
    return this.apiParams.getUrl('applications');
  }

  /**
   * Only sends the api supported data for the application.
   *
   * @param application
   * @returns parsed application
   */
  protected transformRequest(application: Application): Application {
    const { id, features, name, deletedFeatures, lastModifiedBy, createdBy, global } = application;
    return { id, features, name, deletedFeatures, lastModifiedBy, createdBy, global };
  }

  get entityName(): string {
    return 'Application';
  }

  query(params?: HttpParams): Observable<Application[]> {
    return super
      .query(params)
      .pipe(
        catchError(
          error => (USE_MOCK_DATA_ON_ERROR ? of(MOCK_APPLICATION_ACCESS_LIST) : throwError(error))
        )
      );
  }
}
