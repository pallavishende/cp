import { ApplicationResource } from './application-resource';
import { UserRoleListResource } from './user-role-list-resource';
import { RoleResource } from './role-resource';
import { UserPermissionListResource } from './user-permission-list-resource';

export * from './application-resource';
export * from './user-role-list-resource';
export * from './role-resource';
export * from './user-permission-list-resource';

const resources = [
  ApplicationResource,
  UserRoleListResource,
  RoleResource,
  UserPermissionListResource
];

export { resources };
