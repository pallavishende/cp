import { Application, Permission } from '../models';

export const MOCK_APPLICATION_ACCESS_LIST: Application[] = [
  { id: 0, name: 'Home', features: [] },
  { id: 1, name: 'Administration', features: [] },
  { id: 2, name: 'Global Entry', features: [] },
  { id: 3, name: 'Sandbox', features: [] }
];

export const MOCK_PERMISSION_LIST: Permission[] = [
  {
    id: 101,
    feature: { id: 1001, name: 'Temp Feature', key: 'temp_feature', metadataConfig: null }
  }
];

export const USE_MOCK_DATA_ON_ERROR = false;
