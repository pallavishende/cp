import { throwError, Observable, of } from 'rxjs';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';

import { LoggerService } from '@content-platform/logging';
import { catchError, switchMap } from 'rxjs/operators';
/**
 * Resource class used as the extended class for all the content resources.
 *
 * @export
 * @abstract
 * @class Resource
 * @template Type
 */
export abstract class Resource<Type> {
  constructor(protected http: HttpClient, private logger: LoggerService) {}

  abstract getUrl(): string;

  /**
   * Used for either search or retrieving all the content.
   *
   * @param [params] optional params that can be extended.
   * @returns
   */
  query(params?: HttpParams): Observable<Type[]> {
    return this.http
      .get<Type[]>(this.getUrl(), { headers: this.getHeaders(), params: params })
      .pipe(
        switchMap(data => {
          this.logger.log(`Retrieved All ${this.entityName}s`);
          return [this.transformResponse(data)];
        }),
        catchError(error => this.handleError(`Retrieving All ${this.entityName}s Failed`, error))
      );
  }

  /**
   * Retrieves a single item, using the content id
   *
   * @param id
   * @returns
   */
  get(id: number | string): Observable<Type> {
    return this.http.get<Type>(`${this.getUrl()}/${id}`).pipe(
      switchMap(data => {
        this.logger.log(`Retrieved ${this.entityName}`, { id: id });
        return this.transformResponse([data]);
      }),
      catchError(error => this.handleError(`Retrieving ${this.entityName} Failed`, error))
    );
  }

  /**
   * Does a POST to the endpoint, to create a new item
   *
   * @param data
   * @returns
   */
  create(data: Type): Observable<Type> {
    return this.http.post<Type>(this.getUrl(), this.transformRequest(data)).pipe(
      switchMap(createdData => {
        this.logger.log(`Created ${this.entityName}`, { id: createdData['id'] });
        return of(createdData);
      }),
      catchError(error => this.handleError(`Create ${this.entityName} Failed`, error))
    );
  }

  /**
   * Does a PUT to the endpint, to update an existing item.
   *
   * @param data
   * @returns
   */
  update(data: Type): Observable<Type> {
    return this.http.put<Type>(this.getUrl(), this.transformRequest(data)).pipe(
      switchMap(updatedData => {
        this.logger.log(`Updated ${this.entityName}`, { id: updatedData['id'] });
        return of(updatedData);
      }),
      catchError(error => this.handleError(`Update ${this.entityName} Failed`, error))
    );
  }

  /**
   * Does a DELETE to the endpoint with the item id.
   *
   * @param id
   * @returns
   */
  delete(id: number): Observable<{}> {
    return this.http.delete<{}>(`${this.getUrl()}/${id}`).pipe(
      switchMap(() => {
        this.logger.log(`Deleted ${this.entityName}`, { id: id });
        return of(id);
      }),
      catchError(error => this.handleError(`Delete ${this.entityName} Failed`, error))
    );
  }

  /**
   * This function can be overwritten incase specific data needs to be deleted before the request
   */
  protected transformRequest(data: Type): Type {
    return data;
  }

  /**
   * returns the list of response for query or get calls
   *
   * @protected
   * @param {Type[]} data
   * @returns {Type[]}
   * @memberof Resource
   */
  protected transformResponse(data: Type[]): Type[] {
    return data;
  }

  /**
   * Creates the header object.
   */
  protected getHeaders(): HttpHeaders {
    return new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
  }

  /**
   * for logging purpose returns the resource class string
   *
   * @readonly
   * @type {string}
   * @memberof Resource
   */
  abstract get entityName(): string;

  /**
   * error handling in case the resource call fails
   *
   * @protected
   * @param {(Response | any)} error
   * @returns {Observable<any>}
   * @memberof Resource
   */
  protected handleError(msg: string, error: Response | any): Observable<any> {
    const body = error.error && !error.message ? error.error : error;
    const err = (body && body.message) || JSON.stringify(body) || 'Server Error';
    this.logger.log(msg, body);
    return throwError(err);
  }
}
