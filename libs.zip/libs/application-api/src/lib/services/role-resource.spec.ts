import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { GraphApi } from '@content-platform/graph-api';
import { LoggerService } from '@content-platform/logging';
import { of } from 'rxjs';
import { ApiParams } from './api-params';
import { RoleResource } from './role-resource';

describe('RoleResourceService', () => {
  let resource: RoleResource;
  let httpMock: HttpTestingController;
  let graphApi: GraphApi;
  let role1, role2;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        RoleResource,
        {
          provide: LoggerService,
          useValue: {
            instance: () => {
              return { log: () => {} };
            }
          }
        },
        {
          provide: GraphApi,
          useValue: {
            getUsers: userIds =>
              of(
                userIds.map(id => {
                  return { objectId: id };
                })
              )
          }
        },
        {
          provide: ApiParams,
          useValue: {
            getUrl: id => id
          }
        }
      ]
    });

    role1 = {
      id: 1,
      users: ['f0611f33-e1ae-4c36-861a-9d0ed8390327', 'f0611f33-e1ae-4c36-861a-9d0ed8390325'],
      permissions: []
    };
    role2 = {
      id: 2,
      users: [
        'f0611f33-e1ae-4c36-861a-9d0ed8390325',
        'f0611f33-e1ae-4c36-861a-9d0ed8390326',
        'f0611f33-e1ae-4c36-861a-9d0ed8390323'
      ],
      permissions: []
    };

    graphApi = TestBed.get(GraphApi);
    resource = TestBed.get(RoleResource);
    httpMock = TestBed.get(HttpTestingController);
  });

  it('should be created', () => {
    expect(resource).toBeTruthy();
  });

  it('should have update/create/get/query/delete functions', () => {
    expect(resource.update).toBeTruthy();
    expect(resource.query).toBeTruthy();
    expect(resource.get).toBeTruthy();
    expect(resource.delete).toBeTruthy();
    expect(resource.create).toBeTruthy();
  });

  describe('query', () => {
    let value;
    beforeEach(() => {
      resource.query().subscribe(roles => {
        value = roles;
      });
    });

    it('should retrieve all the roles', () => {
      const rolesReq = httpMock.expectOne('roles');
      expect(rolesReq.request.method).toBe('GET');
      rolesReq.flush([role1, role2]);
      expect(value.length).toBe(2);
    });

    it('should add the user profile for each user in role', () => {
      const rolesReq = httpMock.expectOne('roles');
      rolesReq.flush([role1, role2]);
      expect(value[0].users[0]).toEqual({ objectId: role1.users[0] });
      expect(value[0].users[1]).toEqual({ objectId: role1.users[1] });
      expect(value[1].users[0]).toEqual({ objectId: role2.users[0] });
      expect(value[1].users[1]).toEqual({ objectId: role2.users[1] });
      expect(value[1].users[2]).toEqual({ objectId: role2.users[2] });
    });

    it('should make only one call to getUsers for the multiple roles & users', () => {
      const spy: jasmine.Spy = spyOn(graphApi, 'getUsers').and.callThrough();
      const rolesReq = httpMock.expectOne('roles');
      rolesReq.flush([role1, role2]);
      expect(graphApi.getUsers).toHaveBeenCalledTimes(1);
      expect(spy.calls.mostRecent().args[0]).toEqual([
        role1.users[0],
        role1.users[1],
        role2.users[1],
        role2.users[2]
      ]);
    });

    afterEach(() => {
      httpMock.verify();
    });
  });
});
