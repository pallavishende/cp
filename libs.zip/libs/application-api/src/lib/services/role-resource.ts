import { switchMap, map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { GraphApi, UserProfile } from '@content-platform/graph-api';
import { LoggerService } from '@content-platform/logging';
import { uniq } from 'lodash';
import { Observable, of } from 'rxjs';
import { Role } from '../models';
import { ApiParams } from './api-params';
import { Resource } from './resource';

@Injectable()
export class RoleResource extends Resource<Role> {
  constructor(
    http: HttpClient,
    private graphApi: GraphApi,
    logger: LoggerService,
    private apiParams: ApiParams
  ) {
    super(http, logger.instance('RoleResource'));
  }

  getUrl(): string {
    return this.apiParams.getUrl('roles');
  }

  /**
   * Makes sure the users list is a list of strings.
   *
   * @private
   * @param role
   * @returns string of user ids
   */
  private getUserIds(role: Role): string[] {
    // We are getting some fake users from backend in the users list for certain roles (v4 uuid check)
    role.users = [
      ...(<any[]>role.users)
        .filter(user => !!user)
        .filter(
          user =>
            (user as string).search(
              /^[0-9A-F]{8}-[0-9A-F]{4}-[4][0-9A-F]{3}-[89AB][0-9A-F]{3}-[0-9A-F]{12}$/i
            ) !== -1
        )
    ];
    return (<any[]>role.users).filter(user => !!user).map(user => {
      if (typeof user === 'string') {
        return user;
      }
      return (<UserProfile>user).objectId;
    });
  }

  /**
   * Getting user profiles from the users in the roles
   *
   * @private
   * @param {Role} role
   * @returns {Observable<UserProfile[]>}
   * @memberof RoleResource
   */
  private getUsersProfilesFromRole(role: Role): Observable<UserProfile[]> {
    const users: string[] = this.getUserIds(role);

    return users.length > 0 ? this.graphApi.getUsers(users) : of([]);
  }

  /**
   * to get all roles from the database and mapiing user profiles against the users
   *
   * @returns {Observable<Role[]>}
   * @memberof RoleResource
   */
  query(): Observable<Role[]> {
    return super.query().pipe(
      switchMap(roles => {
        if (roles.length > 0) {
          return this.mapUserProfilesToRoles(roles);
        }
        return of(roles);
      })
    );
  }

  /**
   * getting the single role for an id and mapping the user profile for the user in role.
   *
   * @param {(number | string)} id
   * @returns {Observable<Role>}
   * @memberof RoleResource
   */
  get(id: number | string): Observable<Role> {
    return super.get(id).pipe(
      switchMap(role => {
        return this.getUsersProfilesFromRole(role).pipe(
          map(results => {
            return { ...role, users: results };
          })
        );
      })
    );
  }

  update(role: Role): Observable<Role> {
    return super.update(role).pipe(
      switchMap(updatedRole => {
        return this.getUsersProfilesFromRole(updatedRole).pipe(
          map(results => {
            return { ...updatedRole, users: results };
          })
        );
      })
    );
  }

  create(role: Role): Observable<Role> {
    return super.create(role).pipe(
      switchMap(newRole => {
        return this.getUsersProfilesFromRole(newRole).pipe(
          map(results => {
            return { ...newRole, users: results };
          })
        );
      })
    );
  }

  /**
   * Getting user profiles of all the roles, in one request, returns the user entities, as an
   * object. The key is the user id.
   *
   * @private
   * @param {Role} role
   * @returns {Observable<{[id: string]: UserProfile}>}
   * @memberof RoleResource
   */
  private getUserProfilesFromRoles(roles: Role[]): Observable<{ [id: string]: UserProfile }> {
    const users: string[] = [].concat.apply([], roles.map(role => this.getUserIds(role)));

    return (users.length > 0 ? this.graphApi.getUsers(uniq(users)) : of([])).pipe(
      map(userProfiles => {
        return userProfiles.reduce((entities: { [id: string]: UserProfile }, user: UserProfile) => {
          if (user && user.objectId) {
            return {
              ...entities,
              [user.objectId]: user
            };
          }
          return entities;
        }, {});
      })
    );
  }

  /**
   * Mapping users with their profiles in the roles
   *
   * @private
   * @param {Role[]} roles
   * @returns {Observable<Role[]>}
   * @memberof RoleResource
   */
  private mapUserProfilesToRoles(roles: Role[]): Observable<Role[]> {
    return this.getUserProfilesFromRoles(roles).pipe(
      map(userEntities => {
        return roles.map(role => {
          const users: UserProfile[] = this.getUserIds(role)
            .map(userId => {
              return userEntities[userId];
            })
            .filter(user => !!user);
          return { ...role, users };
        });
      })
    );
  }

  /**
   * for logging purpose returns the class name only
   *
   * @readonly
   * @type {string}
   * @memberof RoleResource
   */
  get entityName(): string {
    return 'Role';
  }

  /**
   * request to convert userprofiles to list of user ids
   *
   * @protected
   * @param {Role} role
   * @returns {Role}
   * @memberof RoleResource
   */
  protected transformRequest(role: Role): Role {
    return {
      ...role,
      users: (<any[]>role.users).map(user => {
        if (typeof user === 'string') {
          return user;
        }
        return (<UserProfile>user).objectId;
      })
    };
  }
}
