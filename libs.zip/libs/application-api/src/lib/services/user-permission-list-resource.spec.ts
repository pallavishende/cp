import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { GraphApi } from '@content-platform/graph-api';

import { UserPermissionListResource } from './user-permission-list-resource';
import { ApiParams } from './api-params';
import { LoggerService } from '@content-platform/logging';

const applications = [{ id: 123, name: 'Home' }, { id: 124, name: 'Admin' }];

const permissions = [
  {
    id: 1201,
    permissions: [
      {
        id: 1234,
        feature: { id: 1, name: 'Feature', key: 'key', metadataConfig: null },
        metadata: null
      }
    ]
  },
  {
    id: 1202,
    permissions: [
      {
        id: 1235,
        feature: { id: 2, name: 'New Feature', key: 'new_key', metadataConfig: null },
        metadata: null
      }
    ]
  }
];

describe('UserPermissionListResourceService', () => {
  let resource: UserPermissionListResource;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        UserPermissionListResource,
        {
          provide: GraphApi,
          useValue: {
            getUsers: () => []
          }
        },
        {
          provide: LoggerService,
          useValue: {
            instance: () => {
              return { log: () => {} };
            }
          }
        },
        {
          provide: ApiParams,
          useValue: {
            getUrl: id => id
          }
        }
      ]
    });

    resource = TestBed.get(UserPermissionListResource);
    httpMock = TestBed.get(HttpTestingController);
  });

  it('should be created', () => {
    expect(resource).toBeTruthy();
  });

  it('should have update/create/get/query/delete/createAll functions', () => {
    expect(resource.update).toBeTruthy();
    expect(resource.query).toBeTruthy();
    expect(resource.get).toBeTruthy();
    expect(resource.delete).toBeTruthy();
    expect(resource.create).toBeTruthy();
  });

  describe('get', () => {
    it('should call permissions & applications user profile resource', done => {
      resource.get('id').subscribe(updatedApp => {
        expect(updatedApp.applications.length).toBe(0);
        expect(updatedApp.permissions.length).toBe(2);
        expect(updatedApp.uuid).toEqual('id');
        done();
      });
      const appReq = httpMock.expectOne('userApplications');
      const perReq = httpMock.expectOne('userPermissions');
      expect(appReq.request.method).toBe('GET');
      expect(perReq.request.method).toBe('GET');
      appReq.flush([]);
      perReq.flush(permissions);
      httpMock.verify();
    });

    it('should parse permissions all into one array', done => {
      resource.get('id').subscribe(updatedApp => {
        expect(updatedApp.permissions.length).toBe(2);
        expect(updatedApp.permissions[0]).toEqual(permissions[0].permissions[0]);
        expect(updatedApp.permissions[1]).toEqual(permissions[1].permissions[0]);
        done();
      });
      const appReq = httpMock.expectOne('userApplications');
      const perReq = httpMock.expectOne('userPermissions');
      expect(appReq.request.method).toBe('GET');
      expect(perReq.request.method).toBe('GET');
      appReq.flush([]);
      perReq.flush(permissions);
      httpMock.verify();
    });

    it('should set the applications as well if app admin', done => {
      resource.get('id').subscribe(updatedApp => {
        expect(updatedApp.permissions.length).toBe(2);
        expect(updatedApp.permissions[0]).toEqual(permissions[0].permissions[0]);
        expect(updatedApp.permissions[1]).toEqual(permissions[1].permissions[0]);
        expect(updatedApp.applications.length).toEqual(2);
        done();
      });
      const appReq = httpMock.expectOne('userApplications');
      const perReq = httpMock.expectOne('userPermissions');
      appReq.flush(applications);
      perReq.flush(permissions);

      httpMock.verify();
    });
  });
});
