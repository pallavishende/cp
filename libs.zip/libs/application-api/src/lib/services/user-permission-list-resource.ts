import { map, switchMap, catchError } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoggerService } from '@content-platform/logging';
import { Observable, forkJoin, of } from 'rxjs';
import { Application, Permission, UserPermissionList } from '../models';
import { ApiParams } from './api-params';
import { Resource } from './resource';
import {
  MOCK_APPLICATION_ACCESS_LIST,
  MOCK_PERMISSION_LIST,
  USE_MOCK_DATA_ON_ERROR
} from './mock-data';

@Injectable()
export class UserPermissionListResource extends Resource<UserPermissionList> {
  constructor(http: HttpClient, logger: LoggerService, private apiParams: ApiParams) {
    super(http, logger.instance('UserPermissionListResource'));
  }

  getUrl() {
    return '';
  }

  get(uuid: string): Observable<UserPermissionList> {
    return forkJoin(this.getUserApps(uuid), this.getUserPermissions(uuid)).pipe(
      switchMap(data => {
        const permissions = data[1];
        const applications = data[0];
        return of({
          uuid,
          applications,
          permissions
        }).pipe(switchMap(userPermissionList => of(userPermissionList)));
      })
    );
  }

  get entityName(): string {
    return 'User Permission List';
  }

  private getUserApps(uuid: string): Observable<Application[]> {
    return this.http
      .get<Application[]>(this.apiParams.getUrl('userApplications', { uuid: uuid }), {
        headers: this.getHeaders()
      })
      .pipe(
        catchError(
          error =>
            USE_MOCK_DATA_ON_ERROR
              ? of(MOCK_APPLICATION_ACCESS_LIST)
              : this.handleError(`Retrieving User Apps Failed`, error)
        )
      );
  }

  private getUserPermissions(uuid: string): Observable<Permission[]> {
    return this.http
      .get<Permission[] | UserPermissionList[]>(
        this.apiParams.getUrl('userPermissions', { uuid: uuid }),
        {
          headers: this.getHeaders()
        }
      )
      .pipe(
        map((permissionsList: Permission[] | UserPermissionList[]) => {
          if (
            (<UserPermissionList[]>permissionsList).length > 0 &&
            (<UserPermissionList[]>permissionsList)[0].permissions
          ) {
            const permissions = [].concat.apply(
              [],
              (<UserPermissionList[]>permissionsList).map(list => list.permissions)
            );
            return permissions;
          }
          return permissionsList as Permission[];
        }),
        catchError(
          error =>
            USE_MOCK_DATA_ON_ERROR
              ? of(MOCK_PERMISSION_LIST)
              : this.handleError(`Retrieving User Permissions Failed`, error)
        )
      );
  }
}
