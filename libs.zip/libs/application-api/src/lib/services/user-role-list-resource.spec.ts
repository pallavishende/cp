import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { GraphApi } from '@content-platform/graph-api';

import { UserRoleListResource } from './user-role-list-resource';
import { LoggerService } from '@content-platform/logging';
import { ApiParams } from './api-params';

describe('UserRoleListResourceService', () => {
  let resource: UserRoleListResource;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        UserRoleListResource,
        {
          provide: LoggerService,
          useValue: {
            instance: () => {
              return { log: () => {} };
            }
          }
        },
        {
          provide: GraphApi,
          useValue: {
            getUsers: () => []
          }
        },
        {
          provide: ApiParams,
          useValue: {
            getUrl: () => ''
          }
        }
      ]
    });

    resource = TestBed.get(UserRoleListResource);
  });

  it('should be created', () => {
    expect(resource).toBeTruthy();
  });

  it('should have update/create/get/query/delete/createAll functions', () => {
    expect(resource.update).toBeTruthy();
    expect(resource.query).toBeTruthy();
    expect(resource.get).toBeTruthy();
    expect(resource.delete).toBeTruthy();
    expect(resource.create).toBeTruthy();
  });
});
