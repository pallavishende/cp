import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Resource } from './resource';
import { UserRoleList } from '../models/user';
import { ApiParams } from './api-params';
import { LoggerService } from '@content-platform/logging';

@Injectable()
export class UserRoleListResource extends Resource<UserRoleList> {
  constructor(http: HttpClient, logger: LoggerService, private apiParams: ApiParams) {
    super(http, logger.instance('UserRoleListResource'));
  }

  getUrl() {
    return this.apiParams.getUrl('userRoles');
  }

  protected transformRequest(userRoleList: UserRoleList): UserRoleList {
    const { id, name, uuid, modifiedDate, lastModifiedBy } = userRoleList;
    const roles = userRoleList.roles.map(role => {
      return { id: role.id };
    });
    return { id, uuid, roles, name, modifiedDate, lastModifiedBy } as UserRoleList;
  }

  get entityName(): string {
    return 'User Role List';
  }
}
