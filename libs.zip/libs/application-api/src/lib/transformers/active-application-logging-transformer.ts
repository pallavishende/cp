import { LoggerParamsTransformer } from '@content-platform/logging';
import { ApplicationApiConstants } from '../application-api-config';

export class ActiveApplicationLoggingTransformer extends LoggerParamsTransformer {
  getParams() {
    return {
      activeApplication: ApplicationApiConstants.activeAppName
    };
  }
}
