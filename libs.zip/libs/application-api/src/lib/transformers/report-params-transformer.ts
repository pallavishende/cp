import { Injector } from '@angular/core';
import { ReportParamsTransformer } from '@content-platform/error-handling';

import { ApplicationApiConstants } from '../application-api-config';

export class AppReportParamsTransformer extends ReportParamsTransformer {
  constructor(injector: Injector) {
    super(injector);
  }

  getParams() {
    return {
      Application: ApplicationApiConstants.activeAppName
    };
  }
}
