import { LoggerParamsTransformer } from '@content-platform/logging';
import { Store, select } from '@ngrx/store';
import { authSelectors } from '@content-platform/auth';
import { userRoleListActions } from '../actions';
import { ApplicationsState } from '../reducers';
import { userRoleListSelectors } from '../selectors';
import { switchMap, filter } from 'rxjs/operators';

export class UserRolesLoggingTransformer extends LoggerParamsTransformer {
  private store: Store<ApplicationsState>;
  private roles: string[];

  initialize() {
    this.store = this.injector.get(Store) as Store<ApplicationsState>;
    this.store
      .pipe(
        select(authSelectors.getUserId),
        filter(userId => !!userId),
        switchMap((userId: string) => {
          this.store.dispatch(new userRoleListActions.LoadById(userId));
          return this.store.pipe(select(userRoleListSelectors.getActiveUserRoleNames));
        })
      )
      .subscribe(roleNames => {
        this.roles = roleNames;
      });
  }

  getParams(): { [key: string]: any } {
    return {
      userRoles: this.roles
    };
  }
}
