import { async, TestBed } from '@angular/core/testing';
import { ArcApiModule } from './arc-api.module';

describe('ArcApiModule', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ArcApiModule]
    }).compileComponents();
  }));

  it('should create', () => {
    expect(ArcApiModule).toBeDefined();
  });
});
