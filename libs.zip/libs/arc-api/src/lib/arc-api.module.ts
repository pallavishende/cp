import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { GraphApiModule } from '@content-platform/graph-api';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { effects } from './store/effects';
import { guards } from './guards';
import { fromSite, fromUser, fromRole, fromUserGroup } from './store/reducers';
import { resources } from './services';
import { ApiParams } from './services/api-params';
import { APIInterceptor } from './services/api.interceptor';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';

@NgModule({
  imports: [
    CommonModule,
    GraphApiModule,
    HttpClientModule,
    StoreModule.forFeature('site', fromSite.reducer),
    StoreModule.forFeature('arcUser', fromUser.reducer),
    StoreModule.forFeature('arcRoles', fromRole.reducer),
    StoreModule.forFeature('userGroup', fromUserGroup.reducer),
    EffectsModule.forFeature([...effects])
  ],
  providers: [
    ApiParams,
    ...resources,
    ...guards,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: APIInterceptor,
      multi: true
    }
  ]
})
export class ArcApiModule {
  // injecting as we can't set it inside the withApp function, get this error otherwise:
  // ERROR in Error during template compile of 'AppModule'
  // Function calls are not supported in decorators but 'ArcApiModule' was called.
  constructor() {}
}
