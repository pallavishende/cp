import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { Observable, of } from 'rxjs';

/**
 *  Need implemetation once we start making calls to get the api data
 * 
 * @export
 * @class ArcApiGuard
 * @implements {CanActivate}
 */
@Injectable()
export class ArcApiGuard implements CanActivate {
  constructor() {}

  canActivate(): Observable<boolean> {
    return of(true);
  }
}
