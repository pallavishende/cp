import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';

import { Store, select } from '@ngrx/store';
import { Observable, of } from 'rxjs';

import { filter, catchError, withLatestFrom, map } from 'rxjs/operators';
import { fromRole } from '../store/reducers';
import { roleSelectors } from '../store/selectors';
import { roleActions } from '../store/actions';

@Injectable()
export class ArcRolesGuard implements CanActivate {
  constructor(protected store: Store<fromRole.State>) {}

  canActivate(): Observable<boolean> {
    return this.checkStore().pipe(catchError(() => of(false)));
  }

  checkStore(): Observable<boolean> {
    return this.store.pipe(
      select(roleSelectors.getRolesLoading),
      withLatestFrom(this.store.pipe(select(roleSelectors.getRolesLoaded))),
      filter(([loading, loaded], index) => {
        if (!loaded && !loading && index === 0) {
          this.store.dispatch(new roleActions.Load());
          return false;
        }
        return !loading;
      }),
      map(([, loaded]) => loaded as boolean)
    );
  }
}
