import { ArcApiGuard } from './arc-api.guard';
import { ArcRolesGuard } from './arc-roles.guard';

export const guards = [ArcApiGuard, ArcRolesGuard];

export * from './arc-api.guard';
export * from './arc-roles.guard';
