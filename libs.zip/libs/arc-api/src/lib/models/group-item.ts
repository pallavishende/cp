import { LinkItem } from './link-item.model';

export function isGroupByCheck(p: LinkItem){
  return p.hasOwnProperty('isGroupBy');
} 

export interface GroupByItem extends LinkItem {
   isGroupBy:boolean;
}
