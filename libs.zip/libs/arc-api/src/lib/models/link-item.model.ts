export interface LinkItem {
  uuid: string;
  title: string;
  description?: string;
  contentType?: string;
}
