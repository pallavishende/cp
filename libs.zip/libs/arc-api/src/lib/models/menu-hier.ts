import { LinkItem } from './link-item.model';

export interface MenuHier extends LinkItem {
  path?: string;
  fullName?: string;
}
