import { LinkItem } from './link-item.model';

export interface Role extends LinkItem {
  rights: string[];
  qualifications: Qualification[];
}

export interface Qualification {
  right: string;
  pattern: string;
  subrights: string[];
}
