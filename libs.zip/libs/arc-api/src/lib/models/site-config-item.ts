import { LinkItem } from './link-item.model';
import { MenuHier } from './menu-hier';
import { UserGroupRoleItem } from './user-group-role-item';

export interface SiteConfigItem extends LinkItem {
  sitekey: string;
  name?: string;
  siteName?: string;
  server?: string;
  environment?: string;
  namespace?: string;
  path?: string;
  ugroles?: UserGroupRoleItem[];
  inheritedUgroles?: UserGroupRoleItem[];
  inheritedFrom?: MenuHier;
  arcenv?: string;
  hasUAC?: boolean;
}
