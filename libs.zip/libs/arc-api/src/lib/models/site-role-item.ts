import { LinkItem } from './link-item.model';
import { ITitleRole } from './user-group-role-item';
import { SiteConfigItem } from './site-config-item';

export interface SiteRoleItem extends LinkItem, ITitleRole {
  site: SiteConfigItem;
  roleName: string;
}
