export interface TypeaheadData {
  results: ServerLinkData[];
}

export interface ServerLinkData {
  _uuid: string;
  _title: string;
  _globalId: string;
  _description: string;
}
