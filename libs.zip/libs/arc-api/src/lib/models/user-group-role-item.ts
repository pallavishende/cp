import { LinkItem } from './link-item.model';

export interface ITitleRole {
  title: string;
  roleName: string;
}

export interface UserGroupRoleItem extends LinkItem, ITitleRole {
  userGroup: LinkItem;
  roleName: string;
  role?: LinkItem;
}

export interface UserGroupWithRolesRequestData {
  Role?: { _globalId: string; _contentType?: string };
  UserGroup?: { _globalId: string; _contentType?: string };
  _contentType: string;
  _globalId?: string;
}

export interface UserGroupRequestData {
  _contentType: string;
  _globalId?: string;
}
