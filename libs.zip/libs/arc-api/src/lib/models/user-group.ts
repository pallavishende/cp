import { LinkItem } from './link-item.model';
import { SiteRoleItem } from './site-role-item';
import { UserDetail } from './user';

export interface UserGroup extends LinkItem {
  defaultRoleName: string;
  users: LinkItem[];
  backlinks: LinkItem[];
  siteRoles: SiteRoleItem[];
  userDetails?: { [key: string]: UserDetail };
}
