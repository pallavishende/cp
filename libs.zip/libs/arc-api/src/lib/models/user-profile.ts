import { LinkItem } from './link-item.model';
import { SiteConfigItem } from './site-config-item';

export interface ArcUserProfile {
  userProfileItems: ArcUserProfileItem[];
  namespaces: ArcUserProfileNamespace[];
}

export interface ArcGroupRole {
  groupName: string;
  roleName: string;
}

export interface ArcUserProfileNamespace extends LinkItem {
  site: SiteConfigItem;
  hasUAC: boolean;
  groupRoles: ArcGroupRole[];
}

export interface ArcUserProfileItem {
  groupRoles: ArcGroupRole[];
  server: string;
  environment: string;
  namespace: string;
}
