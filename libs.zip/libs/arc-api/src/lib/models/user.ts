import { LinkItem } from './link-item.model';
import { ArcUserProfile } from './user-profile';
import { UserProfile } from '@content-platform/graph-api';

export interface UserDetail {
  login?: string;
  fullName?: string;
  name?: string;
  surname?: string;
  email?: string;
}

export interface User extends LinkItem, UserDetail {
  profile: ArcUserProfile;
  userProfile?: UserProfile;
  userGroups: LinkItem[];
}
