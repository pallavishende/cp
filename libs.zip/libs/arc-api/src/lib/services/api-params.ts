import { Environments } from '@content-platform/configuration';

type apiKeys =
  | 'arcContentTypeahead'
  | 'userProfile'
  | 'siteTree'
  | 'arcContentById'
  | 'arcContent'
  | 'userDetails'
  | 'arcSiteConfig';

const apiEndpoints = {
  arcContentTypeahead: '/sites/:siteKey/content/typeahead',
  userProfile: '/users/:userName/profile',
  arcContent: '/sites/:siteKey/content',
  siteTree: '/sites/:siteKey/content/:uuid/tree',
  arcContentById: '/sites/:siteKey/content/:uuid',
  userDetails: '/users/details',
  arcSiteConfig: '/sites/:siteKey/siteconfig'
};

export const ISIS_CONFIG_SITE = 'isis-config-live-v2';

/**
 * Class with static methods used to get the urls for the api endpoint
 *
 * @export
 * @class ApiParams
 */
export class ApiParams {
  constructor() {}

  /**
   * Gets the full url for the given endpoint/type, incase there are dynamic values in the url
   * the user can pass in tokens to replace them.
   *
   * @static
   * @param type
   * @param [tokens] optional tokens for the url
   * @returns the endpoint full url
   */
  getUrl(type: apiKeys, tokens?: { [key: string]: string }) {
    let pattern = apiEndpoints[type];

    if (pattern) {
      if (tokens) {
        Object.keys(tokens).forEach(tokenKey => {
          const tokenVal = encodeURIComponent(tokens[tokenKey]);
          const tokenStandIn = ':' + tokenKey;
          pattern = pattern.replace(tokenStandIn, tokenVal);
        });
      }
      return Environments.getUrl('aapiEndpoint') + pattern;
    }
  }
}
