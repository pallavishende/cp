import { throwError, Observable } from 'rxjs';

import { switchMap, catchError, map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';

import { GraphApi, UserProfile, userProfileHelpers } from '@content-platform/graph-api';
import { Environments } from '@content-platform/configuration';

/**
 * Interceptor for the AAPI requests
 * be on every request.
 *
 * @export
 * @class APIInterceptor
 */
@Injectable()
export class APIInterceptor implements HttpInterceptor {
  constructor(private graphApi: GraphApi) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (!request.url.startsWith(Environments.getUrl('aapiEndpoint'))) {
      return next.handle(request);
    } else if (request.method !== 'GET') {
      return this.getUserProfile().pipe(
        switchMap(userProfile => {
          request = request.clone({
            setHeaders: {
              'X-Processed-By': userProfileHelpers.getLDAPUsername(<UserProfile>userProfile),
              'Content-Type': 'application/json'
            }
          });
          return next.handle(request).pipe(
            catchError((err: any) => {
              return throwError(err);
            })
          );
        })
      );
    } else {
      request = request.clone({
        setHeaders: {
          'Content-Type': 'application/json'
        }
      });
      return next.handle(request);
    }
  }

  private getUserProfile(): Observable<UserProfile> {
    return this.graphApi.getCurrentUser().pipe(map(userProfile => userProfile));
  }
}
