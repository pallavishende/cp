import { SiteResource } from './site-resource';
import { UacParser } from './uac-parser.service';
import { UserResource } from './user-resource';
import { RoleResource } from './role-resource';
import { UserGroupResource } from './user-group-resource';

export * from './site-resource';
export * from './user-resource';
export * from './role-resource';
export * from './user-group-resource';

const resources = [SiteResource, UacParser, UserResource, RoleResource, UserGroupResource];

export { resources };
