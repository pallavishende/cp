import { cloneDeep } from 'lodash';

export const menuDataItems = [
  {
    _globalId: 'cfbf79ba-721a-498f-b77a-59ccb3d5ab57',
    _name: 'EPIX',
    _lastModified: '2016-11-17T04:36:22.087-05:00',
    _description: 'posting.mongo-arc-v2.mtvnservices.com / authoring / epix',
    _siteName: 'Epix',
    _contentType: 'ISISConfig:SiteConfig',
    _title: 'epix-authoring',
    UserGroups: [
      {
        _globalId: '8045403c-8745-4067-8761-cc513285755e',
        _count: '0',
        _defaultRole: 'Producer',
        _title: 'Epix Admin',
        _namespace: 'admin'
      },
      {
        _globalId: '5a6945a4-b101-4bfb-b546-506b30ba06bf',
        _defaultRole: 'INTL Shared Producer',
        _title: 'EPIX Limited access',
        _namespace: 'admin'
      }
    ],
    UserGroupsWithRoles: [
      {
        _contentType: 'ISISConfig:UserGroupRole',
        UserGroup: {
          _globalId: '1fcb97db-7df2-473a-8a19-78d95a573831',
          _defaultRole: 'INTL Shared Producer with menu',
          _title: 'INTL Epix Access',
          _namespace: 'admin'
        },
        Role: {
          _globalId: '0d2cb552-7866-4d36-b888-4d0a04ee2813',
          _description:
            'User can ONLY edit the DistPolicies field and Pigeonholes' +
            ' in this namespace - by adding/removing DP\'s in "their own" ' +
            'namespace (i.e. any other namespace where they do have edit rights)',
          _title: 'INTL Shared Producer with menu',
          _namespace: 'admin'
        }
      }
    ]
  }
];

export function getUniqueSiteMenu() {
  menuDataItems[0]._title =
    menuDataItems[0]._title +
    '_' +
    Math.random()
      .toString(36)
      .substr(2, 9);
  return menuDataItems;
}

export function createMenuChildren(depth = 2, numberChildren = 2, data?) {
  data =
    data ||
    cloneDeep({
      _contentType: 'ISISConfig:MenuHierarchy',
      Children: [],
      Items: [...getUniqueSiteMenu()]
    });
  if (depth > 0) {
    for (let i = 0; i < numberChildren; i++) {
      data.Children.push(createMenuChildren(--depth, numberChildren));
    }
  }
  return data;
}

export const UserProfile = {
  user: 'user',
  namespaces: [
    {
      server: 'posting.mongo-arc-v2.mtvnservices-q.mtvi.com',
      environment: 'authoring',
      namespace: 'nick',
      groupRoles: [
        {
          userGroup: 'ARC UI Team',
          role: 'Admin'
        },
        {
          userGroup: 'ISIS Team',
          role: 'Producer'
        }
      ]
    },
    {
      server: 'posting.mongo-arc-v2.mtvnservices-q.mtvi.com',
      environment: 'authoring-sandbox',
      namespace: 'comedy',
      groupRoles: [
        {
          userGroup: 'Default Group',
          role: 'Producer'
        }
      ]
    },
    {
      server: 'posting.mongo-arc-v2.mtvnservices-q.mtvi.com',
      environment: 'authoring-sandbox',
      namespace: 'comedy-intl',
      groupRoles: [
        {
          userGroup: 'Default Group',
          role: 'Producer'
        }
      ]
    }
  ]
};

export const UserLinkItems = {
  results: [
    {
      _globalId: '97815343-9b8c-4aba-832c-c808a1f3847b',
      _defaultRole: 'Admin',
      _title: 'ARC UI Team',
      _namespace: 'admin'
    },
    {
      _globalId: 'af5b36a9-d90b-4615-b6fd-fd8f74cd0bf5',
      _defaultRole: 'Producer',
      _title: 'ISIS Team',
      _namespace: 'admin'
    }
  ]
};

export const Roles = {
  results: [
    {
      _globalId: '23547287-23fd-474c-b3cb-fc73df97309f',
      _description: 'This role is used for all the user groups which do not support publishing',
      _title: 'Producer - No Publish',
      RoleName: 'Producer - No Publish',
      Description: 'This role is used for all the user groups which do not support publishing',
      Rights: [
        {
          _globalId: '1de5811d-88d0-4f60-973b-d2983705e31a',
          _contentType: 'ISISConfig:Right',
          _description: 'Site appears on ISIS menu.',
          _title: 'AppearsOnMenu'
        },
        {
          _globalId: '50ae9365-2fb4-441c-82c8-5db9aa838ab4',
          _description: 'Can create new record',
          _contentType: 'ISISConfig:Right',
          _title: 'CanCreate'
        },
        {
          _globalId: '28821053-3c3d-4058-bf8a-8fc7ac54895f',
          _description: 'Can delete record.',
          _contentType: 'ISISConfig:Right',
          _title: 'CanDelete'
        },
        {
          _globalId: '26e4d66d-d32e-4878-9081-77fa8e765320',
          _description: 'User is allowed to edit content in this namespace.',
          _contentType: 'ISISConfig:Right',
          _title: 'CanEdit'
        }
      ]
    },
    {
      _globalId: 'b92157ec-3533-487e-97a2-8b9caa00ab33',
      _description: 'description',
      _contentType: 'ISISConfig:Role',
      _title: 'INTL Shared Producer',
      RoleName: 'INTL Shared Producer',
      Description: 'Description',
      Rights: [
        {
          _globalId: '50ae9365-2fb4-441c-82c8-5db9aa838ab4',
          _description: 'Can create new record',
          _contentType: 'ISISConfig:Right',
          _title: 'CanCreate'
        }
      ],
      QualifiedRights: [
        {
          _globalId: 'b010ff77-beab-407c-9ea5-34bba0dd2fbe',
          _pattern: '*:*.DistPolicies',
          _description: 'Can add/remove "own" dist policies only.',
          _contentType: 'ISISConfig:QualifiedRight',
          _title: 'CanEdit',
          Right: {
            _globalId: '26e4d66d-d32e-4878-9081-77fa8e765320',
            _description: 'User is allowed to edit content in this namespace.',
            _contentType: 'ISISConfig:Right',
            _title: 'CanEdit'
          },
          Pattern: '*:*.DistPolicies',
          Qualifications: [
            {
              _globalId: 'e81b106c-4f80-4514-a36c-714ec264f1d6',
              _description: 'Can add "own" items to field',
              _contentType: 'ISISConfig:Subright',
              _title: 'CanAddOwn'
            },
            {
              _globalId: '923a2888-4ff9-4910-9caa-1cce04127c2a',
              _description: 'Can remove "own" items from field',
              _contentType: 'ISISConfig:Subright',
              _title: 'CanRemoveOwn'
            }
          ],
          Notes: 'Can add/remove "own" dist policies only.'
        },
        {
          _globalId: '3a19d476-ca06-4e3c-8b37-a73e2a2c60c8',
          _contentType: 'ISISConfig:QualifiedRight',
          _pattern: '*:*.Pigeonholes',
          _title: 'CanEdit',
          Right: {
            _globalId: '26e4d66d-d32e-4878-9081-77fa8e765320',
            _description: 'User is allowed to edit content in this namespace.',
            _contentType: 'ISISConfig:Right',
            _title: 'CanEdit'
          },
          Pattern: '*:*.Pigeonholes',
          Qualifications: [
            {
              _globalId: '2b43c76c-2335-4b61-9b75-9200c16ff78b',
              _description: 'Can add items to field',
              _contentType: 'ISISConfig:Subright',
              _title: 'CanAdd'
            },
            {
              _globalId: '9317dc8a-c09c-4bad-a2a0-597acc153c24',
              _description: 'Can remove items from field',
              _contentType: 'ISISConfig:Subright',
              _title: 'CanRemove'
            }
          ]
        }
      ]
    }
  ]
};
