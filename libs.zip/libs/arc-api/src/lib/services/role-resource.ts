import { Injectable } from '@angular/core';
import { LoggerService } from '@content-platform/logging';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UacParser } from './uac-parser.service';
import { Role } from '../models';
import { map, catchError } from 'rxjs/operators';
import { ApiParams, ISIS_CONFIG_SITE } from './api-params';

@Injectable()
export class RoleResource {
  private logger: LoggerService;
  constructor(
    logger: LoggerService,
    private http: HttpClient,
    private apiParams: ApiParams,
    private parser: UacParser
  ) {
    this.logger = logger.instance('RoleResource');
  }

  loadRoles(): Observable<Role[]> {
    // make menu & ug requests in parallel, don't parse ugs until after parsing menu
    const url = this.apiParams.getUrl('arcContent', { siteKey: ISIS_CONFIG_SITE });
    const headers = this.getHeaders();
    const params = {
      contentType: 'ISISConfig:Role',
      pageSize: '500',
      searchEngine: 'uca',
      summary: 'false'
    };
    return this.http.get(url, { headers, params }).pipe(
      map(data => {
        return this.parser.parseRoles(data);
      }),
      catchError(error => this.handleError(`Loading Roles Failed`, error))
    );
  }

  private getHeaders() {
    // NOTE: with new HttpClient, headers are immutable
    return new HttpHeaders().set('Content-Type', 'application/json');
  }

  /**
   * error handling in case the resource call fails
   *
   * @protected
   * @param {(Response | any)} error
   * @returns {Observable<any>}
   * @memberof Resource
   */
  protected handleError(msg: string, error: Response | any): Observable<any> {
    const body = error.error && !error.message ? error.error : error;
    const err = (body && body.message) || JSON.stringify(body) || 'Server Error';
    this.logger.log(msg, body);
    return throwError(err);
  }
}
