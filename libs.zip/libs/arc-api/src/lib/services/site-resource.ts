import { Injectable } from '@angular/core';
import { LoggerService } from '@content-platform/logging';
import { throwError, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { UacParser } from './uac-parser.service';
import { SiteConfigItem } from '../models';
import { map, catchError } from 'rxjs/operators';
import { ApiParams, ISIS_CONFIG_SITE } from './api-params';

@Injectable()
export class SiteResource {
  private logger: LoggerService;

  private menuInstances = {
    dev: { uuid: 'a9a51d90-26ef-4d0e-b42b-043508d3ab2e' },
    qa: { uuid: '3a08cd0d-d069-47d7-81ec-0af0d507bc9f' },
    live: { uuid: 'fbc0fa8f-abde-409c-b3a9-0a18acde8bc0' }
  };

  constructor(
    private http: HttpClient,
    logger: LoggerService,
    private apiParams: ApiParams,
    private parser: UacParser
  ) {
    this.logger = logger.instance('SiteResource');
  }

  loadSites(instanceName: string = 'live'): Observable<SiteConfigItem[]> {
    const url = this.apiParams.getUrl('siteTree', {
      uuid: this.menuInstances[instanceName].uuid,
      siteKey: ISIS_CONFIG_SITE
    });
    const params = {
      excludeTypes: 'ISISConfig:XMLConfig',
      stopTypes: 'ISISConfig:Role'
    };
    return this.http.get(url, { params }).pipe(
      map(response => {
        return this.parser.parseMenuTree(response);
      }),
      catchError(error => this.handleError(`Site Menu Hierarchy not loaded`, error))
    );
  }

  loadSiteByKey(sitekey: string): Observable<SiteConfigItem> {
    const url = this.apiParams.getUrl('arcSiteConfig', {
      siteKey: sitekey
    });

    return this.http.get(url, {}).pipe(
      map(response => {
        const updatedSite = this.parser.parseSiteConfigItem(response);
        updatedSite.ugroles = this.parser.parseUgroles(response);
        return updatedSite;
      }),
      catchError(error => this.handleError(`Site not loaded`, error))
    );
  }

  loadSiteByGlobalId(globalId: string): Observable<SiteConfigItem> {
    const url = this.apiParams.getUrl('arcContentById', {
      uuid: globalId,
      siteKey: ISIS_CONFIG_SITE
    });

    return this.http.get(url, {}).pipe(
      map(response => {
        const updatedSite = this.parser.parseSiteConfigItem(response);
        updatedSite.ugroles = this.parser.parseUgroles(response);
        return updatedSite;
      }),
      catchError(error => this.handleError(`Site not loaded`, error))
    );
  }

  updateSiteUserGroup(uuid: string, data: any): Observable<SiteConfigItem> {
    const url = this.apiParams.getUrl('arcContentById', {
      uuid: uuid,
      siteKey: ISIS_CONFIG_SITE
    });

    return this.http.patch(url, data, {}).pipe(
      map(response => {
        const updatedSite = this.parser.parseSiteConfigItem(response);
        updatedSite.ugroles = this.parser.parseUgroles(response);
        return updatedSite;
      }),
      catchError(error => this.handleError(`Site not updated`, error))
    );
  }

  /**
   * error handling in case the resource call fails
   *
   * @protected
   * @param {(Response | any)} error
   * @returns {Observable<any>}
   * @memberof Resource
   */
  protected handleError(msg: string, error: Response | any): Observable<any> {
    const body = error.error && !error.message ? error.error : error;
    const err = (body && body.message) || JSON.stringify(body) || 'Server Error';
    this.logger.log(msg, body);
    return throwError(err);
  }
}
