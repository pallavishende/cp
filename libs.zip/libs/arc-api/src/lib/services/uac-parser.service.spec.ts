import { TestBed } from '@angular/core/testing';
import { UacParser } from './uac-parser.service';
import { ArcUserProfile, SiteConfigItem, LinkItem, Role } from '../models';
import {
  menuDataItems,
  createMenuChildren,
  UserProfile,
  UserLinkItems,
  Roles,
  getUniqueSiteMenu
} from './mock-data';

describe('UacParserService', () => {
  let resource: UacParser;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UacParser]
    });

    resource = TestBed.get(UacParser);
  });

  it('should be created', () => {
    expect(resource).toBeTruthy();
  });

  describe('parseMenuTree', () => {
    let parsedMenu: SiteConfigItem[];

    describe('parseItems', () => {
      beforeEach(() => {
        parsedMenu = resource.parseMenuTree({
          _contentType: 'ISISConfig:MenuHierarchy',
          Children: [],
          Items: [...menuDataItems]
        });
      });
      it('should return a list of sites including the items', () => {
        expect(parsedMenu.length).toEqual(1);
        expect(parsedMenu[0].name).toEqual(menuDataItems[0]._name);
        expect(parsedMenu[0].server).toEqual('posting.mongo-arc-v2.mtvnservices.com');
        expect(parsedMenu[0].environment).toEqual('authoring');
        expect(parsedMenu[0].namespace).toEqual('epix');
      });

      it('should add both UserGroupsWithRoles & UserGroups to ugroles', () => {
        expect(parsedMenu[0].ugroles.length).toEqual(3);
        for (const role of parsedMenu[0].ugroles) {
          expect(role.userGroup).toBeDefined();
          expect(role.roleName).toBeDefined();
          expect(role.title).toBeDefined();
        }
      });

      it('should set roleName for UserGroupsWithRoles', () => {
        expect(parsedMenu[0].ugroles.length).toEqual(3);
        const ugRole = parsedMenu[0].ugroles[2];
        expect(ugRole.roleName).toEqual('INTL Shared Producer with menu');
      });

      it('should set environment to qa if url matches arcQa', () => {
        parsedMenu = resource.parseMenuTree({
          _contentType: 'ISISConfig:MenuHierarchy',
          Children: [],
          Items: [
            {
              ...menuDataItems[0],
              _description: 'posting.mongo-arc-v2.mtvnservices-q.mtvi.com / authoring / epix'
            }
          ]
        });
        expect(parsedMenu[0].arcenv).toEqual('qa');
      });

      it('should set environment to uat if url matches arcQa and environment authoring-sandbox', () => {
        parsedMenu = resource.parseMenuTree({
          _contentType: 'ISISConfig:MenuHierarchy',
          Children: [],
          Items: [
            {
              ...menuDataItems[0],
              _description:
                'posting.mongo-arc-v2.mtvnservices-q.mtvi.com / authoring-sandbox / epix'
            }
          ]
        });
        expect(parsedMenu[0].arcenv).toEqual('uat');
      });

      it('should set environment to staging if url matches arcStaging and environment authoring', () => {
        parsedMenu = resource.parseMenuTree({
          _contentType: 'ISISConfig:MenuHierarchy',
          Children: [],
          Items: [
            {
              ...menuDataItems[0],
              _description: 'posting.mongo-arc-v2.mtvnservices-s.mtvi.com / authoring / epix'
            }
          ]
        });
        expect(parsedMenu[0].arcenv).toEqual('staging');
      });

      it('should set arcenv to other if either the url doesnt match or the environment', () => {
        parsedMenu = resource.parseMenuTree({
          _contentType: 'ISISConfig:MenuHierarchy',
          Children: [],
          Items: [
            {
              ...menuDataItems[0],
              _description: 'posting.mongo-arc-v2.mtvnservices-s.com / authoring / epix'
            }
          ]
        });
        expect(parsedMenu[0].arcenv).toEqual('other');

        parsedMenu = resource.parseMenuTree({
          _contentType: 'ISISConfig:MenuHierarchy',
          Children: [],
          Items: [
            {
              ...menuDataItems[0],
              _description:
                'posting.mongo-arc-v2.mtvnservices-s.mtvi.com / authoring-sandbox / epix'
            }
          ]
        });
        expect(parsedMenu[0].arcenv).toEqual('other');

        parsedMenu = resource.parseMenuTree({
          _contentType: 'ISISConfig:MenuHierarchy',
          Children: [],
          Items: [
            {
              ...menuDataItems[0],
              _description: 'posting.mongo-arc-v2.mtvnservices-q.mtvi.com / testing / epix'
            }
          ]
        });
        expect(parsedMenu[0].arcenv).toEqual('other');
      });
    });

    describe('parseChildren', () => {
      beforeEach(() => {
        const data = createMenuChildren(2, 2);
        parsedMenu = resource.parseMenuTree({
          _contentType: 'ISISConfig:MenuHierarchy',
          Children: [data],
          Items: [...getUniqueSiteMenu()]
        });
      });

      it('should return a list of sites including the items & children', () => {
        expect(parsedMenu.length).toEqual(6);
        expect(parsedMenu[0].name).toEqual(menuDataItems[0]._name);
        expect(parsedMenu[0].server).toEqual('posting.mongo-arc-v2.mtvnservices.com');
        expect(parsedMenu[0].environment).toEqual('authoring');
        expect(parsedMenu[0].namespace).toEqual('epix');
      });
    });
  });

  describe('parseUserProfile', () => {
    let parsedProfile: ArcUserProfile;
    beforeEach(() => {
      parsedProfile = resource.parseUserProfile(UserProfile);
    });

    it('should add all namespaces under userProfileItems', () => {
      expect(parsedProfile.userProfileItems.length).toEqual(UserProfile.namespaces.length);
    });

    it('should add all group roles under the profile items group roles', () => {
      expect(parsedProfile.userProfileItems.length).toEqual(UserProfile.namespaces.length);
      for (let i = 0; i < parsedProfile.userProfileItems.length; i++) {
        expect(parsedProfile.userProfileItems[i].groupRoles.length).toEqual(
          UserProfile.namespaces[i].groupRoles.length
        );
      }
    });
  });

  describe('parseLinkItems', () => {
    let parsedUserGroups: LinkItem[];
    beforeEach(() => {
      parsedUserGroups = resource.parseLinkItems(UserLinkItems);
    });

    it('should return a list of LinkItems from the results', () => {
      expect(parsedUserGroups.length).toEqual(UserLinkItems.results.length);
      for (let i = 0; i < UserLinkItems.results.length; i++) {
        expect(parsedUserGroups[i].title).toEqual(UserLinkItems.results[i]._title);
        expect(parsedUserGroups[i].uuid).toEqual(UserLinkItems.results[i]._globalId);
        expect(parsedUserGroups[i].description).toEqual(UserLinkItems.results[i]['_description']);
      }
    });
  });

  describe('parseRoles', () => {
    let parsedRoles: Role[];
    beforeEach(() => {
      parsedRoles = resource.parseRoles(Roles);
    });

    it('should return the parsed list of all results', () => {
      expect(parsedRoles.length).toEqual(Roles.results.length);
      for (let i = 0; i < parsedRoles.length; i++) {
        expect(parsedRoles[i].title).toEqual(Roles.results[i]._title);
        expect(parsedRoles[i].uuid).toEqual(Roles.results[i]._globalId);
        expect(parsedRoles[i].description).toEqual(Roles.results[i]['_description']);
        expect(parsedRoles[i].rights.length).toEqual(Roles.results[i].Rights.length);
      }
    });

    it('should return the parsed list with parsed qualification rights', () => {
      expect(parsedRoles.length).toEqual(Roles.results.length);
      for (let i = 0; i < parsedRoles.length; i++) {
        const parsedRole: Role = parsedRoles[i];
        const unParsedRole = Roles.results[i];
        for (let j = 0; j < parsedRole.qualifications.length; j++) {
          expect(parsedRole.qualifications[j].right).toEqual(
            unParsedRole.QualifiedRights[j]._title
          );
          expect(parsedRole.qualifications[j].pattern).toEqual(
            unParsedRole.QualifiedRights[j]._pattern
          );
          if (unParsedRole.QualifiedRights[j].Qualifications) {
            const subrights = unParsedRole.QualifiedRights[j].Qualifications.map(q => q._title);
            expect(parsedRole.qualifications[j].subrights).toEqual(subrights);
          }
        }
      }
    });
  });
});
