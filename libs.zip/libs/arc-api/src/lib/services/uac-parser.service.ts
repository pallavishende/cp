import {
  LinkItem,
  MenuHier,
  UserGroup,
  SiteConfigItem,
  ArcUserProfile,
  ArcUserProfileItem,
  Role,
  UserGroupRoleItem
} from '../models';

export class UacParser {
  parseLinkItems(json): LinkItem[] {
    const items = [];
    for (const result of json.results) {
      items.push(this.parseLinkItem(result));
    }
    return items;
  }

  parseLinkItem(json): LinkItem {
    return {
      uuid: json._globalId,
      title: json._title ? json._title : json._globalId,
      description: json._description,
      contentType: json._contentType
    };
  }

  parseMenuHier(json): MenuHier {
    return this.parseLinkItem(json) as MenuHier;
  }

  parseUserGroup(json): UserGroup {
    const ug = {
      uuid: json._globalId,
      title: json.GroupName || json._title ? json._title : json._globalId,
      description: json.Description,
      ...json
    } as UserGroup;

    if (json.Role) {
      ug.defaultRoleName = json.Role._title ? json.Role._title : json.Role._globalId;
    }

    ug.users = [];
    if (json.Users) {
      for (const item of json.Users) {
        ug.users.push(this.parseLinkItem(item));
      }
    }

    // we don't use backlinks at the moment,
    // but retaining them so we can check against siteRoles derived from menu
    ug.backlinks = [];
    if (json.Backlinks) {
      for (const item of json.Backlinks.Items) {
        if (item._contentType === 'ISISConfig:SiteConfig') {
          ug.backlinks.push(this.parseSiteConfigItem(item));
        } else {
          ug.backlinks.push(this.parseLinkItem(item));
        }
      }
    }

    return ug;
  }

  private getSiteArcenv(site: SiteConfigItem) {
    const arcLive = 'posting.mongo-arc-v2.mtvnservices.com';
    const arcQa = 'posting.mongo-arc-v2.mtvnservices-q.mtvi.com';
    const arcStaging = 'posting.mongo-arc-v2.mtvnservices-s.mtvi.com';

    let env = 'other';
    if (site.server === arcLive && site.environment === 'authoring') {
      env = 'prod';
    } else if (site.server === arcQa) {
      if (site.environment === 'authoring-sandbox') {
        env = 'uat';
      } else if (site.environment === 'authoring') {
        env = 'qa';
      }
    } else if (site.server === arcStaging && site.environment === 'authoring') {
      env = 'staging';
    }
    return env;
  }

  parseSiteConfigItem(json): SiteConfigItem {
    const item = {
      uuid: json._globalId,
      title: json._name ? json._name : json._globalId,
      sitekey: json._title
    } as SiteConfigItem;
    item.name = json._name;
    item.siteName = json._siteName;
    if (json._description) {
      const array = json._description.split(' / ');
      item.server = array[0];
      item.environment = array[1];
      item.namespace = array[2];
    }
    item.arcenv = this.getSiteArcenv(item);
    return item;
  }

  parseUserProfile(json): ArcUserProfile {
    const profile = {
      userProfileItems: [],
      namespaces: []
    } as ArcUserProfile;
    for (const namespace of json.namespaces) {
      const item = {
        server: namespace.server,
        environment: namespace.environment,
        namespace: namespace.namespace,
        groupRoles: []
      } as ArcUserProfileItem;
      for (const groupRole of namespace.groupRoles) {
        item.groupRoles.push({ groupName: groupRole.userGroup, roleName: groupRole.role });
      }
      profile.userProfileItems.push(item);
    }
    return profile;
  }

  parseRoles(json): Role[] {
    const roles: Role[] = [];
    for (const item of json.results) {
      roles.push(this.parseRole(item));
    }
    // console.log('Roles', roles);
    return roles;
  }

  private parseRole(json): Role {
    const role = {
      uuid: json._globalId,
      title: json._title ? json._title : json._globalId,
      description: json._description,
      rights: [],
      qualifications: []
    } as Role;

    if (json.Rights) {
      for (const right of json.Rights) {
        role.rights.push(right._title);
      }
    }
    if (json.QualifiedRights) {
      for (const qr of json.QualifiedRights) {
        let quals: string[] = [];
        if (qr.Qualifications) {
          quals = qr.Qualifications.map(q => q._title);
        }
        role.qualifications.push({
          right: qr._title,
          pattern: qr._pattern,
          subrights: quals
        });
      }
    }
    return role;
  }

  // ------------------------------------------------------------------------------

  parseMenuTree(json): SiteConfigItem[] {
    const sites = [];
    this.parseNode(json, sites);
    return sites;
  }

  private parseNode(
    json,
    sites: SiteConfigItem[],
    path = '',
    inheritedUgroles: UserGroupRoleItem[] = [],
    inheritedFrom: MenuHier = null
  ) {
    if (json._contentType === 'ISISConfig:MenuHierarchy') {
      this.parseItems(json, sites, path, inheritedUgroles, inheritedFrom);
      this.parseChildren(json, sites, path, inheritedUgroles, inheritedFrom);
    }
  }

  private parseItems(
    json,
    sites: SiteConfigItem[],
    path = '',
    inheritedUgroles: UserGroupRoleItem[] = [],
    inheritedFrom: MenuHier = null
  ) {
    if (json.Items) {
      for (const item of json.Items) {
        const site = this.parseSiteConfigItem(item);
        const dulicateSite = sites.find(s => s.sitekey === site.sitekey);
        if (dulicateSite) {
          continue;
        }
        site.path = path;

        if (item.Users) {
          console.error('site contains Users: ' + site.sitekey);
        }

        const ugroles = this.parseUgroles(item);
        if (ugroles.length) {
          site.ugroles = ugroles;
        } else if (inheritedUgroles.length) {
          // console.log('inheriting uac for site ' + site.sitekey + ' from ' + (inheritedFrom ? inheritedFrom.fullName : 'none'));
          site.inheritedUgroles = inheritedUgroles;
          site.inheritedFrom = inheritedFrom;
        }
        site.hasUAC = !(
          site.ugroles &&
          site.ugroles.length === 1 &&
          site.ugroles[0].userGroup.title &&
          site.ugroles[0].userGroup.title.toLowerCase().includes('default')
        );

        sites.push(site);
      }
    }
  }

  private parseChildren(
    json,
    sites: SiteConfigItem[],
    path = '',
    inheritedUgroles: UserGroupRoleItem[] = [],
    inheritedFrom: MenuHier = null
  ) {
    if (json.Children) {
      for (const child of json.Children) {
        if (child.Users) {
          console.error(
            'menuhier contains Users: ' + child._title + (path ? ' (' + path + ')' : '')
          );
        }

        let ugroles: UserGroupRoleItem[] = this.parseUgroles(child);
        let ugrolesFrom = this.parseMenuHier(child);
        if (ugroles.length) {
          ugrolesFrom = this.parseMenuHier(child);
          ugrolesFrom.path = path;
          ugrolesFrom.fullName = this.appendPath(path, child._title);
        } else {
          // console.log('inheriting uac for menuhier ' + json._title + ' from ' + (inheritedFrom ? inheritedFrom.fullName : 'none'));
          ugroles = inheritedUgroles;
          ugrolesFrom = inheritedFrom;
        }

        // RECURSION
        this.parseNode(child, sites, this.appendPath(path, child._title), ugroles, ugrolesFrom);
      }
    }
  }

  // private parseUgroles(json, inheritedUgroles: UserGroupRoleItem[]): UserGroupRoleItem[] {
  public parseUgroles(json): UserGroupRoleItem[] {
    const ugroles: UserGroupRoleItem[] = [];
    if (json.UserGroups) {
      for (const item of json.UserGroups) {
        const ug = this.parseLinkItem(item);
        ugroles.push({
          ...ug,
          userGroup: ug,
          roleName: item._defaultRole
        });
      }
    }
    if (json.UserGroupsWithRoles) {
      for (const item of json.UserGroupsWithRoles) {
        const ug = this.parseLinkItem(item.UserGroup);
        const roleName = item.Role ? item.Role._title : item.UserGroup._defaultRole;
        ugroles.push({
          ...ug,
          uuid: item._globalId,
          contentType: item._contentType,
          userGroup: ug,
          role: item.Role && this.parseLinkItem(item.Role),
          roleName
        });
      }
    }
    // return (ugroles.length ? ugroles : inheritedUgroles);
    return ugroles;
  }

  private appendPath(path: string, suffix: string): string {
    return path ? path + ' | ' + suffix : suffix;
  }
}
