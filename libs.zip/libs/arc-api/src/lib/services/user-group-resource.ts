import { Injectable } from '@angular/core';
import { LoggerService } from '@content-platform/logging';
import { throwError, Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UacParser } from './uac-parser.service';
import { UserGroup, UserDetail, LinkItem } from '../models';
import { map, catchError, switchMap, take } from 'rxjs/operators';
import { ApiParams, ISIS_CONFIG_SITE } from './api-params';
import { UserResource } from './user-resource';
import { chain } from 'lodash';
import { UserProfile } from '@content-platform/graph-api';

@Injectable()
export class UserGroupResource {
  private logger: LoggerService;

  constructor(
    private http: HttpClient,
    logger: LoggerService,
    private apiParams: ApiParams,
    private parser: UacParser,
    private userResource: UserResource
  ) {
    this.logger = logger.instance('UserGroupResource');
  }

  private getHeaders() {
    // NOTE: with new HttpClient, headers are immutable
    return new HttpHeaders().set('Content-Type', 'application/json');
  }

  loadUserGroups(_instanceName: string = 'live'): Observable<UserGroup[]> {
    const url = this.apiParams.getUrl('arcContent', { siteKey: ISIS_CONFIG_SITE });
    const params = {
      contentType: 'ISISConfig:UserGroup',
      pageSize: '500',
      searchEngine: 'uca'
    };
    const headers = this.getHeaders();
    return this.http.get(url, { headers, params }).pipe(
      map(response => {
        return this.parser.parseLinkItems(response) as UserGroup[];
      }),
      catchError(error => this.handleError(`Unable to load User Groups`, error))
    );
  }

  private getUserDetails(groups: UserGroup[]): Observable<{ [key: string]: UserDetail }> {
    const userLdaps: string[] = chain(groups)
      .flatMap(group => group.users)
      .filter(user => user && user.title)
      .flatMap((user: LinkItem) => user.title)
      .uniq()
      .value();
    return this.userResource.getUserDetails(userLdaps).pipe(
      map(userDetails => {
        return userDetails.reduce(
          (entities: { [key: string]: UserProfile }, detail: UserProfile) => {
            return {
              ...entities,
              [detail.mailNickname.toLowerCase()]: detail
            };
          },
          {}
        );
      }),
      take(1)
    );
  }

  private addUserDetailsToGroup(
    userGroup: UserGroup,
    userDetails: { [key: string]: UserDetail }
  ): void {
    userGroup.userDetails = {};
    if (userGroup.users) {
      userGroup.users.forEach(user => {
        if (user && user.title) {
          userGroup.userDetails[user.title] = userDetails[user.title.toLowerCase()];
        }
      });
    }
  }

  loadUserGroup(uuid: string): Observable<UserGroup> {
    const url = this.apiParams.getUrl('arcContentById', {
      uuid,
      siteKey: ISIS_CONFIG_SITE
    });
    const headers = this.getHeaders();
    return this.http.get(url + '?backlinks=true', { headers }).pipe(
      switchMap(response => {
        const userGroup = this.parser.parseUserGroup(response);
        return this.getUserDetails([userGroup]).pipe(
          map(userDetailEntities => {
            this.addUserDetailsToGroup(userGroup, userDetailEntities);
            return userGroup;
          })
        );
      }),
      catchError(error => this.handleError(`Unable to load User Group with id ${uuid}`, error))
    );
  }

  appendUserToUserGroup(userGroup: UserGroup, user: LinkItem): Observable<UserGroup> {
    const updates = {
      Users: {
        add: [{ _globalId: user.uuid }]
      }
    };
    return this.updateUserGroup(userGroup, updates).pipe(
      switchMap(updUserGroup => {
        return this.userResource.getUserDetails([user.title]).pipe(
          map(userDetails => {
            updUserGroup.userDetails = {
              ...userGroup.userDetails,
              [user.title]: userDetails[0]
            };
            return updUserGroup;
          })
        );
      })
    );
  }

  removeUserFromUserGroup(userGroup: UserGroup, user: LinkItem): Observable<UserGroup> {
    const updates = {
      Users: {
        remove: [{ _globalId: user.uuid }]
      }
    };
    return this.updateUserGroup(userGroup, updates);
  }

  private updateUserGroup(userGroup: UserGroup, updates): Observable<UserGroup> {
    const url = this.apiParams.getUrl('arcContentById', {
      uuid: userGroup.uuid,
      siteKey: ISIS_CONFIG_SITE
    });
    const headers = this.getHeaders();
    return this.http.patch(url, updates, { headers }).pipe(
      map(response => {
        const updatedGroup = this.parser.parseUserGroup(response);
        return updatedGroup;
      })
    );
  }

  /**
   * error handling in case the resource call fails
   *
   * @protected
   * @param {(Response | any)} error
   * @returns {Observable<any>}
   * @memberof Resource
   */
  protected handleError(msg: string, error: Response | any): Observable<any> {
    const body = error.error && !error.message ? error.error : error;
    const err = (body && body.message) || JSON.stringify(body) || 'Server Error';
    this.logger.log(msg, body);
    return throwError(err);
  }
}
