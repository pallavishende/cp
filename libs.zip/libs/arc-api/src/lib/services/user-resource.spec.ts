import { TestBed } from '@angular/core/testing';
import { UserResource } from './user-resource';
import { UacParser } from './uac-parser.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { LoggerService } from '@content-platform/logging';
import { ApiParams } from './api-params';
import { of } from 'rxjs';
import { SiteConfigItem, ArcUserProfileItem } from '../models';
import { HttpRequest } from '@angular/common/http';
import { GraphApi, UserProfile } from '@content-platform/graph-api';

function matchFun(url): ((req: HttpRequest<any>) => boolean) {
  return (req: HttpRequest<any>): boolean => {
    return req.url.startsWith(url);
  };
}

describe('UserResource', () => {
  let resource: UserResource;
  let httpMock: HttpTestingController;
  let graphApi: GraphApi;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        UserResource,
        {
          provide: UacParser,
          useValue: {
            parseUserProfile: data => data,
            parseLinkItems: data => data
          }
        },
        {
          provide: LoggerService,
          useValue: {
            instance: () => {
              return { log: () => {} };
            }
          }
        },
        {
          provide: ApiParams,
          useValue: {
            getUrl: id => id
          }
        },
        {
          provide: GraphApi,
          useValue: {
            getUsersByLdap: () => of([])
          }
        }
      ]
    });

    resource = TestBed.get(UserResource);
    httpMock = TestBed.get(HttpTestingController);
    graphApi = TestBed.get(GraphApi);
  });

  it('should be created', () => {
    expect(resource).toBeTruthy();
  });

  describe('findUsersByTypeahead', () => {
    it('should trigger get request for searching', done => {
      resource.findUsersByTypeahead('title').subscribe(results => {
        expect(results).toEqual([
          {
            uuid: 'test',
            title: 'title',
            description: 'description'
          }
        ]);
        done();
      });

      const req = httpMock.expectOne(matchFun(`arcContentTypeahead`));
      expect(req.request.method).toBe('GET');
      req.flush({
        results: [
          {
            _uuid: 'test',
            _title: 'title',
            _description: 'description'
          }
        ]
      });

      httpMock.verify();
    });

    it('should set title to _globalId, if _title is undefined', done => {
      resource.findUsersByTypeahead('globalid').subscribe(results => {
        expect(results).toEqual([
          {
            uuid: 'test',
            title: 'globalid',
            description: 'description'
          }
        ]);
        done();
      });

      const req = httpMock.expectOne(matchFun(`arcContentTypeahead`));
      expect(req.request.method).toBe('GET');
      req.flush({
        results: [
          {
            _uuid: 'test',
            _globalId: 'globalid',
            _description: 'description'
          }
        ]
      });

      httpMock.verify();
    });

    it('should filter results incase titles do not match', done => {
      resource.findUsersByTypeahead('title').subscribe(results => {
        expect(results).toEqual([]);
        done();
      });

      const req = httpMock.expectOne(matchFun(`arcContentTypeahead`));
      expect(req.request.method).toBe('GET');
      req.flush({
        results: [
          {
            _uuid: '',
            _globalId: 'test',
            _description: 'description'
          }
        ]
      });

      httpMock.verify();
    });

    it('should handle the error correctly, if it failed', done => {
      jest.spyOn((<any>resource).logger, 'log');
      resource.findUsersByTypeahead('title').subscribe(
        () => {},
        error => {
          expect(error).toContain('Http failure response for arcContentTypeahead');
          expect((<jest.Mock>resource['logger'].log).mock.calls[0][0]).toEqual(
            'Searching for title Failed'
          );
          done();
        }
      );

      const req = httpMock.expectOne(matchFun(`arcContentTypeahead`));
      expect(req.request.method).toBe('GET');
      req.error({ message: 'Failed' } as ErrorEvent);
      httpMock.verify();
    });
  });

  describe('getFullUser', () => {
    it('should call both getUserProfile & getGroupsByUser & getUserDetails, combine results and return a User', done => {
      jest
        .spyOn(<any>resource, 'getUserProfile')
        .mockImplementationOnce(() => of({ namespaces: [] }));
      jest.spyOn(<any>resource, 'getGroupsByUser').mockImplementationOnce(() => of([]));
      jest.spyOn(<any>resource, 'getUserDetails').mockImplementationOnce(() => of({}));

      resource.getFullUser('title', 'uuid', {}).subscribe(user => {
        expect(resource['getUserProfile']).toHaveBeenCalledWith('title', {});
        expect(resource['getGroupsByUser']).toHaveBeenCalledWith('uuid');
        expect(resource['getUserDetails']).toHaveBeenCalledWith(['title']);
        expect(user.profile.namespaces).toBeDefined();
        expect(user.userGroups).toEqual([]);
        done();
      });
    });

    describe('getUserProfile', () => {
      beforeEach(() => {
        jest.spyOn(<any>resource, 'getGroupsByUser').mockImplementationOnce(() => of([]));
        jest.spyOn(<any>resource, 'getUserDetails').mockImplementationOnce(() => of({}));
      });

      it('should trigger a get request and return the profile', done => {
        resource.getFullUser('title', 'uuid', {}).subscribe(user => {
          expect(user.profile).toEqual({ namespaces: [], userProfileItems: [] });
          done();
        });
        const req = httpMock.expectOne(matchFun('userProfile'));
        expect(req.request.method).toBe('GET');
        req.flush({ namespaces: [], userProfileItems: [] });
      });

      it('should add UserProfileNamespace to namespaces if site matches namespaceKey', done => {
        jest.spyOn(console, 'warn');
        resource
          .getFullUser('title', 'uuid', {
            'server / env / namespace': <SiteConfigItem[]>[
              {
                name: 'test',
                siteName: 'siteName'
              }
            ]
          })
          .subscribe(user => {
            expect(user.profile.userProfileItems).toEqual(<ArcUserProfileItem[]>[
              {
                server: 'server',
                environment: 'env',
                namespace: 'namespace',
                groupRoles: []
              },
              {
                server: 's',
                environment: 'env',
                namespace: 'namespace',
                groupRoles: []
              }
            ]);
            expect(user.profile.namespaces.length).toEqual(1);
            expect(user.profile.namespaces[0].site).toEqual(<SiteConfigItem>{
              name: 'test',
              siteName: 'siteName'
            });
            expect(console.warn).toHaveBeenCalledWith(
              'site not found for namespace: s / env / namespace'
            );
            done();
          });
        const req = httpMock.expectOne(matchFun('userProfile'));
        expect(req.request.method).toBe('GET');
        req.flush({
          namespaces: [],
          userProfileItems: [
            {
              server: 'server',
              environment: 'env',
              namespace: 'namespace',
              groupRoles: []
            },
            {
              server: 's',
              environment: 'env',
              namespace: 'namespace',
              groupRoles: []
            }
          ]
        });
      });

      afterEach(() => {
        httpMock.verify();
      });
    });

    describe('getGroupsByUser', () => {
      beforeEach(() => {
        jest
          .spyOn(<any>resource, 'getUserProfile')
          .mockImplementationOnce(() => of({ namespaces: [] }));
        jest.spyOn(<any>resource, 'getUserDetails').mockImplementationOnce(() => of({}));
      });

      it('should make a get request and return the parsed user groups', done => {
        resource.getFullUser('title', 'uuid', {}).subscribe(user => {
          expect(user.userGroups).toEqual([]);
          done();
        });
        const req = httpMock.expectOne(matchFun('arcContent'));
        expect(req.request.method).toBe('GET');
        req.flush([]);
      });

      afterEach(() => {
        httpMock.verify();
      });
    });

    describe('getUserDetails', () => {
      beforeEach(() => {
        jest
          .spyOn(<any>resource, 'getUserProfile')
          .mockImplementationOnce(() => of({ namespaces: [] }));
        jest.spyOn(<any>resource, 'getGroupsByUser').mockImplementationOnce(() => of([]));
      });

      it('should make a post request and add user details to the user', done => {
        jest.spyOn(graphApi, 'getUsersByLdap').mockImplementationOnce(() =>
          of([
            {
              mail: 'email',
              surname: 'surname'
            }
          ])
        );
        resource.getFullUser('title', 'uuid', {}).subscribe(user => {
          expect(user.userProfile).toEqual({
            mail: 'email',
            surname: 'surname'
          } as UserProfile);
          expect(graphApi.getUsersByLdap).toHaveBeenCalled();
          done();
        });
      });

      afterEach(() => {
        httpMock.verify();
      });
    });
  });
});
