import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoggerService } from '@content-platform/logging';
import { ApiParams, ISIS_CONFIG_SITE } from './api-params';
import { Observable, throwError, forkJoin, of } from 'rxjs';
import { LinkItem } from '../models/link-item.model';
import { map, catchError, take } from 'rxjs/operators';
import { TypeaheadData } from '../models/typeahead-data';
import { User, ArcUserProfile, SiteConfigItem, ArcUserProfileNamespace } from '../models';
import { UacParser } from './uac-parser.service';
import { siteSelectors } from '../store/selectors';
import { GraphApi, UserProfile } from '@content-platform/graph-api';

@Injectable()
export class UserResource {
  private logger: LoggerService;
  constructor(
    private http: HttpClient,
    logger: LoggerService,
    private apiParams: ApiParams,
    private parser: UacParser,
    private graphApi: GraphApi
  ) {
    this.logger = logger.instance('SiteResource');
  }

  getUserByLdap(ldap: string): Observable<LinkItem> {
    return this.findUsersByTypeahead(ldap).pipe(map(results => results[0]));
  }

  findUsersByTypeahead(usernamePrefix: string): Observable<LinkItem[]> {
    // this is case-insensitive
    const url = this.apiParams.getUrl('arcContentTypeahead', { siteKey: ISIS_CONFIG_SITE });
    const headers = this.getHeaders();
    const params = {
      contentType: 'ISISConfig:User',
      search: usernamePrefix,
      sort: 'title'
    };
    return this.http.get(url, { headers, params }).pipe(
      map((response: TypeaheadData) => {
        return response.results
          .map(item => {
            return {
              uuid: item._uuid,
              title: item._title ? item._title : item._globalId,
              description: item._description
            };
          })
          .filter(user => user.title.toLowerCase().startsWith(usernamePrefix.toLowerCase()));
      }),
      catchError(error => this.handleError(`Searching for ${usernamePrefix} Failed`, error))
    );
  }

  getUserDetails(users: string[]): Observable<UserProfile[]> {
    if (users.length === 0) {
      return of([]);
    }
    return this.graphApi.getUsersByLdap(users).pipe(take(1));
  }

  getFullUser(
    title: string,
    uuid: string,
    sitesmap: { [key: string]: SiteConfigItem[] } = {}
  ): Observable<User> {
    return forkJoin(
      this.getUserProfile(title, sitesmap).pipe(take(1)),
      this.getGroupsByUser(uuid).pipe(take(1)),
      this.getUserDetails([title]).pipe(take(1))
    ).pipe(
      map(responses => {
        const profile = <ArcUserProfile>responses[0];
        const userGroups = <LinkItem[]>responses[1];
        return {
          uuid,
          title,
          profile,
          userGroups,
          userProfile: responses[2][0]
        } as User;
      })
    );
  }

  private getUserProfile(
    userName: string,
    nsmap: { [key: string]: SiteConfigItem[] }
  ): Observable<ArcUserProfile> {
    const url = this.apiParams.getUrl('userProfile', { userName });
    const headers = this.getHeaders();
    return this.http.get(url, { headers }).pipe(
      map(response => {
        const profile = this.parser.parseUserProfile(response);
        for (const item of profile.userProfileItems) {
          const sites = nsmap[siteSelectors.getNamespaceKey(item)];
          if (sites) {
            sites.forEach(site =>
              profile.namespaces.push(<ArcUserProfileNamespace>{
                site,
                groupRoles: item.groupRoles,
                hasUAC: !(
                  item.groupRoles.length === 1 &&
                  item.groupRoles[0].groupName &&
                  item.groupRoles[0].groupName.toLowerCase().includes('default')
                )
              })
            );
          } else {
            console.warn('site not found for namespace: ' + siteSelectors.getNamespaceKey(item));
          }
        }
        return profile;
      })
    );
  }

  private getGroupsByUser(uuid: string) {
    const url = this.apiParams.getUrl('arcContent', { siteKey: ISIS_CONFIG_SITE });
    const params = {
      contentType: 'ISISConfig:UserGroup',
      'field.Users.link.list': uuid,
      sort: 'title',
      pageSize: '500',
      searchEngine: 'uca'
    };
    const headers = this.getHeaders();
    return this.http.get(url, { headers, params }).pipe(
      map(response => {
        const userGroups = this.parser.parseLinkItems(response);
        return userGroups;
      })
    );
  }

  private getHeaders() {
    // NOTE: with new HttpClient, headers are immutable
    return new HttpHeaders().set('Content-Type', 'application/json');
  }

  /**
   * error handling in case the resource call fails
   *
   * @protected
   * @param {(Response | any)} error
   * @returns {Observable<any>}
   * @memberof Resource
   */
  protected handleError(msg: string, error: Response | any): Observable<any> {
    const body = error.error && !error.message ? error.error : error;
    const err = (body && body.message) || JSON.stringify(body) || 'Server Error';
    this.logger.log(msg, body);
    return throwError(err);
  }
}
