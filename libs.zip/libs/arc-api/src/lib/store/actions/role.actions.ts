import { Action } from '@ngrx/store';
import { Role } from '../../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD = '[Arc Role] LOAD';
export const LOAD_SUCCESS = '[Arc Role] LOAD SUCCESS';
export const LOAD_FAILED = '[Arc Role] LOAD FAILED';

export class Load implements Action {
  readonly type = LOAD;
  constructor(public payload = null) {}
}

export class LoadSuccess implements Action {
  readonly type = LOAD_SUCCESS;
  constructor(public payload: Role[]) {}
}

export class LoadFailed extends errorActions.Fail {
  readonly type = LOAD_FAILED;
}

export type All = Load | LoadSuccess | LoadFailed;
