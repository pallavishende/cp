import { Action } from '@ngrx/store';
import { SiteConfigItem, UserGroupRequestData, UserGroupWithRolesRequestData } from '../../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD = '[Site] LOAD';
export const LOAD_SUCCESS = '[Site] LOAD SUCCESS';
export const LOAD_FAILED = '[Site] LOAD FAILED';
export const UPDATE_SITE_USER_GROUP = '[Site] UPDATE SITE USER GROUP';
export const LOAD_BY_KEY = '[Site] LOAD BY KEY';
export const LOAD_BY_KEY_SUCCESS = '[Site] LOAD BY KEY SUCCESS';
export const LOAD_BY_KEY_FAILED = '[Site] LOAD BY KEY FAILED';
export const UPDATE_SUCCESS = '[Site] UPDATE SUCCESS';
export const UPDATE_FAILED = '[Site] UPDATE FAILED';
export const DELETE = '[Site] DELETE';
export const DELETE_SUCCESS = '[Site] DELETE SUCCESS';
export const DELETE_FAILED = '[Site] DELETE FAILED';
export const CREATE = '[Site] CREATE';
export const CREATE_SUCCESS = '[Site] CREATE SUCCESS';
export const CREATE_FAILED = '[Site] CREATE FAILED';

export class Load implements Action {
  readonly type = LOAD;
  constructor(public payload = null) {}
}

export class LoadSuccess implements Action {
  readonly type = LOAD_SUCCESS;
  constructor(public payload: SiteConfigItem[]) {}
}

export class LoadFailed extends errorActions.Fail {
  readonly type = LOAD_FAILED;
}

export class LoadByKey implements Action {
  readonly type = LOAD_BY_KEY;
  constructor(public payload: string) {}
}

export class LoadByKeySuccess implements Action {
  readonly type = LOAD_BY_KEY_SUCCESS;
  constructor(public payload: SiteConfigItem) {}
}

export class LoadByKeyFailed extends errorActions.Fail {
  readonly type = LOAD_BY_KEY_FAILED;
}

export class UpdateSiteUserGroup implements Action {
  readonly type = UPDATE_SITE_USER_GROUP;
  constructor(
    public payload: {
      uuid: string;
      data: {
        UserGroupsWithRoles?:
          | {
              add?: UserGroupWithRolesRequestData[];
              remove?: UserGroupWithRolesRequestData[];
            }
          | UserGroupWithRolesRequestData[];
        UserGroups?:
          | {
              add?: UserGroupRequestData[];
              remove?: UserGroupRequestData[];
            }
          | UserGroupRequestData[];
      };
    }
  ) {}
}

export class UpdateSuccess implements Action {
  readonly type = UPDATE_SUCCESS;
  constructor(public payload: SiteConfigItem) {}
}

export class UpdateFailed extends errorActions.Fail {
  readonly type = UPDATE_FAILED;
}

export class Delete implements Action {
  readonly type = DELETE;
  constructor(public payload: number) {}
}

export class DeleteSuccess implements Action {
  readonly type = DELETE_SUCCESS;
  constructor(public payload: number) {}
}

export class DeleteFailed extends errorActions.Fail {
  readonly type = DELETE_FAILED;
}

export class Create implements Action {
  readonly type = CREATE;
  constructor(public payload: SiteConfigItem) {}
}

export class CreateSuccess implements Action {
  readonly type = CREATE_SUCCESS;
  constructor(public payload: SiteConfigItem) {}
}

export class CreateFailed extends errorActions.Fail {
  readonly type = CREATE_FAILED;
}

export type All =
  | Load
  | LoadSuccess
  | LoadFailed
  | LoadByKey
  | LoadByKeySuccess
  | LoadByKeyFailed
  | UpdateSiteUserGroup
  | UpdateSuccess
  | UpdateFailed
  | Create
  | CreateSuccess
  | CreateFailed
  | Delete
  | DeleteSuccess
  | DeleteFailed;
