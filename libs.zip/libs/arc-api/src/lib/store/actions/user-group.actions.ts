import { Action } from '@ngrx/store';
import { UserGroup, LinkItem } from '../../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD = '[UserGroup] LOAD';
export const LOAD_SUCCESS = '[UserGroup] LOAD SUCCESS';
export const LOAD_FAILED = '[UserGroup] LOAD FAILED';
export const LOAD_BY_ID = '[UserGroup] LOAD_BY_ID';
export const LOAD_BY_ID_SUCCESS = '[UserGroup] LOAD_BY_ID SUCCESS';
export const LOAD_BY_ID_FAILED = '[UserGroup] LOAD_BY_ID FAILED';
export const UPDATE = '[UserGroup] UPDATE';
export const UPDATE_SUCCESS = '[UserGroup] UPDATE SUCCESS';
export const UPDATE_FAILED = '[UserGroup] UPDATE FAILED';
export const ADD_USER = '[UserGroup] ADD_USER';
export const ADD_USER_BY_LDAP = '[UserGroup] ADD_USER_BY_LDAP';
export const ADD_USER_SUCCESS = '[UserGroup]  ADD_USER SUCCESS';
export const ADD_USER_FAILED = '[UserGroup]  ADD_USER FAILED';
export const REMOVE_USER = '[UserGroup] REMOVE_USER';
export const REMOVE_USER_SUCCESS = '[UserGroup]  REMOVE_USER SUCCESS';
export const REMOVE_USER_FAILED = '[UserGroup]  REMOVE_USER FAILED';
export const DELETE = '[UserGroup] DELETE';
export const DELETE_SUCCESS = '[UserGroup] DELETE SUCCESS';
export const DELETE_FAILED = '[UserGroup] DELETE FAILED';
export const CREATE = '[UserGroup] CREATE';
export const CREATE_SUCCESS = '[UserGroup] CREATE SUCCESS';
export const CREATE_FAILED = '[UserGroup] CREATE FAILED';

export class Load implements Action {
  readonly type = LOAD;
  constructor(public payload = null) {}
}

export class LoadSuccess implements Action {
  readonly type = LOAD_SUCCESS;
  constructor(public payload: UserGroup[]) {}
}

export class LoadFailed extends errorActions.Fail {
  readonly type = LOAD_FAILED;
}

export class LoadById implements Action {
  readonly type = LOAD_BY_ID;
  constructor(public payload: string) {}
}

export class LoadByIdSuccess implements Action {
  readonly type = LOAD_BY_ID_SUCCESS;
  constructor(public payload: UserGroup) {}
}

export class LoadByIdFailed extends errorActions.Fail {
  readonly type = LOAD_BY_ID_FAILED;
}

export class Update implements Action {
  readonly type = UPDATE;
  constructor(public payload: UserGroup) {}
}

export class UpdateSuccess implements Action {
  readonly type = UPDATE_SUCCESS;
  constructor(public payload: UserGroup) {}
}

export class UpdateFailed extends errorActions.Fail {
  readonly type = UPDATE_FAILED;
}

export class AddUser implements Action {
  readonly type = ADD_USER;
  constructor(public payload: UserGroup, public user: LinkItem) {}
}
export class AddUserByLDAP implements Action {
  readonly type = ADD_USER_BY_LDAP;
  constructor(public payload: UserGroup, public userLdap: string) {}
}

export class AddUserSuccess implements Action {
  readonly type = ADD_USER_SUCCESS;
  constructor(public payload: UserGroup) {}
}

export class AddUserFailed extends errorActions.Fail {
  readonly type = ADD_USER_FAILED;
}

export class RemoveUser implements Action {
  readonly type = REMOVE_USER;
  constructor(public payload: UserGroup, public user: LinkItem) {}
}

export class RemoveUserSuccess implements Action {
  readonly type = REMOVE_USER_SUCCESS;
  constructor(public payload: UserGroup) {}
}

export class RemoveUserFailed extends errorActions.Fail {
  readonly type = REMOVE_USER_FAILED;
}
export class Delete implements Action {
  readonly type = DELETE;
  constructor(public payload: string) {}
}

export class DeleteSuccess implements Action {
  readonly type = DELETE_SUCCESS;
  constructor(public payload: string) {}
}

export class DeleteFailed extends errorActions.Fail {
  readonly type = DELETE_FAILED;
}

export class Create implements Action {
  readonly type = CREATE;
  constructor(public payload: UserGroup) {}
}

export class CreateSuccess implements Action {
  readonly type = CREATE_SUCCESS;
  constructor(public payload: UserGroup) {}
}

export class CreateFailed extends errorActions.Fail {
  readonly type = CREATE_FAILED;
}

export type All =
  | Load
  | LoadSuccess
  | LoadFailed
  | LoadById
  | LoadByIdSuccess
  | LoadByIdFailed
  | Update
  | UpdateSuccess
  | UpdateFailed
  | AddUser
  | AddUserByLDAP
  | AddUserSuccess
  | AddUserFailed
  | RemoveUser
  | RemoveUserSuccess
  | RemoveUserFailed
  | Create
  | CreateSuccess
  | CreateFailed
  | Delete
  | DeleteSuccess
  | DeleteFailed;
