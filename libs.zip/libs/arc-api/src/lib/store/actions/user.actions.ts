import { Action } from '@ngrx/store';
import { User } from '../../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD = '[Arc User] LOAD';
export const LOAD_SUCCESS = '[Arc User] LOAD SUCCESS';
export const LOAD_FAILED = '[Arc User] LOAD FAILED';
export const UPDATE = '[Arc User] UPDATE';
export const UPDATE_SUCCESS = '[Arc User] UPDATE SUCCESS';
export const UPDATE_FAILED = '[Arc User] UPDATE FAILED';
export const DELETE = '[Arc User] DELETE';
export const DELETE_SUCCESS = '[Arc User] DELETE SUCCESS';
export const DELETE_FAILED = '[Arc User] DELETE FAILED';

export class Load implements Action {
  readonly type = LOAD;
  constructor(public payload: { uuid: string; title: string }) {}
}

export class LoadSuccess implements Action {
  readonly type = LOAD_SUCCESS;
  constructor(public payload: User) {}
}

export class LoadFailed extends errorActions.Fail {
  readonly type = LOAD_FAILED;
}

export class Update implements Action {
  readonly type = UPDATE;
  constructor(public payload: User) {}
}

export class UpdateSuccess implements Action {
  readonly type = UPDATE_SUCCESS;
  constructor(public payload: User) {}
}

export class UpdateFailed extends errorActions.Fail {
  readonly type = UPDATE_FAILED;
}

export class Delete implements Action {
  readonly type = DELETE;
  constructor(public payload: number) {}
}

export class DeleteSuccess implements Action {
  readonly type = DELETE_SUCCESS;
  constructor(public payload: number) {}
}

export class DeleteFailed extends errorActions.Fail {
  readonly type = DELETE_FAILED;
}

export type All =
  | Load
  | LoadSuccess
  | LoadFailed
  | Update
  | UpdateSuccess
  | UpdateFailed
  | Delete
  | DeleteSuccess
  | DeleteFailed;
