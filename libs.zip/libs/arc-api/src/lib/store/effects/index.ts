import { SiteEffects } from './site.effects';
import { UserEffects } from './user.effects';
import { RoleEffects } from './role.effects';
import { UserGroupEffects } from './user-group.effects';

export * from './site.effects';
export * from './user.effects';
export * from './role.effects';
export * from './user-group.effects';

const effects = [SiteEffects, UserEffects, RoleEffects, UserGroupEffects];

export { effects };
