import { Injectable } from '@angular/core';
import { Effect } from '@ngrx/effects';
import { State } from '../reducers/site';

import { DataPersistence } from '@nrwl/nx';
import { RoleResource } from '../../services';
import { roleActions } from '../actions';
import { map } from 'rxjs/operators';

/**
 * The Role effects imported in {@link ArcApiModule }
 *
 */
@Injectable()
export class RoleEffects {
  constructor(private api: RoleResource, private dataPersistence: DataPersistence<State>) {}

  @Effect()
  loadUser$ = this.dataPersistence.fetch(roleActions.LOAD, {
    run: (_action: roleActions.Load) => {
      return this.api.loadRoles().pipe(map(roles => new roleActions.LoadSuccess(roles)));
    },
    onError: (_action: roleActions.Load, error) => {
      return new roleActions.LoadFailed({
        error,
        message: 'Unable to load ARC Roles'
      });
    }
  });
}
