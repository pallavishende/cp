import { Injectable } from '@angular/core';
import { Effect, ofType, Actions } from '@ngrx/effects';
import { State } from '../reducers/site';
import { map, switchMap, catchError } from 'rxjs/operators';

import { SiteResource } from '../../services';
import { arcSiteActions } from '../actions';
import { DataPersistence } from '@nrwl/nx';
import { SiteConfigItem } from '../../models';
import { SpinnerDialogComponent } from '@content-platform/reusable-ui/loading-spinner';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { siteSelectors } from '../selectors';

/**
 * The Site effects imported in {@link ArcApiModule }
 *
 */
@Injectable()
export class SiteEffects {
  private dialogRef: MatDialogRef<SpinnerDialogComponent>;
  dialogConfig: MatDialogConfig;

  constructor(
    private api: SiteResource,
    private dataPersistence: DataPersistence<State>,
    private siteActions$: Actions,
    private dialog: MatDialog
  ) {
    this.dialogConfig = new MatDialogConfig();
    this.dialogConfig.disableClose = true;
    this.dialogConfig.panelClass = 'loading-spinner-wrapper';
  }

  @Effect()
  load$ = this.dataPersistence.fetch(arcSiteActions.LOAD, {
    run: (_action: arcSiteActions.Load) => {
      return this.api.loadSites().pipe(map(arcSites => new arcSiteActions.LoadSuccess(arcSites)));
    },
    onError: (_action: arcSiteActions.Load, error) => {
      return new arcSiteActions.LoadFailed({
        error,
        message: 'Unable to load ARC Sites'
      });
    }
  });

  @Effect()
  getSiteByKey$ = this.dataPersistence.fetch(arcSiteActions.LOAD_BY_KEY, {
    run: (action: arcSiteActions.LoadByKey, state) => {
      const siteData = siteSelectors.getSiteEntities(state)[action.payload];
      if (siteData && siteData.uuid) {
        return this.api.loadSiteByGlobalId(siteData.uuid).pipe(
          map(arcSite => {
            return new arcSiteActions.LoadByKeySuccess(<SiteConfigItem>arcSite);
          })
        );
      }
    },
    onError: (action: arcSiteActions.LoadByKey, error) => {
      return new arcSiteActions.LoadByKeyFailed({
        error,
        message: 'Unable to load ARC site',
        source: action.payload
      });
    }
  });

  @Effect()
  updateUserGroup$ = this.siteActions$.pipe(
    ofType(arcSiteActions.UPDATE_SITE_USER_GROUP),
    map((action: arcSiteActions.UpdateSiteUserGroup) => action.payload),
    switchMap(data => {
      this.showSpinner();
      return this.api.updateSiteUserGroup(data.uuid, data.data).pipe(
        map(arcSite => {
          this.hideSpinner();
          const site = <SiteConfigItem>arcSite;
          if (site.ugroles && site.ugroles.length > 0) {
            const lastUgRole = site.ugroles[site.ugroles.length - 1];
            lastUgRole['$isActive'] = true; // Making sure we select this item
          }
          return new arcSiteActions.UpdateSuccess(<SiteConfigItem>arcSite);
        }),
        catchError(error => {
          this.hideSpinner();
          return [
            new arcSiteActions.UpdateFailed({
              error: error,
              message: 'Unable to update site'
            })
          ];
        })
      );
    })
  );

  private showSpinner() {
    this.hideSpinner();
    this.dialogRef = this.dialog.open(SpinnerDialogComponent, this.dialogConfig);
  }

  private hideSpinner() {
    if (this.dialogRef) {
      this.dialogRef.close();
    }
    this.dialogRef = null;
  }
}
