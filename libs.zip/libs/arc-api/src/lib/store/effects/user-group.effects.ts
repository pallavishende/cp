import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';
import { Effect, Actions, ofType } from '@ngrx/effects';
import { DataPersistence } from '@nrwl/nx';

import { Observable } from 'rxjs';
import { map, switchMap, catchError, mergeMap } from 'rxjs/operators';

import { State } from '../reducers/site';
import { UserGroup } from '../../models';
import { arcUserGroupActions } from '../actions';
import { UserGroupResource, UserResource } from '../../services';
import { notificationActions, NotificationType } from '@content-platform/notifications';
import { DisplayNamePipe } from '@content-platform/pipes';
import { UserProfile } from '@content-platform/graph-api';

/**
 * The UserGroup effects imported in {@link ArcApiModule }
 *
 */
@Injectable()
export class UserGroupEffects {
  private displayNamePipe = new DisplayNamePipe();
  constructor(
    private api: UserGroupResource,
    private userApi: UserResource,
    private dataPersistence: DataPersistence<State>,
    private userGroupActions$: Actions
  ) {}

  /**
   * Loads all the available UserGroups as Link items and triggers a LoadSuccess action.
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when all UserGroups are retrieved
   */
  @Effect()
  load$: Observable<Action> = this.dataPersistence.fetch(arcUserGroupActions.LOAD, {
    run: (_action: arcUserGroupActions.Load) => {
      return this.api
        .loadUserGroups()
        .pipe(map((userGroups: UserGroup[]) => new arcUserGroupActions.LoadSuccess(userGroups)));
    },
    onError: (_action: arcUserGroupActions.Load, error) => {
      return new arcUserGroupActions.LoadFailed({
        error: error,
        message: 'Unable to load all User Groups'
      });
    }
  });

  /* Loads a single the User Group
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when all UserGroups are retrieved
   */
  @Effect()
  loadById$: Observable<Action> = this.dataPersistence.fetch(arcUserGroupActions.LOAD_BY_ID, {
    run: (action: arcUserGroupActions.LoadById) => {
      return this.api
        .loadUserGroup(action.payload)
        .pipe(map((userGroup: UserGroup) => new arcUserGroupActions.LoadByIdSuccess(userGroup)));
    },
    onError: (action: arcUserGroupActions.LoadById, error) => {
      return new arcUserGroupActions.LoadByIdFailed({
        error: error,
        message: `Unable to load User Group with id ${action.payload}`
      });
    }
  });

  /* Adds a user to the User Group
   *
   * @returns { Observable<Action> } Observable with AdduserSuccess action when usergroup is updated
   */
  @Effect()
  addUser$: Observable<Action> = this.userGroupActions$.pipe(
    ofType(arcUserGroupActions.ADD_USER),
    switchMap((action: arcUserGroupActions.AddUser) => {
      return this.api.appendUserToUserGroup(action.payload, action.user).pipe(
        mergeMap((userGroup: UserGroup) => [
          new arcUserGroupActions.AddUserSuccess(userGroup),
          new notificationActions.Open({
            type: NotificationType.Success,
            inputs: {
              props: {
                message: `${this.displayNamePipe.transform(userGroup.userDetails[
                  action.user.title
                ] as UserProfile)} Successfully Added to ${userGroup.title}`
              }
            }
          })
        ]),
        catchError(error => {
          return [
            new arcUserGroupActions.AddUserFailed({
              error: error,
              message: `Unable to add user ${action.user.title} to User Group ${
                action.payload.title
              }`
            })
          ];
        })
      );
    })
  );

  /* Adds a user to the User Group by their LDAP name
   *
   * @returns { Observable<Action> } Observable with AdduserSuccess action when usergroup is updated
   */
  @Effect()
  addUserByLdap$: Observable<Action> = this.userGroupActions$.pipe(
    ofType(arcUserGroupActions.ADD_USER_BY_LDAP),
    switchMap((action: arcUserGroupActions.AddUserByLDAP) => {
      return this.userApi.getUserByLdap(action.userLdap).pipe(
        switchMap(userLinkItem => {
          return this.api.appendUserToUserGroup(action.payload, userLinkItem).pipe(
            mergeMap((userGroup: UserGroup) => [
              new arcUserGroupActions.AddUserSuccess(userGroup),
              new notificationActions.Open({
                type: NotificationType.Success,
                inputs: {
                  props: {
                    message: `${this.displayNamePipe.transform(userGroup.userDetails[
                      action.userLdap
                    ] as UserProfile)} Successfully Added to ${userGroup.title}`
                  }
                }
              })
            ])
          );
        }),
        catchError(error => {
          return [
            new arcUserGroupActions.AddUserFailed({
              error: error,
              message: `Unable to add user ${action.userLdap} to User Group ${action.payload.title}`
            })
          ];
        })
      );
    })
  );

  /* Removes a user to the User Group
   *
   * @returns { Observable<Action> } Observable with AdduserSuccess action when usergroup is updated
   */
  @Effect()
  removeUser$: Observable<Action> = this.userGroupActions$.pipe(
    ofType(arcUserGroupActions.REMOVE_USER),
    switchMap((action: arcUserGroupActions.RemoveUser) => {
      return this.api.removeUserFromUserGroup(action.payload, action.user).pipe(
        mergeMap((userGroup: UserGroup) => [
          new arcUserGroupActions.RemoveUserSuccess(userGroup),
          new notificationActions.Open({
            type: NotificationType.Success,
            inputs: {
              props: {
                message: `${this.displayNamePipe.transform(action.payload.userDetails[
                  action.user.title
                ] as UserProfile)} Successfully Removed from ${userGroup.title}`
              }
            }
          })
        ]),
        catchError(error => {
          return [
            new arcUserGroupActions.RemoveUserFailed({
              error: error,
              message: `Unable to remove user ${action.user.title} from User Group ${
                action.payload.title
              }`
            })
          ];
        })
      );
    })
  );
}
