import { Injectable } from '@angular/core';
import { Effect } from '@ngrx/effects';
import { DataPersistence } from '@nrwl/nx';

import { mergeMap } from 'rxjs/operators';

import { arcUserActions } from '../actions';
import { UserResource } from '../../services/user-resource';
import { ArcState } from '../reducers';
import { siteSelectors } from '../selectors';
import { adUserActions } from '@content-platform/graph-api';

@Injectable()
export class UserEffects {
  constructor(private api: UserResource, private dataPersistence: DataPersistence<ArcState>) {}

  @Effect()
  loadUser$ = this.dataPersistence.fetch(arcUserActions.LOAD, {
    run: (action: arcUserActions.Load, state: ArcState) => {
      const nsmap = siteSelectors.getSitesByNamespace(state);
      // Your custom REST 'load' logic goes here. For now just return an empty list...
      const { uuid, title } = action.payload;
      return this.api
        .getFullUser(title, uuid, nsmap)
        .pipe(
          mergeMap(fullUser => [
            new arcUserActions.LoadSuccess(fullUser),
            new adUserActions.LoadAdUser(fullUser.userProfile.mail)
          ])
        );
    },
    onError: (_action: arcUserActions.Load, error) => {
      return new arcUserActions.LoadFailed({
        error,
        message: 'Unable to load arc user'
      });
    }
  });
}
