import * as fromSite from './site';
import * as fromUser from './user';
import * as fromRole from './role';
import * as fromUserGroup from './user-group';

export interface ArcState {
  site: fromSite.State;
  arcUser: fromUser.UserState;
  arcRoles: fromRole.State;
  userGroup: fromUserGroup.State;
}

export { fromSite, fromUser, fromRole, fromUserGroup };
