import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { Role } from '../../models';
import { roleActions } from '../actions';

export const applicationAdapter = createEntityAdapter<Role>({
  selectId: (item: Role) => item.title,
  sortComparer: sortByName
});

export interface State extends EntityState<Role> {
  loading: boolean;
  loaded: boolean;
}

export const INIT_STATE: State = applicationAdapter.getInitialState({
  loading: false,
  loaded: false
});

export function sortByName(a: Role, b: Role): number {
  return a.title.localeCompare(b.title);
}

export function reducer(state = INIT_STATE, action: roleActions.All) {
  switch (action.type) {
    case roleActions.LOAD: {
      return {
        ...state,
        loading: true,
        loaded: false
      };
    }
    case roleActions.LOAD_SUCCESS: {
      return {
        ...applicationAdapter.addAll(action.payload as Role[], state),
        loading: false,
        loaded: true
      };
    }
    case roleActions.LOAD_FAILED: {
      return { ...state, loading: false, loaded: false };
    }
    default: {
      return state;
    }
  }
}
export const getRolesLoading = (state: State) => state.loading;
export const getRolesLoaded = (state: State) => state.loaded;
