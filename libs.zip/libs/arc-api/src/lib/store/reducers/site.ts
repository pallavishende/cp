import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { SiteConfigItem } from '../../models';
import { arcSiteActions } from '../actions';

export const siteAdapter = createEntityAdapter<SiteConfigItem>({
  selectId: (item: SiteConfigItem) => item.sitekey,
  sortComparer: sortByName
});

export interface State extends EntityState<SiteConfigItem> {
  loading: boolean;
  loadedFullSite: { [sitekey: string]: boolean };
  loadSiteComplete: { [sitekey: string]: boolean };
  loadedAllAsLinkItems: boolean;
}

export const INIT_STATE: State = siteAdapter.getInitialState({
  loading: false,
  loadedFullSite: {},
  loadSiteComplete: {},
  loadedAllAsLinkItems: false
});

export function sortByName(a: SiteConfigItem, b: SiteConfigItem): number {
  return a.name.localeCompare(b.name);
}

export function reducer(state = INIT_STATE, action: arcSiteActions.All) {
  switch (action.type) {
    case arcSiteActions.LOAD: {
      return {
        ...state,
        loading: true,
        loadedAllAsLinkItems: false
      };
    }
    case arcSiteActions.LOAD_SUCCESS: {
      return {
        ...siteAdapter.addAll(action.payload as SiteConfigItem[], state),
        loading: false,
        loadedAllAsLinkItems: true
      };
    }
    case arcSiteActions.LOAD_FAILED: {
      return { ...state, loading: false, loaded: false };
    }
    case arcSiteActions.LOAD_BY_KEY: {
      const loadedFullSite = { ...state.loadedFullSite };
      loadedFullSite[action.payload] = false;

      const loadSiteComplete = { ...state.loadSiteComplete };
      loadSiteComplete[action.payload] = false;

      return {
        ...state,
        loading: true,
        loadedFullSite,
        loadSiteComplete
      };
    }

    case arcSiteActions.LOAD_BY_KEY_FAILED: {
      const loadedFullSite = { ...state.loadedFullSite };
      loadedFullSite[action.payload.source] = false;
      const loadSiteComplete = { ...state.loadSiteComplete };
      loadSiteComplete[action.payload.source] = true;
      return {
        ...state,
        loading: false,
        loadedFullSite,
        loadSiteComplete
      };
    }

    case arcSiteActions.LOAD_BY_KEY_SUCCESS: {
      const loadedFullSite = { ...state.loadedFullSite };
      loadedFullSite[action.payload.sitekey] = true;
      const loadSiteComplete = { ...state.loadSiteComplete };
      loadSiteComplete[action.payload.sitekey] = true;
      return {
        ...siteAdapter.upsertOne(
          {
            ...action.payload
          },
          state
        ),
        loading: false,
        loadedFullSite,
        loadSiteComplete
      };
    }
    case arcSiteActions.UPDATE_SUCCESS: {
      return siteAdapter.updateOne(
        {
          id: action.payload.sitekey,
          changes: action.payload
        },
        state
      );
    }
    default: {
      return state;
    }
  }
}
export const getSitesLoading = (state: State) => state.loading;
export const getSitesLoaded = (state: State) => state.loadedAllAsLinkItems;
