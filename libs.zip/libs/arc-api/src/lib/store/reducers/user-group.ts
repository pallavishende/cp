import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { UserGroup } from '../../models';
import { arcUserGroupActions } from '../actions';

export const userGroupAdapter = createEntityAdapter<UserGroup>({
  selectId: (item: UserGroup) => item.uuid,
  sortComparer: sortByName
});

export interface State extends EntityState<UserGroup> {
  loading: boolean;
  loadedAllAsLinkItems: boolean;
  loadedFullUserGroup: { [uuid: string]: boolean };
}

export const INIT_STATE: State = userGroupAdapter.getInitialState({
  loading: false,
  loadedAllAsLinkItems: false,
  loadedFullUserGroup: {}
});

export function sortByName(a: UserGroup, b: UserGroup): number {
  return a.title.localeCompare(b.title);
}

export function reducer(state: State = INIT_STATE, action: arcUserGroupActions.All) {
  switch (action.type) {
    case arcUserGroupActions.LOAD: {
      return {
        ...state,
        loading: true,
        loadedAllAsLinkItems: false
      };
    }
    case arcUserGroupActions.LOAD_SUCCESS: {
      return {
        ...userGroupAdapter.upsertMany(action.payload as UserGroup[], state),
        loading: false,
        loadedAllAsLinkItems: true
      };
    }
    case arcUserGroupActions.LOAD_BY_ID: {
      const loadedFullUserGroup = { ...state.loadedFullUserGroup };
      loadedFullUserGroup[action.payload] = false;
      return {
        ...state,
        loading: true,
        loadedFullUserGroup
      };
    }
    case arcUserGroupActions.LOAD_BY_ID_SUCCESS: {
      const loadedFullUserGroup = { ...state.loadedFullUserGroup };
      loadedFullUserGroup[action.payload.uuid] = true;
      return {
        ...userGroupAdapter.upsertOne(action.payload, state),
        loading: false,
        loadedFullUserGroup
      };
    }

    case arcUserGroupActions.UPDATE_SUCCESS:
    case arcUserGroupActions.ADD_USER_SUCCESS:
    case arcUserGroupActions.REMOVE_USER_SUCCESS: {
      return userGroupAdapter.upsertOne(action.payload, state);
    }

    case arcUserGroupActions.CREATE_SUCCESS: {
      return userGroupAdapter.upsertOne(action.payload, state);
    }
    case arcUserGroupActions.DELETE_SUCCESS: {
      return userGroupAdapter.removeOne(action.payload, state);
    }
    case arcUserGroupActions.LOAD_FAILED: {
      return { ...state, loading: false, loaded: false };
    }
    case arcUserGroupActions.LOAD_BY_ID_FAILED: {
      return { ...state, loading: false };
    }
    case arcUserGroupActions.CREATE_FAILED:
    case arcUserGroupActions.DELETE_FAILED:
    case arcUserGroupActions.UPDATE_FAILED: {
      return { ...state, loading: false };
    }
    default: {
      return state;
    }
  }
}
export const getUserGroupsLoading = (state: State) => state.loading;
export const getUserGroupsLoaded = (state: State) => state.loadedAllAsLinkItems;
