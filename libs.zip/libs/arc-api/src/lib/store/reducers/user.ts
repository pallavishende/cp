import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { User } from '../../models';
import { arcUserActions } from '../actions';

export const usersAdapter = createEntityAdapter<User>({
  selectId: (item: User) => item.title,
  sortComparer: sortByName
});

export interface UserState extends EntityState<User> {
  loading: boolean;
  loaded: boolean;
}

export const INIT_STATE: UserState = usersAdapter.getInitialState({
  loading: false,
  loaded: false
});

export function sortByName(a: User, b: User): number {
  return a.title.localeCompare(b.title);
}

export function reducer(state = INIT_STATE, action: arcUserActions.All) {
  switch (action.type) {
    case arcUserActions.LOAD: {
      return {
        ...state,
        loading: true,
        loaded: false
      };
    }
    case arcUserActions.LOAD_SUCCESS: {
      return {
        ...usersAdapter.addOne(action.payload, state),
        loading: false,
        loaded: true
      };
    }
    case arcUserActions.LOAD_FAILED: {
      return { ...state, loading: false, loaded: false };
    }
    default: {
      return state;
    }
  }
}
export const getUserLoading = (state: UserState) => state.loading;
export const getUserLoaded = (state: UserState) => state.loaded;
