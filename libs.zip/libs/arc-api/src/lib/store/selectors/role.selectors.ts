import { createFeatureSelector, createSelector } from '@ngrx/store';
import { fromRole } from '../reducers';
import { RoleSummaryUtil } from '../../utils';

export const getRoleRootState = createFeatureSelector<fromRole.State>('arcRoles');
export const getRoleState = createSelector(getRoleRootState, state => state);

export const {
  selectAll: getAllRoleItems,
  selectEntities: getRoleEntities
} = fromRole.applicationAdapter.getSelectors(getRoleState);

export const getRoleSummaryByName = (roleName: string) =>
  createSelector(getRoleEntities, entities => {
    if (roleName && entities[roleName]) {
      const role = entities[roleName];
      return RoleSummaryUtil.getSummary(role)
        .replace('<br>', '\n')
        .replace(/<\/?[^>]+(>|$)/g, '');
    }
    return 'No role specified.';
  });
/**
 * Selector to return the loaded property of the state
 */
export const getRolesLoaded = createSelector(getRoleState, fromRole.getRolesLoaded);

/**
 * Selector to return the loading property of the state
 */
export const getRolesLoading = createSelector(getRoleState, fromRole.getRolesLoading);
