import { createFeatureSelector, createSelector } from '@ngrx/store';
import { fromSite } from '../reducers';
import { SiteConfigItem, ArcUserProfileItem, SiteRoleItem } from '../../models';

export const getSiteRootState = createFeatureSelector<fromSite.State>('site');
export const getSiteState = createSelector(getSiteRootState, state => state);

export const {
  selectAll: getAllSiteItems,
  selectEntities: getSiteEntities
} = fromSite.siteAdapter.getSelectors(getSiteState);

/**
 * Selector to return the loaded property of the state
 */
export const getSitesLoaded = createSelector(getSiteState, fromSite.getSitesLoaded);

/**
 * Selector to return the loading property of the state
 */
export const getSitesLoading = createSelector(getSiteState, fromSite.getSitesLoading);

export const getSitesByNamespace = createSelector(getAllSiteItems, siteItems => {
  const nsmap = {} as { [key: string]: SiteConfigItem[] };
  for (const site of siteItems) {
    const namespaceKey = getNamespaceKey(site);
    nsmap[namespaceKey] = nsmap[namespaceKey] || [];
    nsmap[namespaceKey].push(site);
  }
  return nsmap;
});

export function getNamespaceKey(site: SiteConfigItem | ArcUserProfileItem): string {
  return [site.server, site.environment, site.namespace].join(' / ');
}

export const getSiteByKey = (siteKey: string) =>
  createSelector(getSiteEntities, entities => {
    return entities[siteKey];
  });

/**
 * Selector a single user group has been fully loaded
 */
export const getSiteLoaded = (siteKey: string) =>
  createSelector(getSiteState, (state: fromSite.State) => state.loadedFullSite[siteKey]);

/**
 * Selector a single user group has been fully loaded
 */
export const getSiteLoadComplete = (siteKey: string) =>
  createSelector(getSiteState, (state: fromSite.State) => state.loadSiteComplete[siteKey]);

export const getSiteRolesForUserGroup = (uuid: string) =>
  createSelector(getAllSiteItems, (siteItems: SiteConfigItem[]) => {
    const siteRoles: SiteRoleItem[] = [];
    siteItems.forEach(siteItem => {
      siteRoles.push(
        ...(siteItem.ugroles || []).filter(ugRole => ugRole.userGroup.uuid === uuid).map(ugRole => {
          return { ...siteItem, site: siteItem, roleName: ugRole.roleName };
        })
      );
    });
    return siteRoles;
  });
