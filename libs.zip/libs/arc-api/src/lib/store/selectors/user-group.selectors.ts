import { createFeatureSelector, createSelector } from '@ngrx/store';
import { fromUserGroup } from '../reducers';

export const getUserGroupRootState = createFeatureSelector<fromUserGroup.State>('userGroup');
export const getUserGroupState = createSelector(getUserGroupRootState, state => state);

export const {
  selectAll: getAllUserGroupItems,
  selectEntities: getUserGroupEntities
} = fromUserGroup.userGroupAdapter.getSelectors(getUserGroupState);

/**
 * Selector to return the loaded property of the state
 */
export const getUserGroupsLoaded = createSelector(
  getUserGroupState,
  fromUserGroup.getUserGroupsLoaded
);

/**
 * Selector to return the loading property of the state
 */
export const getUserGroupsLoading = createSelector(
  getUserGroupState,
  fromUserGroup.getUserGroupsLoading
);

/**
 * Selector a single user group has been fully loaded
 */
export const getUserGroupLoaded = (uuid: string) =>
  createSelector(
    getUserGroupState,
    (state: fromUserGroup.State) => state.loadedFullUserGroup[uuid]
  );
