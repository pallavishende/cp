import { createFeatureSelector, createSelector } from '@ngrx/store';
import { fromUser } from '../reducers';

export const getUserRootState = createFeatureSelector<fromUser.UserState>('arcUser');
export const getUserState = createSelector(getUserRootState, state => state);

export const {
  selectAll: getAllUserItems,
  selectEntities: getUserEntities
} = fromUser.usersAdapter.getSelectors(getUserState);

/**
 * Selector to return the loaded property of the state
 */
export const getUserLoaded = createSelector(getUserState, fromUser.getUserLoaded);

/**
 * Selector to return the loading property of the state
 */
export const getUserLoading = createSelector(getUserState, fromUser.getUserLoading);
