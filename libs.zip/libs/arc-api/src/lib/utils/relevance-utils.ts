export class RelevanceUtils {

  static minWordLength = 3;

  static getScore(a: string, b: string): number {
    // score based on # of words or word prefixes that match between a and b
    const awords = this.parseWords(a);
    const bwords = this.parseWords(b);
    const score = awords
      .filter(aword => {
        return bwords.some(bword => bword.startsWith(aword) || aword.startsWith(bword));
      }).length;
    // console.log(`score(${a}, ${b}) = ${score}`);
    return score;
  }

  private static parseWords(s: string): string[] {
    return s.split(' ')
      .map(word => {
        const w = word.toLowerCase();
        return (this.isAlpha3(w) ? w : null);
      })
      .filter(word => word ? true : false);
  }

  private static isAlpha3(s: string): boolean {
    // string contains at least 3 alpha chars
    const regex = new RegExp(`[a-z]{${this.minWordLength}}`);
    return regex.test(s);
  }

}
