import { Role, Qualification } from '../models';

const RIGHTS = {
  appearsOnMenu: 'AppearsOnMenu',
  canEdit: 'CanEdit',
  canCreate: 'CanCreate',
  canDelete: 'CanDelete',
  canPublish: 'CanPublish'
};
const SUBRIGHTS = {
  exclude: 'Exclude',
  canAdd: 'CanAdd',
  canRemove: 'CanRemove',
  canAddOwn: 'CanAddOwn',
  canRemoveOwn: 'CanRemoveOwn'
};

export class RoleSummaryUtil {
  static getSummary(role: Role): string {
    let summary: string;

    if (this.hasAllRights(role) && this.hasNoQualifications(role)) {
      summary = 'All rights, no restrictions';
    } else if (this.hasGuestRights(role)) {
      summary = 'No rights (except to create/edit CMRs)';
    } else {
      summary = this.getRightsSummaryPlusQualifications(role);
    }

    return (
      summary +
      '<br><i>' +
      (this.hasRight(role, RIGHTS.appearsOnMenu) ? 'Appears on menu' : "Doesn't appear on menu") +
      '</i>'
    );
  }

  private static getRightsSummaryPlusQualifications(role: Role): string {
    const rightsSummary = this.getRightsSummary(role);
    const qualifications = this.getQualifications(role);
    // console.log('quals=', qualifications);
    return (
      '<p>' +
      rightsSummary +
      '</p>' +
      (qualifications.length === 0
        ? ''
        : '<i>Exceptions:</i>' + qualifications.map(qual => '<li>' + qual + '</li>').join(''))
    );
  }

  private static getRightsSummary(role: Role) {
    // arrays of rights that role has and doesn't have (excluding canEdit and appearsOnMenu which are treated separately)
    const hasRights = Object.values(RIGHTS).filter(
      right =>
        right !== RIGHTS.appearsOnMenu && right !== RIGHTS.canEdit && this.hasRight(role, right)
    );
    const noRights = Object.values(RIGHTS).filter(
      right =>
        right !== RIGHTS.appearsOnMenu && right !== RIGHTS.canEdit && !this.hasRight(role, right)
    );

    if (this.hasRight(role, RIGHTS.canEdit)) {
      hasRights.splice(0, 0, RIGHTS.canEdit);
      const otherRights = this.joinThings(hasRights.map(right => this.formatRight(right)), 'and');
      return (
        'Can ' +
        otherRights +
        (noRights.length
          ? ' but NOT ' + this.joinThings(noRights.map(right => this.formatRight(right)), 'or')
          : '')
      );
    } else {
      noRights.splice(0, 0, RIGHTS.canEdit);
      const otherRights = this.joinThings(noRights.map(right => this.formatRight(right)), 'or');
      return (
        'CANNOT ' +
        otherRights +
        (hasRights.length
          ? ' but CAN ' + this.joinThings(hasRights.map(right => this.formatRight(right)), 'and')
          : '')
      );
    }
  }

  private static getQualifications(role: Role): string[] {
    // const exclusionsByRight = {};
    const exclusionsByPattern = {};
    const restrictionsBySubrights = {};

    role.qualifications.forEach(qual => {
      if (this.hasSubright(qual, SUBRIGHTS.exclude)) {
        // this.addQualification(exclusionsByRight, this.formatRight(qual.right), this.formatPattern(qual.pattern));
        this.addQualification(
          exclusionsByPattern,
          this.formatPattern(qual.pattern),
          this.formatRight(qual.right)
        );
      } else if (this.hasNoSubrights(qual)) {
        this.addQualification(
          restrictionsBySubrights,
          'can ' + this.formatRight(qual.right),
          this.formatPattern(qual.pattern)
        );
      } else if (
        this.hasSubright(qual, SUBRIGHTS.canAdd) &&
        this.hasSubright(qual, SUBRIGHTS.canRemove)
      ) {
        this.addQualification(
          restrictionsBySubrights,
          'can add/remove',
          this.formatPattern(qual.pattern)
        );
      } else if (
        this.hasSubright(qual, SUBRIGHTS.canAddOwn) &&
        this.hasSubright(qual, SUBRIGHTS.canRemoveOwn)
      ) {
        this.addQualification(
          restrictionsBySubrights,
          'can add/remove OWN',
          this.formatPattern(qual.pattern)
        );
      } else {
        // TODO - do we need work here? at least format the subrights?
        this.addQualification(
          restrictionsBySubrights,
          'can ' + qual.subrights.join('/'),
          this.formatPattern(qual.pattern)
        );
      }
    });

    let exclusions = [];
    if (Object.keys(exclusionsByPattern).length) {
      exclusions = Object.keys(exclusionsByPattern).map(pattern => {
        const rights = exclusionsByPattern[pattern];
        return 'cannot ' + this.joinThings(rights, 'or') + ' ' + pattern;
      });
    }

    let restrictions = [];
    if (Object.keys(restrictionsBySubrights).length) {
      restrictions = Object.keys(restrictionsBySubrights).map(restriction => {
        const patterns = restrictionsBySubrights[restriction];
        return restriction + ' ' + this.joinThings(patterns, 'and');
      });
    }

    const cmrs = !this.hasRight(role, RIGHTS.canEdit) ? ['can create/edit CMRs'] : [];

    if (this.hasRight(role, RIGHTS.canEdit)) {
      return cmrs.concat(exclusions).concat(restrictions);
    } else {
      return cmrs.concat(restrictions).concat(exclusions);
    }
  }

  private static hasSubright(qual: Qualification, subright: string): boolean {
    return qual.subrights.indexOf(subright) !== -1;
  }

  private static hasNoSubrights(qual: Qualification): boolean {
    return qual.subrights.length === 0;
  }

  private static addQualification(exclusions, key, value) {
    if (!exclusions[key]) {
      exclusions[key] = [value];
    } else {
      exclusions[key].push(value);
    }
  }

  private static formatRight(right: string): string {
    if (right.startsWith('Can')) {
      return right.substr(3).toLowerCase();
    } else {
      return right;
    }
  }

  private static formatPattern(pattern: string): string {
    // pattern is X:Y or X:Y.Z => always strip off 'X:' & if Y=*, strip off Y too
    const parts = this.splitPattern(pattern);
    if (parts.length === 1) {
      return parts[0];
    } else if (parts.length === 2) {
      return parts[1];
    } else if (parts[1] === '*') {
      return parts[2];
    } else {
      return parts[1] + '.' + parts[2];
    }
  }

  private static splitPattern(pattern: string): string[] {
    return pattern.split(/[\:\.]+/);
  }

  private static joinThings(things: string[], lastDelim: string): string {
    if (things.length === 0) {
      return '';
    } else if (things.length === 1) {
      return things[0];
    } else {
      return (
        things.slice(0, things.length - 1).join(', ') +
        ' ' +
        lastDelim +
        ' ' +
        things[things.length - 1]
      );
    }
  }

  static hasGuestRights(role: Role): boolean {
    return this.hasNoRights(role) && this.hasNoQualifications(role);
  }

  static hasSharedRights(role: Role): boolean {
    return (
      !this.hasRight(role, RIGHTS.canEdit) && this.hasQualificationFor(role, '*:*.DistPolicies')
    );
  }

  static hasSomeRestrictions(role: Role): boolean {
    return this.hasRight(role, RIGHTS.canEdit) && this.hasQualifications(role); // && !role.hasQualificationFor('*:*.DistPolicies');
  }

  static hasAllRights(role: Role): boolean {
    return Object.values(RIGHTS).every(
      right => right === RIGHTS.appearsOnMenu || role.rights.indexOf(right) !== -1
    );
  }

  static hasNoRights(role: Role): boolean {
    return (
      role.rights.length === 0 ||
      (role.rights.length === 1 && role.rights[0] === RIGHTS.appearsOnMenu)
    );
  }

  static hasRight(role: Role, right: string) {
    return role.rights.indexOf(right) !== -1;
  }

  static hasQualifications(role: Role): boolean {
    return role.qualifications.length !== 0;
  }

  static hasNoQualifications(role: Role): boolean {
    return role.qualifications.length === 0;
  }

  static hasQualificationFor(role: Role, pattern: string): boolean {
    return role.qualifications.some(qual => qual.pattern === pattern);
  }
}
