import { SiteConfigItem, ArcUserProfileNamespace } from '../models';

export class SortUtils {
  static sortByTitle(a, b) {
    const attr = 'title';
    const attrA = a[attr].toLowerCase();
    const attrB = b[attr].toLowerCase();
    if (attrA < attrB) {
      return -1;
    } else if (attrA > attrB) {
      return 1;
    } else {
      return 0;
    }
  }

  static sortSites(a, b) {
    // sort by arcenv + path + siteRole title
    const arcenvOrder = { prod: '1', uat: '2', staging: '3', qa: '4', other: '5' };

    const siteA = <SiteConfigItem>a;
    const siteB = <SiteConfigItem>b;

    const sortA = arcenvOrder[siteA.arcenv] + /* siteA.path + */ siteA.name;
    const sortB = arcenvOrder[siteB.arcenv] + /* siteB.path + */ siteB.name;

    if (sortA < sortB) {
      return -1;
    } else if (sortA > sortB) {
      return 1;
    } else {
      return 0;
    }
  }

  static sortNamespaces(a, b) {
    // sort by noUAC, arcenv + path + siteRole title
    const arcenvOrder = { prod: '1', uat: '2', staging: '3', qa: '4', other: '5' };

    const siteA = <ArcUserProfileNamespace>a;
    const siteB = <ArcUserProfileNamespace>b;

    const uacA = siteA.hasUAC ? '0' : '1';
    const uacB = siteB.hasUAC ? '0' : '1';

    const sortA = uacA + arcenvOrder[siteA.site.arcenv] + /* siteA.site.path + */ siteA.site.name;
    const sortB = uacB + arcenvOrder[siteB.site.arcenv] + /* siteB.site.path + */ siteB.site.name;

    if (sortA < sortB) {
      return -1;
    } else if (sortA > sortB) {
      return 1;
    } else {
      return 0;
    }
  }
}
