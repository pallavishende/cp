import { TestBed, inject } from '@angular/core/testing';

import { StoreModule } from '@ngrx/store';
// import { Auth } from './auth/auth.interfaces';
import * as fromAuth from './auth/auth.reducer';

import { AdAuthGuard } from './ad-auth.guard';

xdescribe('AdAuthGuard', () => {
  // tslint:disable-next-line:prefer-const
  // let store: Store<Auth>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [StoreModule.forRoot(fromAuth.authReducer)],
      providers: [AdAuthGuard]
    });
  });

  it('should ...', inject([AdAuthGuard], (guard: AdAuthGuard) => {
    expect(guard).toBeTruthy();
  }));
});
