import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { Observable } from 'rxjs';

import { Store, select } from '@ngrx/store';
import { Auth } from './auth/auth.interfaces';
import * as fromSelectors from './auth/auth.selectors';
import * as actions from './auth/auth.actions';
import { take, tap, filter, switchMap } from 'rxjs/operators';
import { debugFlagSelectors, debugFlagActions } from '@content-platform/development';

/**
 * Auth guard to be used in the routes, will only continue if user is logged in.
 *
 * @export
 * @class AdAuthGuard
 */
@Injectable()
export class AdAuthGuard implements CanActivate {
  private auth$: Observable<boolean>;

  constructor(private store: Store<Auth>) {
    this.auth$ = this.store.pipe(
      select(debugFlagSelectors.getDebugFlagSettings),
      tap(debugFlagsLoaded => {
        if (!debugFlagsLoaded) {
          this.store.dispatch(new debugFlagActions.Load());
        }
      }),
      filter(debugFlagsLoaded => !!debugFlagsLoaded),
      switchMap(() => this.isLoggedIn()),
      take(1)
    );
  }

  canActivate(): Observable<boolean> {
    return this.auth$;
  }

  private isLoggedIn() {
    return this.store.pipe(
      select(fromSelectors.getIsLoggedIn),
      filter(loggedIn => {
        if (!loggedIn) {
          this.store.dispatch(new actions.SetAdUser());
          return false;
        }
        return true;
      })
    );
  }
}
