import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';

import { AuthApiOptions } from './auth-api.config';

import { NotificationType, notificationActions } from '@content-platform/notifications';
import { Observable, Subject, BehaviorSubject } from 'rxjs';
import { AuthState } from './auth/auth.interfaces';

import './authentication-context.extended';
import { Configuration } from '@content-platform/configuration';
import { filter, take } from 'rxjs/operators';

const createAuthContextFn: adal.AuthenticationContextStatic = AuthenticationContext;
const tokens: { [resource: string]: string } = {};
const tokens$: Subject<{ [resource: string]: string }> = new BehaviorSubject(tokens);

/**
 * Helper service to manage the adal login/logout
 *
 * @export
 * @class AdalService
 */
@Injectable()
export class AdalService {
  private context: adal.AuthenticationContext;

  constructor(private store: Store<AuthState>) {
    Configuration.getAsync('adal')
      .pipe(
        filter(config => !!config),
        take(1)
      )
      .subscribe(() => {
        this.context = new createAuthContextFn(this.getAdalConfig);
      });
  }

  private getOptions(): AuthApiOptions {
    return Configuration.get('adal') || {};
  }

  private get getAdalConfig(): adal.Config {
    let redirectUri = `${window.location.origin}/frameRedirect.html`;
    if (this.getOptions().redirectUri === 'qa') {
      const path = window.location.pathname;
      const prefix = path.split('/')[1];
      redirectUri = `${window.location.origin}/${prefix}/frameRedirect.html`;
    }

    return {
      ...this.getOptions(),
      redirectUri: redirectUri
    };
  }

  /**
   * Uses the resetTokenWithConsent added in the authentication-context.extended.ts file, to ask the user
   * for the azure graph consent.
   *
   * @param resourcePath
   * @param callback
   */
  resetTokenWithConsent(
    resourcePath: string,
    callback: (mesage: string, token: string) => void
  ): void {
    this.context.resetTokenWithConsent(resourcePath, callback);
  }

  /**
   * Used to acquire the azure graph token
   *
   * @param resourcePath that requires the auth token.
   * @param callback called with a message & auth token.
   */
  acquireToken(resourcePath: string, callback?: (mesage: string, token: string) => void): void {
    this.context.acquireToken(resourcePath, (message, token) => {
      if (!token && message && /AADSTS50058/.test(message)) {
        this.showCookieBlockedWarning();
      }
      this.updateTokenObservable(resourcePath, token);
      if (callback) {
        callback(message, token);
      }
    });
  }

  /**
   * Triggers notification, notifying user that the login.microsoftonline.com cookie is blocked.
   */
  private showCookieBlockedWarning() {
    this.store.dispatch(
      new notificationActions.Open({
        type: NotificationType.Error,
        inputs: {
          props: {
            message:
              'Failed to retrieve the Azure Graph Token! Please check if' +
              ' the cookies from login.microsoftonline.com are not blocked.',
            button: {
              label: 'Dismiss'
            }
          }
        }
      })
    );
  }

  /**
   * Gets initial Idtoken for the app backend
   * Saves the resulting Idtoken in localStorage.
   */
  login(): void {
    this.context.login();
  }

  /**
   * Logout user will redirect page to logout endpoint.
   * After logout, it will redirect to post_logout page if provided.
   */
  logout(): void {
    this.context.logOut();
  }

  /**
   * Handles redirection after login operation.
   * Gets access token from url and saves token to the (local/session) storage
   * or saves error in case unsuccessful login.
   */
  handleCallback(): void {
    this.context.handleWindowCallback();
  }

  /**
   * Retrieves and parse idToken from localstorage
   * @returns {User} user object
   */
  get userInfo(): adal.User {
    return this.context.getCachedUser();
  }

  /**
   * Gets token for the adalConfig clientId from local storage cache
   * @returns {string} token if exists and not expired or null
   */
  get accessToken(): string {
    return this.getCachedAccessToken();
  }

  /**
   * Gets an observable  of a token token for the specified resource
   * @param resource {string} the resource to get token for
   * @returns {Observable<{ [resource: string]: string }>} token
   */
  get accessTokens$(): Observable<{ [resource: string]: string }> {
    return tokens$;
  }

  private updateTokenObservable(
    resource: string,
    value = ''
  ): Observable<{ [resource: string]: string }> {
    tokens[resource] = value;
    tokens$.next(tokens);
    return tokens$;
  }

  /**
   * Gets token for the specified resource from local storage cache
   * @param resource {string} the resource to get token for
   * @returns {string} token if exists and not expired or null
   */
  getCachedAccessToken(resource?: string): string {
    return this.context.getCachedToken(resource || this.getAdalConfig.clientId);
  }

  /**
   * Checks userInfo and accessToken for a authenticated user
   * @returns {boolean} if there is a user authenticated
   */
  get isAuthenticated(): boolean {
    return !!this.userInfo && !!this.accessToken;
  }
}
