export interface AuthApiOptions {
  clientId: string;
  tenant: string;
  redirectUri: string;
  endpoints: { [hostname: string]: string };
}
