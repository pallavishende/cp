import { OnDestroy } from '@angular/core';
import { LoggerParamsTransformer } from '@content-platform/logging';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { getADUser, getIsLoggedIn } from './auth/auth.selectors';

export class AuthLoggingTransformer extends LoggerParamsTransformer implements OnDestroy {
  private user: adal.User;
  private loggedIn: boolean;
  private subscriptions: Subscription[] = [];

  initialize() {
    const store = this.injector.get(Store);
    this.subscriptions.push(store.pipe(select(getADUser)).subscribe(user => (this.user = user)));
    this.subscriptions.push(
      store.pipe(select(getIsLoggedIn)).subscribe(loggedIn => (this.loggedIn = loggedIn))
    );
  }

  getParams() {
    return {
      loggedIn: this.loggedIn,
      userName: this.user && this.user.userName
    };
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }
}
