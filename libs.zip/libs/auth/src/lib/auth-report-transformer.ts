import { OnDestroy } from '@angular/core';
import { ReportParamsTransformer } from '@content-platform/error-handling';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { getADUser } from './auth/auth.selectors';

export class AuthReportTransformer extends ReportParamsTransformer implements OnDestroy {
  private user: adal.User;
  private subscriptions: Subscription[] = [];

  initialize() {
    const store = this.injector.get(Store);
    this.subscriptions.push(store.pipe(select(getADUser)).subscribe(user => (this.user = user)));
  }

  getParams() {
    return {
      'User Name': this.user ? this.user.userName : undefined
    };
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }
}
