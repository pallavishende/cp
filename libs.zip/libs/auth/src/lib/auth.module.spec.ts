import { AuthModule } from './auth.module';

describe('AuthModule', () => {
  it('should work', () => {
    const module = AuthModule;
    expect(new module()).toBeDefined();
  });
});
