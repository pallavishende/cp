import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdalService } from './adal.service';

import { StoreModule } from '@ngrx/store';
import { HttpClientModule } from '@angular/common/http';
import { EffectsModule } from '@ngrx/effects';
import { authReducer } from './auth/auth.reducer';
import { authInitialState } from './auth/auth.init';
import { AuthEffects } from './auth/auth.effects';
import { AutoLogoutComponent } from './auth/auto-logout-confirmation/auto-logout.component';
import { MatDialogModule, MatButtonModule } from '@angular/material';

import { MatSnackBarModule } from '@angular/material';
import { LoggingModule } from '@content-platform/logging';
import { ErrorHandlingModule } from '@content-platform/error-handling';

import { HandleAdCallbackResolver } from './handle-ad-callback.resolver';
import { AdAuthGuard } from './ad-auth.guard';
import { NotificationsModule } from '@content-platform/notifications';
import { DevelopmentModule } from '@content-platform/development';
import { AuthLoggingTransformer } from './auth-logging-transformer';
import { AuthReportTransformer } from './auth-report-transformer';
import { AuthDebugFlags } from './debug-flags';
import { MinutesSecondsPipe } from './minutes-seconds.pipe';

/**
 * AuthModule which includes the auth reducer and effects
 *
 * @export
 * @class AuthModule
 */
@NgModule({
  imports: [
    CommonModule,
    StoreModule.forFeature('auth', authReducer, { initialState: authInitialState }),
    EffectsModule.forFeature([AuthEffects]),
    MatSnackBarModule,
    LoggingModule.withExtraParams([AuthLoggingTransformer]),
    HttpClientModule,
    NotificationsModule,
    ErrorHandlingModule.withExtraParams(AuthReportTransformer),
    DevelopmentModule.withFlags(AuthDebugFlags),
    MatDialogModule,
    MatButtonModule
  ],
  providers: [AdalService, AuthEffects, HandleAdCallbackResolver, AdAuthGuard],
  declarations: [AutoLogoutComponent, MinutesSecondsPipe],
  entryComponents: [AutoLogoutComponent],
  exports: []
})
export class AuthModule {}
