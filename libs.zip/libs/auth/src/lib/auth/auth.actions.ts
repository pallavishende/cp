import { Action } from '@ngrx/store';

export const LOGIN = '[Auth] LOGIN';
export const SET_AD_USER = '[Auth] SET AD USER';
export const LOGIN_SUCCESS = '[Auth] LOGIN SUCCESS';
export const LOGIN_FAILED = '[Auth] LOGIN FAILED';

export const LOGOUT = '[Auth] LOGOUT';
export const LOGOUT_SUCCESS = '[Auth] LOGOUT SUCCESS';
export const EXTEND_LOGOUT_TIMER = '[Auth] EXTEND LOGOUT TIMER';
export const SHOW_LOGOUT_TIMER_DIALOG = '[Auth] SHOW LOGOUT TIMER DIALOG';
export const SESSION_UPDATED = '[Auth] SESSION UPDATED';

export class Login implements Action {
  readonly type = LOGIN;
  constructor(public payload = null) {}
}
export class SetAdUser implements Action {
  readonly type = SET_AD_USER;
  constructor(public payload = null) {}
}
export class LoginSuccess implements Action {
  readonly type = LOGIN_SUCCESS;
  constructor(public payload: adal.User) {}
}

export class LoginFailed implements Action {
  readonly type = LOGIN_FAILED;
  constructor(public payload = null) {}
}

export class Logout implements Action {
  readonly type = LOGOUT;
  constructor(public payload = null) {}
}
export class LogoutSuccess implements Action {
  readonly type = LOGOUT_SUCCESS;
  constructor(public payload = null) {}
}

export class ExtendLogoutTimer implements Action {
  readonly type = EXTEND_LOGOUT_TIMER;
}

export class SessionUpdated implements Action {
  readonly type = SESSION_UPDATED;
}

export class ShowLogoutTimerDialog implements Action {
  readonly type = SHOW_LOGOUT_TIMER_DIALOG;
}

export type Action =
  | Login
  | LoginSuccess
  | LoginFailed
  | Logout
  | LogoutSuccess
  | ExtendLogoutTimer
  | ShowLogoutTimerDialog
  | SessionUpdated;
