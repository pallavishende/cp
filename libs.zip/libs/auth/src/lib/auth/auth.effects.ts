import { timer as observableTimer, Observable, of } from 'rxjs';

import {
  tap,
  delay,
  withLatestFrom,
  filter,
  switchMap,
  map,
  takeUntil,
  debounce,
  take,
  combineLatest,
  debounceTime
} from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { Action, Store, select } from '@ngrx/store';
import { Effect, Actions, ofType } from '@ngrx/effects';

import * as authActions from './auth.actions';
import * as authSelectors from './auth.selectors';
import { Auth } from './auth.interfaces';
import { AdalService } from '../adal.service';
import { AuthDebugFlagNames } from '../debug-flags';
import { LoggerService } from '@content-platform/logging';
import { DebugFlagsService } from '@content-platform/development';
import { MatDialog, MatDialogRef } from '@angular/material';
import { AutoLogoutComponent } from './auto-logout-confirmation/auto-logout.component';
import { Configuration } from '@content-platform/configuration';

const TIME_INTERVAL = 1000; // Time interval per second
const APPLICATION_TIMEOUT_DIALOG_TIME = TIME_INTERVAL * 60 * 5; // 5 minutes of popup to refresh the session
let APPLICATION_TIMEOUT_TIME = TIME_INTERVAL * 3600 * 24; // 24 hrs timeout

const AUTO_LOGOUT_START_TIME = 'AUTO_LOGOUT_START_TIME'; // Local storage key for auto logout start time

/**
 * Enum to keep a track of skipping timer and do some actions
 *
 * @enum {number}
 */
enum AutoLogoutActions {
  SHOW_LOGOUT_TIMER_DIALOG = APPLICATION_TIMEOUT_TIME / TIME_INTERVAL,
  SESSION_EXPIRED_LOGOUT = -2,
  SESSION_UPDATED = -1
}

/**
 * The Auth effects imported in {@link AuthModule}
 *
 * @export
 * @class AuthEffects
 */
@Injectable()
export class AuthEffects {
  private logger: LoggerService;
  private dialogRef: MatDialogRef<AutoLogoutComponent>;

  constructor(
    private actions: Actions,
    private adal: AdalService,
    loggerService: LoggerService,
    private debugFlags: DebugFlagsService,
    private store: Store<Auth>,
    public dialog: MatDialog
  ) {
    this.logger = loggerService.instance('Auth');

    // Todo: For Testing purposes only, Will remove this code once testing is completed
    this.debugFlags
      .hasDebugFlagAsync(AuthDebugFlagNames.Auto_Logout_Timeout)
      .pipe(take(1))
      .subscribe(value => {
        if (value) {
          const autoLogoutFlag = parseInt(
            this.debugFlags.getDebugFlagMetadata(AuthDebugFlagNames.Auto_Logout_Timeout),
            0
          );
          if (!isNaN(Number(autoLogoutFlag))) {
            APPLICATION_TIMEOUT_TIME = autoLogoutFlag;

            // Not a good way but just meant for testing so thought can get around.
            (AutoLogoutActions as any).SHOW_LOGOUT_TIMER_DIALOG =
              APPLICATION_TIMEOUT_TIME / TIME_INTERVAL;
          }
        }
      });
  }

  /**
   * Triggers the adal service login functions.
   *
   * @returns Empty resolved observable
   */
  @Effect({ dispatch: false })
  login: Observable<Action> = this.actions.pipe(
    ofType(authActions.LOGIN),
    tap(() => {
      this.adal.login();
    })
  );

  /**
   * Sets the adal user, gets the adal user from the adal [service]{@link AdalService}
   *
   * @returns { Observable<Action> } LoginSuccess action if user exists, otherwise LoginFailed action
   */
  @Effect()
  setADUser: Observable<Action> = this.actions.pipe(
    ofType(authActions.SET_AD_USER),
    map((action: authActions.SetAdUser) => action.payload),
    combineLatest(Configuration.getAsync('adal')),
    filter(([, config]) => !!config),
    map(() => {
      const user = this.adal.userInfo;
      if (user) {
        if (this.debugFlags.hasDebugFlag(AuthDebugFlagNames.Impersonate)) {
          user.profile = {
            ...(this.debugFlags.getDebugFlagMetadata(AuthDebugFlagNames.Impersonate) || {})
          };
          user.profile.oid = user.profile.objectId;
        }

        return new authActions.LoginSuccess(user);
      }
      return new authActions.Login();
    })
  );

  /**
   * Triggers the adal service logout function.
   *
   * @returns { Observable<Action> } Logout Success action
   */
  @Effect()
  logout: Observable<Action> = this.actions.pipe(
    ofType(authActions.LOGOUT),
    map(() => {
      this.adal.logout();
      localStorage.removeItem(AUTO_LOGOUT_START_TIME);
      return new authActions.LogoutSuccess();
    })
  );

  /**
   * Listens to the LOGOUT_SUCCESS action for logs
   */
  @Effect({ dispatch: false })
  logoutSuccess: Observable<Action> = this.actions.pipe(
    ofType(authActions.LOGOUT_SUCCESS),
    tap(() => {
      this.logger.log('LOGOUT SUCCESS');
    })
  );

  /**
   * This effect keeps a track of:
   * 1. user wants to extend the time by performing a ngrx action on the application
   * 2. user does not do any action for APPLICATION_TIMEOUT_TIME we show a dialog which runs for APPLICATION_TIMEOUT_DIALOG_TIME
   * 3. user does not do any action for APPLICATION_TIMEOUT_TIME + APPLICATION_TIMEOUT_DIALOG_TIME the system automatically logs out.
   * 4. also keeps a sync for multiple sessions with all the above 3 points mentioned
   *
   * @type {Observable<Action>}
   * @memberof AuthEffects
   */
  @Effect()
  extendApplicationTimeout: Observable<Action> = this.actions.pipe(
    withLatestFrom(this.store.pipe(select(authSelectors.getIsLoggedIn))),
    filter(
      ([action, loggedIn]) => loggedIn && action.type !== authActions.SHOW_LOGOUT_TIMER_DIALOG
    ),
    debounceTime(1000),
    switchMap(([action]) => {
      let currentTime = new Date().toISOString();

      // Setting the timestamp in localstorage when the timer starts or resets by any action (Syncing multiple windows)
      if (action.type !== authActions.SESSION_UPDATED && action.type !== authActions.LOGOUT) {
        localStorage.setItem(AUTO_LOGOUT_START_TIME, currentTime);
      }

      // TODO: don't trigger this every second... and remove the user of localStorage if possible.
      return observableTimer(0, TIME_INTERVAL).pipe(
        takeUntil(observableTimer(APPLICATION_TIMEOUT_TIME + APPLICATION_TIMEOUT_DIALOG_TIME)),
        map(value => {
          const startTime = localStorage.getItem(AUTO_LOGOUT_START_TIME);
          // Logout happened already from another session
          if (!startTime) {
            return AutoLogoutActions.SESSION_EXPIRED_LOGOUT;
          }
          // Comparing the timestamps based of the current session with the local storage session
          const dateFromLocalStorage = new Date(startTime);
          const currentDate = new Date(currentTime);
          if (dateFromLocalStorage > currentDate) {
            currentTime = dateFromLocalStorage.toISOString();
            // We do a debounce to skip the current timer and reinitiate the timer again
            return AutoLogoutActions.SESSION_UPDATED;
          }
          return value + 1;
        }),
        debounce(value => of({}).pipe(delay(this.getDebounceTime(value))))
      );
    }),
    map(value => {
      // This condition triggers if there is a new time stamp initiated by another instance(session)
      switch (value) {
        case AutoLogoutActions.SHOW_LOGOUT_TIMER_DIALOG:
          return new authActions.ShowLogoutTimerDialog();
        case AutoLogoutActions.SESSION_UPDATED:
          // We close the dialog if the session gets extended by another instance
          if (this.dialogRef) {
            this.dialogRef.close();
          }
          return new authActions.SessionUpdated();
        default:
          // Logging out from the app after the entire session timesout
          return new authActions.Logout();
      }
    })
  );

  /**
   * This effect shows the autologout timer dialog incase user does not do any operation for
   * APPLICATION_TIMEOUT_TIME time.
   *
   * @type {Observable<Action>}
   * @memberof AuthEffects
   */
  @Effect({ dispatch: false })
  showLogoutTimerDialog: Observable<Action> = this.actions.pipe(
    ofType(authActions.SHOW_LOGOUT_TIMER_DIALOG),
    tap(() => {
      this.dialogRef = this.dialog.open(AutoLogoutComponent, {
        width: '380px',
        data: { timeout: APPLICATION_TIMEOUT_DIALOG_TIME },
        position: { top: '0%' },
        disableClose: true
      });
    })
  );

  /**
   * This function returns the debounce delay time
   *
   * @private
   * @param {number} value
   * @returns {number}
   * @memberof AuthEffects
   */
  private getDebounceTime(value: number): number {
    switch (value) {
      case AutoLogoutActions.SESSION_EXPIRED_LOGOUT:
      case AutoLogoutActions.SESSION_UPDATED:
      case AutoLogoutActions.SHOW_LOGOUT_TIMER_DIALOG:
        return 0;
      default:
        const timeRemaining =
          ((APPLICATION_TIMEOUT_TIME + APPLICATION_TIMEOUT_DIALOG_TIME) / TIME_INTERVAL - value) *
          TIME_INTERVAL;
        return timeRemaining;
    }
  }
}
