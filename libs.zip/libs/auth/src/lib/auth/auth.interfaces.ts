/**
 * An interface for the Auth state
 */
export interface Auth {
  loggedIn: boolean;
  user: adal.User;
}

export interface AuthState {
  readonly auth: Auth;
}
