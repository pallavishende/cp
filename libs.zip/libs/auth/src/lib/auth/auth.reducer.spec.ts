import { authReducer } from './auth.reducer';
import { authInitialState } from './auth.init';
import { Auth } from './auth.interfaces';
import * as authActions from './auth.actions';

describe('authReducer', () => {
  it('authActions.LoginSuccess()', () => {
    const state: Auth = authInitialState;
    const mockUser = {
      userName: 'test.name@example.com',
      profile: {
        name: 'Test Name',
        avatar: 'http://via.placeholder.com/100'
      }
    };
    const action = new authActions.LoginSuccess(mockUser);
    const actual = authReducer(state, action);
    expect(actual).toEqual({ loggedIn: true, user: mockUser });
  });

  it('authActions.LogoutSuccess()', () => {
    const state: Auth = authInitialState;
    const action = new authActions.LogoutSuccess();
    const actual = authReducer(state, action);
    expect(actual).toEqual({ loggedIn: false, user: undefined });
  });
});
