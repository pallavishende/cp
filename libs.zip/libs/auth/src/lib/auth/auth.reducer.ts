import { Auth } from './auth.interfaces';
import * as authActions from './auth.actions';

export const INITIAL_STATE: Auth = {
  loggedIn: false,
  user: undefined
};

/**
 * Ngrx reducer for the auth state, this updates the state for the login/logout success actions
 *
 * @export
 * @param [state=INITIAL_STATE]
 * @param action
 * @returns { Auth } Updated state or the default state
 */
export function authReducer(state: Auth = INITIAL_STATE, action: authActions.Action): Auth {
  switch (action.type) {
    case authActions.LOGIN_SUCCESS: {
      return { ...state, user: action.payload, loggedIn: true };
    }

    case authActions.LOGOUT_SUCCESS: {
      return { ...state, user: undefined, loggedIn: false };
    }

    default: {
      return state;
    }
  }
}

export const isLoggedIn = (state: Auth) => state.loggedIn;
export const getADUser = (state: Auth) => state.user;
