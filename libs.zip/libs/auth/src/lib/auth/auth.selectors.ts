import { createFeatureSelector, createSelector } from '@ngrx/store';
import { Auth } from './auth.interfaces';
import * as fromAuth from './auth.reducer';

/**
 * Feature selector for the auth state
 */
export const getAuthState = createFeatureSelector<Auth>('auth');
/**
 * Selector to get the AD user from the state
 */
export const getADUser = createSelector(
  getAuthState,
  fromAuth.getADUser
);
/**
 * Selector to get the AD user id from the state
 */
export const getUserId = createSelector(
  getADUser,
  user => user && user.profile && user.profile.oid
);
/**
 * Selector to get the login state
 */
export const getIsLoggedIn = createSelector(
  getAuthState,
  fromAuth.isLoggedIn
);
