import { timer as observableTimer, Observable } from 'rxjs';

import { takeUntil, finalize, map } from 'rxjs/operators';
import { Component, Optional, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { Store } from '@ngrx/store';
import * as authActions from '../auth.actions';

export interface ConfirmationDialogData {
  title: string;
  message: string;
  yesButtonLabel: string;
  noButtonLabel: string;
  timeout: number;
}

const ConfirmationDialogDefault: ConfirmationDialogData = {
  title: 'Confirmation',
  message: 'Session is going to expire, do you want to stay in the current session?',
  timeout: 1000 * 60 * 5, // 5 minutes
  yesButtonLabel: 'Yes',
  noButtonLabel: 'No'
};

@Component({
  selector: 'app-auto-logout-confirmation-dialog',
  templateUrl: './auto-logout.component.html'
})
export class AutoLogoutComponent {
  countdown$: Observable<number>;
  timerStopped: boolean;

  constructor(
    public dialogRef: MatDialogRef<AutoLogoutComponent>,
    @Optional()
    @Inject(MAT_DIALOG_DATA)
    public data: ConfirmationDialogData = ConfirmationDialogDefault,
    private store: Store<{}>
  ) {
    this.data = { ...ConfirmationDialogDefault, ...data };
    this.timerStopped = false;
    const interval = 1000;
    const duration = this.data.timeout;
    const stream$ = observableTimer(0, interval).pipe(
      finalize(() => {
        if (!this.timerStopped) {
          this.dialogRef.close();
        }
      }),
      takeUntil(observableTimer(duration + interval)),
      map(value => duration - value * interval)
    );
    this.countdown$ = stream$.pipe(map(value => <number>value / 1000));
  }

  onClick(btnName: string): void {
    if (btnName === 'yes') {
      this.store.dispatch(new authActions.ExtendLogoutTimer());
    } else {
      this.store.dispatch(new authActions.Logout());
    }
    this.timerStopped = true;
    this.dialogRef.close();
  }
}
