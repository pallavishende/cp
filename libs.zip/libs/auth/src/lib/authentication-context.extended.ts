AuthenticationContext.prototype.resetTokenWithConsent = function(resource, callback) {
  this.clearCacheForResource(resource);
  const expectedState = this._guid() + '|' + resource;
  this.config['state'] = expectedState;
  this._renewStates.push(expectedState);
  this._requestType = this.REQUEST_TYPE.RENEW_TOKEN;
  let urlNavigate = this._getNavigateUrl('token', resource);
  urlNavigate = urlNavigate + '&prompt=consent';
  this._acquireTokenInProgress = true;
  this.registerCallback(expectedState, resource, callback);
  this._loginPopup(urlNavigate, resource, callback);
};

namespace adal {
  export interface AuthenticationContext {
    resetTokenWithConsent: (
      resource: string,
      callback: (message: string, token: string) => any
    ) => void;
  }
}
