export enum AuthDebugFlagNames {
  Impersonate = 'impersonate_user',
  Auto_Logout_Timeout = 'auto_logout_timeout'
}

export const AuthDebugFlags = [
  {
    name: AuthDebugFlagNames.Impersonate,
    hasMetadata: true,
    metadataHint: 'UUID of user to impersonate',
    inputType: 'auto-complete'
  },
  {
    name: AuthDebugFlagNames.Auto_Logout_Timeout,
    hasMetadata: true,
    metadataHint: 'Enter the time in ms'
  }
];
