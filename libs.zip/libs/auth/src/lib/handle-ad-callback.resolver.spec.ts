import { TestBed, inject } from '@angular/core/testing';

import { AdalService } from './adal.service';

import { HandleAdCallbackResolver } from './handle-ad-callback.resolver';

xdescribe('HandleAdCallbackGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AdalService, HandleAdCallbackResolver]
    });
  });

  it('should ...', inject([HandleAdCallbackResolver], (resolver: HandleAdCallbackResolver) => {
    expect(resolver).toBeTruthy();
  }));
});
