import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';

import { AdalService } from './adal.service';
import { Configuration } from '@content-platform/configuration';
import { map, filter } from 'rxjs/operators';
import { Observable } from 'rxjs';

/**
 * Resolver used for the login route, to retrieve the user login information for the
 * adal service.
 * Example:
 * ```ts
 * { path: 'login', component: LoginComponent, resolve: { user: HandleAdCallbackResolver } }
 * ```
 *
 * @export
 * @class HandleAdCallbackResolver
 */
@Injectable()
export class HandleAdCallbackResolver implements Resolve<adal.User | boolean> {
  constructor(private adalService: AdalService) {}

  resolve(): Observable<adal.User | boolean> {
    return this.adalConfigLoaded().pipe(
      filter(loaded => loaded),
      map(() => {
        this.adalService.handleCallback();
        if (this.adalService.isAuthenticated) {
          return this.adalService.userInfo;
        }
        return false;
      })
    );
  }

  private adalConfigLoaded(): Observable<boolean> {
    return Configuration.getAsync('adal').pipe(
      map(config => {
        console.log(config);
        return !!config;
      })
    );
  }
}
