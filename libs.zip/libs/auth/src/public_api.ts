export { AuthModule } from './lib/auth.module';
export { HandleAdCallbackResolver } from './lib/handle-ad-callback.resolver';
export { Auth, AuthState } from './lib/auth/auth.interfaces';

import * as authActions from './lib/auth/auth.actions';
import * as fromAuth from './lib/auth/auth.reducer';
import * as authSelectors from './lib/auth/auth.selectors';
import { AdAuthGuard } from './lib/ad-auth.guard';
export { authActions, fromAuth, authSelectors, AdAuthGuard };
export { AdalService } from './lib/adal.service';

export { AuthDebugFlagNames } from './lib/debug-flags';
