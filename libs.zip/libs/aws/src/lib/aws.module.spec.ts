import { AwsModule } from './aws.module';

describe('AwsModule', () => {
  it('should work', () => {
    expect(new AwsModule()).toBeDefined();
  });
});
