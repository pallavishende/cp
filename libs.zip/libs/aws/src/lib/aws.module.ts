import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FileUploadService } from './services/file-upload.service';
import { LoggingModule } from '@content-platform/logging';

@NgModule({
  imports: [CommonModule, LoggingModule],
  providers: [FileUploadService]
})
export class AwsModule {}
