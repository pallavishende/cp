export class FileItem {
  name: string;
  size: number | string;
  type: string;
  file: File;
  metadata?: string;
  fileCategory?: string;
  uploadSuccess?: boolean;
  uploading?: boolean;
}
