export interface FileUploadStats {
  duration: string;
  avgSpeed: string;
}
