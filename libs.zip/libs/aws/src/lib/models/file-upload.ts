import { Observable } from 'rxjs';
import { FileItem } from './file-item';

export interface FileUpload extends FileItem {
  originalFileName?: string;
  modifiedFileName?: string;
  uploadSuccess?: boolean;
  uploadFlag?: boolean;
  uploadProgress?: Observable<number>;
  uploadSpeed?: Observable<string>;
  uploadFailed?: boolean;
}
