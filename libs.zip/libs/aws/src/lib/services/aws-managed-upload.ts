import {
  HttpRequest,
  HttpEvent,
  HttpEventType,
  HttpClient,
  HttpParams,
  HttpHeaders,
  HttpResponse
} from '@angular/common/http';
import {
  tap,
  last,
  map,
  catchError,
  switchMap,
  mergeMap,
  toArray,
  retry
} from 'rxjs/operators';
import {
  Observable,
  Subject,
  throwError,
  timer,
  from,
} from 'rxjs';
import {
  FileUploadStats
} from '../models';
import {
  Environments
} from '@content-platform/configuration';

export interface UploadProgress {
  uploadSpeed: string; // Mbps
  progress: number; // percentage
  duration: string; // seconds
}

export interface FilePart {
  blob: File;
  partNumber: string;
  requestURL ? : string;
}

export interface ProgressTracker {
  loaded: number;
}

export type FileParts = FilePart[];

const CHUNK_SIZE = 50000000; // 50MB
// No of retry attempts
const RETRY_ATTEMPTS = 2;
const PROGRESS_REFRESH_INTERVAL = 1000;

export class AWSManagedUpload {
  private currentLoadedTime = 0;
  private currentLoadedData = 0;
  private lastLoadTime = 0;
  private lastLoadedData = 0;
  private bucketId: string;
  private progress: Map<string, ProgressTracker> = new Map();
  private uploadStart = 0;
  private onProgressSubject = new Subject < UploadProgress > ();

  constructor(private http: HttpClient, 
    private preSignedUrl: string, 
    private file: File,
    private fileName?: string) {}

  /**
   * Returns the Megabits per second value of the size & duration.
   *
   * @private
   * @param size is in bytes
   * @param duration in seconds
   * @returns
   */
  private getAvgUploadSpeed(size: number, duration: number): string {
    if (size) {
      const fileSize = size / 1000000; // Megabytes
      const megabits = fileSize * 8;
      return (megabits / duration).toFixed(1);
    }
    return null;
  }

  /**
   * Used to keep track of the upload progress, keeps track of the current
   * upload speed, and the amount uploaded thus far.
   *
   * @private
   * @param event
   */
  private updateProgress(event: HttpEvent < any > ): void {
    if (event.type === HttpEventType.UploadProgress) {
      this.currentLoadedData = event.loaded;
      this.currentLoadedTime = performance.now();
    }
  }
/**
 *
 *
 * @private
 * @param {HttpEvent < any >} event
 * @param {*} partNumber
 * @memberof AWSManagedUpload
/**
 *
 *
 * @private
 * @param {HttpEvent < any >} event
 * @param {*} partNumber
 * @memberof AWSManagedUpload
 */
private updateMultiPartProgress(event: HttpEvent < any >, partNumber ) {
    if(!this.progress.get(partNumber)) {
      this.progress.set(partNumber, {
          loaded: 0
      });
    }
    const partTracker = this.progress.get(partNumber);
    if (event.type === HttpEventType.UploadProgress) {
      partTracker.loaded = event.loaded;
      this.progress.set(partNumber, partTracker);
    }
    this.currentLoadedData = 0;
    this.progress.forEach(partProgress => {
      this.currentLoadedData += partProgress.loaded;
    });
    this.currentLoadedTime = performance.now();
  }

  /**
   * Can be subscribed to, to get the progress of the file upload.
   *
   * @returns
   */
  withProgress(): Observable < UploadProgress > {
    return timer(0, PROGRESS_REFRESH_INTERVAL)
    .pipe(
      map(() => {
        const uploadProgress = {
          duration: ((performance.now() - this.uploadStart) / 1000).toFixed(3),
          uploadSpeed: this.getAvgUploadSpeed(this.currentLoadedData - this.lastLoadedData, 
            ((this.currentLoadedTime - this.lastLoadTime) / 1000)),
          progress: Math.round(((100 * this.currentLoadedData) / this.file.size) - 1)
        };
        this.lastLoadedData = this.currentLoadedData;
        this.lastLoadTime = this.currentLoadedTime;
        if(uploadProgress.progress < 0 || isNaN(uploadProgress.progress)) {
          uploadProgress.progress = 0;
        }
        return uploadProgress;
      })
    );
  }

  upload(multipart = false): Observable < FileUploadStats > {
    if(!multipart) {
      this.uploadStart = performance.now();

    // only enable reportProgress if we are subscribing to withProgress.

    const req = new HttpRequest('PUT', this.preSignedUrl, this.file, {
      responseType: 'text',
      reportProgress: true
    });

    return this.http.request(req).pipe(
      tap(event => {
        this.updateProgress(event);
      }),
      last(),
      map(() => {
        const duration = (performance.now() - this.uploadStart) / 1000; // seconds
        this.onProgressSubject.complete();
        return {
          duration: duration.toFixed(3),
          avgSpeed: this.getAvgUploadSpeed(this.file.size, duration)
        };
      }),
      catchError(error => {
        this.onProgressSubject.complete();
        return throwError(error);
      })
    );
    } else {
      return this.uploadAsMultipleParts();
    }
  }

  uploadAsMultipleParts() {
    this.uploadStart = performance.now();

    return this.getBucketId()
      .pipe(
        switchMap(bucket => {
          return this.getFilePartURLS(bucket);
        }),
        switchMap(fileBlobArray => {
          const uploadRequests = [];
          fileBlobArray.forEach(blob => {
            const req = new HttpRequest('PUT', blob.requestURL, blob.blob, {
              headers: new HttpHeaders({
                'Content-Type': 'multipart/form-data'
              }),
              responseType: 'text',
              reportProgress: true,
              params: new HttpParams({
                fromObject: {
                  uploadId: this.bucketId,
                  partNumber: blob.partNumber
                }
              })
            });
            const httpCall = this.http
              .request(req)
              .pipe(
                tap(event => this.updateMultiPartProgress(event, blob.partNumber)),
                last(),
                retry(RETRY_ATTEMPTS),
                catchError(err => {
                  return Observable.throw(err);
                })
              );
            uploadRequests.push(httpCall);
          });
          return from(uploadRequests)
          .pipe(
            mergeMap(uploadRequest => uploadRequest, 3),
              toArray(),
              map((responses: HttpResponse<any>[]) => {
                return responses.map((response) => {
                  const requestURL = new URL(response.url);
                  return {
                    eTag: (response.headers.get('etag') as string).replace(`""`, ''),
                    partNumber: +requestURL.searchParams.get('partNumber')
                  };
                });
              }),
              catchError(err => {
                this.onProgressSubject.complete();
                return Observable.throw(err);
              })
            );
        }),
        switchMap(partETags => {
          return this.completeRequest(partETags);
        }),
        map(() => {
          const duration = (performance.now() - this.uploadStart) / 1000; // seconds
          this.onProgressSubject.complete();
          return {
            duration: duration.toFixed(3),
            avgSpeed: this.getAvgUploadSpeed(this.file.size, duration)
          };
        }),
        catchError(error => {
          this.onProgressSubject.complete();
          return throwError(error);
        })
      );
  }

  splitFileIntoParts(file ? : File): FileParts {
    file = this.file;
    const fileSize = file.size;
    const noOfChunks = Math.floor(fileSize / CHUNK_SIZE) + 1;
    const blobArray: FileParts = [];
    let start, end, blob;

    for (let index = 1; index < noOfChunks + 1; index++) {
      start = (index - 1) * CHUNK_SIZE;
      end = (index) * CHUNK_SIZE;
      blob = (index < noOfChunks) ? file.slice(start, end) : file.slice(start);
      blobArray.push({
        blob,
        partNumber: index.toString()
      });
    }
    return blobArray;
  }

  getBucketId() {
    const baseUrl = Environments.getUrl('submissionEndpoint');
    const configUrl = `${baseUrl}/s3/initiate-multipart-upload`;
    const fileName = this.fileName;
    return this.http.get(configUrl, {
        observe: 'response',
        responseType: 'text',
        params: {
          fileName
        }
      })
      .pipe(
        map(response => {
          this.bucketId = response.headers.get('Location');
          return this.bucketId;
        }),
      );
  }

  getFilePartURLS(bucketId: string): Observable < FileParts > {
    const fileName = this.fileName;
    const fileBlobArray = this.splitFileIntoParts();
    // const presignedURLRequestArray = [];
    const parts = fileBlobArray.length;
    const requestURL = `${Environments.getUrl('submissionEndpoint')}/s3/resource-multipart`;
    const params = {
      fileName,
      uploadId: bucketId,
      parts: parts.toString(),
      requestMethod: 'PUT'
    };
    return this.http
      .get<string[]>(requestURL, {
        params
      })
      .pipe(
        map(URLs => {
          URLs.forEach((url, index) => {
            fileBlobArray[index].requestURL = url;
          });
          return fileBlobArray;
        }),
        catchError(err => {
          this.onProgressSubject.complete();
          return Observable.throw(err);
        })
      );
  }

  completeRequest(partETags) {
    const requestURL = `${Environments.getUrl('submissionEndpoint')}/s3/complete-multipart-upload`;
    return this.http.post(requestURL, {
        uploadId: this.bucketId,
        partETags,
        key: this.fileName
      })
      .pipe(
        catchError(err => {
          this.onProgressSubject.complete();
          return Observable.throw(err);
        })
      );
  }

}
