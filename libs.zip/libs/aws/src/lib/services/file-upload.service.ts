import { throwError, Observable, Observer } from 'rxjs';
import { Injectable, NgZone } from '@angular/core';
import { LoggerService } from '@content-platform/logging';

import { HttpClient } from '@angular/common/http';
import { catchError, tap, map, startWith } from 'rxjs/operators';
import { BehaviorSubject, of, zip } from 'rxjs';
import { OverlayRef } from '@angular/cdk/overlay';
import { AWSManagedUpload, UploadProgress } from './aws-managed-upload';
import { notificationActions, NotificationType } from '@content-platform/notifications';
import { Store } from '@ngrx/store';
import { Environments } from '@content-platform/configuration';
import { FileUpload, FileUploadStats } from '../models';

@Injectable()
export class FileUploadService {
  private logger: LoggerService;
  fileUploadSucceed$ = new BehaviorSubject<string>(undefined);
  enableFileUpload$ = new BehaviorSubject<boolean>(true);
  fileEmitter$ = new BehaviorSubject<FileUpload[]>(undefined);
  enableFileProgress: boolean;
  fileArray: FileUpload[] = [];
  fileItems: FileUpload[];
  count: number;
  uploadingFilesCount = 0;
  uploadedFilesCount = 0;
  overlayElem: Observable<OverlayRef>;
  overlayElemSubject$$ = new BehaviorSubject<OverlayRef>(undefined);

  constructor(
    private http: HttpClient,
    loggerService: LoggerService,
    private store: Store<any>,
    private ngZone: NgZone
  ) {
    this.overlayElem = this.overlayElemSubject$$.asObservable();
    this.logger = loggerService.instance('FileUploadService');
    this.enableFileUpload$.subscribe(value => {
      this.enableFileProgress = value;
    });
    this.fileEmitter$.subscribe(value => {
      if (value) {
        const newFilesCount = value.length;
        const tempCount = this.fileArray.filter(val => !val.uploadFlag).length;
        this.uploadingFilesCount = tempCount + newFilesCount;

        value.forEach(element => {
          element.uploadFlag = false;
          this.fileArray.push(element);
        });

        this.fileItems = this.fileArray;
        this.count = this.fileItems.length;
      }
    });
    this.fileUploadSucceed$.subscribe(value => {
      if (value) {
        this.fileItems.forEach(file => {
          if (file.modifiedFileName === value) {
            file.uploadFlag = true;
          }
        });
        // Check whether all the files are uploaded
        const uploaded = this.fileItems.filter(item => item.uploadFlag === true);
        if (uploaded.length === this.fileItems.length) {
          this.uploadedFilesCount = uploaded.length;
          this.uploadingFilesCount = 0;
        } else {
          this.uploadingFilesCount = this.fileItems.filter(val => !val.uploadFlag).length;
        }
      }
    });
  }
  private handleError(error: Response | any, logMessage: string, extraParams?): Observable<any> {
    const body = error.error || error;
    let err;
    try {
      err = JSON.stringify(body) || 'Server Error';
    } catch (error) {
      err = 'Server Error';
    }
    this.logger.log(logMessage, extraParams);
    return throwError(err);
  }

  setOverlayRef(data: OverlayRef) {
    this.overlayElemSubject$$.next(data);
  }

  /**
   * Notifies file error
   */
  displayFileError(error: any, fileName: string, message?: string): Observable<any> {
    message = message || 'Failed to get file URL';
    this.store.dispatch(
      new notificationActions.Open({
        type: NotificationType.Error,
        inputs: {
          props: {
            message,
            button: {
              label: 'Dismiss',
              action: function() {}
            }
          }
        }
      })
    );
    return this.handleError(error, message, {
      fileName: fileName
    });
  }

  /**
   * Filters out uploaded files
   */
  clearCompletedFiles() {
    this.fileArray = this.fileArray.filter(fileItem => !fileItem.uploadSuccess);
  }

  /**
   * Adds url to file object
   */
  addUrlToFiles(filedata: FileUpload[], s3BucketKey?: string): Observable<FileUpload[]> {
    const filesToUpload = filedata.filter(file => !file.uploadSuccess);
    // No Files to upload
    if (filesToUpload.length === 0) {
      return of(filedata);
    }

    const filesWithUrls$ = filesToUpload.map(fileitem => {
      if (!fileitem.metadata) {
        const fileName = fileitem.name;
        return this.getFileUrl(fileName, 'PUT', s3BucketKey).pipe(
          map(url => {
            fileitem.metadata = url;
            return fileitem;
          }),
          catchError(error => this.displayFileError(error, fileName))
        );
      }
      return of(fileitem);
    });
    return zip(...filesWithUrls$);
  }

  /**
   * Gets file url for the given file
   */
  getFileUrl(
    fileName: string,
    requestMethod: 'PUT' | 'GET',
    bucketKey?: string
  ): Observable<string> {
    const baseUrl = Environments.getUrl('submissionEndpoint');
    const configUrl = `${baseUrl}/s3/resource`;
    const params = { fileName, requestMethod, bucketKey };
    return this.http
      .get(configUrl, { observe: 'response', responseType: 'text', params })
      .pipe(map(res => res.headers.get('location')));
  }

  /**
   * Uploads file to s3 bucket outside angular so it doesn't trigger digests continually
   */
  uploadFileToS3Bucket(preSignedUrl: string, file: FileUpload, multipart = false) {
    return Observable.create((observer: Observer<FileUploadStats>) => {
      this.ngZone.runOutsideAngular(() => {
        this.uploadFile(preSignedUrl, file, multipart).subscribe(
          data => {
            this.ngZone.run(() => {
              observer.next(data);
            });
          },
          error => {
            observer.error(error);
          },
          () => observer.complete()
        );
      });
    });
  }

  /**
   * Uploads file to s3 bucket
   */
  private uploadFile(preSignedUrl: string, file: FileUpload, multipart = false) {
    let speed;
    let progress;
    const req = new AWSManagedUpload(this.http, preSignedUrl, file.file, file.modifiedFileName);

    // To track the upload progress percentage of the file
    file.uploadProgress = req.withProgress().pipe(
      map((item: UploadProgress) => {
        progress = item.progress;
        return item.progress;
      }),
      startWith(0)
    );

    // To track the upload speed of the file
    file.uploadSpeed = req.withProgress().pipe(
      map((item: UploadProgress) => {
        speed = item.uploadSpeed;
        return item.uploadSpeed;
      })
    );
    file.uploadFailed = false;
    file.uploading = true;

    return req.upload(multipart).pipe(
      tap(_res => {
        this.fileUploadSucceed$.next(file.modifiedFileName);
        file.uploading = false;
      }),
      catchError(error => {
        file.uploadFailed = true;
        file.uploading = false;
        return this.handleError(error, 'Failed to upload file to S3 bucket', {
          fileName: file.name,
          fileSize: file.size,
          fileType: file.type,
          uploadProgress: progress,
          uploadSpeed: speed,
          message: error
        });
      })
    );
  }

  uploadFileAmazonBucket(fileObject: FileUpload) {
    return this.http
      .put(fileObject.metadata, fileObject.file, {
        observe: 'response',
        responseType: 'text'
      })
      .pipe(
        catchError(error =>
          this.handleError(error, 'Failed to upload file to S3 bucket', {
            fileName: fileObject.file.name,
            fileSize: fileObject.file.size,
            fileType: fileObject.file.type
          })
        )
      );
  }
}
