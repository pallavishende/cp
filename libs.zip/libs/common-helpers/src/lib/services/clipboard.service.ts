import { Inject, Injectable } from '@angular/core';
import { DOCUMENT } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class ClipboardService {
  constructor(@Inject(DOCUMENT) private document) {}

  copyToClipboard(value: string) {
    const textarea = this.document.createElement('textarea');
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    textarea.value = value;

    this.document.body.appendChild(textarea);
    textarea.select();

    try {
      const successful = this.document.execCommand('copy');
      if (!successful) {
        throw successful;
      }
    } catch (err) {
      window.prompt('Copy to clipboard: Ctrl+C, Enter');
    }

    textarea.remove();
  }
}
