import { ClipboardService } from './clipboard.service';
import { NavigationHelperService } from './navigation-helper.service';

export * from './clipboard.service';
export * from './navigation-helper.service';

const resources = [ClipboardService, NavigationHelperService];

export { resources };
