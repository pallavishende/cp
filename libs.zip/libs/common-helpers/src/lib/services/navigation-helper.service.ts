import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NavigationHelperService {
  constructor() {}

  public getUrlSanitizedString(str: string): string {
    return str
      .toLowerCase()
      .replace(/[^\w\s]/gi, '') // remove special chars
      .replace(/\s/g, '-') // concatenate with commas
      .replace(/-+/g, '-'); // remove possible duplicated commas
  }
}
