import { ConfigurationService } from './configuration.service';

export function configurationLoader(configurationService: ConfigurationService) {
  return () => {
    return configurationService.loadConfiguration();
  };
}
