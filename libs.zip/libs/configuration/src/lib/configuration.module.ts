import { NgModule, APP_INITIALIZER } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { configurationLoader } from './configuration-loader';
import { ConfigurationService } from './configuration.service';

@NgModule({
  imports: [CommonModule, HttpClientModule],
  providers: [
    ConfigurationService,
    {
      provide: APP_INITIALIZER,
      useFactory: configurationLoader,
      deps: [ConfigurationService],
      multi: true
    }
  ]
})
export class ConfigurationModule {}
