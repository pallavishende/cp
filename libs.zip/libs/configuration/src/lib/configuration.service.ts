import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { localhostConfiguration } from './localhost-config';

export class Configuration {
  private static config: any;
  private static hasSetSubject = new BehaviorSubject<boolean>(false);

  public static get(key: string) {
    return this.config && this.config[key];
  }

  public static getAsync(key: string): Observable<any> {
    return this.hasSetSubject.pipe(
      map(() => {
        if (this.config && this.config[key]) {
          return this.config[key];
        }
        return null;
      })
    );
  }

  public static setConfig(data: any) {
    this.config = data;
    this.hasSetSubject.next(true);
  }

  public static getConfig() {
    return this.config;
  }
}

@Injectable()
export class ConfigurationService {
  private isRunningInLocalhost: boolean;
  private configuration: any;

  constructor(private http: HttpClient) {
    this.isRunningInLocalhost = document.URL.toString().includes('localhost');
  }

  public isRunningLocally() {
    return this.isRunningInLocalhost;
  }

  public loadConfiguration(): Promise<any> {
    console.log('Loading configuration...');
    let promise;
    if (this.isConfigurationLoaded()) {
      return Promise.resolve();
    } else if (!this.isRunningLocally()) {
      promise = this.http.get('/config.json').toPromise();
      promise.then(res => {
        const config = JSON.stringify(res);
        this.saveConfiguration(config);
      });
      return promise;
    } else {
      const config = JSON.stringify(localhostConfiguration);
      this.saveConfiguration(config);
      return Promise.resolve(config);
    }
  }

  public getConfiguration() {
    if (this.configuration && this.configuration.config) {
      return this.configuration.config;
    } else {
      return null;
    }
  }

  private isConfigurationLoaded(): boolean {
    if (Configuration.getConfig()) {
      return true;
    }
    return false;
  }

  private saveConfiguration(config: string) {
    const configuration = JSON.parse(config);
    Configuration.setConfig(configuration.config);
    console.log('Configuration loaded from server.');
  }
}
