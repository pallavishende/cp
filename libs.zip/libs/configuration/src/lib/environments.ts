import { Configuration } from './configuration.service';

interface EnvironmentEndpoint {
  endpoint: string;
  type: string;
}

type environments =
  | 'submissionEndpoint'
  | 'permissionsEndpoint'
  | 'updEndpoint'
  | 'endpointProfile'
  | 'pushNotificationEndpoint'
  | 'tlsEndpoint'
  | 'aapiEndpoint'
  | 'preferenceEndpoint'
  | 'ebxEndpoint'
  | 'gegatewayEndpoint'
  | 'reggieEndpoint'
  | 'reggieRecordEndpoint'
  | 'uwfDashboardEndpoint'
  | 'vmsApiEndpoint'
  | 'taxonomySolrEndpoint'
  | 'tagfinderSolrEndpoint'
  | 'taggingServiceEndpoint';

const environmentEndpoints: { [key: string]: EnvironmentEndpoint } = {
  gegatewayEndpoint: { endpoint: '/gegateway', type: 'globalEntryGatewayUrl' },
  submissionEndpoint: { endpoint: '/gegateway/api/v1', type: 'globalEntryGatewayUrl' },
  permissionsEndpoint: { endpoint: '/permissions/api', type: 'contentPlatformGatewayUrl' },
  updEndpoint: { endpoint: '/upd/api/v1', type: 'contentPlatformGatewayUrl' },
  endpointProfile: { endpoint: '/endpoint-profile/api', type: 'contentPlatformGatewayUrl' },
  pushNotificationEndpoint: { endpoint: '/gegateway/ws', type: 'globalEntryGatewayUrl' },
  tlsEndpoint: { endpoint: '/gegateway/tls/api', type: 'globalEntryGatewayUrl' },
  aapiEndpoint: { endpoint: '/aapi/v1', type: 'contentPlatformGatewayUrl' },
  ebxEndpoint: { endpoint: '/ebx', type: 'contentPlatformGatewayUrl' },
  preferenceEndpoint: { endpoint: '/preferences/api/v1', type: 'contentPlatformGatewayUrl' },
  reggieEndpoint: { endpoint: '/reggie', type: 'contentPlatformGatewayUrl' },
  reggieRecordEndpoint: { endpoint: '/reggie-record', type: 'contentPlatformGatewayUrl' },
  uwfDashboardEndpoint: { endpoint: '/uwfdashboard', type: 'contentPlatformGatewayUrl' },
  vmsApiEndpoint: { endpoint: '/gegateway/vms/api', type: 'globalEntryGatewayUrl' },
  taxonomySolrEndpoint: { endpoint: '/tt/taxonomy-solr', type: 'contentPlatformGatewayUrl' },
  tagfinderSolrEndpoint: { endpoint: '/tt/tagfinder-solr', type: 'contentPlatformGatewayUrl' },
  taggingServiceEndpoint: { endpoint: '/tt/tagging/api', type: 'contentPlatformGatewayUrl' }
};

export class Environments {
  static getUrl(environment: environments): string {
    const data = environmentEndpoints[environment];
    return Configuration.get(data.type) + data.endpoint;
  }
}
