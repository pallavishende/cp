export const localhostConfiguration = {
  config: {
    adal: {
      tenant: 'viacom.onmicrosoft.com',
      clientId: 'd96b3fc9-3e1a-4839-baec-2e0a3f216af3',
      redirectUri: 'dev',
      endpoints: {
        'https://dev.gateway.globalentry.viacom.com': '068cb5fa-4388-4f7a-9c16-ac9bbfc8103b',
        'https://dev.gateway.contentplatform.viacom.com': '3eaa8d96-e68c-48e1-9861-329227193d28'
      }
    },
    globalEntryGatewayUrl: 'https://dev.gateway.globalentry.viacom.com',
    contentPlatformGatewayUrl: 'https://dev.gateway.contentplatform.viacom.com'
  }
};
