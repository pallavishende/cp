import { async, TestBed } from '@angular/core/testing';
import { ContentcatalogApiModule } from './content-catalog-api.module';

describe('ContentcatalogApiModule', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ContentcatalogApiModule]
    }).compileComponents();
  }));

  it('should create', () => {
    expect(ContentcatalogApiModule).toBeDefined();
  });
});
