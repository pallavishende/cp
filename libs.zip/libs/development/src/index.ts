export { DevelopmentModule } from './lib/development.module';
export { DebugFlagsService } from './lib/services/debug-flags.service';

export const FEATURE_FLAG_KEY = 'show_feature_flags_menu';

export * from './lib/selectors';
export * from './lib/actions';
export * from './lib/reducers';
export * from './lib/config';
