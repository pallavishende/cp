import { Action } from '@ngrx/store';
import * as fromConfig from '../config';

export enum ActionTypes {
  LoadDebugFlags = '[DebugFlags] Load Flags',
  LoadDebugFlagsSuccess = '[DebugFlags] Load Flags Success',
  SetDebugFlags = '[DebugFlags] Set Flags'
}

export class Set implements Action {
  readonly type = ActionTypes.SetDebugFlags;
  constructor(public payload: fromConfig.DebugFlagSettings) {}
}
export class Load implements Action {
  readonly type = ActionTypes.LoadDebugFlags;
  constructor() {}
}
export class LoadSuccess implements Action {
  readonly type = ActionTypes.LoadDebugFlagsSuccess;
  constructor(public payload: fromConfig.DebugFlagSettings) {}
}

export type All = Load | Set | LoadSuccess;
