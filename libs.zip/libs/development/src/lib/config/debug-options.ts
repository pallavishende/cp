import { InjectionToken } from '@angular/core';

export const DebugFlagList = new InjectionToken<DebugFlag[]>('DebugFlagList');
export const DevelopmentModuleProdEnvironment = new InjectionToken<boolean>(
  'DevelopmentModuleProdEnvironment'
);

export interface DebugFlag {
  name: string;
  hasMetadata?: boolean;
  metadataHint?: string;
  inputType?: string;
  onChange?: (enabled: boolean, metadata?: string) => void;
}

export interface DebugFlagSettings {
  [flagName: string]: boolean | any;
}

export const GlobalDebugFlags: DebugFlag[] = [];
