import { DevelopmentModule } from './development.module';

describe('DevelopmentModule', () => {
  it('should work', () => {
    expect(new DevelopmentModule()).toBeDefined();
  });
});
