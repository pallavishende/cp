import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import * as fromConfig from './config';

import { fromDebugFlags } from './reducers';
import { DebugFlagEffects } from './effects/debug-flag.effects';
import { DebugFlagsService, DebugFlagsStorageService } from './services';
import { IfDebugFlagDirective } from './directives/if-debug-flag.directive';
import { IfDebugFlagAsyncDirective } from './directives/if-debug-flag-async.directive';
import { IfNotDebugFlagDirective } from './directives/if-not-debug-flag.directive';
import { IfNotDebugFlagAsyncDirective } from './directives/if-not-debug-flag-async.directive';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    StoreModule.forFeature('debugFlags', fromDebugFlags.debugFlagsReducer),
    EffectsModule.forFeature([DebugFlagEffects])
  ],
  providers: [
    DebugFlagsService,
    DebugFlagEffects,
    DebugFlagsStorageService,
    {
      provide: fromConfig.DebugFlagList,
      multi: true,
      useValue: fromConfig.GlobalDebugFlags
    }
  ],
  declarations: [
    IfDebugFlagDirective,
    IfDebugFlagAsyncDirective,
    IfNotDebugFlagDirective,
    IfNotDebugFlagAsyncDirective
  ],
  entryComponents: [],
  exports: [
    IfDebugFlagDirective,
    IfDebugFlagAsyncDirective,
    IfNotDebugFlagDirective,
    IfNotDebugFlagAsyncDirective
  ]
})
export class DevelopmentModule {
  static forRoot(production: boolean, flags: fromConfig.DebugFlag[] = []): ModuleWithProviders {
    return {
      ngModule: DevelopmentModule,
      providers: [
        {
          provide: fromConfig.DebugFlagList,
          multi: true,
          useValue: flags
        },
        { provide: fromConfig.DevelopmentModuleProdEnvironment, useValue: production }
      ]
    };
  }

  static withFlags(flags: fromConfig.DebugFlag[] = []): ModuleWithProviders {
    return {
      ngModule: DevelopmentModule,
      providers: [
        {
          provide: fromConfig.DebugFlagList,
          multi: true,
          useValue: flags
        }
      ]
    };
  }
}
