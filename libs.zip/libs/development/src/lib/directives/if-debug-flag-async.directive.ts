import { Directive, Input, TemplateRef, ViewContainerRef, OnDestroy } from '@angular/core';
import { DebugFlagsService } from '../services';
import { enableDisableView } from './if-debug-flag.directive';
import { Subscription } from 'rxjs';

@Directive({
  selector: '[appIfDebugFlagAsync]'
})
export class IfDebugFlagAsyncDirective implements OnDestroy {
  private debugFlagSubscription: Subscription;
  private hasView = false;

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private debugFlagsService: DebugFlagsService
  ) {}

  @Input()
  set appIfDebugFlagAsync(flagName: string) {
    this.removeSubscription();
    this.debugFlagSubscription = this.debugFlagsService
      .hasDebugFlagAsync(flagName)
      .subscribe(hasFlag => {
        this.hasView = enableDisableView(
          hasFlag,
          this.viewContainer,
          this.templateRef,
          this.hasView
        );
      });
  }

  ngOnDestroy() {
    this.removeSubscription();
  }

  private removeSubscription() {
    if (this.debugFlagSubscription) {
      this.debugFlagSubscription.unsubscribe();
    }
  }
}
