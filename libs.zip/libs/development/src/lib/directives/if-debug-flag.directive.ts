import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { DebugFlagsService } from '../services';

export function enableDisableView(
  enableView: boolean,
  viewContainer: ViewContainerRef,
  templateRef: TemplateRef<any>,
  hasView: boolean
): boolean {
  if (enableView && !hasView) {
    viewContainer.createEmbeddedView(templateRef);
    return true;
  } else if (!enableView && hasView) {
    viewContainer.clear();
    return false;
  }
  return hasView;
}

@Directive({
  selector: '[appIfDebugFlag]'
})
export class IfDebugFlagDirective {
  private hasView = false;

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private debugFlagService: DebugFlagsService
  ) {}

  @Input()
  set appIfDebugFlag(flagName: string) {
    this.hasView = enableDisableView(
      this.debugFlagService.hasDebugFlag(flagName),
      this.viewContainer,
      this.templateRef,
      this.hasView
    );
  }
}
