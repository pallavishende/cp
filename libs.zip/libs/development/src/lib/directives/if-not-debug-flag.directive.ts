import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { DebugFlagsService } from '../services';
import { enableDisableView } from './if-debug-flag.directive';

@Directive({
  selector: '[appIfNotDebugFlag]'
})
export class IfNotDebugFlagDirective {
  private hasView = false;

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private debugFlagsService: DebugFlagsService
  ) {}

  @Input()
  set appIfNotDebugFlag(flagName: string) {
    this.hasView = enableDisableView(
      !this.debugFlagsService.hasDebugFlag(flagName),
      this.viewContainer,
      this.templateRef,
      this.hasView
    );
  }
}
