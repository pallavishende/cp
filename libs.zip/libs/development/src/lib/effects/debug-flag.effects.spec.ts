import { TestBed } from '@angular/core/testing';
import { StoreModule } from '@ngrx/store';
import { provideMockActions } from '@ngrx/effects/testing';
import { DataPersistence } from '@nrwl/nx';
import { TestScheduler } from 'rxjs/testing';
import { DebugFlagsStorageService } from '../services';

import { DebugFlagEffects } from './debug-flag.effects';
import { debugFlagActions } from '../actions';

import { Observable } from 'rxjs';

import * as fromConfig from '../config';

class DebugStorageMock {
  storedValue: fromConfig.DebugFlagSettings;

  saveToLocalStorage(settings: fromConfig.DebugFlagSettings) {
    this.storedValue = settings;
  }

  clearLocalStorage() {
    this.storedValue = undefined;
  }

  getFromLocalStorage(): fromConfig.DebugFlagSettings {
    return this.storedValue;
  }
}

function createTestScheduler(): TestScheduler {
  return new TestScheduler((actual, expected) => {
    expect(actual).toEqual(expected);
  });
}

describe('DebugFlagsEffects', () => {
  let actions$: Observable<any>;
  let effects$: DebugFlagEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [StoreModule.forRoot({})],
      providers: [
        DebugFlagEffects,
        DataPersistence,
        provideMockActions(() => actions$),
        { provide: DebugFlagsStorageService, useClass: DebugStorageMock }
      ]
    });

    effects$ = TestBed.get(DebugFlagEffects);
  });

  describe('someEffect', () => {
    it('should work', () => {
      createTestScheduler().run(helpers => {
        const { hot, expectObservable } = helpers;
        actions$ = hot('-a-|', { a: new debugFlagActions.Load() });

        expectObservable(effects$.load$).toBe('-a-|', { a: new debugFlagActions.LoadSuccess({}) });
      });
    });
  });
});
