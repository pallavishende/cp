import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { debugFlagActions } from '../actions';
import { DebugFlagsStorageService } from '../services';

@Injectable()
export class DebugFlagEffects {
  constructor(
    private debugFlagActions$: Actions,
    private debugFlagsStorage: DebugFlagsStorageService
  ) {}

  @Effect()
  load$: Observable<Action> = this.debugFlagActions$.pipe(
    ofType(debugFlagActions.ActionTypes.LoadDebugFlags),
    map(() => {
      return new debugFlagActions.LoadSuccess(this.debugFlagsStorage.getFromLocalStorage() || {});
    })
  );

  @Effect({ dispatch: false })
  set$ = this.debugFlagActions$.pipe(
    ofType(debugFlagActions.ActionTypes.SetDebugFlags),
    map((action: debugFlagActions.Set) => action.payload),
    tap(payload => this.debugFlagsStorage.saveToLocalStorage(payload))
  );
}
