import { debugFlagActions } from '../actions';
import { DebugFlagSettings } from '../config';

/**
 * Interface to the part of the Store containing DebugFlagsState
 * and other information related to DebugFlagsData.
 */
export interface State {
  settings: DebugFlagSettings;
  isLoaded: boolean;
}

export const INIT_STATE: State = { settings: null, isLoaded:false};

export function debugFlagsReducer(state = INIT_STATE, action: debugFlagActions.All): State {
  switch (action.type) {
    case debugFlagActions.ActionTypes.LoadDebugFlagsSuccess:
    case debugFlagActions.ActionTypes.SetDebugFlags:
      return { ...state, settings: action.payload, isLoaded:true };
    case debugFlagActions.ActionTypes.LoadDebugFlags: {
      return state;
    }

    default:
      return state;
  }
}
