import { createFeatureSelector, createSelector } from '@ngrx/store';
import { fromDebugFlags } from '../reducers';

export const getDebugFlagsState = createFeatureSelector<fromDebugFlags.State>('debugFlags');

/**
 * Selector to return the current settings for the Feature Flags
 */
export const getDebugFlagSettings = createSelector(getDebugFlagsState, state => state.settings);

/**
 * Selector to return the the Feature Flags are loaded
 */
export const getDebugFlagsLoaded = createSelector(getDebugFlagsState, state => state.isLoaded);
