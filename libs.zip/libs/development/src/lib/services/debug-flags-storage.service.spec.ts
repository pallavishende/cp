import { TestBed, inject } from '@angular/core/testing';
import { DebugFlagsStorageService } from './debug-flags-storage.service';

describe('DebugFlagsStorageService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DebugFlagsStorageService]
    });
  });

  it('should be created', inject(
    [DebugFlagsStorageService],
    (service: DebugFlagsStorageService) => {
      expect(service).toBeTruthy();
    }
  ));
});
