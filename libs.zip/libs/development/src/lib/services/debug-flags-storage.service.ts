import { Injectable } from '@angular/core';

import * as fromConfig from '../config';

const DEBUG_FLAGS_LOCAL_STORAGE_KEY = 'DEBUG_FLAGS_LOCAL_STORAGE_KEY';

@Injectable()
export class DebugFlagsStorageService {
  constructor() {}

  saveToLocalStorage(settings: fromConfig.DebugFlagSettings) {
    try {
      localStorage.setItem(DEBUG_FLAGS_LOCAL_STORAGE_KEY, JSON.stringify(settings));
    } catch (error) {
      // ignore
    }
    return;
  }

  clearLocalStorage() {
    localStorage.removeItem(DEBUG_FLAGS_LOCAL_STORAGE_KEY);
  }

  getFromLocalStorage(): fromConfig.DebugFlagSettings {
    try {
      const settingsJson = localStorage.getItem(DEBUG_FLAGS_LOCAL_STORAGE_KEY);
      return settingsJson ? JSON.parse(settingsJson) : {};
    } catch (error) {
      // ignore
    }
    return {};
  }
}
