import { map, filter, distinctUntilChanged } from 'rxjs/operators';
import { Inject, Injectable } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import * as fromConfig from '../config';

import { fromDebugFlags } from '../reducers';
import { getDebugFlagSettings } from '../selectors/debug-flag.selectors';

import { uniq, flattenDeep } from 'lodash';

export interface DebugFlagsServiceInterface {
  flags: fromConfig.DebugFlag[];
  hasDebugFlag(flagName: string): boolean;
  hasDebugFlagAsync(flagName: string): Observable<boolean>;
  getDebugFlagMetadata(flagName: string): boolean | any;
  getDebugFlagMetadataAsync(flagName: string): Observable<boolean | any>;
}

@Injectable()
export class DebugFlagsService implements DebugFlagsServiceInterface {
  private debugFlagSettings: fromConfig.DebugFlagSettings;
  private debugFlagSettings$: Observable<fromConfig.DebugFlagSettings>;

  constructor(
    private store: Store<fromDebugFlags.State>,
    @Inject(fromConfig.DebugFlagList) private debugFlagList: fromConfig.DebugFlag[]
  ) {
    this.debugFlagSettings$ = this.store.pipe(select(getDebugFlagSettings));
    this.debugFlagSettings$.pipe(distinctUntilChanged()).subscribe(settings => {
      if (settings != null) {
        this.debugFlagSettings = settings;
        this.flags
          .filter(flag => !!flag.onChange)
          .forEach(flag => {
            flag.onChange(!!this.debugFlagSettings[flag.name], this.debugFlagSettings[flag.name]);
          });
      }
    });
  }

  get flags(): fromConfig.DebugFlag[] {
    return uniq(flattenDeep(this.debugFlagList || []));
  }

  get settings(): fromConfig.DebugFlagSettings {
    return this.debugFlagSettings;
  }

  hasDebugFlag(flagName: string): boolean {
    return this.debugFlagSettings && !!this.debugFlagSettings[flagName];
  }

  getDebugFlagMetadata(flagName: string): boolean | any {
    return this.debugFlagSettings[flagName];
  }

  hasDebugFlagAsync(flagName: string): Observable<boolean> {
    return this.debugFlagSettings$.pipe(
      filter(settings => !!settings),
      map(settings => !!settings[flagName])
    );
  }

  getDebugFlagMetadataAsync(flagName: string): Observable<boolean | any> {
    return this.debugFlagSettings$.pipe(
      filter(settings => !!settings),
      map(settings => settings[flagName])
    );
  }
}
