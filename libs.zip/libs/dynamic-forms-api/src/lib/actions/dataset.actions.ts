import { Action } from '@ngrx/store';
import { Dataset, DatasetLookup } from '../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD = '[Dataset] Load';
export const LOAD_BY_ID = '[Dataset] Load By Id';
export const LOAD_SUCCESS = '[Dataset] Load Success';
export const LOAD_FAILED = '[Dataset] Load Failed';
export const LOAD_ALL_FOR_SCHEMA = '[Dataset] Load All For Schema';
export const LOAD_ALL_FOR_SCHEMA_SUCCESS = '[Dataset] Load All For Schema Success';
export const LOAD_ALL_FOR_SCHEMA_FAILED = '[Dataset] Load All For Schema Failed';
export const CREATE = '[Dataset] Create';
export const CREATE_SUCCESS = '[Dataset] Create Success';
export const CREATE_FAILED = '[Dataset] Create Failed';
export const UPDATE = '[Dataset] Update';
export const UPDATE_SUCCESS = '[Dataset] Update Success';
export const UPDATE_FAILED = '[Dataset] Update Failed';
export const DELETE = '[Dataset] Delete';
export const DELETE_SUCCESS = '[Dataset] Delete Success';
export const DELETE_FAILED = '[Dataset] Delete Failed';
export const LOAD_FOR_KEYS = '[Dataset] Load For Keys';
export const LOAD_FOR_KEYS_SUCCESS = '[Dataset] Load For Keys Success';
export const LOAD_FOR_KEYS_FAILED = '[Dataset] Load For Keys Failed';

export class Load implements Action {
  readonly type = LOAD;
  constructor(public payload: DatasetLookup) {}
}

export class LoadById implements Action {
  readonly type = LOAD_BY_ID;
  constructor(public payload: number) {}
}

export class LoadSuccess implements Action {
  readonly type = LOAD_SUCCESS;
  constructor(public payload: Dataset) {}
}

export class LoadAllForSchemaSuccess implements Action {
  readonly type = LOAD_ALL_FOR_SCHEMA_SUCCESS;
  constructor(public payload: { datasets: Dataset[]; schemaName: string }) {}
}

export class LoadFailed extends errorActions.Fail {
  readonly type = LOAD_FAILED;
}

export class LoadAllForSchemaFailed extends errorActions.Fail {
  readonly type = LOAD_ALL_FOR_SCHEMA_FAILED;
}

export class Update implements Action {
  readonly type = UPDATE;
  constructor(public payload: Dataset) {}
}
export class UpdateFailed extends errorActions.Fail {
  readonly type = UPDATE_FAILED;
}
export class UpdateSuccess implements Action {
  readonly type = UPDATE_SUCCESS;
  constructor(public payload: Dataset) {}
}

export class Create implements Action {
  readonly type = CREATE;
  constructor(public payload: Dataset) {}
}
export class CreateFailed extends errorActions.Fail {
  readonly type = CREATE_FAILED;
}
export class CreateSuccess implements Action {
  readonly type = CREATE_SUCCESS;
  constructor(public payload: Dataset) {}
}
export class Delete implements Action {
  readonly type = DELETE;
  constructor(public payload: number) {}
}
export class DeleteFailed extends errorActions.Fail {
  readonly type = DELETE_FAILED;
}
export class DeleteSuccess implements Action {
  readonly type = DELETE_SUCCESS;
}

export class LoadForKeys implements Action {
  readonly type = LOAD_FOR_KEYS;
  constructor(public payload: DatasetLookup) {}
}
export class LoadForKeysSuccess implements Action {
  readonly type = LOAD_FOR_KEYS_SUCCESS;
  constructor(public payload: Dataset[]) {}
}
export class LoadForKeysFailed extends errorActions.Fail {
  readonly type = LOAD_FOR_KEYS_FAILED;
}

export type All =
  | Load
  | LoadById
  | LoadSuccess
  | LoadFailed
  | LoadAllForSchemaSuccess
  | LoadAllForSchemaFailed
  | Create
  | CreateSuccess
  | CreateFailed
  | Update
  | UpdateSuccess
  | UpdateFailed
  | Delete
  | DeleteSuccess
  | DeleteFailed
  | LoadForKeys
  | LoadForKeysSuccess
  | LoadForKeysFailed;
