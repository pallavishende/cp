import { Action } from '@ngrx/store';
import { FieldSchemaResponse } from '../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD = '[FieldSchemaResponse] Load';
export const LOAD_WITH_NESTED_SCHEMAS = '[FieldSchemaResponse] Load With Nested Schemas';
export const LOAD_SUCCESS = '[FieldSchemaResponse] Load Success';
export const LOAD_FAILED = '[FieldSchemaResponse] Load Failed';
export const UPDATE = '[FieldSchemaResponse] Update';
export const UPDATE_SUCCESS = '[FieldSchemaResponse] Update Success';
export const UPDATE_FAILED = '[FieldSchemaResponse] Update Failed';
export const CREATE = '[FieldSchemaResponse] Create';
export const CREATE_SUCCESS = '[FieldSchemaResponse] Create Success';
export const CREATE_FAILED = '[FieldSchemaResponse] Create Failed';
export const DELETE = '[FieldSchemaResponse] Delete';
export const DELETE_SUCCESS = '[FieldSchemaResponse] Delete Success';
export const DELETE_FAILED = '[FieldSchemaResponse] Delete Failed';

export class Load implements Action {
  readonly type = LOAD;
  constructor(public payload: string[]) {}
}

export class LoadWithNestedSchemas implements Action {
  readonly type = LOAD_WITH_NESTED_SCHEMAS;
  constructor(public payload: string[]) {}
}

export class LoadSuccess implements Action {
  readonly type = LOAD_SUCCESS;
  constructor(public payload: FieldSchemaResponse[]) {}
}

export class LoadFailed extends errorActions.Fail {
  readonly type = LOAD_FAILED;
}

export class Update implements Action {
  readonly type = UPDATE;
  constructor(public payload: FieldSchemaResponse) {}
}

export class UpdateSuccess implements Action {
  readonly type = UPDATE_SUCCESS;
  constructor(public payload: FieldSchemaResponse) {}
}

export class UpdateFailed extends errorActions.Fail {
  readonly type = UPDATE_FAILED;
}

export class Create implements Action {
  readonly type = CREATE;
  constructor(public payload: FieldSchemaResponse) {}
}

export class CreateSuccess implements Action {
  readonly type = CREATE_SUCCESS;
  constructor(public payload: FieldSchemaResponse) {}
}

export class CreateFailed extends errorActions.Fail {
  readonly type = CREATE_FAILED;
}

export class Delete implements Action {
  readonly type = DELETE;
  constructor(public payload: string) {}
}

export class DeleteSuccess implements Action {
  readonly type = DELETE_SUCCESS;
  constructor(public payload = null) {}
}

export class DeleteFailed extends errorActions.Fail {
  readonly type = DELETE_FAILED;
}

export type All =
  | Load
  | LoadSuccess
  | LoadWithNestedSchemas
  | LoadFailed
  | Update
  | UpdateSuccess
  | UpdateFailed
  | Create
  | CreateSuccess
  | CreateFailed
  | Delete
  | DeleteFailed
  | DeleteSuccess;
