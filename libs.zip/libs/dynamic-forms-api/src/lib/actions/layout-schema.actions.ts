import { Action } from '@ngrx/store';
import { LayoutSchemaResponse } from '../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD = '[LayoutSchemaResponse] Load';
export const LOAD_WITH_FIELDS = '[LayoutSchemaResponse] Load With Fields';
export const LOAD_SUCCESS = '[LayoutSchemaResponse] Load Success';
export const LOAD_FAILED = '[LayoutSchemaResponse] Load Failed';
export const UPDATE = '[LayoutSchemaResponse] Update';
export const UPDATE_SUCCESS = '[LayoutSchemaResponse] Update Success';
export const UPDATE_FAILED = '[LayoutSchemaResponse] Update Failed';
export const CREATE = '[LayoutSchemaResponse] Create';
export const CREATE_SUCCESS = '[LayoutSchemaResponse] Create Success';
export const CREATE_FAILED = '[LayoutSchemaResponse] Create Failed';
export const DELETE = '[LayoutSchemaResponse] Delete';
export const DELETE_SUCCESS = '[LayoutSchemaResponse] Delete Success';
export const DELETE_FAILED = '[LayoutSchemaResponse] Delete Failed';

export class Load implements Action {
  readonly type = LOAD;
  constructor(public payload: string) {}
}

export class LoadWithFields implements Action {
  readonly type = LOAD_WITH_FIELDS;
  constructor(public payload: string[]) {}
}

export class LoadSuccess implements Action {
  readonly type = LOAD_SUCCESS;
  constructor(public payload: LayoutSchemaResponse) {}
}

export class LoadFailed extends errorActions.Fail {
  readonly type = LOAD_FAILED;
}

export class Update implements Action {
  readonly type = UPDATE;
  constructor(public payload: LayoutSchemaResponse) {}
}

export class UpdateSuccess implements Action {
  readonly type = UPDATE_SUCCESS;
  constructor(public payload: LayoutSchemaResponse) {}
}

export class UpdateFailed extends errorActions.Fail {
  readonly type = UPDATE_FAILED;
}

export class Create implements Action {
  readonly type = CREATE;
  constructor(public payload: LayoutSchemaResponse) {}
}

export class CreateSuccess implements Action {
  readonly type = CREATE_SUCCESS;
  constructor(public payload: LayoutSchemaResponse) {}
}

export class CreateFailed extends errorActions.Fail {
  readonly type = CREATE_FAILED;
}

export class Delete implements Action {
  readonly type = DELETE;
  constructor(public payload: number) {}
}

export class DeleteSuccess implements Action {
  readonly type = DELETE_SUCCESS;
  constructor(public payload = null) {}
}

export class DeleteFailed extends errorActions.Fail {
  readonly type = DELETE_FAILED;
}

export type All =
  | Load
  | LoadWithFields
  | LoadSuccess
  | LoadFailed
  | Update
  | UpdateSuccess
  | UpdateFailed
  | Create
  | CreateSuccess
  | CreateFailed
  | Delete
  | DeleteFailed
  | DeleteSuccess;
