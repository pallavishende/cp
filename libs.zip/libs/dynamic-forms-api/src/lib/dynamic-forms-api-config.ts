import { InjectionToken, Provider } from '@angular/core';
import { CustomDatasetProvider, SchemaOverride } from './models';
export const DYNAMIC_FORMS_API_OPTIONS = new InjectionToken<boolean>('DynamicFormsApiOptions');

export interface DynamicFormsApiOptions {
  useLocalStorage?: boolean;
  customDatasetProviders?: CustomDatasetProvider[];
  customDatasetServices?: Provider[];
  schemaOverrides?: SchemaOverride;
}
