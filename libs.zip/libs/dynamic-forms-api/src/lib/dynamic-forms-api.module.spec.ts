import { async, TestBed } from '@angular/core/testing';
import { DynamicFormsApiModule } from './dynamic-forms-api.module';

describe('DynamicFormsApiModule', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [DynamicFormsApiModule]
    }).compileComponents();
  }));

  it('should create', () => {
    expect(DynamicFormsApiModule).toBeDefined();
  });
});
