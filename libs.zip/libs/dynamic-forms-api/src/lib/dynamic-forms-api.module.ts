import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders } from '@angular/core';
import { InterceptorsModule } from '@content-platform/interceptors';
import { LoggingModule } from '@content-platform/logging';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { effects } from './effects';
import { DynamicFormApiReducers } from './reducers';
import {
  ApiParams,
  resources,
  CustomDatasetProviderRegistry,
  CUSTOM_DATASET_PROVIDERS,
  DatasetRetriever,
  SchemaOverrideService,
  CUSTOM_DATASET_SEARCH_PROVIDERS,
  SearchDatasetProviderFactory
} from './services';
import {
  LayoutSchemaGuard,
  FieldSchemaGuard,
  DatasetGuard,
  LayoutSchemaWithFieldsGuard
} from './guards';
import { CustomDatasetProvider } from './models';
import { DynamicFormsApiOptions, DYNAMIC_FORMS_API_OPTIONS } from './dynamic-forms-api-config';
import { SortByRelevancePipe } from '@content-platform/pipes';

@NgModule({
  imports: [
    CommonModule,
    InterceptorsModule,
    StoreModule.forFeature('dynamicFormApi', DynamicFormApiReducers),
    EffectsModule.forFeature(effects),
    LoggingModule
  ],
  providers: [
    ApiParams,
    ...resources,
    LayoutSchemaGuard,
    FieldSchemaGuard,
    DatasetGuard,
    LayoutSchemaWithFieldsGuard,
    CustomDatasetProviderRegistry,
    {
      provide: CUSTOM_DATASET_PROVIDERS,
      multi: true,
      useValue: []
    },
    DatasetRetriever,
    SchemaOverrideService,
    SortByRelevancePipe
  ]
})
export class DynamicFormsApiModule {
  static withExtraDatasetProviders(
    customDatasetProviders: CustomDatasetProvider[] = []
  ): ModuleWithProviders {
    return {
      ngModule: DynamicFormsApiModule,
      providers: [
        {
          provide: CUSTOM_DATASET_PROVIDERS,
          multi: true,
          useValue: customDatasetProviders || []
        }
      ]
    };
  }

  static forRoot(options: DynamicFormsApiOptions): ModuleWithProviders {
    return {
      ngModule: DynamicFormsApiModule,
      providers: [
        { provide: DYNAMIC_FORMS_API_OPTIONS, useValue: options },
        {
          provide: CUSTOM_DATASET_PROVIDERS,
          multi: true,
          useValue: options.customDatasetProviders || []
        },
        {
          provide: CUSTOM_DATASET_SEARCH_PROVIDERS,
          useFactory: SearchDatasetProviderFactory,
          deps: [...(options.customDatasetServices || [])]
        }
      ]
    };
  }
}
