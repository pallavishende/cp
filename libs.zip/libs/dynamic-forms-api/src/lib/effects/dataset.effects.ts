import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Observable } from 'rxjs';
import { catchError, map, mergeMap, switchMap } from 'rxjs/operators';
import { datasetActions } from '../actions';
import { Dataset } from '../models';
import { DatasetResource } from '../services';

/**
 * The schema effects imported in {@link DatasetApiModule }
 *
 */
@Injectable()
export class DatasetEffects {
  constructor(private datasetActions$: Actions, private api: DatasetResource) {}

  /**
   * Loads specific dataset
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when dataset is retrieved
   */
  @Effect()
  load$: Observable<Action> = this.datasetActions$.pipe(
    ofType(datasetActions.LOAD),
    map((action: datasetActions.Load) => action.payload),
    mergeMap(({ contentType, fieldKey }) =>
      this.api.get(contentType, fieldKey as string).pipe(
        map((schema: Dataset) => new datasetActions.LoadSuccess(schema)),
        catchError(error => [
          new datasetActions.LoadFailed({
            error: error,
            message: `Unable to load ${contentType} ${fieldKey} dataset`
          })
        ])
      )
    )
  );

  /**
   * Loads dataset for given keys
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when dataset is retrieved
   */
  @Effect()
  loadForKeys$: Observable<Action> = this.datasetActions$.pipe(
    ofType(datasetActions.LOAD_FOR_KEYS),
    map((action: datasetActions.LoadForKeys) => action.payload),
    mergeMap(({ contentType, fieldKey }) =>
      this.api.getAll(contentType, fieldKey as string).pipe(
        map((dataset: Dataset[]) => new datasetActions.LoadForKeysSuccess(dataset)),
        catchError(error => [
          new datasetActions.LoadForKeysFailed({
            error: error,
            message: `Unable to load ${contentType} ${fieldKey} dataset`
          })
        ])
      )
    )
  );

  /**
   * Loads specific dataset
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when dataset is retrieved
   */
  @Effect()
  loadById$: Observable<Action> = this.datasetActions$.pipe(
    ofType(datasetActions.LOAD_BY_ID),
    map((action: datasetActions.LoadById) => action.payload),
    mergeMap(id =>
      this.api.getById(id).pipe(
        map((schema: Dataset) => new datasetActions.LoadSuccess(schema)),
        catchError(error => [
          new datasetActions.LoadFailed({
            error: error,
            message: `Unable to load dataset with id ${id}`
          })
        ])
      )
    )
  );

  /**
   * Updates the dataset and triggers a UpdateSuccess action.
   *
   * @returns { Observable<Action> } Observable with UpdateSuccess action with the updated dataset
   */
  @Effect()
  update$: Observable<Action> = this.datasetActions$.pipe(
    ofType(datasetActions.UPDATE),
    map((action: datasetActions.Update) => action.payload),
    switchMap((dataset: Dataset) =>
      this.api.update(dataset).pipe(
        switchMap(() => this.api.get(dataset.contentType, dataset.fieldKey)),
        map(updatedDataset => new datasetActions.UpdateSuccess(updatedDataset)),
        catchError(error => [
          new datasetActions.UpdateFailed({
            error: error,
            message: `Unable to update ${dataset.contentType} ${dataset.fieldKey} dataset`
          })
        ])
      )
    )
  );

  /**
   * Create new dataset and CreateSuccess action.
   *
   * @returns { Observable<Action> } Observable with CreateSuccess action with the updated dataset
   */
  @Effect()
  create$: Observable<Action> = this.datasetActions$.pipe(
    ofType(datasetActions.CREATE),
    map((action: datasetActions.Create) => action.payload),
    switchMap((dataset: Dataset) =>
      this.api.create(dataset).pipe(
        switchMap(() => this.api.get(dataset.contentType, dataset.fieldKey)),
        map(newDataset => new datasetActions.CreateSuccess(newDataset)),
        catchError(error => [
          new datasetActions.CreateFailed({
            error: error,
            message: `Unable to create ${dataset.contentType} ${dataset.fieldKey} dataset`
          })
        ])
      )
    )
  );

  /**
   * Delete dataset.
   *
   * @returns { Observable<Action> } Observable with DeleteSuccess action
   */
  @Effect()
  delete$: Observable<Action> = this.datasetActions$.pipe(
    ofType(datasetActions.DELETE),
    map((action: datasetActions.Delete) => action.payload),
    switchMap((id: number) =>
      this.api.delete(id).pipe(
        map(() => new datasetActions.DeleteSuccess()),
        catchError(error => [
          new datasetActions.DeleteFailed({
            error: error,
            message: `Unable to delete dataset with id ${id}`
          })
        ])
      )
    )
  );
}
