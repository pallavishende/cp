import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { map, catchError, mergeMap, withLatestFrom, switchMap } from 'rxjs/operators';
import { fieldSchemaActions, layoutSchemaActions } from '../actions';
import { FieldSchemaResource, SchemaHelper } from '../services';
import { FieldSchemaResponse } from '../models';
import { Store, Action, select } from '@ngrx/store';
import { fieldSchemaSelectors } from '../selectors';
import { DynamicFormsApiState } from '../reducers';
import { authSelectors } from '@content-platform/auth';

@Injectable()
export class FieldSchemaEffects {
  constructor(
    private schemaActions$: Actions,
    private api: FieldSchemaResource,
    private store: Store<DynamicFormsApiState>
  ) {}

  /**
   * Loads all the availabe schemas only when a user is logged in and triggers a LoadSuccess action.
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when all schemas are retrieved
   */
  @Effect()
  load$: Observable<Action> = this.schemaActions$.pipe(
    ofType(fieldSchemaActions.LOAD),
    map((action: fieldSchemaActions.Load) => action.payload),
    mergeMap((fieldKeys: string[]) =>
      this.api.get(fieldKeys).pipe(
        map(
          (fieldSchemas: FieldSchemaResponse[]) => new fieldSchemaActions.LoadSuccess(fieldSchemas)
        ),
        catchError(error => [
          new fieldSchemaActions.LoadFailed({
            error: error,
            message: `Unable to load field schema`
          })
        ])
      )
    )
  );

  /**
   * Loads all the availabe field schemas and triggers the datasets loads.
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when all schemas are retrieved, and
   *    the dataset actions
   */
  @Effect()
  loadWithNestedSchemas$: Observable<Action> = this.schemaActions$.pipe(
    ofType(fieldSchemaActions.LOAD_WITH_NESTED_SCHEMAS),
    map((action: fieldSchemaActions.Load) => action.payload),
    withLatestFrom(this.store.pipe(select(fieldSchemaSelectors.getSchemaEntities))),
    mergeMap(([fieldKeys, schemaEntities]) => {
      fieldKeys = fieldKeys.filter(key => !schemaEntities[key]);
      return this.api.get(fieldKeys).pipe(
        mergeMap((fieldSchemas: FieldSchemaResponse[]) => {
          const actions = [];
          actions.push(new fieldSchemaActions.LoadSuccess(fieldSchemas));
          const nestedFieldSchemas = SchemaHelper.getAllNestedSchemaFields(
            fieldSchemas.map(resp => resp.fieldSchema)
          );
          if (nestedFieldSchemas.length > 0) {
            actions.push(new layoutSchemaActions.LoadWithFields(nestedFieldSchemas));
          }
          return actions;
        }),
        catchError(error => [
          new fieldSchemaActions.LoadFailed({
            error: error,
            message: `Unable to load field schema`
          })
        ])
      );
    })
  );

  /**
   * Update new schema and CreateSuccess action.
   *
   * @returns { Observable<Action> } Observable with CreateSuccess action with the updated schema
   */
  @Effect()
  update$: Observable<Action> = this.schemaActions$.pipe(
    ofType(fieldSchemaActions.UPDATE),
    map((action: fieldSchemaActions.Update) => action.payload),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([schema, userId]) =>
      this.api.update({ ...schema, updatedBy: userId }).pipe(
        switchMap(() => this.api.get(schema.fieldKey)),
        map(newSchema => new fieldSchemaActions.UpdateSuccess(newSchema[0])),
        catchError(error => [
          new fieldSchemaActions.UpdateFailed({
            error: error,
            message: `Unable to update ${schema.fieldKey} schema`
          })
        ])
      )
    )
  );

  /**
   * Create new schema and CreateSuccess action.
   *
   * @returns { Observable<Action> } Observable with CreateSuccess action with the updated schema
   */
  @Effect()
  create$: Observable<Action> = this.schemaActions$.pipe(
    ofType(fieldSchemaActions.CREATE),
    map((action: fieldSchemaActions.Create) => action.payload),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([schema, userId]) =>
      this.api.create({ ...schema, createdBy: userId }).pipe(
        switchMap(() => this.api.get(schema.fieldKey)),
        map(newSchema => new fieldSchemaActions.CreateSuccess(newSchema[0])),
        catchError(error => [
          new fieldSchemaActions.CreateFailed({
            error: error,
            message: `Unable to create ${schema.fieldKey} schema`
          })
        ])
      )
    )
  );

  /**
   * Delete schema.
   *
   * @returns { Observable<Action> } Observable with DeleteSuccess action
   */
  @Effect()
  delete$: Observable<Action> = this.schemaActions$.pipe(
    ofType(fieldSchemaActions.DELETE),
    map((action: fieldSchemaActions.Delete) => action.payload),
    switchMap((id: string) =>
      this.api.delete(id).pipe(
        map(() => new fieldSchemaActions.DeleteSuccess()),
        catchError(error => [
          new fieldSchemaActions.DeleteFailed({
            error: error,
            message: `Unable to delete schema with id ${id}`
          })
        ])
      )
    )
  );
}
