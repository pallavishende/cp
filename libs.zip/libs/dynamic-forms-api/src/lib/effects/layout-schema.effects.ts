import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action, Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map, switchMap, catchError, withLatestFrom, mergeMap } from 'rxjs/operators';
import { layoutSchemaActions, fieldSchemaActions } from '../actions';
import { LayoutSchemaResource, SchemaHelper } from '../services';
import { LayoutSchemaResponse } from '../models';
import { DynamicFormsApiState } from '../reducers';
import { authSelectors } from '@content-platform/auth';
import { uniq } from 'lodash';
import { layoutSchemaSelectors } from '../selectors';

@Injectable()
export class LayoutSchemaEffects {
  constructor(
    private schemaActions$: Actions,
    private api: LayoutSchemaResource,
    private store: Store<DynamicFormsApiState>
  ) {}

  /**
   *
   *  Loads all the availabe schemas only when a user is logged in and triggers a LoadSuccess action.
   * @returns { Observable<Action> } Observable with LoadSuccess action when all schemas are retrieved
   *
   */

  @Effect()
  load$: Observable<any> = this.schemaActions$.pipe(
    ofType(layoutSchemaActions.LOAD),
    map((action: layoutSchemaActions.Load) => action.payload),
    switchMap(contentType => {
      return this.api.get(contentType).pipe(
        switchMap((schema: LayoutSchemaResponse[]) => {
          const actions = [];
          schema.forEach(layoutResponse => {
            actions.push(new layoutSchemaActions.LoadSuccess(layoutResponse));
          });
          return actions;
        }),
        catchError(error => [
          new layoutSchemaActions.LoadFailed({
            error: error,
            message: `Unable to load ${contentType} layout schema`
          })
        ])
      );
    })
  );

  @Effect()
  loadWithFields$: Observable<any> = this.schemaActions$.pipe(
    ofType(layoutSchemaActions.LOAD_WITH_FIELDS),
    map((action: layoutSchemaActions.LoadWithFields) => action.payload),
    withLatestFrom(this.store.pipe(select(layoutSchemaSelectors.getSchemaEntities))),
    mergeMap(([contentTypes, layoutSchemaEntities]) => {
      contentTypes = contentTypes.filter(contentType => !layoutSchemaEntities[contentType]);
      return this.api.get(contentTypes).pipe(
        mergeMap((schema: LayoutSchemaResponse[]) => {
          const actions = [];
          let schemaFields = [];
          schema.forEach(layoutResponse => {
            const fields = SchemaHelper.getAllLayoutSchemaFields(layoutResponse.layoutSchema);
            schemaFields = [...schemaFields, ...fields];
            actions.push(new layoutSchemaActions.LoadSuccess(layoutResponse));
          });
          actions.push(new fieldSchemaActions.LoadWithNestedSchemas(uniq(schemaFields)));
          return actions;
        }),
        catchError(error => [
          new layoutSchemaActions.LoadFailed({
            error: error,
            message: `Unable to load ${contentTypes.join(',')} layout schema`
          })
        ])
      );
    })
  );

  /**
   * Update new schema and CreateSuccess action.
   *
   * @returns { Observable<Action> } Observable with CreateSuccess action with the updated schema
   */
  @Effect()
  update$: Observable<Action> = this.schemaActions$.pipe(
    ofType(layoutSchemaActions.UPDATE),
    map((action: layoutSchemaActions.Update) => action.payload),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([schema, userId]) =>
      this.api.update({ ...schema, updatedBy: userId }, schema.contentType).pipe(
        switchMap(() => this.api.get(schema.contentType)),
        map(newSchema => new layoutSchemaActions.UpdateSuccess(newSchema[0])),
        catchError(error => [
          new layoutSchemaActions.UpdateFailed({
            error: error,
            message: `Unable to update ${schema.contentType} schema`
          })
        ])
      )
    )
  );

  /**
   * Create new schema and CreateSuccess action.
   *
   * @returns { Observable<Action> } Observable with CreateSuccess action with the updated schema
   */
  @Effect()
  create$: Observable<Action> = this.schemaActions$.pipe(
    ofType(layoutSchemaActions.CREATE),
    map((action: layoutSchemaActions.Create) => action.payload),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([schema, userId]) =>
      this.api.create({ ...schema, createdBy: userId }, schema.contentType).pipe(
        switchMap(() => this.api.get(schema.contentType)),
        map(newSchema => new layoutSchemaActions.CreateSuccess(newSchema[0])),
        catchError(error => [
          new layoutSchemaActions.CreateFailed({
            error: error,
            message: `Unable to create ${schema.contentType} schema`
          })
        ])
      )
    )
  );

  /**
   * Delete schema.
   *
   * @returns { Observable<Action> } Observable with DeleteSuccess action
   */
  @Effect()
  delete$: Observable<Action> = this.schemaActions$.pipe(
    ofType(layoutSchemaActions.DELETE),
    map((action: layoutSchemaActions.Delete) => action.payload),
    switchMap((id: number) =>
      this.api.delete(id).pipe(
        map(() => new layoutSchemaActions.DeleteSuccess()),
        catchError(error => [
          new layoutSchemaActions.DeleteFailed({
            error: error,
            message: `Unable to delete schema with id ${id}`
          })
        ])
      )
    )
  );
}
