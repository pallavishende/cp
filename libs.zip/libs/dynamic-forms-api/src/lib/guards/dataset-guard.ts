import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot } from '@angular/router';

import { Store, select } from '@ngrx/store';
import { Observable, of } from 'rxjs';

import { filter, withLatestFrom, catchError, map } from 'rxjs/operators';

import { fromFieldSchema } from '../reducers';
import { datasetSelectors } from '../selectors';
import { datasetActions } from '../actions';

import { CustomDatasetProviderRegistry } from '../services/custom-dataset-provider-registry';

const SCHEMA_GUARD_CONTENT_DATA_PROPERTY = 'contentType';
const SCHEMA_GUARD_KEY_DATA_PROPERTY = 'datasetKeys';

/**
 * A Guard that actives a route based on if a schema is accessible
 * Use the data property of the route to define the required schema content type
 * https://stackoverflow.com/a/42721468
 *
 * @example
 *  const routes: Routes = [{
      path: '',
      component: SomeComponent,
      data: {
        schemaContentType: 'someContentType',
        datasetKeys: [
          'key1',
          'key2'
        ]
      },
      canActivate: [SchemaGuard]
 *  }];
 * @export
 * @class SchemaGuard
 * @implements {CanActivate}
 */
@Injectable()
export class DatasetGuard implements CanActivate {
  constructor(
    private store: Store<fromFieldSchema.State>,
    private customDatasets: CustomDatasetProviderRegistry
  ) {}

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    const contentType =
      route.data[SCHEMA_GUARD_CONTENT_DATA_PROPERTY] ||
      route.params[SCHEMA_GUARD_CONTENT_DATA_PROPERTY];
    const fieldKeys = route.data[SCHEMA_GUARD_KEY_DATA_PROPERTY] as string[];

    return this.checkStore(contentType, fieldKeys).pipe(catchError(() => of(false)));
  }

  checkStore(contentType: string, fieldKey: string[]): Observable<boolean> {
    const customProvider = this.customDatasets.getProvider(contentType);
    if (customProvider) {
      return customProvider.checkStore(this.store, contentType, fieldKey);
    }
    let triedToLoad = false;
    return this.store.pipe(
      select(datasetSelectors.getDatasetLoading),
      withLatestFrom(
        this.store.pipe(
          select(datasetSelectors.getDatasetByContentTypeAndFieldKey(contentType, fieldKey[0]))
        )
      ),
      filter(([datasetLoading, dataset]) => {
        if (!dataset && !datasetLoading && !triedToLoad) {
          this.store.dispatch(new datasetActions.LoadForKeys({ contentType, fieldKey }));
          triedToLoad = true;
          return false;
        }
        return !datasetLoading;
      }),
      map(([, schema]) => {
        if (!!schema) {
          return true;
        }
        return false;
      })
    );
  }
}
