import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot } from '@angular/router';

import { Store, select } from '@ngrx/store';
import { Observable, of } from 'rxjs';

import { filter, withLatestFrom, catchError, switchMap } from 'rxjs/operators';

import { fromFieldSchema } from '../reducers';
import { fieldSchemaSelectors } from '../selectors';
import { fieldSchemaActions } from '../actions';

const SCHEMA_GUARD_KEY_DATA_PROPERTY = 'fieldKeys';
const SCHEMA_GUARD_KEY_PARAM_PROPERTY = 'fieldKey';

/**
 * A Guard that actives a route based on if a schema is accessible
 * Use the data property of the route to define the required schema content type
 * https://stackoverflow.com/a/42721468
 *
 * @example
 *  const routes: Routes = [{
      path: '',
      component: SomeComponent,
      data: {
        contentType: 'someContentType',
        fieldKeys: [
          'key1',
          'key2'
        ]
      },
      canActivate: [SchemaGuard]
 *  }];
 * @export
 * @class SchemaGuard
 * @implements {CanActivate}
 */
@Injectable()
export class FieldSchemaGuard implements CanActivate {
  constructor(private store: Store<fromFieldSchema.State>) {}

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    let fieldKey = route.data[SCHEMA_GUARD_KEY_DATA_PROPERTY] as string[];
    fieldKey = fieldKey || [route.params[SCHEMA_GUARD_KEY_PARAM_PROPERTY]];

    return this.checkStore(fieldKey).pipe(catchError(() => of(false)));
  }

  checkStore(fieldKeys: string[]): Observable<boolean> {
    return this.store.pipe(
      select(fieldSchemaSelectors.getFieldSchemasLoading),
      withLatestFrom(
        this.store.pipe(select(fieldSchemaSelectors.getFieldSchemaMapByFieldKeys(fieldKeys)))
      ),
      filter(([schemaLoading, schemaFieldMap], index) => {
        const missingFieldKeys = [];
        if (schemaFieldMap) {
          for (const key of fieldKeys) {
            if (!schemaFieldMap[key]) {
              missingFieldKeys.push(key);
            }
          }
          fieldKeys = missingFieldKeys as string[];
        }
        if (missingFieldKeys.length > 0 && !schemaLoading && index === 0) {
          this.store.dispatch(new fieldSchemaActions.Load(fieldKeys));
          return false;
        }
        return !schemaLoading;
      }),
      switchMap(([, schema]) => {
        if (!!schema) {
          return of(true);
        }
        return of(false);
      })
    );
  }
}
