import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot } from '@angular/router';

import { Store, select } from '@ngrx/store';
import { Observable, of } from 'rxjs';

import { filter, withLatestFrom, catchError, switchMap } from 'rxjs/operators';

import { fromLayoutSchema } from '../reducers';
import { layoutSchemaSelectors } from '../selectors';
import { layoutSchemaActions } from '../actions';

const SCHEMA_GUARD_DATA_PROPERTY = 'contentType';

/**
 * A Guard that actives a route based on if a schema is accessible
 * Use the data property of the route to define the required schema content type
 * https://stackoverflow.com/a/42721468
 *
 * @example
 *  const routes: Routes = [{
      path: '',
      component: SomeComponent,
      data: {
        contentType: 'someContentType'
      },
      canActivate: [SchemaGuard]
 *  }];
 * @export
 * @class SchemaGuard
 * @implements {CanActivate}
 */
@Injectable()
export class LayoutSchemaGuard implements CanActivate {
  constructor(private store: Store<fromLayoutSchema.State>) {}

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    const contentType =
      route.data[SCHEMA_GUARD_DATA_PROPERTY] || route.params[SCHEMA_GUARD_DATA_PROPERTY];

    return this.checkStore(contentType).pipe(catchError(() => of(false)));
  }

  checkStore(contentType: string): Observable<boolean> {
    return this.store.pipe(
      select(layoutSchemaSelectors.getLayoutSchemasLoading),
      withLatestFrom(
        this.store.pipe(select(layoutSchemaSelectors.getLayoutSchemaByContentType(contentType)))
      ),
      filter(([schemaLoading, schema], index) => {
        if (!schema && !schemaLoading && index === 0) {
          this.store.dispatch(new layoutSchemaActions.Load(contentType));
          return false;
        }
        return !schemaLoading;
      }),
      switchMap(([, schema]) => {
        if (!!schema) {
          return of(true);
        }
        return of(false);
      })
    );
  }

  /**
   * Waits until the datasets are loaded, returns true either way, as the schema would of been retrieved correctly.
   *
   * @param contentType
   * @returns Observable<true>

  checkDatasetStore(contentType: string): Observable<boolean> {
    return this.store.select(datasetSelectors.getDatasetLoading).pipe(
      withLatestFrom(this.store.select(datasetSelectors.getSchemaDatasetLoaded(contentType))),
      filter(([datasetLoading, datasetLoaded], index) => {
        if (!datasetLoaded && !datasetLoading && index === 0) {
          return false;
        }
        return !datasetLoading;
      }),
      map(() => true)
    );
  }
  */
}
