import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot } from '@angular/router';

import { Store, select } from '@ngrx/store';
import { Observable, of, forkJoin } from 'rxjs';

import { switchMap, map, take, filter } from 'rxjs/operators';

import { fromLayoutSchema } from '../reducers';
import { layoutSchemaSelectors } from '../selectors';
import { LayoutSchemaGuard } from './layout-schema-guard';
import { FieldSchemaGuard } from './field-schema-guard';
import { SchemaHelper } from '../services';
import { DatasetGuard } from './dataset-guard';

const SCHEMA_GUARD_DATA_PROPERTY = 'contentType';

@Injectable()
export class LayoutSchemaWithFieldsGuard implements CanActivate {
  constructor(
    private store: Store<fromLayoutSchema.State>,
    private layoutSchemaGuard: LayoutSchemaGuard,
    private fieldSchemaGuard: FieldSchemaGuard,
    private datasetGuard: DatasetGuard
  ) {}

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    const contentType =
      route.data[SCHEMA_GUARD_DATA_PROPERTY] || route.params[SCHEMA_GUARD_DATA_PROPERTY];

    return this.checkStore(contentType);
  }

  checkStore(contentType: string): Observable<boolean> {
    return this.loadAllSchemaData(contentType).pipe(
      switchMap(loaded => {
        if (loaded) {
          return this.loadDatasets(contentType);
        }
        return of(loaded);
      })
    );
  }

  loadLayoutSchemaWithFields(contentType: string): Observable<boolean> {
    return this.layoutSchemaGuard.checkStore(contentType).pipe(
      switchMap(() =>
        this.store.pipe(
          select(layoutSchemaSelectors.getLayoutSchemaFieldsByContentType(contentType))
        )
      ),
      filter(fields => !!fields),
      switchMap(fields => this.fieldSchemaGuard.checkStore(fields))
    );
  }

  loadAllSchemaData(contentType): Observable<boolean> {
    return this.loadLayoutSchemaWithFields(contentType).pipe(
      switchMap(loaded => {
        if (loaded) {
          return this.store.pipe(
            select(layoutSchemaSelectors.getLayoutSchemaSchemaFields(contentType))
          );
        }
        return of(null);
      }),
      switchMap(fieldSchemas => {
        if (fieldSchemas) {
          const nestedFieldSchemas = SchemaHelper.getAllNestedSchemaFields(fieldSchemas);
          if (nestedFieldSchemas.length > 0) {
            return forkJoin(
              nestedFieldSchemas.map(ct => this.loadAllSchemaData(ct).pipe(take(1)))
            ).pipe(
              map(gottenSchemas => gottenSchemas.every(val => val)),
              take(1)
            );
          }
          return of(true);
        }
        return of(false);
      })
    );
  }

  loadDatasets(contentType): Observable<boolean> {
    return this.store.pipe(
      select(layoutSchemaSelectors.getLayoutSchemaSchemaFields(contentType)),
      switchMap(fieldSchemas => {
        const datasetKeys = SchemaHelper.getAllDatasetFields(fieldSchemas);
        if (datasetKeys.length > 0) {
          return this.datasetGuard.checkStore(contentType, datasetKeys).pipe(map(() => true));
        }
        return of(true);
      })
    );
  }
}
