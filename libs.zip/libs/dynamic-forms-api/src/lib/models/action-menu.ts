import { HasDependencies } from './field-dependency';
export interface ActionMenuItem extends HasDependencies {
  title: string;
  key: string;
  value?: string | boolean | number;
  icon?: string;
  mode?: string[];
  disabled?: boolean;
}

export interface ActionMenuOptions {
  atRowIndex?: number;
  actions: ActionMenuItem[];
}
