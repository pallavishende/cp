import { Store, MemoizedSelector } from '@ngrx/store';
import { Observable } from 'rxjs';

import { DatasetOptions } from './dataset';

/**
 * Interface for getting data for drop downs from other sources
 *
 * @export
 * @interface CustomDatasetProvider
 */
export interface CustomDatasetProvider {
  /**
   * Override in subclass. This function returns true when this provider should be used for the given content type
   *
   * @param {string} contentType
   * @returns {boolean}
   * @memberof CustomDatasetProvider
   */
  useThisProvider(contentType: string): boolean;

  /**
   * Checks the store for the given datasets
   *
   * @param {string} store
   * @param {string} contentType
   * @param {string[]} fieldKey
   * @returns {Observable<boolean>}
   * @memberof CustomDatasetProvider
   */
  checkStore(store: Store<{}>, contentType: string, fieldKey: string[]): Observable<boolean>;

  /**
   * Get Selector for retrieving the given dataset
   *
   * @param {string} contentType
   * @param {string} fieldKey
   * @returns {MemoizedSelector<object, DatasetOptions[]>}
   * @memberof CustomDatasetProvider
   */
  selectDatasetOptions(
    contentType: string,
    fieldKey: string
  ): MemoizedSelector<object, DatasetOptions[]>;
}
