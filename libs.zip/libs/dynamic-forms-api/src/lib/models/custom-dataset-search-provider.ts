import { Observable } from 'rxjs';

import { DatasetOptions } from './dataset';

/**
 * Interface for getting data for drop downs from other sources
 *
 * @export
 * @interface CustomDatasetSearchProvider
 */
export interface CustomDatasetSearchProvider {
  /**
   * Override in subclass. This function returns true when this provider should be used for the given content type
   *
   * @param {string} contentType
   * @param {string} fieldKey
   * @returns {boolean}
   * @memberof CustomDatasetProvider
   */
  useThisProvider(contentType: string, fieldKey: string): boolean;

  /**
   * search for dropdown values
   *
   * @param {string} searchString
   * @returns {Observable<DatasetOptions[]>}
   * @memberof CustomDatasetSearchProvider
   */
  search(searchString: string): Observable<DatasetOptions[]>;
}
