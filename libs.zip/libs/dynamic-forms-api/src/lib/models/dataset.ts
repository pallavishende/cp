import { DatasetValue } from '@content-platform/application-api';

export type DatasetOptionsArray = Array<DatasetValue>;

export interface DatasetOptions {
  group?: string;
  values: DatasetOptionsArray;
}

export interface DatasetLookup {
  contentType: string;
  fieldKey: string | string[];
}

export interface Dataset extends DatasetLookup {
  id: number;
  value: DatasetOptions[];
  fieldKey: string;
  modifiedBy: string;
  submittedBy: string;
  submittedDate: string;
}

export type DatasetResponse = Dataset[];

export interface DatasetState {
  contentType: string;
  value: Array<Dataset>;
  fieldKey?: string[];
}
