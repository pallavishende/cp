export interface FieldDependency {
  action: string;
  field: string;
  value?: any;
  except?: boolean; // if "true" should disable all values except the ones provided in value array
  fieldInRoot?: boolean; // if the dependant field needs to be find in root
}

export interface HasDependencies {
  dependency?: FieldDependency | FieldDependency[];
}
