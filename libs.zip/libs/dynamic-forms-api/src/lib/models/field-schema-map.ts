import { FieldSchema } from './field-schema';

export interface FieldSchemaMap {
  [fieldKey: string]: FieldSchema;
}

export interface FieldSchemaMapByMode {
  [mode: string]: {
    [fieldKey: string]: FieldSchema;
  };
}

export interface FieldSchemaResponse {
  id: string;
  fieldKey: string;
  fieldSchema: FieldSchema;
  createdBy?: string;
  updatedBy?: string;
}

export interface FieldSchemaState {
  contentType: string;
  map: FieldSchemaMap;
}
