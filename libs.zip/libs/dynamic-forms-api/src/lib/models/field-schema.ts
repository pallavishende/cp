import { ValidatorSchema } from './validator-schema';
import { KeyValue } from './key-value';
import { HasDependencies } from './field-dependency';
import { SortValue } from './sort-value';

export interface FieldSchemaRequestParams {
  contentType: string;
  fieldKey: string | string[];
}

export interface FieldSchema extends HasDependencies {
  name: string;
  type: string;
  value?: string | any[];
  key?: string;
  validators?: ValidatorSchema[];
  default?: string | boolean;
  required?: boolean;
  multiSelect?: boolean;
  label?: string;
  placeholder?: string;
  description?: string;
  order?: number;
  options?: KeyValue[];
  fields?: FieldSchema[];
  schema?: string;
  columnWidth?: number;
  sort?: SortValue;
}
