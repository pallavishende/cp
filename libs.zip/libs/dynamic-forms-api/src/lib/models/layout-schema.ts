import { ActionMenuOptions } from './action-menu';
import { FileExplorerValidatorOptions } from './validator-schema';

export type LayoutType = 'row' | 'column' | 'group' | 'field' | 'layout' | 'framework';

export type LayoutMode = 'view' | 'edit' | 'create';

export interface LayoutSchemaOptions {
  id?: string;
  width?: number;
  autoWidth?: boolean;
  name?: string;
  readonly?: boolean;
  addable?: boolean;
  hidden?: boolean;
  hideIfEmpty?: boolean;
  removable?: boolean;
  collapsed?: boolean;
  hideRemoveAction?: { atRowIndex: number };
  showAddAction?: { atRowIndex: number };
  headerInfoFieldName?: string;
  actionsMenu?: ActionMenuOptions;
  panelActionDependantFields?: Array<string>;
  fileValidationOptions?: FileExplorerValidatorOptions;
  useFilenameFor?: { fileExtensions?: string[]; fieldName: string };
  hideBoxShadow?: boolean;
}

export interface LayoutSchema {
  id?: string;
  mode?: LayoutMode[];
  selector: string;
  type: LayoutType;
  options?: LayoutSchemaOptions;
  content?: LayoutSchema[];
}

export interface LayoutSchemaResponse {
  id: number;
  contentType: string;
  layoutSchema: LayoutSchema | LayoutSchema[];
  createdBy?: string;
  updatedBy?: string;
}
