import { FieldSchema } from './field-schema';
import { LayoutSchema } from './layout-schema';

export interface SchemaOverride {
  layout?: { [contentType: string]: { layoutSchema: LayoutSchema[]; contentType?: string } };
  field?: { [fieldKey: string]: { fieldSchema: FieldSchema; fieldKey?: string } };
}
