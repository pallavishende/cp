export interface SortValue {
  sortBy: string;
  sortOrder: string;
}
