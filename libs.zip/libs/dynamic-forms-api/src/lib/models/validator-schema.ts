export interface ValidatorSchema {
  required?: boolean;
  minLength?: number;
  maxLength?: number;
  pattern?: string;
  exactLength?: number;
}

/**
 * Categorize files based on extesions. For example mov, mxf, mp4 can be categorized as video
 * In File Explorer component same category extensions appear as group
 */
export interface FileCategoryLookup {
  extensions: string[];
  category: string;
}

/**
 * Defines number of files allowed per extension.
 * When the count exceed larger than the defined, error message is shown
 */
export interface FileCountLookup {
  extensions: string[];
  maxLimit: number;
  errorMessageToShow?: string;
}

/**
 * This matches the two values for the same value and matches by the lookupFieldName
 *
 * @export
 * @interface FileUniqueValue
 */
export interface FileUniqueValue {
  lookupFieldNames: string;
  values: string[];
  errorMessageToShow?: string;
}

/**
 * Defines various file validator options. Options includes file extensions to support
 * number of files allowed. max file size allowed and file category list.
 */
export interface FileExplorerValidatorOptions {
  fileExtensions?: string[];
  useFileCategorySelector?: boolean;
  fileCategoryList?: FileCategoryLookup[];
  maxFileSizeBytes?: number;
  maxNumberOfFiles?: number;
  maxTotalFilesSizeInBytes?: number;
  fileLimit?: FileCountLookup[];
  categoriesToHideForOtherTypes?: string[];
  fileUniqueValue?: FileUniqueValue;
}
