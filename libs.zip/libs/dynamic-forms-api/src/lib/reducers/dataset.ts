import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { Dataset, DatasetLookup } from '../models';
import { datasetActions } from '../actions';

export function getDatasetId(item: DatasetLookup) {
  return item.contentType + '_' + item.fieldKey;
}

export function getDatasetLookupFromId(datasetId: string): DatasetLookup {
  const [contentType, fieldKey] = datasetId.split('_');
  return { contentType, fieldKey };
}

export const datasetAdapter = createEntityAdapter<Dataset>({
  selectId: getDatasetId,
  sortComparer: false
});

export interface State extends EntityState<Dataset> {
  loading: number;
  schemaDatasetsLoaded: string[];
}

export const INIT_STATE: State = datasetAdapter.getInitialState({
  loading: 0,
  schemaDatasetsLoaded: []
});

const increaseLoading = (loading: number): number => loading + 1;
const decreaseLoading = (loading: number): number => (loading <= 0 ? 0 : loading - 1);

export function reducer(state = INIT_STATE, action: datasetActions.All): State {
  switch (action.type) {
    case datasetActions.LOAD_FOR_KEYS:
    case datasetActions.LOAD: {
      return {
        ...state,
        loading: increaseLoading(state.loading)
      };
    }
    case datasetActions.LOAD_SUCCESS: {
      return {
        ...datasetAdapter.upsertOne(action.payload, state),
        loading: state.loading - 1
      };
    }
    case datasetActions.UPDATE_SUCCESS: {
      return {
        ...datasetAdapter.upsertOne(action.payload, state)
      };
    }
    case datasetActions.LOAD_FOR_KEYS_FAILED:
    case datasetActions.LOAD_ALL_FOR_SCHEMA_FAILED:
    case datasetActions.LOAD_FAILED: {
      return { ...state, loading: decreaseLoading(state.loading) };
    }
    case datasetActions.LOAD_ALL_FOR_SCHEMA_SUCCESS: {
      const schemaDatasetsLoaded = [...state.schemaDatasetsLoaded, action.payload.schemaName];
      return {
        ...datasetAdapter.upsertMany(action.payload.datasets, state),
        schemaDatasetsLoaded,
        loading: decreaseLoading(state.loading)
      };
    }
    case datasetActions.LOAD_FOR_KEYS_SUCCESS: {
      return {
        ...datasetAdapter.upsertMany(action.payload, state),
        loading: decreaseLoading(state.loading),
        schemaDatasetsLoaded: [...action.payload.map(data => data.fieldKey)]
      };
    }
    default: {
      return state;
    }
  }
}

export const getDatasetLoading = (state: State) => state.loading > 0;
export const getSchemaDatasetsLoaded = (state: State) => state.schemaDatasetsLoaded;
