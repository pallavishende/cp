import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { FieldSchemaResponse } from '../models';
import { fieldSchemaActions } from '../actions';

export const schemaAdapter = createEntityAdapter<FieldSchemaResponse>({
  selectId: (item: FieldSchemaResponse) => item.fieldKey,
  sortComparer: false
});

export interface State extends EntityState<FieldSchemaResponse> {
  loading: boolean;
  loaded: boolean;
  loadingFields: string[];
}

export const INIT_STATE: State = schemaAdapter.getInitialState({
  loading: false,
  loaded: false,
  loadingFields: []
});

export function reducer(state = INIT_STATE, action: fieldSchemaActions.All) {
  switch (action.type) {
    case fieldSchemaActions.LOAD:
    case fieldSchemaActions.LOAD_WITH_NESTED_SCHEMAS: {
      // keep track of fields that are being loaded, make sure we dont add any to the list
      // that have already been loaded.
      const loadingFields = [...state.loadingFields, ...action.payload].filter(
        fieldKey => !state.entities[fieldKey]
      );
      return {
        ...state,
        loading: true,
        loaded: false,
        loadingFields
      };
    }
    case fieldSchemaActions.LOAD_SUCCESS: {
      // removed the loaded fields from the loading list.
      const loadedFields = action.payload.map(fieldSchemaResp => fieldSchemaResp.fieldKey);
      const loadingFields = state.loadingFields.filter(loadingField => {
        return loadedFields.indexOf(loadingField) === -1;
      });
      return {
        ...schemaAdapter.addMany(action.payload, state),
        loading: loadingFields.length > 0,
        loaded: loadingFields.length === 0, // only set loaded to true when all fields in queue are finished
        loadingFields
      };
    }
    case fieldSchemaActions.UPDATE_SUCCESS: {
      return schemaAdapter.updateOne(
        {
          id: action.payload.fieldKey,
          changes: action.payload
        },
        state
      );
    }
    case fieldSchemaActions.CREATE_SUCCESS: {
      return schemaAdapter.addOne(action.payload, state);
    }
    case fieldSchemaActions.LOAD_FAILED: {
      return { ...state, loading: false, loaded: false };
    }
    case fieldSchemaActions.CREATE_FAILED:
    case fieldSchemaActions.UPDATE_FAILED: {
      return { ...state, loading: false };
    }
    default: {
      return state;
    }
  }
}
export const getSchemasLoading = (state: State) => state.loading;
export const getSchemasLoaded = (state: State) => state.loaded;
