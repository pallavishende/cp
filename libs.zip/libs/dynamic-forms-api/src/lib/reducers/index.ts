import * as fromDataset from './dataset';
import * as fromLayoutSchema from './layout-schema';
import * as fromFieldSchema from './field-schema';

import { ActionReducerMap, createFeatureSelector } from '@ngrx/store';

export interface DynamicFormsApiState {
  dataset: fromDataset.State;
  layoutSchema: fromLayoutSchema.State;
  fieldSchema: fromFieldSchema.State;
}

export const DynamicFormApiReducers: ActionReducerMap<DynamicFormsApiState> = {
  dataset: fromDataset.reducer,
  layoutSchema: fromLayoutSchema.reducer,
  fieldSchema: fromFieldSchema.reducer
};

export const getDynamicFormApiState = createFeatureSelector<DynamicFormsApiState>('dynamicFormApi');

export { fromDataset, fromLayoutSchema, fromFieldSchema };
