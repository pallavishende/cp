import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { LayoutSchemaResponse } from '../models';
import { layoutSchemaActions } from '../actions';

export const schemaAdapter = createEntityAdapter<LayoutSchemaResponse>({
  selectId: (item: LayoutSchemaResponse) => item.contentType,
  sortComparer: false
});

export interface State extends EntityState<LayoutSchemaResponse> {
  loading: boolean;
  loaded: boolean;
}

export const INIT_STATE: State = schemaAdapter.getInitialState({
  loading: false,
  loaded: false
});

export function reducer(state = INIT_STATE, action: layoutSchemaActions.All) {
  switch (action.type) {
    case layoutSchemaActions.LOAD:
    case layoutSchemaActions.LOAD_WITH_FIELDS: {
      return {
        ...state,
        loading: true,
        loaded: false
      };
    }
    case layoutSchemaActions.LOAD_SUCCESS: {
      return {
        ...schemaAdapter.addOne(action.payload, state),
        loading: false,
        loaded: true
      };
    }
    case layoutSchemaActions.UPDATE_SUCCESS: {
      return schemaAdapter.updateOne(
        {
          id: action.payload.contentType,
          changes: action.payload
        },
        state
      );
    }
    case layoutSchemaActions.CREATE_SUCCESS: {
      return schemaAdapter.addOne(action.payload, state);
    }
    case layoutSchemaActions.LOAD_FAILED: {
      return { ...state, loading: false, loaded: false };
    }
    case layoutSchemaActions.CREATE_FAILED:
    case layoutSchemaActions.UPDATE_FAILED: {
      return { ...state, loading: false };
    }
    default: {
      return state;
    }
  }
}
export const getSchemasLoading = (state: State) => state.loading;
export const getSchemasLoaded = (state: State) => state.loaded;
