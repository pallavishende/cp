import { createSelector } from '@ngrx/store';
import { fromDataset } from '../reducers';
import { getDynamicFormApiState } from '../reducers/index';
export const getDatasetState = createSelector(
  getDynamicFormApiState,
  state => state.dataset
);

export const {
  selectAll: getAllDatasetItems,
  selectEntities: getDatasetEntities
} = fromDataset.datasetAdapter.getSelectors(getDatasetState);

/**
 * Allows selector to pass in an id for a specific dataset
 */
export const getDatasetByContentTypeAndFieldKey = (contentType: string, fieldKey: string) =>
  createSelector(
    getDatasetEntities,
    entities => {
      return entities[fromDataset.getDatasetId({ contentType, fieldKey })];
    }
  );

/**
 * Selector to return the loaded property of the state
 */
export const getSchemaDatasetsLoaded = createSelector(
  getDatasetState,
  fromDataset.getSchemaDatasetsLoaded
);

/**
 * Selector to return the loaded property of the state
 */
export const getSchemaDatasetLoaded = (schemaName: string) =>
  createSelector(
    getSchemaDatasetsLoaded,
    (loaded: string[]) => !!loaded.includes(schemaName)
  );

/**
 * Selector to return the loading property of the state
 */
export const getDatasetLoading = createSelector(
  getDatasetState,
  fromDataset.getDatasetLoading
);

export const getDatasetOptions = (contentType, fieldKey) => {
  return createSelector(
    getDatasetByContentTypeAndFieldKey(contentType, fieldKey),
    dataset => (dataset ? dataset.value : undefined)
  );
};

export const getDatasetsByContentType = contentType => {
  return createSelector(
    getAllDatasetItems,
    datasets => datasets.filter(dataset => dataset.contentType === contentType)
  );
};
