import { createSelector } from '@ngrx/store';
import { fromFieldSchema } from '../reducers';
import { getDynamicFormApiState } from '../reducers/index';
import { FieldSchema } from '../models';

export const getFieldSchemaState = createSelector(
  getDynamicFormApiState,
  state => state.fieldSchema
);

export const {
  selectAll: getAllSchemaItems,
  selectEntities: getSchemaEntities
} = fromFieldSchema.schemaAdapter.getSelectors(getFieldSchemaState);

/**
 * Allows selector to pass in an id for a specific schema
 */
export const getFieldSchemaByContentType = contentType =>
  createSelector(
    getSchemaEntities,
    entities => {
      return entities[contentType];
    }
  );

export const getFieldSchemas = (fieldKeys: string[]) =>
  createSelector(
    getSchemaEntities,
    entities => {
      const fieldSchemas = [];
      for (const fieldKey of fieldKeys) {
        if (entities[fieldKey] && entities[fieldKey].fieldSchema) {
          fieldSchemas.push(entities[fieldKey].fieldSchema);
        }
      }
      return fieldSchemas;
    }
  );
/**
 * Allows selector to pass in an id for a specific schema
 */
export const getFieldSchemaMapByFieldKeys = (fieldKeys: string[]) =>
  createSelector(
    getSchemaEntities,
    entities => {
      return fieldKeys.reduce((map: { [id: number]: FieldSchema }, fieldKey: string) => {
        if (entities[fieldKey] && entities[fieldKey].fieldSchema) {
          return {
            ...map,
            [fieldKey]: entities[fieldKey].fieldSchema
          };
        }
        return map;
      }, {});
    }
  );

/**
 * Selector to return the loaded property of the state
 */
export const getFieldSchemasLoaded = createSelector(
  getFieldSchemaState,
  fromFieldSchema.getSchemasLoaded
);

/**
 * Selector to return the loading property of the state
 */
export const getFieldSchemasLoading = createSelector(
  getFieldSchemaState,
  fromFieldSchema.getSchemasLoading
);
