import { createSelector } from '@ngrx/store';
import { fromLayoutSchema } from '../reducers';
import { getDynamicFormApiState } from '../reducers/index';
import { SchemaHelper } from '../services/schema-helper';
import { LayoutSchema, FieldSchemaMap } from '../models';
import * as fieldSchemaSelectors from './field-schema.selectors';

export const getLayoutSchemaState = createSelector(
  getDynamicFormApiState,
  state => state.layoutSchema
);

export const {
  selectAll: getAllSchemaItems,
  selectEntities: getSchemaEntities
} = fromLayoutSchema.schemaAdapter.getSelectors(getLayoutSchemaState);

/**
 * Allows selector to pass in an id for a specific schema
 */
export const getLayoutSchemaByContentType = contentType =>
  createSelector(
    getSchemaEntities,
    entities => entities[contentType]
  );

export const getLayoutSchemaFieldsByContentType = contentType =>
  createSelector(
    getLayoutSchemaByContentType(contentType),
    respSchema => {
      if (!respSchema) {
        return null;
      }
      if ((<LayoutSchema[]>respSchema.layoutSchema).length) {
        return SchemaHelper.getAllLayoutSchemaFields(respSchema.layoutSchema);
      }
      return SchemaHelper.getAllLayoutSchemaFields(<LayoutSchema>respSchema.layoutSchema);
    }
  );

export const getLayoutSchemaFieldsWithOptionsByContentType = contentType =>
  createSelector(
    getLayoutSchemaByContentType(contentType),
    respSchema => {
      if (!respSchema) {
        return null;
      }
      if ((<LayoutSchema[]>respSchema.layoutSchema).length) {
        return SchemaHelper.getAllLayoutSchemaFieldsWithOptions(respSchema.layoutSchema);
      }
      return SchemaHelper.getAllLayoutSchemaFieldsWithOptions(<LayoutSchema>(
        respSchema.layoutSchema
      ));
    }
  );

export const getLayoutSchemaByContentTypeWithFieldSchemaMap = contentType =>
  createSelector(
    getLayoutSchemaByContentType(contentType),
    getLayoutSchemaFieldsWithOptionsByContentType(contentType),
    fieldSchemaSelectors.getSchemaEntities,
    (schemaResp, schemaFields, fieldEntities) => {
      if (!schemaFields) {
        return null;
      }
      const fieldSchemaMapByMode = SchemaHelper.getFieldSchemaMapByMode(
        schemaFields,
        fieldEntities
      );
      return {
        layoutSchema: schemaResp && <LayoutSchema[]>schemaResp.layoutSchema,
        fieldSchemaMapByMode
      };
    }
  );

export function getAllLayoutSchemaFieldsRecursively(contentType, state, data) {
  data[contentType] = getLayoutSchemaByContentTypeWithFieldSchemaMap(contentType)(state);
  if (!data[contentType]) {
    return;
  }
  for (const mode of Object.keys(data[contentType].fieldSchemaMapByMode)) {
    for (const fieldKey of Object.keys(data[contentType].fieldSchemaMapByMode[mode])) {
      const fieldData = data[contentType].fieldSchemaMapByMode[mode][fieldKey];
      if (fieldData && fieldData.schema && !data[fieldData.schema]) {
        getAllLayoutSchemaFieldsRecursively(fieldData.schema, state, data);
      }
    }
  }
}

export const getAllLayoutSchemaData = contentType => {
  return state => {
    const data = {};
    getAllLayoutSchemaFieldsRecursively(contentType, state, data);
    return data as {
      [key: string]: {
        fieldSchemaMapByMode: { [key: string]: FieldSchemaMap };
        layoutSchema: LayoutSchema[];
      };
    };
  };
};

export const getLayoutSchemaSchemaFields = contentType =>
  createSelector(
    getLayoutSchemaFieldsByContentType(contentType),
    fieldSchemaSelectors.getSchemaEntities,
    (fieldKeys, fieldEntities) => {
      const schemaFields = [];
      for (const fieldKey of fieldKeys) {
        if (fieldEntities[fieldKey] && fieldEntities[fieldKey].fieldSchema) {
          schemaFields.push(fieldEntities[fieldKey].fieldSchema);
        }
      }
      return schemaFields;
    }
  );
/**
 * Selector to return the loaded property of the state
 */
export const getLayoutSchemasLoaded = createSelector(
  getLayoutSchemaState,
  fromLayoutSchema.getSchemasLoaded
);

/**
 * Selector to return the loading property of the state
 */
export const getLayoutSchemasLoading = createSelector(
  getLayoutSchemaState,
  fromLayoutSchema.getSchemasLoading
);
