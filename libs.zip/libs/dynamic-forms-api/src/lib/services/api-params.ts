import { Inject } from '@angular/core';
import { Environments } from '@content-platform/configuration';
import { DYNAMIC_FORMS_API_OPTIONS, DynamicFormsApiOptions } from '../dynamic-forms-api-config';

type apiKeys =
  | 'dataset'
  | 'layoutSchema'
  | 'layoutSchemaContentTypes'
  | 'fieldSchema'
  | 'submissionsContentTypes'
  | 'fieldSchemaFieldKeys';

const apiEndpoints = {
  dataset: '/submissions/dataset',
  layoutSchema: '/layout/schema',
  layoutSchemaContentTypes: `/layout/schema/content-types?`,
  submissionsContentTypes: '/submissions/content-types?',
  fieldSchema: '/field/schema',
  fieldSchemaFieldKeys: '/field/schema/fieldkeys'
};

const localStorageEndpoints = {
  schema: 'assets/data/content-schema.json',
  layoutSchema: 'assets/data/layout-schema-new.json',
  fieldSchema: 'assets/data/field-schema.json',
  dataset: 'assets/data/dataset.json'
};

/**
 * Class with static methods used to get the urls for the api endpoint
 *
 * @export
 * @class ApiParams
 */
export class ApiParams {
  constructor(@Inject(DYNAMIC_FORMS_API_OPTIONS) private apiOptions: DynamicFormsApiOptions) {}
  /**
   * Gets the full url for the given endpoint/type, incase there are dynamic values in the url
   * the user can pass in tokens to replace them.
   *
   * @static
   * @param type
   * @param [tokens] optional tokens for the url
   * @returns the endpoint full url
   */
  getUrl(type: apiKeys, tokens?: { [key: string]: string | number }) {
    if (this.apiOptions.useLocalStorage) {
      return localStorageEndpoints[type];
    }
    let pattern = apiEndpoints[type];

    if (pattern) {
      if (tokens) {
        Object.keys(tokens).forEach(tokenKey => {
          const tokenVal = encodeURIComponent(<string>tokens[tokenKey]);
          const tokenStandIn = ':' + tokenKey;
          pattern = pattern.replace(tokenStandIn, tokenVal);
        });
      }

      return Environments.getUrl('submissionEndpoint') + pattern;
    }
  }
}
