import { Injectable, Inject, InjectionToken } from '@angular/core';

import { CustomDatasetProvider, CustomDatasetSearchProvider } from '../models';
export const CUSTOM_DATASET_PROVIDERS = new InjectionToken<CustomDatasetProvider[]>(
  'CUSTOM_DATASET_PROVIDERS'
);
export const CUSTOM_DATASET_SEARCH_PROVIDERS = new InjectionToken<CustomDatasetProvider[]>(
  'CUSTOM_DATASET_SEARCH_PROVIDERS'
);
export const SearchDatasetProviderFactory = (...services) => {
  return services;
};

@Injectable()
export class CustomDatasetProviderRegistry {
  private providers: CustomDatasetProvider[];
  private searchProviders: CustomDatasetSearchProvider[];

  constructor(
    @Inject(CUSTOM_DATASET_PROVIDERS) providers: CustomDatasetProvider[],
    @Inject(CUSTOM_DATASET_SEARCH_PROVIDERS) searchProviders: CustomDatasetSearchProvider[]
  ) {
    // flatten
    this.providers = providers
      .reduce((acc, val) => acc.concat(val), [])
      .filter(provider => !!provider);

    this.searchProviders = searchProviders
      .reduce((acc, val) => acc.concat(val), [])
      .filter(provider => !!provider);
  }

  public getProvider(contentType: string): CustomDatasetProvider {
    return this.providers.find(provider => provider.useThisProvider(contentType));
  }

  public getSearchProvider(contentType: string, fieldKey: string): CustomDatasetSearchProvider {
    return this.searchProviders.find(provider => provider.useThisProvider(contentType, fieldKey));
  }
}
