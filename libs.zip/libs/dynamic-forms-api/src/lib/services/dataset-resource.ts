import { throwError, Observable, of } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ApiParams } from './api-params';
import { LoggerService } from '@content-platform/logging';
import { catchError, tap, map } from 'rxjs/operators';
import { Dataset, DatasetOptions } from '../models';
import { fromDataset } from '../reducers';
import { CustomDatasetProviderRegistry } from './custom-dataset-provider-registry';

@Injectable()
export class DatasetResource {
  private logger: LoggerService;

  constructor(
    private http: HttpClient,
    loggerService: LoggerService,
    private apiParams: ApiParams,
    private customDatasets: CustomDatasetProviderRegistry
  ) {
    this.logger = loggerService.instance('DatasetResource');
  }

  private getUrl() {
    return this.apiParams.getUrl('dataset');
  }

  /**
   * Retrieves a single item, using the content id
   *
   * @param contentType
   * @param fieldKey
   * * @returns
   */
  getById(dataId: number): Observable<Dataset> {
    return this.http.get<DatasetOptions>(`${this.getUrl()}/${dataId}`).pipe(
      tap(() => {
        this.logger.log(`Retrieved Dataset`, { id: dataId });
      }),
      catchError(error => this.handleError(`Retrieving Dataset Failed`, error))
    );
  }

  /**
   * Retrieves all, using the contentType and fieldKey
   *
   * @param contentType
   * @param fieldKey
   * * @returns
   */
  getAll(contentType: string, fieldKey: string | string[]): Observable<Dataset[]> {
    if (this.customDatasets.getProvider(contentType)) {
      // We're getting the data from another source
      return of([]);
    }
    return this.http
      .get<Dataset[]>(this.getUrl(), {
        params: {
          contentType,
          fieldKey
        }
      })
      .pipe(
        tap(datasetArray => {
          this.logger.log(`Retrieved Datasets`, {
            contentType,
            fieldKey,
            numberOfDatasets: datasetArray.length
          });
        }),
        catchError(error => this.handleError(`Retrieving Datasets Failed`, error))
      );
  }

  /**
   * Retrieves a single item, using the contentType and fieldKey
   *
   * @param contentType
   * @param fieldKey
   * * @returns
   */
  get(contentType: string, fieldKey: string | string[]): Observable<Dataset> {
    return this.http
      .get<Dataset>(this.getUrl(), {
        params: {
          contentType,
          fieldKey
        }
      })
      .pipe(
        map(datasetArray => datasetArray[0]),
        tap(dataset => {
          this.logger.log(`Retrieved Dataset`, { contentType, fieldKey, id: dataset.id });
        }),
        catchError(error => this.handleError(`Retrieving Dataset Failed`, error))
      );
  }

  get entityName(): string {
    return 'Dataset';
  }

  /**
   * Does a POST to the endpint, to update an existing item.
   *
   * @param data
   * @returns
   */
  create(data: Dataset): Observable<Dataset> {
    // TODO: "submittedBy" should be overwritten by the server, although currently it expects the "submittedBy" property
    // and fails if it is not there.
    data.submittedBy = data.submittedBy || 'User';
    data.modifiedBy = data.modifiedBy || 'User';
    return this.http.post<Dataset>(`${this.getUrl()}`, data).pipe(
      tap(() => {
        this.logger.log(`Created Dataset ${fromDataset.getDatasetId(data)}`);
      }),
      catchError(error =>
        this.handleError(`Create ${fromDataset.getDatasetId(data)} Dataset Failed`, error)
      )
    );
  }

  /**
   * Does a PUT to the endpint, to update an existing item.
   *
   * @param data
   * @returns
   */
  update(data: Dataset): Observable<Dataset> {
    // TODO: "submittedBy" should be overwritten by the server, although currently it expects the "submittedBy" property
    // and fails if it is not there.
    data.submittedBy = data.submittedBy || 'User';
    data.modifiedBy = data.modifiedBy || 'User';
    return this.http.put<Dataset>(`${this.getUrl()}/${data.id}`, data).pipe(
      tap(() => {
        this.logger.log(`Updated Dataset ${fromDataset.getDatasetId(data)}`);
      }),
      catchError(error =>
        this.handleError(`Update ${fromDataset.getDatasetId(data)} Dataset Failed`, error)
      )
    );
  }

  /**
   * Does a DELETE to the endpint, to remove an existing item.
   *
   * @param dataId
   * @returns
   */
  delete(dataId: number): Observable<Dataset> {
    return this.http.delete<Dataset>(`${this.getUrl()}/${dataId}`).pipe(
      tap(() => {
        this.logger.log(`Deleted Dataset`, { dataId });
      }),
      catchError(error => this.handleError(`Deleting Dataset Failed`, error))
    );
  }

  searchFieldKeys(contentType: string, fieldKey: string) {
    const configUrl = this.apiParams.getUrl('submissionsContentTypes');

    return this.http
      .get(configUrl, {
        params: new HttpParams().set('contentType', contentType).set('fieldKey', `%${fieldKey}%`)
      })
      .pipe(
        map(response => {
          const results = [];
          for (const key in response) {
            if (response.hasOwnProperty(key)) {
              results.push({ result: response[key] });
            }
          }
          return results;
        }),
        catchError(error => {
          if (error.status === 404) {
            return of([{ result: 'No results found for this term' }]);
          }
        })
      );
  }

  /**
   * error handling in case the resource call fails
   *
   * @protected
   * @param {(Response | any)} error
   * @returns {Observable<any>}
   * @memberof Resource
   */
  protected handleError(msg: string, error: Response | any): Observable<any> {
    const body = error.error || error;
    const err = JSON.stringify(body) || 'Server Error';
    this.logger.log(msg, body);
    return throwError(err);
  }
}
