import { Injectable } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { filter } from 'lodash';
import { DynamicFormsApiState } from '../reducers';
import { datasetSelectors } from '../selectors';
import { DatasetOptions } from '../models';
import { CustomDatasetProviderRegistry } from './custom-dataset-provider-registry';

@Injectable()
export class DatasetRetriever {
  constructor(
    private store: Store<DynamicFormsApiState>,
    private customDatasetRegistry: CustomDatasetProviderRegistry
  ) {}

  getDatasetFromStore(contentType: string, fieldKey: string): Observable<DatasetOptions[]> {
    const customProvider = this.customDatasetRegistry.getProvider(contentType);
    if (customProvider) {
      return this.store.pipe(select(customProvider.selectDatasetOptions(contentType, fieldKey)));
    }
    return this.store.pipe(select(datasetSelectors.getDatasetOptions(contentType, fieldKey)));
  }

  searchDataset(
    searchString: string,
    contentType: string,
    fieldKey: string
  ): Observable<DatasetOptions[]> {
    const customProvider = this.customDatasetRegistry.getSearchProvider(contentType, fieldKey);
    if (customProvider) {
      return customProvider.search(searchString).pipe(take(1));
    }
    return this.getDatasetFromStore(contentType, fieldKey).pipe(
      map(datasetValues => this.filterBy(searchString, datasetValues)),
      take(1)
    );
  }

  searchWithDataset(searchString: string, datasetValues: DatasetOptions[]): DatasetOptions[] {
    return this.filterBy(searchString, datasetValues);
  }

  private filterBy(value: string, datasetValues: DatasetOptions[]): DatasetOptions[] {
    const filterValue = value ? value.toLowerCase() : null;
    const check: DatasetOptions[] = datasetValues
      .map(state => {
        return {
          group: state.group,
          values: (filterValue
            ? filter(state.values, val => {
                return (
                  val.description.toLowerCase().includes(filterValue) ||
                  val.description.toLowerCase().indexOf(filterValue) === 0
                );
              })
            : state.values
          ).slice(0, 100)
        };
      })
      .filter(group => group.values.length > 0);
    return check;
  }
}
