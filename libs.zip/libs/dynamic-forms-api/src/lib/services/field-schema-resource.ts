import { throwError, Observable, of } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ApiParams } from './api-params';
import { FieldSchemaResponse } from '../models';
import { LoggerService } from '@content-platform/logging';
import { SortByRelevancePipe } from '@content-platform/pipes';
import { catchError, tap, map } from 'rxjs/operators';
import { SchemaOverrideService } from './schema-override.service';

@Injectable()
export class FieldSchemaResource {
  private logger: LoggerService;

  constructor(
    private http: HttpClient,
    loggerService: LoggerService,
    private apiParams: ApiParams,
    private schemaOverrideService: SchemaOverrideService,
    private sortByRelevance: SortByRelevancePipe
  ) {
    this.logger = loggerService.instance('SubmissionsFieldSchemaResource');
  }

  private getUrl() {
    return this.apiParams.getUrl('fieldSchema');
  }

  /**
   * Retrieves a single item, using the content id
   *
   * @param id
   * @returns
   */
  get(fieldKey: string | string[]): Observable<FieldSchemaResponse[]> {
    if (!fieldKey || fieldKey.length === 0) {
      return of([]);
    }
    return this.http
      .get<FieldSchemaResponse[]>(`${this.getUrl()}`, {
        params: { fieldKey }
      })
      .pipe(
        tap(() => {
          this.logger.log(`Retrieved Field Schemas`, { fieldKey });
        }),
        map(data => {
          return this.schemaOverrideService.processFieldSchemaResonse(data);
        }),
        catchError(error => this.handleError(`Retrieving Field Schemas Failed`, error))
      );
  }

  searchFieldkeys(fieldKey: string) {
    const configUrl = this.apiParams.getUrl('fieldSchemaFieldKeys');

    return this.http
      .get<FieldSchemaResponse[]>(configUrl, {
        params: new HttpParams().set('fieldKey', `%${fieldKey}%`)
      })
      .pipe(
        map(response => {
          const results = [];
          for (const item of response) {
            results.push({ result: item });
          }
          return this.sortByRelevance.transform(results, fieldKey, 'result');
        }),
        catchError(error => {
          if (error.status === 404) {
            return of([{ result: 'No results found for this term' }]);
          }
        })
      );
  }

  /**
   * Does a POST to the endpoint, to create a new item
   *
   * @param data
   * @returns
   */
  create(data: FieldSchemaResponse): Observable<FieldSchemaResponse> {
    return this.http.post<FieldSchemaResponse>(this.getUrl(), data).pipe(
      tap(() => {
        this.logger.log(`Created Field Schema ${data.fieldKey}`, { data });
      }),
      catchError(error => this.handleError(`Create ${data.fieldKey} Field Schema Failed`, error))
    );
  }

  /**
   * Does a PUT to the endpint, to update an existing item.
   *
   * @param data
   * @returns
   */
  update(data: FieldSchemaResponse): Observable<FieldSchemaResponse> {
    return this.http.put<FieldSchemaResponse>(`${this.getUrl()}/${data.id}`, data).pipe(
      tap(() => {
        this.logger.log(`Updated Field Schema ${data.fieldKey}`, { data });
      }),
      catchError(error => this.handleError(`Update ${data.fieldKey} Field Schema Failed`, error))
    );
  }

  /**
   * Does a DELETE to the endpint, to remove an existing item.
   *
   * @param data
   * @returns
   */
  delete(schemaId: string): Observable<FieldSchemaResponse> {
    return this.http.delete<FieldSchemaResponse>(`${this.getUrl()}/${schemaId}`).pipe(
      tap(() => {
        this.logger.log(`Deleted Schema`, { schemaId });
      }),
      catchError(error => this.handleError(`Deleting Schema Failed`, error))
    );
  }

  get entityName(): string {
    return 'FieldSchema';
  }

  /**
   * error handling in case the resource call fails
   *
   * @protected
   * @param {(Response | any)} error
   * @returns {Observable<any>}
   * @memberof Resource
   */
  protected handleError(msg: string, error: Response | any): Observable<any> {
    const body = error.error || error;
    const err = JSON.stringify(body) || 'Server Error';
    this.logger.log(msg, body);
    return throwError(err);
  }
}
