import { throwError, Observable, of } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ApiParams } from './api-params';
import { LayoutSchemaResponse } from '../models';
import { LoggerService } from '@content-platform/logging';
import { catchError, tap, map } from 'rxjs/operators';
import { SchemaOverrideService } from './schema-override.service';
import { SortByRelevancePipe } from '@content-platform/pipes';

@Injectable()
export class LayoutSchemaResource {
  private logger: LoggerService;

  constructor(
    private http: HttpClient,
    loggerService: LoggerService,
    private apiParams: ApiParams,
    private schemaOverrideService: SchemaOverrideService,
    private sortByRelevance: SortByRelevancePipe
  ) {
    this.logger = loggerService.instance('SubmissionsLayoutSchemaResource');
  }

  private getUrl() {
    return this.apiParams.getUrl('layoutSchema');
  }

  /**
   * Retrieves a single item, using the content id
   *
   * @param id
   * @returns
   */
  get(contentType: string | string[]): Observable<LayoutSchemaResponse[]> {
    if (!contentType || contentType.length === 0) {
      return of([]);
    }
    return this.http
      .get<LayoutSchemaResponse[]>(`${this.getUrl()}`, {
        params: { contentType }
      })
      .pipe(
        tap(() => {
          this.logger.log(`Retrieved Schema ${contentType}`, { contentType });
        }),
        map(data => {
          return this.schemaOverrideService.processLayoutSchemaResonse(data);
        }),
        catchError(error => this.handleError(`Retrieving ${contentType} Schema Failed`, error))
      );
  }

  /**
   * Does a POST to the endpoint, to create a new item
   *
   * @param data
   * @returns
   */
  create(data: LayoutSchemaResponse, contentType: string): Observable<LayoutSchemaResponse> {
    return this.http
      .post<LayoutSchemaResponse>(this.getUrl(), data, {
        params: { contentType }
      })
      .pipe(
        tap(() => {
          this.logger.log(`Created Schema ${contentType}`, { contentType });
        }),
        catchError(error => this.handleError(`Create ${contentType} Schema Failed`, error))
      );
  }

  /**
   * Does a PUT to the endpint, to update an existing item.
   *
   * @param data
   * @returns
   */
  update(data: LayoutSchemaResponse, contentType: string): Observable<LayoutSchemaResponse> {
    return this.http
      .put<LayoutSchemaResponse>(`${this.getUrl()}/${data.id}`, data, {
        params: { contentType }
      })
      .pipe(
        tap(() => {
          this.logger.log(`Updated Schema ${contentType}`, { contentType });
        }),
        catchError(error => this.handleError(`Update ${contentType} Schema Failed`, error))
      );
  }

  /**
   * Does a DELETE to the endpint, to remove an existing item.
   *
   * @param data
   * @returns
   */
  delete(schemaId: number): Observable<LayoutSchemaResponse> {
    return this.http.delete<LayoutSchemaResponse>(`${this.getUrl()}/${schemaId}`).pipe(
      tap(() => {
        this.logger.log(`Deleted Schema`, { schemaId });
      }),
      catchError(error => this.handleError(`Deleting Schema Failed`, error))
    );
  }

  searchContentTypes(contentType: string) {
    const configUrl = this.apiParams.getUrl('layoutSchemaContentTypes');

    return this.http
      .get(configUrl, {
        params: new HttpParams().set('contentType', `%${contentType}%`)
      })
      .pipe(
        map(response => {
          const results = [];
          for (const key in response) {
            if (response.hasOwnProperty(key)) {
              results.push({ result: response[key] });
            }
          }
          return this.sortByRelevance.transform(results, contentType, 'result');
        }),
        catchError(error => {
          if (error.status === 404) {
            return of([{ result: 'No results found for this term' }]);
          }
        })
      );
  }

  get entityName(): string {
    return 'LayoutSchema';
  }

  /**
   * error handling in case the resource call fails
   *
   * @protected
   * @param {(Response | any)} error
   * @returns {Observable<any>}
   * @memberof Resource
   */
  protected handleError(msg: string, error: Response | any): Observable<any> {
    const body = error.error || error;
    const err = JSON.stringify(body) || 'Server Error';
    this.logger.log(msg, body);
    return throwError(err);
  }
}
