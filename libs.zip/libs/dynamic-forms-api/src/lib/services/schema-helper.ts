import {
  FieldSchema,
  LayoutSchema,
  FieldSchemaResponse,
  KeyValue,
  LayoutSchemaOptions
} from '../models';
import { uniq, isArray, cloneDeep } from 'lodash';

/**
 * A service with several functions to parse the ContentSchema
 *
 * @export
 * @class SchemaHelper
 */
export class SchemaHelper {
  constructor() {}

  static getAllLayoutSchemaFields(schemas: LayoutSchema | LayoutSchema[]): string[] {
    let fields = [];
    if (!isArray(schemas)) {
      schemas = [schemas] as LayoutSchema[];
    }
    for (const schema of schemas as LayoutSchema[]) {
      this.getLayoutSchemaFields(schema, fields);
    }
    fields = fields.map(data => data.fieldName);
    return uniq(fields);
  }

  static getAllLayoutSchemaFieldsWithOptions(
    schemas: LayoutSchema | LayoutSchema[]
  ): { fieldName: string; mode: string[]; options?: KeyValue }[] {
    const fields = [];
    if (!isArray(schemas)) {
      schemas = [schemas] as LayoutSchema[];
    }
    for (const schema of schemas as LayoutSchema[]) {
      this.getLayoutSchemaFields(schema, fields);
    }
    return uniq(fields);
  }

  private static getLayoutSchemaFields(
    schema: LayoutSchema,
    fields: { fieldName: string; mode: string[]; options?: LayoutSchemaOptions }[]
  ) {
    if (schema) {
      if (schema.type === 'field') {
        fields.push({
          fieldName: schema.selector,
          mode: schema.mode,
          options: schema.options
        });
      } else if (schema.content && schema.content.length > 0) {
        for (const nestedSchema of schema.content) {
          this.getLayoutSchemaFields(nestedSchema, fields);
        }
      }
    }
  }

  static getAllDatasetFields(fields: FieldSchema[]): string[] {
    const datasetFields = [];
    for (const field of fields) {
      this.addDatasetFieldIfExists(field, datasetFields);
      if (field.type === 'row' && field.fields && field.fields.length > 0) {
        for (const rowField of field.fields) {
          this.addDatasetFieldIfExists(rowField, datasetFields);
        }
      }
    }
    return uniq(datasetFields);
  }

  static addDatasetFieldIfExists(field: FieldSchema, datasetFields: string[]): void {
    if (
      field &&
      field.type &&
      field.options &&
      (field.options.find(option => !!option.fieldKey) ||
        field.options.find(option => !!option.autocomplete))
    ) {
      for (const opt of field.options) {
        if (opt.fieldKey) {
          datasetFields.push(<string>opt.fieldKey);
        }
      }
    }
  }

  static getAllNestedSchemaFields(fields: FieldSchema[]): string[] {
    const nestedSchemas = [];
    for (const field of fields) {
      if (field && field.schema) {
        nestedSchemas.push(field.schema);
      }
    }
    return uniq(nestedSchemas);
  }

  static getFieldSchemaMap(
    schemaFields: { fieldName: string; options?: KeyValue }[],
    fieldEntities: { [key: string]: FieldSchemaResponse }
  ) {
    return schemaFields.reduce((map: { [key: string]: FieldSchema }, fieldData) => {
      const { fieldName: fieldKey } = fieldData;
      if (fieldEntities[fieldKey] && fieldEntities[fieldKey].fieldSchema) {
        const fieldSchema: FieldSchema = cloneDeep(fieldEntities[fieldKey].fieldSchema);
        fieldSchema.options = fieldSchema.options || [];
        if (fieldData.options && Object.keys(fieldData.options).length > 0) {
          fieldSchema.options.push(fieldData.options);
        }
        return {
          ...map,
          [fieldKey]: fieldSchema
        };
      }
      return map;
    }, {});
  }

  static getFieldSchemaMapByMode(
    schemaFields: { fieldName: string; mode: string[]; options?: KeyValue }[],
    fieldEntities: { [key: string]: FieldSchemaResponse }
  ): { [mode: string]: { [key: string]: FieldSchema } } {
    const schemaMapByMode = {};
    for (const field of schemaFields) {
      for (const supportedMode of field.mode) {
        schemaMapByMode[supportedMode] = schemaMapByMode[supportedMode] || {};

        let fieldSchema = {} as FieldSchema;
        if (fieldEntities[field.fieldName] && fieldEntities[field.fieldName].fieldSchema) {
          fieldSchema = cloneDeep(fieldEntities[field.fieldName].fieldSchema);
        }
        fieldSchema.options = fieldSchema.options || [];

        if (field.options && Object.keys(field.options).length > 0) {
          fieldSchema.options.push(field.options);
        }
        schemaMapByMode[supportedMode][field.fieldName] = fieldSchema;
      }
    }
    return schemaMapByMode;
  }

  static getFormLayoutOption(layout: LayoutSchema | LayoutSchema[], optionName: string) {
    let foundLayout = layout;
    if (foundLayout instanceof Array) {
      foundLayout = (foundLayout as Array<LayoutSchema>).find(lay => lay.type === 'layout');
    }
    return foundLayout && foundLayout.options && foundLayout.options[optionName];
  }
}
