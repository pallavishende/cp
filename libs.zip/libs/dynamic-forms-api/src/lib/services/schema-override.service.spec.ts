import { TestBed } from '@angular/core/testing';
import { LayoutSchemaResponse, LayoutSchema, FieldSchemaResponse } from '../models';

import { SchemaOverrideService } from './schema-override.service';
import { DynamicFormsApiOptions, DYNAMIC_FORMS_API_OPTIONS } from '../dynamic-forms-api-config';

const mockOptions: DynamicFormsApiOptions = {
  useLocalStorage: false,
  schemaOverrides: {
    layout: {
      content1: {
        layoutSchema: [
          {
            mode: ['view'],
            selector: 'group',
            type: 'column',
            options: {}
          }
        ]
      }
    },
    field: {
      field1: {
        fieldSchema: {
          name: 'test',
          type: 'text'
        }
      }
    }
  }
};

const mockLayoutResponse: LayoutSchemaResponse[] = [
  {
    id: 1,
    contentType: 'content1',
    layoutSchema: []
  },
  {
    id: 2,
    contentType: 'content2',
    layoutSchema: []
  }
];

const mockFieldResponse: FieldSchemaResponse[] = [
  {
    id: 'field1',
    fieldKey: 'field1',
    fieldSchema: { name: 'old', type: 'dropdown' }
  },
  {
    id: 'field2',
    fieldKey: 'field2',
    fieldSchema: { name: 'old', type: 'dropdown' }
  }
];

describe('SchemaOverrideService', () => {
  let service: SchemaOverrideService;
  beforeEach(() =>
    TestBed.configureTestingModule({
      providers: [
        SchemaOverrideService,
        {
          provide: DYNAMIC_FORMS_API_OPTIONS,
          useValue: mockOptions
        }
      ]
    })
  );

  it('should be created', () => {
    service = TestBed.get(SchemaOverrideService);
    expect(service).toBeTruthy();
  });

  describe('layout overrides', () => {
    beforeEach(() => {
      service = TestBed.get(SchemaOverrideService);
    });

    it('should override a schema if configured to do so...', () => {
      const result = service.processLayoutSchemaResonse(mockLayoutResponse);
      expect(result[0].contentType).toEqual('content1');
      expect((<LayoutSchema[]>result[0].layoutSchema).length).toEqual(1);
      expect((<LayoutSchema[]>result[0].layoutSchema)[0].type).toEqual('column');
    });

    it('should not override a schema if not configured to do so...', () => {
      const result = service.processLayoutSchemaResonse(mockLayoutResponse);
      expect(result[1].contentType).toEqual('content2');
      expect((<LayoutSchema[]>result[1].layoutSchema).length).toEqual(0);
      expect(<LayoutSchema[]>result[1].layoutSchema).toEqual(<LayoutSchema[]>(
        mockLayoutResponse[1].layoutSchema
      ));
    });
  });

  describe('field overrides', () => {
    beforeEach(() => {
      service = TestBed.get(SchemaOverrideService);
    });

    it('should override a schema if configured to do so...', () => {
      const result = service.processFieldSchemaResonse(mockFieldResponse);
      expect(result[0].fieldKey).toEqual('field1');
      expect(result[0].fieldSchema.name).toEqual('test');
      expect(result[0].fieldSchema.type).toEqual('text');
    });

    it('should not override a schema if not configured to do so...', () => {
      const result = service.processFieldSchemaResonse(mockFieldResponse);
      expect(result[1].fieldKey).toEqual('field2');
      expect(result[1].fieldSchema.name).toEqual('old');
      expect(result[1].fieldSchema.type).toEqual('dropdown');
    });
  });
});
