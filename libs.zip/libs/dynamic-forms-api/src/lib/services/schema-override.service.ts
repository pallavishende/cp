import { Injectable, Inject } from '@angular/core';
import { LayoutSchema, LayoutSchemaResponse, FieldSchema, FieldSchemaResponse } from '../models';
import { DYNAMIC_FORMS_API_OPTIONS, DynamicFormsApiOptions } from '../dynamic-forms-api-config';

@Injectable()
export class SchemaOverrideService {
  constructor(@Inject(DYNAMIC_FORMS_API_OPTIONS) private apiOptions: DynamicFormsApiOptions) {}

  processLayoutSchemaResonse(data: LayoutSchemaResponse[]): LayoutSchemaResponse[] {
    for (const schema of data) {
      schema.layoutSchema = this.updateLayoutSchemaIfNeeded(schema);
    }
    return data;
  }

  private updateLayoutSchemaIfNeeded(schema: LayoutSchemaResponse): LayoutSchema[] | LayoutSchema {
    if (
      this.apiOptions.schemaOverrides &&
      this.apiOptions.schemaOverrides.layout &&
      this.apiOptions.schemaOverrides.layout[schema.contentType]
    ) {
      return <LayoutSchema[]>(
        this.apiOptions.schemaOverrides.layout[schema.contentType].layoutSchema
      );
    }
    return schema.layoutSchema;
  }

  processFieldSchemaResonse(data: FieldSchemaResponse[]): FieldSchemaResponse[] {
    for (const schema of data) {
      schema.fieldSchema = this.updateFieldSchemaIfNeeded(schema);
    }
    return data;
  }

  private updateFieldSchemaIfNeeded(schema: FieldSchemaResponse): FieldSchema {
    if (
      this.apiOptions.schemaOverrides &&
      this.apiOptions.schemaOverrides.field &&
      this.apiOptions.schemaOverrides.field[schema.fieldKey]
    ) {
      return <FieldSchema>this.apiOptions.schemaOverrides.field[schema.fieldKey].fieldSchema;
    }
    return schema.fieldSchema;
  }
}
