import { PermissionDataSets } from './apps-helper/permission-data-sets';

export abstract class ApiDataService {
  static readonly REQUEST_ENDPOINTS = {
    // TODO: Change to Environments.getUrl('permissionsEndpoint') when running with Docker
    USER_ROLES: 'https://uat.gateway.contentplatform.viacom.com/permissions/api' + '/roles',
    USER_PROFILES:
      'https://uat.gateway.contentplatform.viacom.com/permissions/api' + '/user-profiles',
    SPECIFIC_USER: function(userUUID: string) {
      return ApiDataService.REQUEST_ENDPOINTS.USER_PROFILES + `/${userUUID}`;
    },
    DELETE_ROLE: function(roleID: string) {
      return ApiDataService.REQUEST_ENDPOINTS.USER_ROLES + `/${roleID}`;
    }
  };
  static readonly TEST_ROLE_ID = {
    DEFAULT_DEV: '1204',
    TEST_ADMIN_ONE_REGION: '3864',
    TEST_ADMIN_MANY_REGIONS: '3865',
    TEST_ADMIN_NO_REGIONS: '3866',
    TEST_ADMIN_DUPLICATE: '3867'
  };
  static REQUEST_PATTERN_ENDPOINTS = {
    BASE_GE: '.*gateway.globalentry.viacom.com/gegateway/api/v1',
    BASE_AC: '.*gateway.contentplatform.viacom.com/aapi/v1',
    SELECT_REGIONS_ON_DASHBOARD: function(value: string) {
      return ApiDataService.REQUEST_PATTERN_ENDPOINTS.BASE_GE + `.*sortColumn.*region=${value}`;
    },
    SUBMIT_ENTRY: function() {
      return ApiDataService.REQUEST_PATTERN_ENDPOINTS.BASE_GE + '/submissions';
    },
    ADD_GROUP_ROLE_PAIR: function() {
      return (
        ApiDataService.REQUEST_PATTERN_ENDPOINTS.BASE_AC + '/sites/isis-config-live-v2/content/.*'
      );
    }
  };

  public static getBodyForRoleCreation(roleName: string) {
    return { name: `${roleName}` };
  }

  public static getBodyForRoleSettings(
    roleId: string,
    shortUserID: string,
    userUUID: string,
    secondRoleId?: string
  ) {
    if (secondRoleId === undefined) {
      return {
        id: shortUserID,
        uuid: userUUID,
        roles: [{ id: `${roleId}` }]
      };
    } else {
      return {
        id: shortUserID,
        uuid: userUUID,
        roles: [{ id: `${roleId}` }, { id: `${secondRoleId}` }]
      };
    }
  }

  public static getBodyForPermissionSetting(
    roleId: string,
    permissions: PermissionDataSets[],
    userUUIDWhomSet: string
  ) {
    return {
      id: roleId,
      users: [`${userUUIDWhomSet}`],
      permissions: permissions
    };
  }
}
