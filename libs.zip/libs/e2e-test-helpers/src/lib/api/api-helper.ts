import Logger from '@viacom/mqe-core-js/build/helpers/Logger';
import { RequestDetails } from './request-details';
const requestPromise = require('request-promise');

export abstract class ApiHelper {
  private static logger = Logger.getLogger('ApiHelper');

  static async sendRequest(requestDetails: RequestDetails) {
    this.logger.debug('Request is: ' + JSON.stringify(requestDetails));
    return requestPromise(requestDetails)
      .then(parsedBody => {
        this.logger.debug('Response is:' + JSON.stringify(parsedBody));
        return parsedBody;
      })
      .catch(error => {
        throw Error(`It's impossible to send the request '${error}'`);
      });
  }
}
