export abstract class PermissionDataSets {
  static readonly regionsFeature = function(regions: string | any[]): PermissionDataSets[] {
    return [
      {
        feature: { id: 9051 }, // Regions feature id
        metadata: regions
      }
    ];
  };

  static readonly fullAccessGeAndAdminAppsFeature = function(): PermissionDataSets[] {
    return [
      {
        feature: {
          id: 1001,
          name: 'Create and Edit Applications',
          key: 'edit_apps',
          metadataConfig: { metadataId: 19465, type: null, dataset: null, allowMultiple: false }
        }
      },
      {
        feature: {
          id: 1003,
          name: 'Edit User Permissions',
          key: 'edit_users',
          metadataConfig: { metadataId: 19468, type: null, dataset: null, allowMultiple: false }
        }
      },
      {
        feature: {
          id: 18001,
          name: 'Global Entry Dataset Manager',
          key: 'dataset_manager',
          metadataConfig: { metadataId: 19463, type: null, dataset: null, allowMultiple: false }
        }
      },
      {
        feature: {
          id: 14601,
          name: 'Global Entry Schema Editor',
          key: 'schema_editor',
          metadataConfig: { metadataId: 19464, type: null, dataset: null, allowMultiple: false }
        }
      },
      {
        feature: {
          id: 3754,
          name: 'Log in',
          key: 'log_in_administration',
          metadataConfig: { metadataId: 19467, type: null, dataset: null, allowMultiple: false }
        }
      },
      {
        feature: {
          id: 1002,
          name: 'Create and Edit Roles',
          key: 'edit_roles',
          metadataConfig: { metadataId: 19466, type: null, dataset: null, allowMultiple: false }
        }
      },
      {
        feature: {
          id: 13801,
          name: 'Create submission',
          key: 'create_submission',
          metadataConfig: { metadataId: 29478, type: null, dataset: null, allowMultiple: false }
        }
      },
      {
        feature: {
          id: 1107,
          name: 'View dashboard - my submissions',
          key: 'view_my_submissions',
          metadataConfig: { metadataId: 29474, type: null, dataset: null, allowMultiple: false }
        }
      },
      {
        feature: {
          id: 1110,
          name: 'Administer users & features',
          key: 'administer_users',
          metadataConfig: { metadataId: 29477, type: null, dataset: null, allowMultiple: false }
        }
      },
      {
        feature: {
          id: 1101,
          name: 'View dashboard - submissions for review',
          key: 'view_submissions_for_review',
          metadataConfig: { metadataId: 29481, type: null, dataset: null, allowMultiple: false }
        }
      },
      {
        feature: {
          id: 1106,
          name: 'Login',
          key: 'login',
          metadataConfig: { metadataId: 29473, type: null, dataset: null, allowMultiple: false }
        }
      },
      {
        feature: {
          id: 1103,
          name: 'Register as new user',
          key: 'register_as_new_user',
          metadataConfig: { metadataId: 29483, type: null, dataset: null, allowMultiple: false }
        }
      },
      {
        feature: {
          id: 13802,
          name: 'Edit submission',
          key: 'edit_submission',
          metadataConfig: { metadataId: 29479, type: null, dataset: null, allowMultiple: false }
        }
      },
      {
        feature: {
          id: 1109,
          name: 'Invite a new user',
          key: 'invite_new_user',
          metadataConfig: { metadataId: 29476, type: null, dataset: null, allowMultiple: false }
        }
      },
      {
        feature: {
          id: 1102,
          name: 'Re-submit',
          key: 'resubmit',
          metadataConfig: { metadataId: 29482, type: null, dataset: null, allowMultiple: false }
        }
      },
      {
        feature: {
          id: 1108,
          name: 'View dashboard - all submissions',
          key: 'view_all_submissions',
          metadataConfig: { metadataId: 29475, type: null, dataset: null, allowMultiple: false }
        }
      },
      {
        feature: {
          id: 9051,
          name: 'Region',
          key: 'ge_region',
          metadataConfig: {
            metadataId: 29480,
            type: 'dataset',
            dataset: 'content-platform_global-entry-regions',
            allowMultiple: true
          }
        }
      }
    ];
  };
}
