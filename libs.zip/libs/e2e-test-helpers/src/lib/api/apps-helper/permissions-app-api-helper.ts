import { ApiHelper, ApiMethodsEnum, RequestDetails, ApiDataService, TokenHelper } from '../index';
import { JavaScriptCommands, JavascriptExecutor } from '../../js-commands';
import { PermissionDataSets } from '@content-platform/e2e-test-helpers/src/lib/api/apps-helper/permission-data-sets';
// tslint:disable-next-line: nx-enforce-module-boundaries
import { Constants } from '../../../../../../apps/administration-e2e/src/constants/constants';

export abstract class PermissionsAppApiHelper {
  private static readonly GE_APP_ID = 'f23f5104-e489-44d3-a02d-f7a11364a7d2';
  private static readonly ADMINISTRATION_APP_ID = '7699f58a-9dfb-466c-a3c8-cae64c536a4a';

  static async createNewRole(roleName?: string): Promise<string> {
    const requestForNewRole = RequestDetails.buildRequest(
      ApiMethodsEnum.POST,
      ApiDataService.REQUEST_ENDPOINTS.USER_ROLES,
      await this.getCurrentUserTokenFromPage(),
      ApiDataService.getBodyForRoleCreation(roleName)
    );
    return await ApiHelper.sendRequest(requestForNewRole).then(result => result.id);
  }

  static async setPrivilegesAndRoleToUser(
    roleId: string,
    features: PermissionDataSets[],
    userUUIDWhomSet?: string
  ): Promise<void> {
    if (userUUIDWhomSet === undefined) {
      userUUIDWhomSet = await this.getCurrentUserUUID();
    }

    const requestForRegionAddingParams = RequestDetails.buildRequest(
      ApiMethodsEnum.PUT,
      ApiDataService.REQUEST_ENDPOINTS.USER_ROLES,
      await this.getCurrentUserTokenFromPage(),
      ApiDataService.getBodyForPermissionSetting(roleId, features, userUUIDWhomSet)
    );
    return ApiHelper.sendRequest(requestForRegionAddingParams);
  }

  static async setRole(
    roleId: string,
    secondRoleID?: string,
    userShortIDWhomSet?: string,
    userUUIDWhomSet?: string
  ): Promise<void> {
    if (userShortIDWhomSet === undefined || userUUIDWhomSet === undefined) {
      userShortIDWhomSet = await this.getCurrentUserShortID();
      userUUIDWhomSet = await this.getCurrentUserUUID();
    }

    const requestForRegionAddingParams = RequestDetails.buildRequest(
      ApiMethodsEnum.PUT,
      ApiDataService.REQUEST_ENDPOINTS.USER_PROFILES,
      await this.getCurrentUserTokenFromPage(),
      ApiDataService.getBodyForRoleSettings(
        roleId,
        userShortIDWhomSet,
        userUUIDWhomSet,
        secondRoleID
      )
    );
    return ApiHelper.sendRequest(requestForRegionAddingParams);
  }

  static async deleteRole(roleId: string): Promise<void> {
    const deleteRoleParams = RequestDetails.buildRequest(
      ApiMethodsEnum.DELETE,
      ApiDataService.REQUEST_ENDPOINTS.DELETE_ROLE(roleId),
      await this.getCurrentUserTokenFromPage()
    );
    return ApiHelper.sendRequest(deleteRoleParams);
  }

  static async getUserApplicationsWithPermissions(): Promise<string[]> {
    const requestForUserApps = RequestDetails.buildRequest(
      ApiMethodsEnum.GET,
      Constants.CALL_FOR_USER_APPS_WITH_PERMISSIONS,
      await this.getCurrentUserTokenFromPage(this.ADMINISTRATION_APP_ID)
    );
    const userApps: string[] = ['Initial variable'];
    await ApiHelper.sendRequest(requestForUserApps).then(async response => {
      for (let i = 1; i < response.length; i++) {
        await userApps.push(response[i].name);
      }
    });
    return userApps;
  }

  static async getUserPermissionsIds(): Promise<string[]> {
    const requestForUserPermissions = RequestDetails.buildRequest(
      ApiMethodsEnum.GET,
      Constants.CALL_FOR_USER_PERMISSIONS,
      await this.getCurrentUserTokenFromPage(this.ADMINISTRATION_APP_ID)
    );
    const userPermissionsIds: string[] = ['Initial variable'];
    await ApiHelper.sendRequest(requestForUserPermissions).then(async response => {
      for (let i = 1; i < response.length; i++) {
        await userPermissionsIds.push(response[i].id);
      }
    });
    return userPermissionsIds;
  }

  static async doesAppHaveAdminRights(app: string): Promise<boolean> {
    const requestForUserApps = RequestDetails.buildRequest(
      ApiMethodsEnum.GET,
      Constants.CALL_FOR_USER_APPS_WITH_PERMISSIONS,
      await this.getCurrentUserTokenFromPage(this.ADMINISTRATION_APP_ID)
    );
    const jp = require('jsonpath');
    return ApiHelper.sendRequest(requestForUserApps).then(
      async response => jp.query(response, `$[?(@.name==="${app}")].admin`) === 'true'
    );
  }

  // Auxiliary functions
  private static getCurrentUserTokenFromPage(appID: string = this.GE_APP_ID): Promise<string> {
    return JavascriptExecutor.executeScript(JavaScriptCommands.TOKEN_REQUEST(appID));
  }

  private static async getCurrentUserUUID(): Promise<string> {
    const token = await this.getCurrentUserTokenFromPage();
    return TokenHelper.getUserUUID(token);
  }

  private static async getUserProperties(userUUID: string): Promise<any> {
    const userPropertiesParams = RequestDetails.buildRequest(
      ApiMethodsEnum.GET,
      ApiDataService.REQUEST_ENDPOINTS.SPECIFIC_USER(userUUID),
      await this.getCurrentUserTokenFromPage()
    );
    return ApiHelper.sendRequest(userPropertiesParams);
  }

  private static async getCurrentUserShortID(): Promise<string> {
    const currentUserUUID = await this.getCurrentUserUUID();
    return this.getUserProperties(currentUserUUID).then(
      currentUserProperties => currentUserProperties.id
    );
  }
}
