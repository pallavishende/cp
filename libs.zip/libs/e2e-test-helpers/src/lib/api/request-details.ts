export abstract class RequestDetails {
  static buildRequest(requestMethod: string, url: string, token: string, body?: Object) {
    return {
      method: requestMethod,
      uri: url,
      json: true,
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + `${token}`
      },
      body: body
    };
  }
}
