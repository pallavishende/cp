const jwtDecode = require('jwt-decode');

export abstract class TokenHelper {
  private static getDecodedToken(token: string) {
    return jwtDecode(token);
  }

  static getUserUUID(token: string) {
    return this.getDecodedToken(token).oid;
  }
}
