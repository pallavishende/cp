export enum AppsList {
  HOME = 'Home',
  GLOBAL_ENTRY = 'Global Entry',
  ADMINISTRATION = 'Administration',
  SANDBOX = 'Sandbox'
}
