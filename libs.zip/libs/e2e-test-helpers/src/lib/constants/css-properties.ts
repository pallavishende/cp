export abstract class CSSProperties {
  static readonly COLOR: string = 'color';

  static readonly BACKGROUND_COLOR: string = 'background-color';

  static readonly FONT_SIZE: string = 'font-size';

  static readonly FONT_WEIGHT: string = 'font-weight';

  static readonly HEIGHT: string = 'height';

  static readonly BOX_SHADOW: string = 'box-shadow';

  static readonly PADDING_RIGHT: string = 'padding-right';
}
