export abstract class FtpConstants {
  static readonly CREDENTIALS = {
    HOST: 'delivery.nl.vimn.com',
    PORT: 2222,
    USER: 'GlobalEntry-Admin',
    PASSWORD: 'EhyBAWeLE3AB'
  };
}

export enum FtpUser {
  ADMIN = '/GCS_MusicSubmission/uat/',
  FASTRAX = '/Fastrax/uat/',
  FASTRAX_FRANCE = '/Fastrax_France/uat/',
  BITMAX = '/Bitmax/uat/',
  SONY_MUSIC = '/Sony_Music/uat/',
  PROMOSTREAM = '/Promostream/uat/'
}
