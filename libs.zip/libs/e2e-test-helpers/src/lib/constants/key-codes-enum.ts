export enum KeyCodes {
  BACKSPACE = 8,
  TAB = 9,
  ENTER = 13,
  SHIFT = 16,
  CTRL = 17,
  ALT = 18,
  ARROW_RIGHT = 39,
  ARROW_LEFT = 37,
  ARROW_UP = 38,
  ARROW_DOWN = 40,
  SEMICOLON = 186,
  COMMA = 188,
  PAGE_UP = 33,
  PAGE_DOWN = 34
}
