export class LoginConstants {
  static readonly DEFAULT_USER = {
    VIACOM_EMAIL: 'artsiom.kaptur@viacomcontractor.com',
    VIACOM_PASSWORD: '060812sS88!!'
  };
}
