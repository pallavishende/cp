export abstract class PatternConstants {
  static readonly BUILD_INFO = '^[0-9]{4}-[0-9]{2}-[0-9]{2}_[a-zA-Z0-9]+_[a-zA-Z0-9]+$';
  static readonly HEADER_LOGO_SRC = '^http(s?)://.+/assets/logo.png$';
  static readonly BOX_SHADOW = '^(\\s?rgba\\(0,\\s0,\\s0,\\s0\\.\\d{1,2}\\)(\\s-?\\dpx,?){4}){3}$';
  static readonly SCHEMA_EDITOR_REPLACEMENT = /(?:\\[rn]|[\r\n]+)+/g;
  static readonly SUBMISSION_ID = '^GE[\\d]+$';
  static readonly SMALL_FILE_IMAGE_SRC = function(extesion: string): string {
    return `^https?\:\/\/.+\/assets\/image\/${extesion}-icon.png$`;
  };
}
