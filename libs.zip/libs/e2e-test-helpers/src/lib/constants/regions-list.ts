export abstract class RegionsList {
  static readonly BENELUX = { name: 'BENELUX', description: 'Benelux (Netherlands & Flanders)' };
  static readonly FRANCE = { name: 'FRANCE', description: 'France' };
  static readonly GSA = { name: 'GSA', description: 'GSA (Germany, Switzerland, Austria)' };
  static readonly POLAND = { name: 'POLAND', description: 'Poland' };
  static readonly NORDICS = {
    name: 'NORDICS',
    description: 'Nordics (Norway, Sweden, Denmark, Finland)'
  };
  static readonly UK = { name: 'UK', description: 'UK' };
  static readonly JAPAN = { name: 'JAPAN', description: 'Japan' };
  static readonly HUNGARY = { name: 'HUNGARY', description: 'Hungary' };
  static readonly SA = { name: 'SA', description: 'Africa: South Africa (SA)' };
  static readonly ROA = { name: 'ROA', description: 'Africa: Res of Africa (ROA)' };
  static readonly ITALY = { name: 'ITALY', description: 'Italy' };
  static readonly PORTUGAL = { name: 'PORTUGAL', description: 'Portugal' };
  static readonly ANZ = { name: 'ANZ', description: 'ANZ (Australia, New Zealand)' };
  static readonly ASIA = { name: 'ASIA', description: 'Asia' };
  static readonly SEA = { name: 'SEA', description: 'South East Asia (SEA)' };
  static readonly LAM = { name: 'LAM', description: 'Latin America' };
  static readonly USA = { name: 'US', description: 'United States' };
}
