export abstract class StringConstants {
  static readonly EMPTY_STRING = '';

  static readonly CHARS_SET = {
    SYMBOLS_SET: ['..', '[[', ']]', '((', '))', '**', '++', '--', '??', '^^', '$$', '||'],
    ALPHANUMERIC_SET: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',
    ALPHANUMERIC_LOWER_ONLY: 'abcdefghijklmnopqrstuvwxyz',
    NUMBERS_ONLY: '0123456789'
  };
}
