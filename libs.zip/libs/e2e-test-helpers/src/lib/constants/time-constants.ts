export abstract class TimeConstants {
  static readonly MS = {
    _100: 100,
    _300: 300,
    _500: 500,
    _1000: 1000,
    _2000: 2 * 1000,
    _3000: 3 * 1000,
    _5000: 5 * 1000,
    _10000: 10 * 1000,
    _90000: 90 * 1000
  };

  static readonly SEC = {
    _1: 1,
    _3: 3,
    _5: 5,
    _10: 10,
    _20: 20,
    _30: 30,
    _90: 90
  };

  static readonly MIN_IN_MS = {
    _1: 60 * 1000,
    _2: 2 * 60 * 1000
  };
}
