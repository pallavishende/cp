import Logger from '@viacom/mqe-core-js/build/helpers/Logger';
import { web } from '@viacom/mqe-core-js';
import { LoginPage } from '../po/login-page.po';
import { LoginConstants } from '../constants';
import { WebInteractExt } from '../web-interact';
import { BrowserUtils } from '../utils/browser-utils';
// Parameters to transmit through the console while using Jenkins
const BROWSER_NAME = process.env.BROWSER_NAME;
const PLATFORM = process.env.PLATFORM;

export class CoreManagerHelper {
  private static logger = Logger.getLogger('CoreManagerHelper');
  private static browser;

  public static readonly DEFAULT_CAPS = {
    MQEDesktopBrowserName: !BROWSER_NAME ? 'chrome' : BROWSER_NAME, // chrome, firefox, ie, safari, MicrosoftEdge
    MQEDesktopOSPlatform: !PLATFORM ? 'WINDOWS' : PLATFORM, // MAC, WINDOWS
    MQEDesktopExcludedTargetLocations: 'us-east-1b',
    MQEProxyPort: `${8889 + Math.floor(Math.random() * 1000)}`,
    MQEEnableScreenRecording: 'true' // It is recommended to disable the value as it loads the system if there is no need to record video
  };

  public static async initiateDriver(
    caps: {
      MQEDesktopBrowserName: string;
      MQEDesktopOSPlatform: string;
      MQEProxyPort: string;
    } = this.DEFAULT_CAPS,
    login?: string,
    password?: string
  ) {
    await web.Manager.initiateDriver(caps);
    this.browser = new WebInteractExt(null, null, null);
    await this.loginToApp(login, password);
  }

  public static async loginToApp(
    email = LoginConstants.DEFAULT_USER.VIACOM_EMAIL,
    password = LoginConstants.DEFAULT_USER.VIACOM_PASSWORD
  ) {
    const loginPage = new LoginPage();
    await loginPage.get();
    if (
      this.DEFAULT_CAPS.MQEDesktopBrowserName === 'MicrosoftEdge' &&
      (await loginPage.isPickAnAccountMenuVisible())
    ) {
      await loginPage.clickUseAnotherAccount();
    }
    await loginPage.setEmail(email);
    await loginPage.setViacomEmailAndPassword(email, password);
    await loginPage.setStayInAccount();
    await BrowserUtils.maximizeWindow();
  }

  public static async stopDriver() {
    await web.Manager.stopDriver();
  }

  public static setSession(session: string) {
    web.Manager.sessionID = session;
  }

  public static getSession() {
    return web.Manager.sessionID;
  }

  public static getBrowser() {
    return this.browser;
  }

  public static isInitialized() {
    CoreManagerHelper.logger.debug('Is browser initialized: ' + (this.browser !== undefined));
    return this.browser !== undefined;
  }

  public static getCoreServerEventLogs() {
    CoreManagerHelper.logger.debug('Core server event logs:');
    return this.browser.getCoreServerEventLogs();
  }
}
