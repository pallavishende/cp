const excelToJson = require('convert-excel-to-json');

export abstract class ExcelHelper {
  static getJsonFromExcel(filePath: string, columnToKey?, sheets?) {
    return excelToJson({
      sourceFile: filePath,
      columnToKey: columnToKey,
      sheets: sheets
    });
  }
}
