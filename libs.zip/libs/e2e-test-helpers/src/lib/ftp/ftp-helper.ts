import Logger from '@viacom/mqe-core-js/build/helpers/Logger';
// tslint:disable-next-line:nx-enforce-module-boundaries
import { FtpConstants, FtpUser, TimeConstants } from '../constants';
import { DirectoryItem } from '../helpers/directory-item';

const PromiseSftp = require('promise-sftp');

export abstract class FtpHelper {
  private static logger = Logger.getLogger('FtpHelper');
  private static sftp = new PromiseSftp();

  /**
   * @returns an array of Directory Items, which are the representations of any object, that is stored in the requested directory
   * @param baseDirectory - the path to the folder, the content list of which we want to get
   * @param user - Type of FTP user with his own credentials
   */
  static async getDirectoriesList(baseDirectory: string): Promise<DirectoryItem[]> {
    let _list: DirectoryItem[] = [];
    const _sftp = this.sftp;
    const _logger = this.logger;
    await _sftp
      .connect({
        host: FtpConstants.CREDENTIALS.HOST,
        user: FtpConstants.CREDENTIALS.USER,
        password: FtpConstants.CREDENTIALS.PASSWORD,
        port: FtpConstants.CREDENTIALS.PORT
      })
      .then(function(serverMessage) {
        _logger.debug('Server message: ' + serverMessage);
        return _sftp.list(baseDirectory);
      })
      .then(function(list) {
        _list = list;
        _logger.debug('Directory listing');
        console.dir(_list);
        return _sftp.end();
      });
    return _list;
  }

  /**
   * Uploads file to the Manual-uploads directory, from which in can later proceed to the app server automatically
   * @param filePath - path to the file, that needs to be uploaded
   * @param remoteName - name, with which file will upload to the server
   * @param user - Type of FTP user with his own credentials
   */
  static async uploadFile(filePath: string, remoteName: string, user: FtpUser): Promise<void> {
    const _sftp = this.sftp;
    const _logger = this.logger;
    await _sftp
      .connect({
        host: FtpConstants.CREDENTIALS.HOST,
        user: FtpConstants.CREDENTIALS.USER,
        password: FtpConstants.CREDENTIALS.PASSWORD,
        port: FtpConstants.CREDENTIALS.PORT
      })
      .then(function(serverMessage) {
        _logger.debug('Server message: ' + serverMessage);
        return _sftp.put(filePath, user + remoteName);
      })
      .then(function() {
        _logger.debug('Uploaded as ' + remoteName);
        return _sftp.end();
      });
  }

  /**
   * The waiter for the file leaving the Manual-uploads directory to later proceed either to 'In Progress' or 'Error' directory.
   * It gets the Manual-uploads folder every 3 seconds and as soon as it doesn't contain uploaded file, it stops.
   * @param fileName - file, that needs to leave Manual-uploads
   * @param user - Type of FTP user with his own credentials
   * @param timeOut - if file is still presented in Manual-uploads after this time, method throws an error
   */
  static waitForLeaveMainDirectory(
    fileName: string,
    user: FtpUser,
    timeOut = TimeConstants.MS._90000
  ): Promise<boolean> {
    return new Promise((resolve, reject) => {
      let isDone = true;
      const start = new Date().getTime();
      let current: number;
      const loop = setInterval(async () => {
        (await FtpHelper.getDirectoriesList(user)).forEach(item => {
          if (item.name === fileName) {
            isDone = false;
          }
        });
        current = new Date().getTime();
        if (current - start > timeOut) {
          reject(new Error('Timeout'));
          clearInterval(loop);
        }
        if (isDone) {
          resolve(isDone);
          clearInterval(loop);
        }
        isDone = true;
      }, TimeConstants.MS._3000);
    });
  }

  static async isFileInDirectory(
    directory: string,
    fileName: string,
    user: FtpUser
  ): Promise<boolean> {
    const directoryItems: DirectoryItem[] = await FtpHelper.getDirectoriesList(user + directory);
    let isPresented = false;
    directoryItems.forEach(item => {
      if (item.name === fileName) {
        isPresented = true;
      }
    });
    return isPresented;
  }

  static async deleteFile(filePath: string): Promise<void> {
    const _sftp = this.sftp;
    const _logger = this.logger;
    await _sftp
      .connect({
        host: FtpConstants.CREDENTIALS.HOST,
        user: FtpConstants.CREDENTIALS.USER,
        password: FtpConstants.CREDENTIALS.PASSWORD,
        port: FtpConstants.CREDENTIALS.PORT
      })
      .then(function(serverMessage) {
        _logger.debug('Server message: ' + serverMessage);
        return _sftp.unlink(filePath);
      })
      .then(function() {
        _logger.debug('Deleted ' + filePath);
        return _sftp.end();
      });
  }
}
