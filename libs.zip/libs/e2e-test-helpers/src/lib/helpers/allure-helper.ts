import { WebInteractExt } from '../web-interact/impl/web-interact';
import * as fs from 'fs';
import { ProxyManagerTs } from '../proxy';

export class AllureHelper {
  public static async attachScreenshot(name = 'Screenshot') {
    const imgPath = await new WebInteractExt(null, null, null).getScreenshot();
    const imgFile = await fs.readFileSync(imgPath);
    await this.add(name, imgFile, 'image/png');
  }

  public static async attachFailureScreenshot() {
    await this.attachScreenshot('Failure Screenshot');
  }

  public static async attachDesktopScreenRecording() {
    const recordingPath = await new WebInteractExt(null, null, null).getScreenRecording();
    const recordingFile = await fs.readFileSync(recordingPath);
    await this.add('Desktop Screen Recording', recordingFile, 'video/quicktime');
  }

  public static async attachProxyResults() {
    const harLog = await ProxyManagerTs.getHarLogAsString();
    await this.add('Proxy Log', harLog, 'text/plain');
  }

  public static async attachAppXMLTree() {
    const pageSource = await new WebInteractExt(null, null, null).getPageSource();
    await this.add('Page Source', pageSource, 'text/plain');
  }

  // async attachDeviceLog () {
  //     const deviceLog = await new WebInteractExt(null, null, null).getDeviceLog()
  //     await this.add('Device Log', deviceLog, 'text/plain')
  // }

  // async attachHtmlFile (attachName, file) {
  // }

  // async attachCoreServerLog () {
  //     const wdLogPath = await new WebInteractExt(null, null, null).getCoreServerEventLogs()
  //     const logFile = await fs.readFileSync(wdLogPath)
  //     await this.add('Core Server event log', logFile, 'text/plain')
  // }

  public static async attachInteractLog() {
    const fileName = process.env.PWD + '/log/' + (await this.getLogfileName());
    const logFile = await fs.readFileSync(fileName);
    await this.add('Interact log', logFile, 'text/plain');
  }

  public static async attachWebDriverLogs() {
    const wdLogPath = await new WebInteractExt(null, null, null).getWebDriverLogs();
    const logFile = await fs.readFileSync(wdLogPath);
    await this.add('WebDriver Log', logFile, 'text/plain');
  }

  // async attachAppiumLog () {
  //     const appiumLog = await new WebInteractExt(null, null, null).getAppiumLog()
  //     await this.add('Appium Log', appiumLog, 'text/plain')
  // }

  public static async add(attachmentName, buffer, type) {
    const globalAny: any = global;
    const allureReporter = globalAny.allure;
    if (allureReporter) {
      await allureReporter.addAttachment(attachmentName, buffer, type);
    }
  }

  public static getLogfileName() {
    const today = new Date();
    const dd = today.getDate();
    const mm = today.getMonth() + 1;
    const yyyy = today.getFullYear();

    const fileName = `${yyyy}_${mm}_${dd}_logging.log`;
    return fileName;
  }
}
