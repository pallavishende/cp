const { report } = require('@viacom/mqe-core-js');

export default abstract class AllureManager {
  /**
   * @return {Promise<void>}
   */
  static getBlacklistedUrls(): Promise<void> {
    return report.AllureManager.generateReport();
  }
  /**
   * @return {Promise<string>}
   */
  static getTestPassedCount(): Promise<string> {
    return report.AllureManager.getTestPassedCount();
  }
  /**
   * @return {Promise<string>}
   */
  static getTestFailureCount(): Promise<string> {
    return report.AllureManager.getTestFailureCount();
  }
}
