import { NgModule, ModuleWithProviders, APP_INITIALIZER, Injector } from '@angular/core';
import { InjectionToken } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Store } from '@ngrx/store';
import { authActions } from '@content-platform/auth';
import { Router } from '@angular/router';

export const SKIP_AUTO_LOGIN = new InjectionToken('skip-auto-login');

const fakeUsers = [];
function createFakeUser(displayName: string, customId?: string) {
  if (displayName) {
    let [surname, givenName] = displayName.split(', ');
    givenName = givenName || '';
    surname = surname || '';
    const objectId = customId || `${givenName}-${surname}`.toLowerCase();
    return {
      objectId,
      givenName,
      surname,
      displayName,
      mail: `${givenName}.${surname}@fake.com`
    };
  }
}

export function addFakeUser(name, uuid?) {
  const user = createFakeUser(name, uuid);
  if (user) {
    fakeUsers.push(user);
  }
}

export function findFakeUsers(searchString: string) {
  searchString = searchString.toLowerCase();
  return fakeUsers.filter(user => {
    if (
      user.givenName.toLowerCase().startsWith(searchString) ||
      user.surname.toLowerCase().startsWith(searchString) ||
      user.displayName.toLowerCase().startsWith(searchString)
    ) {
      return true;
    }
    return false;
  });
}

export function findFakeUserById(uuid: string) {
  return fakeUsers.find(user => user.objectId === uuid) || createFakeUser('Fake, User', uuid);
}

export function init_app(injector: Injector) {
  return () => {
    if (window['_adalInstance']) {
      if (
        !sessionStorage.getItem('set-fake-login') ||
        sessionStorage.getItem('set-fake-login') === 'false'
      ) {
        return true;
      }
      window['_adalInstance'].getCachedToken = function(id) {
        if (/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/.test(id)) {
          return 'fake-token';
        }
        return 'fake-token';
      };
      window['_adalInstance'].getCachedUser = function() {
        return {
          profile: {
            oid: 'userid'
          },
          userName: 'test.user@fake.viacom.com'
        };
      };
      window['_adalInstance'].login = function() {
        const router: Router = injector.get(Router);
        const deeplinkUrl = location.pathname;
        const store = injector.get(Store);
        store.dispatch(new authActions.SetAdUser());
        setTimeout(() => {
          router.navigate([deeplinkUrl]);
        });
      };
      return Promise.resolve();
    }
    return true;
  };
}

/**
 * AutoLoginModule which includes the SKIP_AUTO_LOGIN injection token
 *
 * @export
 * @class AutoLoginModule
 */
@NgModule({
  imports: [CommonModule]
})
export class AutoLoginModule {
  static forRoot(e2e: boolean = false): ModuleWithProviders {
    return {
      ngModule: AutoLoginModule,
      providers: [
        e2e
          ? {
              provide: APP_INITIALIZER,
              useFactory: init_app,
              deps: [Injector],
              multi: true
            }
          : []
      ]
    };
  }
}
