export class DirectoryItem {
  private _type: string;
  private _name: string;
  private _date: Date;
  private _rights: { user: string; group: string; other: string };
  private _owner: string;
  private _group: string;
  private _target: string;
  private _sticky: boolean;

  get type(): string {
    return this._type;
  }

  set type(value: string) {
    this._type = value;
  }

  get name(): string {
    return this._name;
  }

  set name(value: string) {
    this._name = value;
  }

  get date(): Date {
    return this._date;
  }

  set date(value: Date) {
    this._date = value;
  }

  get rights(): { user: string; group: string; other: string } {
    return this._rights;
  }

  set rights(value: { user: string; group: string; other: string }) {
    this._rights = value;
  }

  get owner(): string {
    return this._owner;
  }

  set owner(value: string) {
    this._owner = value;
  }

  get group(): string {
    return this._group;
  }

  set group(value: string) {
    this._group = value;
  }

  get target(): string {
    return this._target;
  }

  set target(value: string) {
    this._target = value;
  }

  get sticky(): boolean {
    return this._sticky;
  }

  set sticky(value: boolean) {
    this._sticky = value;
  }
}
