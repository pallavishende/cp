const Emailer = require('@viacom/mqe-core-js').report.Emailer;

export abstract class Reporter {
  static async sendReportResults(result, subject, recipients, reportUrl) {
    const mailBody = `<b>Test run complete</b><br><br>
    Tests passed: ${result.testPassedCount}<br>
    Tests failed: ${result.testFailureCount}<br>
    Tests skipped: ${result.testSkippedCount}<hr>
    A detailed functional report is available: <a href=${reportUrl}>report</a><br><br>
    QA Automation`;
    if (recipients !== null || recipients !== undefined) {
      await Emailer.sendEmail('NOREPLY@dteqa.com', recipients, subject, mailBody);
    }
  }
}
