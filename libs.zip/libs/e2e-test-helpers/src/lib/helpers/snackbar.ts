import { browser, ExpectedConditions, $ } from 'protractor';

/**
 * Uses protractor to wait for the snackbar element to dissapear, used for notifications.
 *
 * Example:
 * ```ts
 * it('should hide menu when clicking on the apps icon again', async () => {
 *  await helpers.waitForSnackbarToLeave();
 *  await page.header.applicationMenu.open();
 *
 *  expect(page.header.applicationMenu.getMenuItemsCount()).toBe(2);
 *  page.header.applicationMenu.clickMenuIcon();
 * });
 * ```
 *
 * @export
 * @returns { Promise<boolean> }
 */
export function waitForSnackbarToLeave() {
  return browser.wait(
    ExpectedConditions.not(ExpectedConditions.presenceOf($('snack-bar-container'))),
    5000,
    'Snackbar did not dissapear in time'
  );
}
