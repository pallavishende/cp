const { report } = require('@viacom/mqe-core-js');

export default abstract class UploadManager {
  /**
   * @return {Promise<void>}
   */
  static uploadReportToS3(): Promise<void> {
    return report.UploadManager.uploadReportToS3();
  }
}
