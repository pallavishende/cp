export interface ImageInteract {
  /**
   * Initiates the image element and prepares it on the server. NOTE - this should be the first call in an Image Interact command
   * when executing against an image element.
   */
  initElement(): ImageInteract;

  /**
   * Executes the functions in `this.commandQueue`. This makes chaining available for WebInteract
   */
  execute(): Promise<any>;

  /**
   * Returns the current locator path of the current locator image.
   */
  getLocator(): Promise<string>;

  /**
   * Returns the current locator simple name of the current locator image.
   */
  getLocatorSimpleName(): Promise<string>;

  /**
   * Overrides the default image minimum similarity match. The new setting lasts only until a new waitFor calls is
   * performed or a new element find is initiated. Setting this to a lower value will reduce the max requirement
   * match on an image - meaning the lower the value, the more likely you are to get a match, but the less likely
   * it is to be a valid find.
   */
  setMinImageMatch(minimumMatchValue: number): ImageInteract;

  /**
   * Overrides the default element timeout used for all 'waitFor' method calls on an element.
   * The new timeout lasts only until a new waitFor calls is * performed or a new element find is initiated.
   */
  setTimeout(timeoutInSec: number): ImageInteract;

  /**
   * Overrides the default element locator as passed to the constructor.
   *
   * @param {String} locatorSource The new locator source - either a absolute path to a local image file, or a url to an image.
   * @return {*} defReturnValue()
   */
  setLocator(locatorSource: string): ImageInteract;

  /**
   * Resizes element locator image to the desired width/height.
   *
   * @param {Number} imageWidth The new image width to resize the image to.
   * @param {Number} imageHeight The new image height to resize the image to.
   * @return {*} defReturnValue()
   */
  resizeLocator(imageWidth: number, imageHeight: number): ImageInteract;

  /**
   * Pauses the test execution and causes the thread to sleep for the indicated amount of time in milliseconds.
   */
  pause(waitTimeInMS: number): ImageInteract;

  /**
   * Checks for the presence of the element until the provided timeout expires, and returns true or false.
   *
   */
  isPresent(timeoutInSec: number): ImageInteract;

  /**
   * Waits for an element to be present before timing out and throwing an exception.
   */
  waitForPresent(): ImageInteract;

  /**
   * Waits for an element to NOT be present before timing out and throwing an exception.
   */
  waitForNotPresent(): ImageInteract;

  /**
   * Gets the text from the matching element provided by the locator.
   * @param {String} languageCode - The 3 char iso code of the language of the text in the image.
   */
  getText(languageCode: string): Promise<string>;

  /**
   * Returns the location of the element in a x,y point object. The location point is the uppermost, upperleft
   * point of the found element.
   */
  getLocation(): Promise<{ x: number; y: number }>;

  /**
   * Gets the element size in a width,height dimension object.
   */
  getSize(): Promise<{ x: number; y: number }>;

  /**
   * Clicks the element. The click occurs at the uppermost, upperleft point of the element.
   */
  click(): ImageInteract;

  /**
   * Types a text string into an element.
   */
  type(text: string): ImageInteract;

  /**
   * Sends a keyboard keycode to the screen/image under test.
   */
  sendKeycode(keycode: number): ImageInteract;

  /**
   * Uploads a file using the default file manager of the OS.
   *
   * @param {String} fileToUpload The File to upload to the website under test.
   * @return {String} The name of the uploaded file for detection on the webpage
   */
  uploadFile(fileToUpload: string): Promise<string>;
}
