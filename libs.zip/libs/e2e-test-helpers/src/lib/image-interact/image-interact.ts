import { image } from '@viacom/mqe-core-js';
import CoreServerHttpClient from '@viacom/mqe-core-js/build/helpers/CoreServerHttpClient';
import Logger from '@viacom/mqe-core-js/build/helpers/Logger';
import { ImageInteract } from './image-interact-interface';

export class ImageInteractExt implements ImageInteract {
  private httpClient;
  private logger;
  private interact: any;

  constructor(locator: string, locatorSimpleName: string) {
    this.interact = new image.Interact(locator, locatorSimpleName).initElement();
    this.httpClient = new CoreServerHttpClient();
    this.logger = Logger.getLogger('ImageInteract');
  }

  initElement(): ImageInteract {
    return this.interact.initElement();
  }

  public execute(): Promise<any> {
    return this.interact.execute();
  }

  getLocator(): Promise<string> {
    return this.interact.getLocator();
  }

  getLocatorSimpleName(): Promise<string> {
    return this.interact.getLocatorSimpleName();
  }

  setMinImageMatch(minimumMatchValue: number): ImageInteract {
    return this.interact.setMinImageMatch(minimumMatchValue);
  }

  setTimeout(timeoutInSec: number): ImageInteract {
    return this.interact.setTimeout(timeoutInSec);
  }

  setLocator(locatorSource: string): ImageInteract {
    return this.interact.setLocator(locatorSource);
  }

  resizeLocator(imageWidth: number, imageHeight: number): ImageInteract {
    return this.interact.resizeLocator(imageWidth, imageHeight);
  }

  pause(waitTimeInMS: number): ImageInteract {
    return this.interact.pause(waitTimeInMS);
  }

  isPresent(timeoutInSec: number): ImageInteract {
    return this.interact.pause(timeoutInSec);
  }

  waitForPresent(): ImageInteract {
    return this.interact.waitForPresent();
  }

  waitForNotPresent(): ImageInteract {
    return this.interact.waitForNotPresent();
  }

  getText(languageCode: string): Promise<string> {
    return this.interact.getText(languageCode);
  }

  getLocation(): Promise<{ x: number; y: number }> {
    return this.interact.getLocation();
  }

  getSize(): Promise<{ x: number; y: number }> {
    return this.interact.getSize();
  }

  click(): ImageInteract {
    return this.interact.click();
  }

  type(text: string): ImageInteract {
    return this.interact.type(text);
  }

  sendKeycode(keycode: number): ImageInteract {
    return this.interact.sendKeycode(keycode);
  }

  uploadFile(fileToUpload: string): Promise<string> {
    return this.interact.uploadFile();
  }
}
