const JasmineSpecReporter = require('jasmine-spec-reporter');
const colors = require('colors');

const SPEC_START_MESSAGE = specFullName => `\n====== SPEC STARTED: ${specFullName} =======\n`;

const ColorProcessor = function(configuration) {};
ColorProcessor.prototype = new JasmineSpecReporter.DisplayProcessor();
ColorProcessor.prototype.displaySuccessfulSpec = function(spec, log) {
  return colors.blue('\n' + log);
};
ColorProcessor.prototype.displayFailedSpec = function(spec, log) {
  return colors.red('\n' + log);
};
ColorProcessor.prototype.displaySpecErrorMessages = function(spec, log) {
  return colors.red(log + '\n');
};
ColorProcessor.prototype.displaySummaryErrorMessages = function(spec, log) {
  return colors.red('\n' + log);
};

export const SPEC_REPORTER = new JasmineSpecReporter.SpecReporter({
  spec: {
    displayErrorMessage: true,
    displayStacktrace: true,
    displaySuccessful: true,
    displayFailed: true,
    displayPending: true,
    displayDuration: true
  },
  summary: {
    displaySuccessful: true,
    displayFailed: true,
    displayErrorMessages: true,
    displayStacktrace: true,
    displayPending: true,
    displayDuration: true
  },
  colors: {
    enabled: true,
    successful: 'green',
    failed: 'red',
    pending: 'yellow'
  },
  customProcessors: [ColorProcessor]
});

export const CUSTOM_REPORTER = {
  specStarted: spec => {
    spec.getFullName = () => spec.fullName;
    if (jasmine.getEnv().specFilter(spec)) {
      console.log(colors.green(SPEC_START_MESSAGE(spec.fullName)));
    }
  }
};
