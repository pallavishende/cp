export abstract class JavaScriptCommands {
  static TOKEN_REQUEST = function(userId: string) {
    return `var currentToken;window._adalInstance.acquireToken('${userId}', 
        (_message, token) => { currentToken=token;}); return currentToken;`;
  };
}
