import { LocType } from '../constants';
import { WebInteractExt } from '../web-interact/impl/web-interact';
import Logger from '@viacom/mqe-core-js/build/helpers/Logger';

export abstract class JavascriptExecutor {
  private static logger = Logger.getLogger('JavascriptExecutor');

  public static executeScript(command: string): Promise<string> {
    this.logger.debug('Execute JavaScript command:' + command);
    return new WebInteractExt(LocType.XPATH, '//body', 'Body page element')
      .waitForPresent()
      .executeJavascript(command)
      .execute();
  }
}
