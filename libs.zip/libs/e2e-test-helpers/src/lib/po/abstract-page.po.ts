import { WebInteractExt } from '../web-interact';
import { DebugFlagsPopup } from './debug-flags-popup.po';
import { TimeoutPopup } from './timeout-popup.po';
const TEST_URL = process.env.TEST_URL;

export abstract class AbstractPage {
  protected _debugPopup: DebugFlagsPopup;
  protected _timeoutPopup: TimeoutPopup;

  protected constructor() {
    this._debugPopup = new DebugFlagsPopup();
    this._timeoutPopup = new TimeoutPopup();
  }

  get(url?: string): Promise<void> {
    const globalAny: any = global;
    let fullUrl: string;
    fullUrl = `${globalAny.baseUrl}/${globalAny.appName}`;
    if (url) {
      fullUrl = `${fullUrl}/${url}/`;
    }

    return new WebInteractExt(null, null, null).openUrl(fullUrl).execute();
  }

  // Returns url depending on how tests are run Jasmine/Jest
  getFinalUrl(): string {
    const globalAny: any = global;
    if (globalAny.baseUrl !== undefined) {
      return globalAny.baseUrl;
    }
    return TEST_URL === undefined ? location.href : TEST_URL;
  }

  get debugPopup(): DebugFlagsPopup {
    return this._debugPopup;
  }

  get timeoutPopup(): TimeoutPopup {
    return this._timeoutPopup;
  }
}
