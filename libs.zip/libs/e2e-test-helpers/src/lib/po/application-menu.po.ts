import { AppsList } from '../constants/apps-list';
import { Attribute, LocType, TimeConstants } from '../constants/index';
import { WebInteract } from '../web-interact/web-interact-interface';
import { WebInteractArray } from '../web-interact/web-interact-array-int';
import { WebInteractExt } from '../web-interact/impl/web-interact';

/**
 * Page Object for the application menu
 *
 * @export
 * @class ApplicationMenu
 */
export class ApplicationMenu {
  private applicationMenuDropdown: WebInteract;
  private applicationMenu: WebInteract;
  private menuItems: WebInteractArray;

  constructor(container: WebInteract) {
    this.applicationMenuDropdown = container.getChild(
      ".//mat-icon[contains(@class, 'apps-icon')]",
      'Application menu dropdown'
    );
    this.applicationMenu = new WebInteractExt(
      LocType.XPATH,
      ".//div[contains(@class, 'applications-menu')]",
      'Applications menu'
    );
    this.menuItems = this.applicationMenu.getChilds('.//mat-grid-tile', 'Applications menu items');
  }

  /**
   * Opens the application menu.
   *
   * @returns { Promise<void> } Resolves promise when menu appears
   */
  async open() {
    await this.applicationMenuDropdown
      .waitForVisible()
      .click()
      .execute();
    return this.waitForMenuToShow();
  }

  /**
   * Closes the application menu.
   *
   * @returns { Promise<void> } Resolves promise when menu dissapears
   */
  async close() {
    return this.applicationMenu
      .waitForVisible()
      .click()
      .pause(TimeConstants.MS._1000)
      .execute();
  }

  /**
   * Used to click the application icon when the menu is open, as
   * there is an overlay otherwise for the button click
   */
  clickMenuIcon() {
    return this.applicationMenuDropdown
      .waitForPresent()
      .mouseOver()
      .click()
      .execute();
  }

  /**
   *
   * @returns { Promise<number> } Menu item count
   */
  getMenuItemsCount() {
    return this.menuItems.count();
  }

  /**
   * Gets text of the given menu item by index.
   *
   * @param {number} index
   * @returns { Promise<string> } string of the menu text.
   */
  getMenuItemText(index: number) {
    return this.menuItems.get(index).then(item => item.waitForVisible().getText());
  }

  /**
   * Waits for the application menu to appear
   *
   */
  private async waitForMenuToShow() {
    await this.applicationMenu.waitForVisible().execute();
  }

  private getAppItem(application: AppsList) {
    const appIndex = (() => {
      switch (application) {
        case AppsList.HOME:
          return 0;
        case AppsList.ADMINISTRATION:
          return 1;
        case AppsList.GLOBAL_ENTRY:
          return 2;
        case AppsList.SANDBOX:
          return 3;
        default:
          throw new Error('Unsupported application.');
      }
    })();
    return this.menuItems.get(appIndex);
  }

  switchToApp(application: AppsList): void {
    this.getAppItem(application).then(async item => {
      await item
        .waitForPresent()
        .click()
        .execute();
    });
  }

  async getIconSrc(application: AppsList): Promise<string> {
    return this.getAppItem(application).then(item => {
      return item
        .getChild('.//img', 'Image')
        .waitForVisible()
        .getAttributeValue(Attribute.NAME.SRC);
    });
  }

  async isMenuVisible() {
    return this.applicationMenu.isVisible(TimeConstants.SEC._3);
  }

  async isMenuPresent() {
    return this.applicationMenu.isPresent(TimeConstants.SEC._3);
  }
}
