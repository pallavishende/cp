// tslint:disable-next-line:nx-enforce-module-boundaries
import { WebInteract, WebInteractArray, WebInteractExt } from '../web-interact/index';
// tslint:disable-next-line:nx-enforce-module-boundaries
import { Attribute, LocType } from '../constants/index';
// tslint:disable-next-line:nx-enforce-module-boundaries
import { CoreActionsUtils } from '../utils/core-actions-utils';

export class DebugFlagsPopup {
  protected containerElement: WebInteract;
  protected flagInputs: WebInteractArray;
  protected flagCheckboxes: WebInteractArray;
  protected cancelBtn: WebInteract;
  protected okBtn: WebInteract;
  protected impersonateDropDown: WebInteract;

  constructor() {
    this.containerElement = new WebInteractExt(
      LocType.XPATH,
      './/app-debug-flags-dialog',
      'Debug Flags popup'
    );
    this.flagInputs = this.containerElement.getChilds(
      ".//div[contains(@class, 'mat-menu-content')]",
      'Input field'
    );
    this.flagCheckboxes = this.containerElement.getChilds(
      ".//mat-checkbox[contains(@class, 'mat-checkbox')]",
      'Input checkbox'
    );
    this.cancelBtn = this.containerElement.getChild(
      ".//button//span[text()='Cancel']",
      'Cancel button'
    );
    this.okBtn = this.containerElement.getChild(".//button//span[text()='OK']", 'Ok button');
    this.impersonateDropDown = this.containerElement.getChild(
      ".//div[@role='listbox']/mat-option",
      'Impersonate dropdown'
    );
  }

  /**
   * Waits for the Debug Flags popup to appear
   *
   */
  waitForOpened(timeOut?: number): Promise<void> {
    if (timeOut !== undefined) {
      this.okBtn.setTimeout(timeOut);
    }
    return this.okBtn.waitForVisible().execute();
  }

  async closeDebugPopup(): Promise<void> {
    await this.cancelBtn
      .waitForVisible()
      .click()
      .execute();
    return this.containerElement.waitForNotVisible().execute();
  }

  async applyFlags(): Promise<void> {
    await this.okBtn
      .waitForVisible()
      .click()
      .execute();
    return this.containerElement.waitForNotVisible().execute();
  }

  /**
   * get input field
   * @param field - name of field placeholder
   */
  private getInputItem(field: string): WebInteract {
    return this.containerElement.getChild(
      `.//div[contains(text(),'${field}')]/.././/input`,
      `Input item'`
    );
  }

  /**
   * clear input field
   */
  async clearField(item: string): Promise<void> {
    return CoreActionsUtils.clearTextUsingKeys(this.getInputItem(item));
  }

  /**
   * enter text to input field
   * @param item - particular input field
   * @param text - string to loctype
   * @param index (optional) - field number (for fields with similar placeholders)
   */
  async type(item: string, timoutText: string): Promise<void> {
    return this.getInputItem(item)
      .waitForVisible()
      .clearText()
      .sendKeys(timoutText)
      .execute();
  }

  clickCheckBox(field: string): Promise<void> {
    return this.flagCheckboxes.get(+field).then(elem =>
      elem
        .waitForVisible()
        .click()
        .execute()
    );
  }

  selectFirstFromDropdown(): Promise<void> {
    return this.impersonateDropDown
      .waitForVisible()
      .click()
      .execute();
  }

  async isChecked(field: string): Promise<boolean> {
    const elem = await this.flagCheckboxes.get(+field);
    const state = await elem.waitForVisible().getAttributeValue(Attribute.NAME.CLASS);
    return state.includes('checked');
  }
}
