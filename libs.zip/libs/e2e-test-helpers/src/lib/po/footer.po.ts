import { WebInteract, WebInteractExt } from '../web-interact';
import { CSSProperties, LocType } from '../constants';

export class Footer {
  private containerElement: WebInteract;
  private buildInfo: WebInteract;

  constructor() {
    this.containerElement = new WebInteractExt(
      LocType.XPATH,
      "//div[contains(@class, 'footer-container')]",
      'Footer container'
    );
    this.buildInfo = this.containerElement.getChild(
      ".//div[contains(@class, 'version-container')]",
      'Build info message'
    );
  }

  getHeight() {
    return this.containerElement.waitForPresent().getCssValue(CSSProperties.HEIGHT);
  }

  getBiuldInfo(): Promise<string> {
    return this.buildInfo.waitForPresent().getText();
  }
}
