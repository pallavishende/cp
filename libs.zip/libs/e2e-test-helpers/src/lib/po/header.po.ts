import { ApplicationMenu } from './application-menu.po';
import { Comparison } from '../utils/comparator/comparison';
import { WebInteract } from '../web-interact/web-interact-interface';
import { LocType, TimeConstants, Attribute } from '../constants/index';
import { WebInteractExt } from '../web-interact/impl/web-interact';
import { UserMenu } from './user-menu.po';

/**
 * Nav bar header protractor page object
 *
 * @export
 * @class Header
 */
export class Header {
  private containerElement: WebInteract;
  private logo: WebInteract;
  private appTitle: WebInteract;
  private userName: WebInteract;
  private userArrowDropDown: WebInteract;
  private userAvatar: WebInteract;
  private appsMenuBtn: WebInteract;
  private loginBtn: WebInteract;
  private _applicationMenu: ApplicationMenu;
  private _userMenu: UserMenu;

  constructor() {
    this.containerElement = new WebInteractExt(LocType.XPATH, '//mat-toolbar', 'Header container');
    this.logo = this.containerElement.getChild(".//img[contains(@class, 'logo')]", 'Logo');
    this.appTitle = this.containerElement.getChild(
      ".//div[contains(@class, 'app-title')]",
      'Application title'
    );
    this.userName = this.containerElement.getChild(
      ".//button[contains(@class, 'user-name-button')]",
      'User Name'
    );
    this.loginBtn = this.userName.getChild(
      ".//span[contains(@class, 'mat-button-wrapper')]",
      'Login button'
    );
    this.userAvatar = this.userName.getChild('.//mat-icon[1]', 'User Avatar');
    this.userArrowDropDown = this.userName.getChild('.//mat-icon[2]', 'User Arrow dropdown');
    this.appsMenuBtn = new WebInteractExt(
      LocType.XPATH,
      './/app-applications-menu//button',
      'Apps menu'
    );
    this._applicationMenu = new ApplicationMenu(this.containerElement);
    this._userMenu = new UserMenu(this.containerElement);
  }

  get applicationMenu(): ApplicationMenu {
    return this._applicationMenu;
  }

  get userMenu(): UserMenu {
    return this._userMenu;
  }

  isHeaderContainerVisible(): Promise<boolean> {
    return this.containerElement.isVisible(TimeConstants.SEC._3);
  }

  /**
   * Gets displayed username
   *
   * @returns { Promise<string> }
   */
  getUserName(): Promise<string> {
    return this.userName.waitForPresent().getText();
  }

  /**
   * Clicks the username icon, to display the login/logout menu
   *
   */
  clickLogo(): Promise<void> {
    return this.logo
      .waitForPresent()
      .click()
      .pause(1000)
      .execute();
  }

  /**
   * Gets application title
   *
   * @returns { Promise<string> }
   */
  getAppTitle(): Promise<string> {
    return this.appTitle.waitForPresent().getText();
  }

  /**
   * Gets value of Logo 'src' attribute
   *
   * @returns { Promise<boolean> }
   */
  getLogoImgSrc(): Promise<string> {
    return this.logo.waitForVisible().getAttributeValue(Attribute.NAME.SRC);
  }

  /**
   * Compares the application logo with the reference.
   *
   * @param reference - The image name from 'assets/baseline/' for comparison.
   * @returns { Promise<number> } - where number is the percentage of the difference.
   */
  compareLogo(reference): Promise<number> {
    return Comparison.compareElement(this.logo, reference);
  }

  /**
   * Checks if the header is displayed on the page
   *
   * @returns { Promise<boolean> }
   */
  isHeaderVisible(): Promise<boolean> {
    return this.containerElement.isVisible(TimeConstants.SEC._3);
  }

  /**
   * Checks if the logo is displayed in the header
   *
   * @returns { Promise<boolean> }
   */
  isLogoVisible(): Promise<boolean> {
    return this.logo.isVisible(TimeConstants.SEC._3);
  }

  /**
   * Checks if the login button is displayed in the header
   *
   * @returns { Promise<boolean> }
   */
  isLoginBtnVisible(): Promise<boolean> {
    return this.loginBtn.isVisible(TimeConstants.SEC._3);
  }

  /**
   * Checks if the username is displayed in the header
   *
   * @returns { Promise<boolean> }
   */
  isUserNameVisible(): Promise<boolean> {
    return this.userName.isVisible(TimeConstants.SEC._3);
  }

  /**
   * Checks if the user arrow icon is displayed in the header
   *
   * @returns { Promise<boolean> }
   */
  isUserArrowDropDownVisible(): Promise<boolean> {
    return this.userArrowDropDown.isVisible(TimeConstants.SEC._3);
  }

  /**
   * Checks if the user avatar is displayed in the header
   *
   * @returns { Promise<boolean> }
   */
  isUserAvatarVisible(): Promise<boolean> {
    return this.userAvatar.isVisible(TimeConstants.SEC._3);
  }

  /**
   * Checks if the Applications menu button is displayed in the header
   *
   * @returns { Promise<boolean> }
   */
  isAppsMenuVisible(): Promise<boolean> {
    return this.appsMenuBtn.isVisible(TimeConstants.SEC._3);
  }

  clickContainer(): Promise<void> {
    return this.containerElement
      .waitForPresent()
      .click()
      .pause(TimeConstants.MS._1000)
      .execute();
  }
}
