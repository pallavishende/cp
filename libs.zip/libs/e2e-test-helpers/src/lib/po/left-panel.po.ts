// tslint:disable-next-line:nx-enforce-module-boundaries
import {
  LocType,
  TimeConstants,
  Attribute
} from '../../../../../libs/e2e-test-helpers/src/lib/constants';
// tslint:disable-next-line:nx-enforce-module-boundaries
import {
  WebInteract,
  WebInteractArray,
  WebInteractExt
} from '../../../../../libs/e2e-test-helpers/src/lib/web-interact';

export class LeftPanel {
  protected _leftPanel: WebInteract;
  protected expandCollapseBtn: WebInteract;
  protected sectionButtons: WebInteractArray;
  protected sectionsName: WebInteractArray;
  protected readonly collapsedContainer = new WebInteractExt(
    LocType.XPATH,
    './/mat-sidenav-content',
    'Collapsed container'
  );
  protected readonly expandedContainer = new WebInteractExt(
    LocType.XPATH,
    ".//mat-sidenav[contains(@class, 'mat-drawer')]",
    'Expanded container'
  );

  constructor() {
    this.initCollapsedLocators();
  }

  get leftPanel(): WebInteract {
    return this._leftPanel;
  }

  async updateLocators() {
    (await this.isLeftPanelExpanded()) ? this.initExpandedLocators() : this.initCollapsedLocators();
  }

  private initCollapsedLocators() {
    this._leftPanel = this.collapsedContainer;
    this.initLocators();
  }

  private initExpandedLocators() {
    this._leftPanel = this.expandedContainer;
    this.initLocators();
  }

  private initLocators() {
    this.expandCollapseBtn = this._leftPanel.getChild(
      ".//div[contains(@class, 'sidenav-actions') and .//mat-icon]",
      'Expand Collapse buttons'
    );
    this.sectionButtons = this._leftPanel.getChilds(
      ".//a[contains(@class, 'mat-list-item')]",
      'Sections buttons'
    );
    this.sectionsName = this._leftPanel.getChilds(
      ".//span[contains(@class, 'matItem')]",
      'Sections name'
    );
  }

  isLeftPanelDisplayed(): Promise<boolean> {
    return this._leftPanel.isVisible(TimeConstants.SEC._3);
  }

  isLeftPanelExpanded() {
    return this.expandedContainer
      .waitForPresent()
      .getAttributeValue(Attribute.NAME.STYLE)
      .then(style => style.includes('visible;'));
  }

  getLPsize() {
    return this._leftPanel.getSize();
  }

  isExpandBtnVisible() {
    return this.expandCollapseBtn.isVisible(TimeConstants.SEC._5);
  }

  async expandCollapseLP() {
    await this.expandCollapseBtn
      .waitForPresent()
      .click()
      .pause(TimeConstants.MS._1000)
      .execute();
    await this.updateLocators();
  }

  getLPClass() {
    return this._leftPanel.waitForPresent().getAttributeValue(Attribute.NAME.CLASS);
  }

  getMenuItemsCount() {
    return this.sectionButtons.count();
  }

  getMenuItemsName(index: number) {
    return this.sectionsName.get(index).then(element => element.waitForPresent().getText());
  }

  isIconActive(index: number): Promise<boolean> {
    return this.sectionButtons
      .get(index)
      .then(element => element.waitForPresent().getAttributeValue(Attribute.NAME.CLASS))
      .then(attribute => attribute.includes(Attribute.VALUE.ACTIVE_ROUTE));
  }

  isMenuItemVisible(index: number): Promise<boolean> {
    return this.sectionButtons.get(index).then(element => {
      return typeof element !== 'undefined' ? element.isVisible(TimeConstants.SEC._1) : false;
    });
  }

  clickMenuItem(index: number): Promise<void> {
    return this.sectionButtons.get(index).then(element =>
      element
        .waitForPresent()
        .click()
        .pause(TimeConstants.MS._2000)
        .execute()
    );
  }
}
