// tslint:disable-next-line:nx-enforce-module-boundaries
import { WebInteract, WebInteractExt } from '../web-interact';
// tslint:disable-next-line:nx-enforce-module-boundaries
import { LocType, TimeConstants } from '../constants';
import { AbstractPage } from './abstract-page.po';

export class LoginPage extends AbstractPage {
  private emailField: WebInteract;
  private nextButton: WebInteract;
  private viacomLoginField: WebInteract;
  private viacomPasswordField: WebInteract;
  private viacomLogOn: WebInteract;
  private yesButton: WebInteract;
  private pickAnAccountMenu: WebInteract;
  private useAnotherAccount: WebInteract;

  constructor() {
    super();
    this.emailField = new WebInteractExt(LocType.XPATH, ".//input[@type='email']", 'Email field');
    this.nextButton = new WebInteractExt(LocType.XPATH, ".//input[@value='Next']", 'Next button');
    this.viacomLoginField = new WebInteractExt(
      LocType.XPATH,
      ".//input[@id = 'Enter user name']",
      'Viacom login field'
    );
    this.viacomPasswordField = new WebInteractExt(
      LocType.XPATH,
      ".//input[@type='password']",
      'Viacom password field'
    );
    this.viacomLogOn = new WebInteractExt(
      LocType.XPATH,
      ".//input[@value='Log On']",
      'Viacom Log On button'
    );
    this.yesButton = new WebInteractExt(LocType.XPATH, ".//input[@value='Yes']", 'Yes button');
    this.pickAnAccountMenu = new WebInteractExt(
      LocType.XPATH,
      "//div[@id='loginHeader' and text()='Pick an account']",
      'Pick an account menu'
    );
    this.useAnotherAccount = new WebInteractExt(
      LocType.XPATH,
      "//div[@id='otherTileText']",
      'Use another account option'
    );
  }

  async get(): Promise<void> {
    return super.get();
  }

  isPickAnAccountMenuVisible(): Promise<boolean> {
    return this.pickAnAccountMenu.isVisible(TimeConstants.SEC._3);
  }

  clickUseAnotherAccount(): Promise<void> {
    return this.useAnotherAccount
      .setTimeout(TimeConstants.SEC._10)
      .waitForVisible()
      .click()
      .execute();
  }

  async setEmail(email: string): Promise<void> {
    await this.emailField
      .setTimeout(TimeConstants.SEC._10)
      .waitForVisible()
      .sendKeys(email)
      .execute();
    return this.nextButton
      .waitForVisible()
      .click()
      .execute();
  }

  async setViacomEmailAndPassword(email: string, pass: string): Promise<void> {
    await this.viacomLoginField
      .setTimeout(TimeConstants.SEC._10)
      .waitForVisible()
      .sendKeys(email)
      .execute();
    await this.viacomPasswordField
      .waitForVisible()
      .sendKeys(pass)
      .execute();
    return this.viacomLogOn
      .waitForVisible()
      .click()
      .execute();
  }

  setStayInAccount(): Promise<void> {
    return this.yesButton
      .setTimeout(TimeConstants.SEC._10)
      .waitForVisible()
      .click()
      .execute();
  }
}
