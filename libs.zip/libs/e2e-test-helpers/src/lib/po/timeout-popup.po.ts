import {
  WebInteract,
  WebInteractExt
} from '../../../../../libs/e2e-test-helpers/src/lib/web-interact';
import { LocType, TimeConstants } from '../../../../../libs/e2e-test-helpers/src/lib/constants';

export class TimeoutPopup {
  protected containerElement: WebInteract;
  protected popupTitle: WebInteract;
  protected popupTextContainer: WebInteract;
  protected popupText: WebInteract;
  protected popupTimer: WebInteract;
  protected yesBtn: WebInteract;
  protected noBtn: WebInteract;

  constructor() {
    this.containerElement = new WebInteractExt(
      LocType.XPATH,
      './/mat-dialog-container//app-auto-logout-confirmation-dialog',
      'Timeout popup'
    );
    this.popupTitle = this.containerElement.getChild('.//h3', 'Popup title');
    this.popupTextContainer = this.containerElement.getChild(
      ".//div[contains(@class, 'mat-dialog-content')]",
      'Text container'
    );
    this.popupText = this.containerElement.getChild('.//p', 'Popup text');
    this.popupTimer = this.popupTextContainer.getChild('.//label', 'Popup timer');
    this.yesBtn = this.containerElement.getChild(
      ".//button//span[contains(text(),'Yes')]",
      'Popup timer'
    );
    this.noBtn = this.containerElement.getChild(
      ".//button//span[contains(text(),'No')]",
      'Popup timer'
    );
  }

  waitForOpened(timeOut?: number): Promise<void> {
    if (timeOut !== undefined) {
      this.popupTitle.setTimeout(timeOut);
    }
    return this.popupTitle.waitForVisible().execute();
  }

  isPopupVisible(): Promise<boolean> {
    return this.containerElement.isVisible(TimeConstants.SEC._1);
  }

  isPopupTitleVisible(): Promise<boolean> {
    return this.popupTitle.isVisible(TimeConstants.SEC._1);
  }

  isPopupTextVisible(): Promise<boolean> {
    return this.popupText.isVisible(TimeConstants.SEC._1);
  }

  isPopupTimerVisible(): Promise<boolean> {
    return this.popupTimer.isVisible(TimeConstants.SEC._1);
  }

  isYesBtnVisible(): Promise<boolean> {
    return this.yesBtn.isVisible(TimeConstants.SEC._1);
  }

  isNoBtnVisible(): Promise<boolean> {
    return this.noBtn.isVisible(TimeConstants.SEC._1);
  }

  async acceptExtention(): Promise<void> {
    await this.yesBtn
      .waitForVisible()
      .click()
      .execute();
    return this.containerElement.waitForNotVisible().execute();
  }

  async closeDebugPopup(): Promise<void> {
    await this.noBtn
      .waitForVisible()
      .click()
      .execute();
    return this.containerElement.waitForNotVisible().execute();
  }
}
