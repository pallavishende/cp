import { LocType, TimeConstants } from '../constants/index';
import { WebInteract } from '../web-interact/web-interact-interface';
import { WebInteractArray } from '../web-interact/web-interact-array-int';
import { WebInteractExt } from '../web-interact/impl/web-interact';

/**
 * Page Object for the user menu
 *
 * @export
 * @class ApplicationMenu
 */
export class UserMenu {
  private userMenuDropdown: WebInteract;
  private userMenu: WebInteract;
  private userMenuItems: WebInteractArray;

  constructor(container: WebInteract) {
    this.userMenuDropdown = container.getChild(
      ".//button[contains(@class, 'user-name-button')]",
      'User menu dropdown'
    );
    this.userMenu = new WebInteractExt(
      LocType.XPATH,
      ".//div[contains(@class, 'mat-menu-content')]",
      'User menu'
    );
    this.userMenuItems = this.userMenu.getChilds(
      ".//button[contains(@class, 'mat-menu-item')] ",
      'User menu items'
    );
  }

  /**
   * Opens the user menu.
   *
   * @returns { Promise<void> } Resolves promise when menu appears
   */
  async open() {
    await this.userMenuDropdown
      .waitForVisible()
      .click()
      .execute();
    return this.waitForMenuToShow();
  }

  /**
   * Closes the user menu.
   *
   * @returns { Promise<void> } Resolves promise when menu dissapears
   */
  close() {
    return this.userMenuDropdown
      .waitForVisible()
      .click()
      .pause(TimeConstants.MS._1000)
      .execute();
  }

  /**
   * Used to click the user menu item when the menu is open, as
   * there is an overlay otherwise for the button click
   */
  clickMenuIcon() {
    return this.userMenuDropdown
      .waitForPresent()
      .mouseOver()
      .click()
      .execute();
  }

  /**
   *
   * @returns { Promise<number> } Menu item count
   */
  getMenuItemsCount() {
    return this.userMenuItems.count();
  }

  /**
   * Gets text of the given menu item by index.
   *
   * @param {number} index
   * @returns { Promise<string> } string of the menu text.
   */
  getMenuItemText(index: number) {
    return this.userMenuItems.get(index).then(item =>
      item
        .waitForVisible()
        .getText()
        .then(text => text.trim())
    );
  }

  /**
   * Waits for the user menu to appear
   *
   */
  private async waitForMenuToShow() {
    await this.userMenu.waitForVisible().execute();
  }

  private getMenuUserItem(item: string): Promise<WebInteract> {
    return this.userMenuItems
      .filter(usr => {
        return usr
          .waitForVisible()
          .getText()
          .then(text => text.includes(item));
      })
      .first();
  }

  selectOption(item: string): Promise<void> {
    return this.getMenuUserItem(item).then(elem =>
      elem
        .waitForVisible()
        .click()
        .execute()
    );
  }

  isMenuItemVisible(item: string): Promise<boolean> {
    return this.getMenuUserItem(item).then(elem => elem.isVisible(TimeConstants.SEC._3));
  }

  isMenuVisible(): Promise<boolean> {
    return this.userMenu.isVisible(TimeConstants.SEC._3);
  }

  isMenuPresent(): Promise<boolean> {
    return this.userMenu.isPresent(TimeConstants.SEC._3);
  }
}
