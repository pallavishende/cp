import { CoreManagerHelper } from '../core-manager/core-manager-helper';
import TestAssetInfo from '@viacom/mqe-core-js/build/lab/TestAssetInfo';

export class ProxyManagerHelper {
  private static readonly DEFAULT_CAPS = {
    browser_type: CoreManagerHelper.DEFAULT_CAPS.MQEDesktopBrowserName,
    proxy_instance_port: CoreManagerHelper.DEFAULT_CAPS.MQEProxyPort,
    desktop_os_type: CoreManagerHelper.DEFAULT_CAPS.MQEDesktopOSPlatform,
    session_id: CoreManagerHelper.getSession(),
    proxy_server_port: '15001'
  };

  public static async initiateProxy(caps: Object = this.DEFAULT_CAPS) {
    TestAssetInfo.initInfo(caps);
  }
}
