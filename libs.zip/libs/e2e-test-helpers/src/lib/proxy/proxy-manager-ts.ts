import { proxy } from '@viacom/mqe-core-js';

export abstract class ProxyManagerTs {
  /**
   * Pass request rewrite rules
   * @param {string} requestFilter filter string
   * @return {Promise<boolean>} true or false
   */
  static applyRequestFilter(requestFilter: string): Promise<boolean> {
    return proxy.Manager.applyRequestFilter(requestFilter).then(
      res => String(res).toLowerCase() === 'true'
    );
  }

  /**
   * Pass request rewrite rules
   * @param {string} responseFilter filter string
   * @return {Promise<boolean>} true or false
   */
  static applyResponseFilter(responseFilter: string): Promise<boolean> {
    return proxy.Manager.applyResponseFilter(responseFilter).then(
      res => String(res).toLowerCase() === 'true'
    );
  }

  /**
   * Clear blacklisted URLs
   * @return {Promise<void>}
   */
  static clearBlackListedUrls(): Promise<void> {
    return proxy.Manager.clearBlackListedUrls();
  }

  /**
   * Clear whitelisted URLs
   * @return {Promise<void>}
   */
  static clearWhiteListedUrls(): Promise<void> {
    return proxy.Manager.clearWhiteListedUrls();
  }

  /**
   * Enable HAR Log
   * @return {Promise<boolean>} true or false
   */
  static enableHarLogCapture(): Promise<boolean> {
    return proxy.Manager.enableHarLogCapture().then(res => String(res).toLowerCase() === 'true');
  }

  /**
   * Enable wait for all requests
   * @param {string} quietPeriodInMs wait time
   * @param {string} timeoutInMs timeout
   * @return {Promise<void>}
   */
  static enableWaitForAllCalls(quietPeriodInMs: string, timeoutInMs: string): Promise<void> {
    return proxy.Manager.enableWaitForAllCalls(quietPeriodInMs, timeoutInMs);
  }

  /**
   * Get list of blacklisted URLs
   * @return {Promise<string>} URL list
   */
  static getBlacklistedUrls(): Promise<string> {
    return proxy.Manager.getBlacklistedUrls();
  }

  /**
   * Get HAR data as string
   * @returns {Promise<string>} har data as string
   */
  static getHarLogAsString(): Promise<string> {
    return proxy.Manager.getHarLogAsString();
  }

  /**
   * Gets the proxy instance port.
   * @return {Promise<string>} proxy instance port
   */
  static getProxyInstancePort(): Promise<string> {
    return proxy.Manager.getProxyInstancePort();
  }

  /**
   * Gets the proxy server port.
   * @return {Promise<string>} proxy server port
   */
  static getProxyServerPort(): Promise<string> {
    return proxy.Manager.getProxyServerPort();
  }

  /**
   * Get list of whitelisted URLs
   * @return {Promise<string>} true or false
   */
  static getWhitelistedUrls(): Promise<string> {
    return proxy.Manager.getWhitelistedUrls();
  }

  /**
   * Check if proxy instance running or not
   * @return {Promise<boolean>} true or false
   */
  static isProxyInstanceRunning(): Promise<boolean> {
    return proxy.Manager.isProxyInstanceRunning().then(res => String(res).toLowerCase() === 'true');
  }

  /**
   * Check if proxy server running or not
   * @return {Promise<boolean>} true or false
   */
  static isProxyServerRunning(): Promise<boolean> {
    return proxy.Manager.isProxyServerRunning().then(res => String(res).toLowerCase() === 'true');
  }

  /**
   * Restart proxy instance
   * @return {Promise<void>}
   */
  static resetProxy(): Promise<void> {
    return proxy.Manager.resetProxy();
  }

  /**
   * Set bandwidth throttling
   * @param {string} downstreamKbps downstream bandwidth
   * @param {string} upstreamKbps upstream bandwidth
   * @return {Promise<void>}
   */
  static setBandwidth(downstreamKbps: string, upstreamKbps: string): Promise<void> {
    return proxy.Manager.setBandwidth(downstreamKbps, upstreamKbps);
  }

  /**
   * Set blacklist URL
   * @param {string} urlPattern URL
   * @param {string} statusCodeToReturn http status code
   * @return {Promise<void>}
   */
  static setBlackListedUrls(urlPattern: string, statusCodeToReturn: string): Promise<void> {
    return proxy.Manager.setBlackListedUrls(urlPattern, statusCodeToReturn);
  }

  /**
   * Set request header
   * @param {string} header header name
   * @param {string} value header value
   * @return {Promise<void>}
   */
  static setHeader(header: string, value: string): Promise<void> {
    return proxy.Manager.setHeader(header, value);
  }

  /**
   * Set network latency
   * @param {string} latency latency value
   * @return {Promise<void> }
   */
  static setLatency(latency: string): Promise<void> {
    return proxy.Manager.setLatency(latency);
  }

  /**
   * Set proxy connection realted timeouts
   * @param {string} requestTimeout request timeout
   * @param {string} readTimeout request timeout
   * @param {string} connectionTimeout request timeout
   * @return {Promise<void>}
   */
  static setTimeouts(
    requestTimeout: string,
    readTimeout: string,
    connectionTimeout: string
  ): Promise<void> {
    return proxy.Manager.setTimeouts(requestTimeout, readTimeout, connectionTimeout);
  }

  /**
   * Set whitelist URL
   * @param {string} urlPattern URL
   * @param {string} statusCodeToReturn http status code
   * @return {Promise<void>}
   */
  static setWhiteListedUrls(urlPattern: string, statusCodeToReturn: string): Promise<void> {
    return proxy.Manager.setWhiteListedUrls(urlPattern, statusCodeToReturn);
  }
}
