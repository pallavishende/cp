import { ProxyManagerTs } from './proxy-manager-ts';
import { WaitUtils } from '../utils/wait-utils';
import { TimeConstants } from '../constants/time-constants';
import Logger from '@viacom/mqe-core-js/build/helpers/Logger';

export class ProxyUtils {
  private static logger = Logger.getLogger('ProxyUtils');

  static async getEntries() {
    return JSON.parse(await ProxyManagerTs.getHarLogAsString()).log.entries;
  }

  static async getRequests() {
    const entries = await this.getEntries();
    return entries.map(entry => entry.request);
  }

  static async getRequestUrls() {
    const requests = await this.getRequests();
    return requests.map(request => request.url);
  }

  // returns responses by given requestUrl or if it matches pattern
  static async getRequestsByUrl(requestUrl: string, requestMethod?: string) {
    const entries = await this.getEntries();
    const responses = [];
    entries.forEach(entry => {
      if (entry.request.url === requestUrl || RegExp(requestUrl).test(entry.request.url)) {
        if ((requestMethod && entry.request.method === requestMethod) || !requestMethod) {
          responses.push(entry.request);
        }
      }
    });
    return responses;
  }

  static async isCallFired(requestUrl: string, requestMethod: string) {
    this.logger.debug(
      `Check that call was fired with URL pattern '${requestUrl}' with request method '${requestMethod}'`
    );
    return ProxyUtils.getRequestsByUrl(requestUrl, requestMethod).then(data => {
      this.logger.debug(`Data from request '${data}'`);
      return data.length !== 0;
    });
  }

  static async getRequest(requestUrl: string, requestMethod?: string) {
    this.logger.debug(
      `Get request with URL pattern '${requestUrl}' and request method '${requestMethod}'`
    );
    await this.waitForRequest(requestUrl, TimeConstants.MS._5000);
    return ProxyUtils.getRequestsByUrl(requestUrl, requestMethod).then(data => {
      return JSON.parse(data[0].postData.text);
    });
  }

  static async getResponse(requestUrl: string, requestMethod: string) {
    this.logger.debug(
      `Get response with URL pattern '${requestUrl}' and request method '${requestMethod}'`
    );
    await ProxyUtils.waitForResponse(requestUrl, TimeConstants.MS._5000, requestMethod);
    return ProxyUtils.getResponses(requestUrl, requestMethod).then(data => {
      return JSON.parse(data[0].content.text);
    });
  }

  // returns responses by given requestUrl or if it matches pattern
  static async getResponses(requestUrl: string, requestMethod?: string) {
    const entries = await this.getEntries();
    const responses = [];
    entries.forEach(entry => {
      if (
        entry.request.url === requestUrl ||
        (RegExp(requestUrl).test(entry.request.url) && entry.response.bodySize !== -1)
      ) {
        if ((requestMethod && entry.request.method === requestMethod) || !requestMethod) {
          responses.push(entry.response);
        }
      }
    });
    return responses;
  }

  static async waitForResponse(requestUrl: string, timeoutImMS: number, requestMethod?: string) {
    const startTime = new Date().getTime();
    let currentTime;
    let entries;
    do {
      currentTime = new Date().getTime();
      entries = await this.getResponses(requestUrl, requestMethod);
      await WaitUtils.sleep(TimeConstants.MS._500);
    } while (entries.length === 0 && startTime > currentTime - timeoutImMS);
    if (entries.length === 0) {
      throw new Error(
        `Response was not found for the ${timeoutImMS / 1000} seconds. Request url: ${requestUrl}`
      );
    }
  }

  static async waitForRequest(requestUrl: string, timeoutImMS: number) {
    const startTime = new Date().getTime();
    let currentTime;
    let entries;
    let res;
    do {
      currentTime = new Date().getTime();
      entries = await this.getRequestUrls();
      res = entries.find(url => url === requestUrl || RegExp(requestUrl).test(url));
      await WaitUtils.sleep(TimeConstants.MS._500);
    } while (res === undefined && startTime > currentTime - timeoutImMS);
    if (res === undefined) {
      throw new Error(
        `Request call was not found for the ${timeoutImMS /
          1000} seconds. Request url: ${requestUrl}`
      );
    }
  }
}
