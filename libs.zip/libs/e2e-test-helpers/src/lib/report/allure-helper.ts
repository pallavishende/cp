const fs = require('fs');
export class AllureHelper {
  static cleanDirectory(directoryPath: string, removeSelf?: boolean) {
    let files;
    try {
      if (removeSelf === undefined) {
        removeSelf = true;
      }
      files = fs.readdirSync(directoryPath);
      if (files.length > 0) {
        for (let i = 0; i < files.length; i++) {
          const filePath = directoryPath + '/' + files[i];
          if (fs.statSync(filePath).isFile()) {
            fs.unlinkSync(filePath);
          } else {
            this.cleanDirectory(filePath);
          }
        }
        if (removeSelf) {
          fs.rmdirSync(directoryPath);
        }
      }
    } catch (e) {
      console.log(
        'The contents of the directory with the result of the past test run cannot be deleted: ' + e
      );
    }
  }
}
