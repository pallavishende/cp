// Temporarily commenting

// import CoreServerHttpClient from '@viacom/mqe-core-js/build/helpers/CoreServerHttpClient';
// import Logger from '@viacom/mqe-core-js/build/helpers/Logger';
// const path = require('path');
//
// export class ReportHelper {
//   private httpClient;
//   private logger;
//
//   constructor() {
//     this.httpClient = new CoreServerHttpClient();
//     this.logger = Logger.getLogger('Report Helper');
//   }
//
//   public generateReport(): Promise<void> {
//     this.logger.debug('Generate Report');
//     let jobNumber = 'OPTIONAL';
//     let jobName = 'OPTIONAL';
//     const reportDir = path.join(__dirname, '../../../../../allure-report');
//     const allureDir = path.join(__dirname, '../../../../../allure-results');
//
//     if (!!process.env.EC2_SUBNET) {
//       jobName = process.env.JOB_NAME;
//       jobNumber = process.env.BUILD_ID;
//     }
//     return this.httpClient.postRequest('GenerateReport', {
//       0: reportDir,
//       1: 'true',
//       2: 'true',
//       3: allureDir,
//       4: jobName,
//       5: jobNumber,
//       6: 'force_local'
//     });
//   }
//
//   public async uploadReportToS3(): string {
//     this.logger.debug('Uploading report to S3');
//     const reportDir = path.join(__dirname, '../../../../../allure-report');
//     const result = await this.httpClient.postRequest('UploadReportToS3', {
//       0: reportDir,
//       1: 'force_local'
//     });
//     this.logger.debug('MQE test report saved to Amazon S3 at: ' + result[1]);
//     return result[1];
//   }
// }
