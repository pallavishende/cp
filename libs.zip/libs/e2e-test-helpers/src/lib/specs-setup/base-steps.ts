// Temporarily commenting
//
// import { registerAllureReporter } from 'jest-allure/dist/setup';
// // tslint:disable-next-line:nx-enforce-module-boundaries
// import { CoreManagerHelper } from '../core-manager/index';
// import { AllureHelper } from '../report/allure-helper';
// import { TimeConstants } from '../constants/time-constants';
// import Logger from '@viacom/mqe-core-js/build/helpers/Logger';
// import { report } from '@viacom/mqe-core-js';
// import { ReportHelper } from '../report/report-helper';
// const logger = Logger.getLogger('Jest Base Steps');
// const fs = require('fs');
// require('jest-expect-message');
// export const maxConcurrentTests = 10;
//
// global.beforeAll(async () => {
//   await AllureHelper.cleanDirectory('allure-results', false);
//   registerAllureReporter();
//   await report.GlobalReportDir.setReportDir('allure-results');
// });
//
// global.beforeEach(async () => {
//   jest.setTimeout(TimeConstants.MS._90000);
//   await CoreManagerHelper.initiateDriver();
// });
//
// global.afterEach(async function() {
//   try {
//     if (CoreManagerHelper.isInitialized()) {
//       const screenShotBuffer = await CoreManagerHelper.getBrowser().getScreenshot();
//       await reporter.addAttachment('Screenshot', fs.readFileSync(screenShotBuffer), 'image/png');
//
//       const screenRecordingBuffer = await CoreManagerHelper.getBrowser().getScreenRecording();
//       await reporter.addAttachment(
//         'Screenrecording',
//         fs.readFileSync(screenRecordingBuffer),
//         'video/mp4'
//       );
//     }
//   } catch (e) {
//     logger.debug(`Unable to attach test artifacts: ${e}`);
//   } finally {
//     await CoreManagerHelper.stopDriver();
//     logger.info('Stop the driver after the test execution');
//   }
// });
//
// global.afterAll(async () => {
//   if (!!process.env.EC2_SUBNET) {
//     const reportHelper = new ReportHelper();
//     logger.info(`Generating reports`);
//     await reportHelper.generateReport();
//     const reportUrl = reportHelper.uploadReportToS3();
//     if (!reportUrl || reportUrl === 'Unknown') {
//       logger.debug(`Local execution, report wasn't uploaded`);
//     } else {
//       logger.info(`Url of uploaded report: ${reportUrl}`);
//     }
//   }
// });
