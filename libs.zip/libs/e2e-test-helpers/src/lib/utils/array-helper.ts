import Logger from '@viacom/mqe-core-js/build/helpers/Logger';
export class ArrayUtils {
  private static logger = Logger.getLogger('ProxyGEHelper');

  static equals(array1, array2) {
    return (
      array1.length === array2.length && array1.every((value, index) => value === array2[index])
    );
  }

  static isEqualsIgnoreOrder(array1, array2) {
    return this.equals(array1.sort(), array2.sort());
  }

  static allElementsEquals(array, value) {
    let isEquals = true;
    array.forEach((item, index) => {
      if (item !== value) {
        this.logger.debug(
          `Value with ${index} index is not equals. Expected ${value}, got ${array[index]}`
        );
        isEquals = false;
      }
    });
    return isEquals;
  }

  static allElementsContain(array, value) {
    let isContain = true;
    array.forEach((item, index) => {
      if (!item.includes(value)) {
        this.logger.debug(
          `Value with ${index} index does not contain expected value. Expected ${value}, got ${
            array[index]
          }`
        );
        isContain = false;
      }
    });
    return isContain;
  }

  static allElementsStartsWith(array, value) {
    let isStartsWith = true;
    array.forEach((item, index) => {
      if (!item.startsWith(value)) {
        this.logger.debug(
          `Value with ${index} index does not starts with expected value. Expected ${value}, got ${
            array[index]
          }`
        );
        isStartsWith = false;
      }
    });
    return isStartsWith;
  }

  static allElementsMatch(array, value) {
    let isMatch = true;
    array.forEach((item, index) => {
      if (item.match(value) === null) {
        this.logger.debug(
          `Value with ${index} index does not match with expected RegEx. RegEx - ${value}, value - ${
            array[index]
          }`
        );
        isMatch = false;
      }
    });
    return isMatch;
  }
}
