import { WebInteractExt } from '../web-interact';
import { TimeConstants } from '../constants';

export class BrowserUtils {
  static getApplicationTitle(): Promise<string> {
    return new WebInteractExt(null, null, null).getTitle();
  }

  static getCurrentUrl(): Promise<string> {
    return new WebInteractExt(null, null, null).getUrl();
  }

  static openURL(url: string): Promise<void> {
    return new WebInteractExt(null, null, null).openUrl(url).execute();
  }

  static closeTab(): Promise<void> {
    return new WebInteractExt(null, null, null).closeWindow().execute();
  }

  static refreshPage(): Promise<void> {
    return new WebInteractExt(null, null, null).refresh().execute();
  }

  static goBack(): Promise<void> {
    return new WebInteractExt(null, null, null).goBack().execute();
  }

  static getAlertText(): Promise<string> {
    return new WebInteractExt(null, null, null).waitForAlertPresent().getAlertText();
  }

  static getWindowSize(): Promise<any> {
    return new WebInteractExt(null, null, null).getWindowSize();
  }

  static maximizeWindow(): Promise<void> {
    return new WebInteractExt(null, null, null).maximizeWindow().execute();
  }

  static getClipboardData(): Promise<string> {
    return new WebInteractExt(null, null, null).getClipboardContent();
  }

  static acceptAlert(): Promise<void> {
    return new WebInteractExt(null, null, null)
      .waitForAlertPresent()
      .acceptAlert()
      .execute();
  }

  static dismissAlert(): Promise<void> {
    return new WebInteractExt(null, null, null)
      .waitForAlertPresent()
      .dismissAlert()
      .execute();
  }

  static isAlertPresent(waitingTime = TimeConstants.SEC._3): Promise<boolean> {
    return new WebInteractExt(null, null, null)
      .setTimeout(waitingTime)
      .waitForAlertPresent()
      .execute()
      .then(val => val[0] === 'SUCCESS')
      .catch(() => false);
  }
}
