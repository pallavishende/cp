import { browser } from 'protractor';

export class Comparison {
  /**
   * Takes a screenshot of the element and compares it with the reference.
   *
   * @param element - The ElementFinder that is used to get the position.
   * @param reference - The image name from 'assets/baseline/' for comparison.
   * @returns { Promise<number> } - where number is the percentage of the difference.
   */
  static compareElement(element, reference) {
    return browser.protractorImageComparison.checkElement(element, reference);
  }
}
