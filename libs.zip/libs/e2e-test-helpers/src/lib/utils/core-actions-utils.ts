import { WebInteract, WebInteractExt } from '../web-interact/index';
import { LocType, Key } from '../constants/index';

export class CoreActionsUtils {
  static sendKey(key: string) {
    return new WebInteractExt(LocType.XPATH, '//body', 'Body page element')
      .waitForPresent()
      .sendKeys(key)
      .execute();
  }

  static clearTextUsingKeys(inputElem: WebInteract) {
    return inputElem
      .waitForVisible()
      .sendKeys(Key.HOME)
      .sendKeys(Key.SHIFT + Key.END)
      .sendKeys(Key.DELETE)
      .execute();
  }
}
