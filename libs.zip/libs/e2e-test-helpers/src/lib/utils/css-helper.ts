export class CSSHelper {
  private static whiteRGB = {
    r: 255,
    g: 255,
    b: 255
  };

  static rgbaToHex(rgba, rgbBackground = this.whiteRGB) {
    const rgbaObj = this.parseRGBA(rgba);
    let rgb;
    rgbaObj.a !== undefined
      ? (rgb = {
          r: Math.round((1 - rgbaObj.a) * rgbBackground.r + rgbaObj.a * rgbaObj.r),
          g: Math.round((1 - rgbaObj.a) * rgbBackground.g + rgbaObj.a * rgbaObj.g),
          b: Math.round((1 - rgbaObj.a) * rgbBackground.b + rgbaObj.a * rgbaObj.b)
        })
      : (rgb = {
          r: +rgbaObj.r,
          g: +rgbaObj.g,
          b: +rgbaObj.b
        });
    return '#' + this.hex(rgb.r) + this.hex(rgb.g) + this.hex(rgb.b);
  }

  private static parseRGBA(rgba) {
    const params = rgba.match(/^rgba*\((\d+),\s*(\d+),\s*(\d+),*\s*(\d+\.?\d*|\.\d+)*\)$/);
    return {
      r: params[1],
      g: params[2],
      b: params[3],
      a: params[4]
    };
  }

  private static hex(x: number) {
    const hex = x.toString(16);
    return hex.length === 1 ? '0' + hex : hex;
  }
}
