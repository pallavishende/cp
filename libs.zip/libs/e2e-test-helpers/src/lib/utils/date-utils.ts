export class DateUtils {
  /**
   * @returns date in format Tue Nov 20 2018 12:52:30 GMT+0300 (Moscow Standard Time)
   */
  static readonly CURRENT_DATE = new Date();

  /**
   * @returns date in format Tue Nov 20 2018 00:00:00 GMT+0300 (Moscow Standard Time)
   */
  static readonly CURRENT_DATE_WITH_ZERO_TIME = new Date(new Date().setHours(0, 0, 0, 0));

  static getCurrentDate() {
    const options = { month: 'long', day: 'numeric', year: 'numeric' };
    return new Date().toLocaleString('en-US', options);
  }

  /**
   * @returns string with current date, e.g. 2018/8/20
   */
  static getCurrentDateShortForm(): string {
    return this.CURRENT_DATE.toISOString()
      .slice(0, 10)
      .replace(/-/g, '/');
  }
}
