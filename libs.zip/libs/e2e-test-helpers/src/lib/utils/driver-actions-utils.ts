import { browser, protractor } from 'protractor';

export class DriverActionsUtils {
  static sendKey(key: string) {
    return browser
      .actions()
      .sendKeys(key)
      .perform();
  }

  /**
   * click on another area
   */
  static unFocusElement(x: number = 5, y: number = 5) {
    return browser
      .actions()
      .mouseMove({ x: x, y: y })
      .click()
      .perform();
  }

  /**
   * clear input element
   */
  static clear(element) {
    return element
      .clear()
      .then(() => {
        return element.sendKeys('a');
      })
      .then(() => {
        return element.sendKeys(protractor.Key.BACK_SPACE);
      });
  }
}
