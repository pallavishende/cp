export class HardAssert {
  static assertTrue(condition: any, message?: string) {
    condition.then(result => {
      if (!(result === true)) {
        throw Error(`Assert True failed. ${message}`);
      }
    });
  }

  static assertFalse(condition: any, message?: string) {
    condition.then(result => {
      if (!(result === false)) {
        throw Error(`Assert False failed. ${message}`);
      }
    });
  }

  static assertEquals(condition1: any, condition2: any, message?: string) {
    condition1.then(result => {
      if (!(result === condition2)) {
        throw Error(
          `Assert failed. Values is not equals. Actual: '${result}'. Expected: '${condition2}'. ${message}`
        );
      }
    });
  }
}
