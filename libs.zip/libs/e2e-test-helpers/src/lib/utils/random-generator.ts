import { StringConstants } from '../constants/string-constants';

export class RandomGenerator {
  /**
   * get random string from alphanumeric set
   */
  static generateString(
    length: number = 5,
    characters: string = StringConstants.CHARS_SET.ALPHANUMERIC_SET
  ): string {
    let text = '';

    for (let i = 0; i < length; i++) {
      text += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return text;
  }

  /**
   * get random character from array randomly
   */
  static getRandomChar(characters: string[] = StringConstants.CHARS_SET.SYMBOLS_SET) {
    const rand = Math.floor(Math.random() * characters.length);
    return characters[rand];
  }
}
