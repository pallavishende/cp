export enum SortOrder {
  ASC = -1,
  DES = 1
}

export class SortHelper {
  static isSorted(arr: Array<any>, order: SortOrder, checkedElement?: string): boolean {
    const arrType: string = arr[0].constructor.name;
    let compare: (a, b) => number;
    switch (arrType) {
      case String.name: {
        compare = (a: string, b: string) => a.localeCompare(b);
        break;
      }
      case Date.name: {
        compare = (a, b) => +(a > b) - +(a < b);
        break;
      }
      default: {
        throw TypeError(`Array with elements type of '${arrType}' is not supported by SortHelper.`);
      }
    }

    let comparison: number;
    let result = true;
    for (let i = 0; i < arr.length - 1; i++) {
      comparison = compare(arr[i], arr[i + 1]);
      if (!(comparison === 0) && !(comparison === order)) {
        console.log(
          `At '${checkedElement}' the values '${arr[i].toString()}' and '${arr[
            i + 1
          ].toString()}' is not sorted in ${SortOrder[order]} order.`
        );
        result = false;
        break;
      }
    }
    return result;
  }
}
