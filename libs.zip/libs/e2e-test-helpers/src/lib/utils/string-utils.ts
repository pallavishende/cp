export class StringUtils {
  static removeSpaces(str: string) {
    return str.replace(/ /g, '');
  }

  static isMatched(str: string, pattern: string): boolean {
    return new RegExp(pattern).test(str);
  }

  /**
   * get full file name from file path.
   * For example from ../assets/data-file/docx-first-sample.docx to 'docx-first-sample.docx'
   * @param filePath - the path to the file
   */
  static getFullFileName(filePath: string) {
    return filePath
      .split('\\')
      .pop()
      .split('/')
      .pop();
  }

  /**
   * get file name from file path.
   * For example from ../assets/data-file/docx-first-sample.docx to 'docx-first-sample'
   * @param filePath - the path to the file
   */
  static getFileName(filePath: string) {
    return this.getFullFileName(filePath).split('.')[0];
  }

  /**
   * get file extension from file path.
   * For example from ../assets/data-file/docx-first-sample.docx to docx'
   * @param filePath - the path to the file
   */
  static getFileExtension(filePath: string) {
    return filePath.split('.').pop();
  }

  static isEndsWith(baseString: string, suffix) {
    return baseString.slice(-suffix.length) === suffix;
  }

  static replace(str: string, pattern: string | RegExp, replacement: string): string {
    return str.replace(pattern, replacement);
  }

  static parseTime(timeStr: string): { hours: number; minutes: number } {
    const actualHours: number = +timeStr.split(':')[0];
    const actualMinutes: number = +timeStr.split(':')[1];
    return { hours: actualHours, minutes: actualMinutes };
  }
}
