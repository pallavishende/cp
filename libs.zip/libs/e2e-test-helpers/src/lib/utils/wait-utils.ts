import { TimeConstants } from '../constants';

export class WaitUtils {
  static sleep(pauseInMs: TimeConstants): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, pauseInMs)).then(() =>
      console.log(`Pause ${pauseInMs} millisecond`)
    );
  }
}
