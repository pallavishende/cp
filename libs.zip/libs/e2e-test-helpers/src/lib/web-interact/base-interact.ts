import { LocType } from '../constants/index';
import { web } from '@viacom/mqe-core-js';

export interface Locator {
  type: string;
  locator: string;
  locatorSimpleName: string;
}

export abstract class BaseInteract {
  protected XPATH_SEPARATOR = '/';
  protected CSS_SEPARATOR = ' ';
  protected NAME_SEPARATOR = ' -> ';

  protected interact: any;

  constructor(type: LocType | string, locator: string, locatorSimpleName: string) {
    this.interact = new web.Interact(type, locator, locatorSimpleName);
  }

  protected generateChildLocator(locator: string, locatorSimpleName: string): Locator {
    let newLocator: string;
    let newSimpleName: string;
    switch (this.interact.type) {
      case LocType.CSS:
        newLocator = this.interact.locator + this.CSS_SEPARATOR + locator;
        break;
      case LocType.XPATH:
        newLocator = this.interact.locator + this.XPATH_SEPARATOR + locator;
        break;
      default:
        throw new Error(
          `Locator type ERROR. '${this.interact.type}' doesn't support nested elements.`
        );
    }
    newSimpleName = this.interact.locatorSimpleName + this.NAME_SEPARATOR + locatorSimpleName;
    return { type: this.interact.type, locator: newLocator, locatorSimpleName: newSimpleName };
  }
}
