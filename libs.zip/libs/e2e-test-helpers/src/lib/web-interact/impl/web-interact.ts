import { BaseInteract } from '../base-interact';
import CoreServerHttpClient from '@viacom/mqe-core-js/build/helpers/CoreServerHttpClient';
import Logger from '@viacom/mqe-core-js/build/helpers/Logger';
import { WebInteract } from '../web-interact-interface';
import { LocType, TimeConstants } from '../../constants/index';
import { WebInteractArray } from '../web-interact-array-int';
import { CoreManagerHelper } from '../../core-manager/core-manager-helper';

export class WebInteractExt extends BaseInteract implements WebInteract {
  private httpClient;
  private logger;

  constructor(type: LocType | string, locator: string, locatorSimpleName: string) {
    super(type, locator, locatorSimpleName);
    this.httpClient = new CoreServerHttpClient();
    this.logger = Logger.getLogger('WebInteract');
  }

  getChild(locator: string, locatorSimpleName: string): WebInteract {
    const loc = this.generateChildLocator(locator, locatorSimpleName);
    return new WebInteractExt(loc.type, loc.locator, loc.locatorSimpleName);
  }

  getChilds(locator: string, locatorSimpleName: string): WebInteractArray {
    const loc = this.generateChildLocator(locator, locatorSimpleName);
    // tslint:disable-next-line:no-use-before-declare
    return new WebInteractArrayImpl(loc.type, loc.locator, loc.locatorSimpleName);
  }

  getAllElements(): WebInteractArray {
    // tslint:disable-next-line:no-use-before-declare
    return new WebInteractArrayImpl(
      this.interact.type,
      this.interact.locator,
      this.interact.locatorSimpleName
    );
  }

  public sendKeys(text: string): WebInteract {
    this.interact.typeText(text);
    return this;
  }

  public getScreenshot(): any {
    return this.interact.getScreenshot().execute();
  }

  public typeIntoAlert(text: string): WebInteract {
    this.interact.typeIntoAlert(text);
    return this;
  }

  public getAlertText(): Promise<string> {
    return this.interact.getAlertText().execute();
  }

  public dismissAlert(): WebInteract {
    this.interact.dismissAlert();
    return this;
  }

  public acceptAlert(): WebInteract {
    this.interact.acceptAlert();
    return this;
  }

  public waitForAlertNotPresent(): WebInteract {
    this.interact.waitForAlertNotPresent();
    return this;
  }

  public waitForAlertPresent(): WebInteract {
    this.interact.waitForAlertPresent();
    return this;
  }

  public setWindowSize(x: number, y: number): WebInteract {
    this.interact.setWindowSize(x, y);
    return this;
  }

  public setWindowPosition(x: number, y: number): WebInteract {
    this.interact.setWindowPosition(x, y);
    return this;
  }

  public getWindowPosition(): Promise<{ x: number; y: number }> {
    return this.interact.getWindowPosition().execute();
  }

  public getWindowSize(): Promise<{ width: number; height: number }> {
    return this.interact.getWindowSize().execute();
  }

  public maximizeWindow(): WebInteract {
    this.interact.maximizeWindow();
    return this;
  }

  public switchToFrameById(id: string): WebInteract {
    this.interact.switchToFrameById(id);
    return this;
  }

  public switchToFrameByIndex(index: number): WebInteract {
    this.interact.switchToFrameByIndex(index);
    return this;
  }

  public switchToDefaultWindow(): WebInteract {
    this.interact.switchToDefaultWindow();
    return this;
  }

  public deselectAllOptions(): WebInteract {
    this.interact.deselectAllOptions();
    return this;
  }

  public deselectByIndex(index: number): WebInteract {
    this.interact.deselectByIndex(index);
    return this;
  }

  public selectByIndex(index: number): WebInteract {
    this.interact.selectByIndex(index);
    return this;
  }

  public deselectByValue(value: string): WebInteract {
    this.interact.deselectByValue(value);
    return this;
  }

  public selectByValue(value: string): WebInteract {
    this.interact.selectByValue(value);
    return this;
  }

  public deselectByText(text: string): WebInteract {
    this.interact.deselectByText(text);
    return this;
  }

  public selectByText(text: string): WebInteract {
    this.interact.selectByText(text);
    return this;
  }

  public getSelectedOptions(): Promise<Array<string>> {
    return this.interact.getSelectedOptions().execute();
  }

  public getSelectOptions(): Promise<Array<string>> {
    return this.interact.getSelectOptions().execute();
  }

  public mouseOverByJavascript(): WebInteract {
    this.interact.mouseOverByJavascript();
    return this;
  }

  public mouseOver(): WebInteract {
    this.interact.mouseOver();
    return this;
  }

  // Current implementation does not work with Global Entry
  public moveFromTo(xOffset, yOffset): WebInteract {
    this.interact.commandQueue.push(() => {
      this.logger.debug(
        `Move the ${
          this.interact.locatorSimpleName
        } element offset by coordinates '${xOffset}', '${yOffset}'`
      );
      return this.httpClient.postRequest(
        'WebElementMoveFromTo',
        Object.assign({}, this.interact.preparedJSONElement, { 1: xOffset, 2: yOffset })
      );
    });
    this.interact.defReturnValue();
    return this;
  }

  public submit(): WebInteract {
    this.interact.submit();
    return this;
  }

  public getUrl(): Promise<string> {
    return this.interact.getUrl().execute();
  }

  public refresh(): WebInteract {
    this.interact.refresh();
    return this;
  }

  public goForward(): WebInteract {
    this.interact.goForward();
    return this;
  }

  public goBack(): WebInteract {
    this.interact.goBack();
    return this;
  }

  public getAllCookies(): Promise<any> {
    return this.interact.getAllCookies().execute();
  }

  public deleteCookieByName(name: string): WebInteract {
    this.interact.deleteCookieByName(name);
    return this;
  }

  public deleteAllCookies(): WebInteract {
    this.interact.deleteAllCookies();
    return this;
  }

  public addCookie(name: string, value: string): WebInteract {
    this.interact.addCookie(name, value);
    return this;
  }

  public closeWindow(): WebInteract {
    this.interact.closeWindow();
    return this;
  }

  public openNewWindow(): WebInteract {
    this.interact.openNewWindow();
    return this;
  }

  public switchToWindow(windowId: string): WebInteract {
    this.interact.switchToWindow(windowId);
    return this;
  }

  public getAllWindowIds(): Promise<Array<string>> {
    return this.interact.getAllWindowIds().execute();
  }

  public getCurrentWindowId(): Promise<string> {
    return this.interact.getCurrentWindowId().execute();
  }

  public executeJavascript(javascript: string): WebInteract {
    this.interact.executeJavascript(javascript);
    return this;
  }

  public executeJavascriptInWindow(javascript: string): WebInteract {
    this.interact.executeJavascriptInWindow(javascript);
    return this;
  }

  public clearText(): WebInteract {
    this.interact.clearText();
    return this;
  }

  public rightClick(): WebInteract {
    this.interact.rightClick();
    return this;
  }

  public doubleClick(): WebInteract {
    this.interact.doubleClick();
    return this;
  }

  public clickOffSet(xCoord: number, yCoord: number): WebInteract {
    this.interact.clickOffSet(xCoord, yCoord);
    return this;
  }

  public click(): WebInteract {
    if (CoreManagerHelper.DEFAULT_CAPS.MQEDesktopBrowserName !== 'safari') {
      this.interact.click();
    } else {
      this.interact.executeJavascript('arguments[0].click();');
    }
    return this;
  }

  public scrollIntoView(): WebInteract {
    this.interact.scrollIntoView();
    return this;
  }

  public scroll(numOfScrolls: number, xNum: number, yNum: number): WebInteract {
    this.interact.scroll(numOfScrolls, xNum, yNum);
    return this;
  }

  public getLocationFromAll(): Promise<Array<{ x: number; y: number }>> {
    return this.interact.getLocationFromAll().execute();
  }

  public getLocation(): Promise<{ x: number; y: number }> {
    return this.interact.getLocation().execute();
  }

  public getSizeFromAll(): Promise<Array<{ width: number; height: number }>> {
    return this.interact.getSizeFromAll().execute();
  }

  public getSize(): Promise<{ width: number; height: number }> {
    return this.interact
      .getSize()
      .execute()
      .then(size => {
        return { width: +size.x, height: +size.y };
      });
  }

  public getAttributeValueFromAll(attribute: string): Promise<Array<string>> {
    return this.interact.getAttributeValueFromAll(attribute).execute();
  }

  public getAttributeValue(attribute: string): Promise<string> {
    return this.interact.getAttributeValue(attribute).execute();
  }

  public getTextFromAll(): Promise<Array<string>> {
    return this.interact.getTextFromAll().execute();
  }

  public getText(): Promise<string> {
    return this.interact.getText().execute();
  }

  public getCountOfElements(): Promise<number> {
    return this.interact
      .getCountOfElements()
      .execute()
      .then(res => +res);
  }

  public waitForTitle(title: string): WebInteract {
    this.interact.waitForTitle(title);
    return this;
  }

  public waitForUrl(url: string): WebInteract {
    this.interact.waitForUrl(url);
    return this;
  }

  public waitForPresentInFrame(): WebInteract {
    this.interact.waitForPresentInFrame();
    return this;
  }

  public waitForScrolledTo(maxScrolls: number, xNum: number, yNum: number): any {
    this.interact.waitForScrolledTo(maxScrolls, xNum, yNum); // <- TODO, not implemented
    return this;
  }

  public waitForNotText(text: string): WebInteract {
    this.interact.waitForNotText(text);
    return this;
  }

  public waitForText(text: string): WebInteract {
    this.interact.waitForText(text);
    return this;
  }

  public waitForNotAttributeWithValue(attribute: string, attributeValue: string): WebInteract {
    this.interact.waitForNotAttributeWithValue(attribute, attributeValue);
    return this;
  }

  public waitForAttributeWithValue(attribute: string, attributeValue: string): WebInteract {
    this.interact.waitForAttributeWithValue(attribute, attributeValue);
    return this;
  }

  public waitForNotPresentOrVisible(): WebInteract {
    this.interact.waitForNotPresentOrVisible();
    return this;
  }

  public waitForNotVisible(): WebInteract {
    this.interact.waitForNotVisible();
    return this;
  }

  public waitForAllVisible(): WebInteract {
    this.interact.waitForAllVisible();
    return this;
  }

  public waitForNotPresent(): WebInteract {
    this.interact.waitForNotPresent();
    return this;
  }

  public waitForAllPresent(): WebInteract {
    this.interact.waitForAllPresent();
    return this;
  }

  public hasText(text: string): Promise<boolean> {
    return this.interact
      .hasText(text)
      .execute()
      .then(res => String(res).toLowerCase() === 'true');
  }

  public waitForPresent(): WebInteract {
    this.interact.waitForPresent();
    return this;
  }

  public hasAttributeWithValue(attribute: string, attributeValue: string): Promise<boolean> {
    return this.interact
      .hasAttributeWithValue(attribute, attributeValue)
      .execute()
      .then(res => String(res).toLowerCase() === 'true');
  }

  public isVisible(timeoutInSec: number): Promise<boolean> {
    return this.interact
      .isVisible(timeoutInSec)
      .execute()
      .then(res => String(res).toLowerCase() === 'true');
  }

  public isPresent(timeoutInSec: number): Promise<boolean> {
    return this.interact
      .isPresent(timeoutInSec)
      .execute()
      .then(res => String(res).toLowerCase() === 'true');
  }

  public pause(waitTimeInMS: number): WebInteract {
    this.interact.pause(waitTimeInMS);
    return this;
  }

  public setTimeout(timeoutInSec: number): WebInteract {
    this.interact.setTimeout(timeoutInSec);
    return this;
  }

  public waitForVisible(): WebInteract {
    this.interact.waitForVisible();
    return this;
  }

  public getTitle(): Promise<string> {
    return this.interact.getTitle().execute();
  }

  public openUrl(url: string): WebInteract {
    this.interact.openUrl(url);
    return this;
  }

  public verify(func: Function): WebInteract {
    this.interact.verify(func);
    return this;
  }

  public setLocator(
    type: string | LocType,
    locator: string,
    locatorSimpleName: string
  ): WebInteract {
    this.interact.setLocator(type, locator, locatorSimpleName);
    return this;
  }

  public execute(): Promise<any> {
    return this.interact.execute();
  }

  public getCssValue(cssProperty: string): Promise<string> {
    return this.interact.getCssValue(cssProperty).execute();
  }

  public waitForChildrenPresent(childLocatorType: string, childLocator: string): WebInteract {
    return this.interact.waitForChildrenPresent(childLocatorType, childLocator);
  }

  public getClipboardContent(): Promise<string> {
    return this.interact.getClipboardContent().execute();
  }

  public setClipboardContent(content: string): WebInteract {
    return this.interact.setClipboardContent(content);
  }

  public getWebDriverLogs(): any {
    return this.interact.getWebDriverLogs().execute();
  }

  public getBrowserLogs(): any {
    return this.interact.getBrowserLogs().execute();
  }

  public getPageSource(): any {
    return this.interact.getPageSource().execute();
  }

  public getScreenRecording(): any {
    return this.interact.getScreenRecording().execute();
  }

  public getCoreServerEventLogs(): any {
    return this.interact.getCoreServerEventLogs().execute();
  }
}

export class WebInteractArrayImpl extends BaseInteract implements WebInteractArray {
  constructor(type: LocType | string, locator: string, locatorSimpleName: string) {
    super(type, locator, locatorSimpleName);
  }

  async count(): Promise<number> {
    return this.interact
      .isPresent(TimeConstants.SEC._3)
      .execute()
      .then(res => {
        if (res === 'true') {
          // tslint:disable-next-line:no-use-before-declare
          return new WebInteractContainer(this.findElements()).count();
        } else {
          return 0;
        }
      });
  }

  getChilds(locator: string, locatorSimpleName: string): WebInteractArray {
    const loc = this.generateChildLocator(locator, locatorSimpleName);
    return new WebInteractArrayImpl(loc.type, loc.locator, loc.locatorSimpleName);
  }

  public getArray(): Promise<Array<WebInteract>> {
    // tslint:disable-next-line:no-use-before-declare
    return new WebInteractContainer(this.findElements()).getArray();
  }

  public get(index: number): Promise<WebInteract> {
    // tslint:disable-next-line:no-use-before-declare
    return new WebInteractContainer(this.findElements()).get(index);
  }

  public last(): Promise<WebInteract> {
    // tslint:disable-next-line:no-use-before-declare
    return new WebInteractContainer(this.findElements()).last();
  }

  public first(): Promise<WebInteract> {
    // tslint:disable-next-line:no-use-before-declare
    return new WebInteractContainer(this.findElements()).first();
  }

  public map<T>(mapFn: (webInteract?: WebInteract, index?: number) => T | any): Promise<Array<T>> {
    // tslint:disable-next-line:no-use-before-declare
    return new WebInteractContainer(this.findElements()).map<T>(mapFn);
  }

  public filter(
    filterFn: (webInteract: WebInteract, index?: number) => boolean | Promise<boolean>
  ): WebInteractArray {
    // tslint:disable-next-line:no-use-before-declare
    return new WebInteractContainer(this.findElements()).filter(filterFn);
  }

  public each(fn: (webInteract?: WebInteract, index?: number) => any): Promise<WebInteractArray> {
    // tslint:disable-next-line:no-use-before-declare
    return new WebInteractContainer(this.findElements()).each(fn);
  }

  private async findElements(): Promise<Array<WebInteract>> {
    const numberOfElements = await this.interact
      .waitForAllPresent()
      .getCountOfElements()
      .execute();
    const elements: Array<WebInteract> = [];
    for (let i = 0; i < numberOfElements; i++) {
      let newLocator: string;
      switch (this.interact.type) {
        case LocType.CSS:
          newLocator = this.interact.locator + `:nth-of-type(${i + 1})`;
          break;
        case LocType.XPATH:
          newLocator = `(${this.interact.locator})[${i + 1}]`;
          break;
        default:
          throw new Error(
            `Locator type ERROR. '${this.interact.type}' doesn't support element arrays.`
          );
      }
      elements.push(
        new WebInteractExt(this.interact.type, newLocator, this.interact.locatorSimpleName + i)
      );
    }
    return elements;
  }
}

class WebInteractContainer implements WebInteractArray {
  private elements: Promise<Array<WebInteract>>;

  constructor(elements: Promise<Array<WebInteract>>) {
    this.elements = elements;
  }

  count(): Promise<number> {
    return this.elements.then(arr => arr.length);
  }

  getChilds(locator: string, locatorSimpleName: string): WebInteractArray {
    const childs = this.elements.then(elems => {
      return elems.map<WebInteract>(elem => elem.getChild(locator, locatorSimpleName));
    });
    return new WebInteractContainer(childs);
  }

  public getArray(): Promise<Array<WebInteract>> {
    return this.elements;
  }

  public get(index: number): Promise<WebInteract> {
    return this.elements.then(arr => arr[index]);
  }

  public last(): Promise<WebInteract> {
    return this.elements.then(arr => arr[arr.length - 1]);
  }

  public first(): Promise<WebInteract> {
    return this.elements.then(arr => arr[0]);
  }

  public map<T>(
    mapFn: (webInteract?: WebInteract, index?: number) => Promise<T> | T | any
  ): Promise<Array<T>> {
    return this.elements.then(async elems => {
      const results = new Array<T | any>();
      for (let i = 0; i < elems.length; i++) {
        results.push(await mapFn(elems[i], i));
      }
      return results;
    });
  }

  public filter(
    filterFn: (webInteract: WebInteract, index?: number) => boolean | Promise<boolean>
  ): WebInteractArray {
    this.elements = this.elements.then(async elems => {
      const results = new Array<boolean>();
      for (let i = 0; i < elems.length; i++) {
        results.push(await filterFn(elems[i], i));
      }
      const filteredElements = new Array<WebInteract>();
      results.forEach((result, i) => {
        if (result) {
          filteredElements.push(elems[i]);
        }
      });
      return filteredElements;
    });
    return this;
  }

  public each(fn: (webInteract?: WebInteract, index?: number) => any): Promise<WebInteractArray> {
    return this.map(fn).then((): any => this);
  }
}
