import { WebInteract } from './web-interact-interface';

export interface WebInteractArray {
  getChilds(locator: string, locatorSimpleName: string): WebInteractArray;

  count(): Promise<number>;

  each(fn: (webInteract?: WebInteract, index?: number) => any): Promise<WebInteractArray>;

  filter(
    filterFn: (webInteract: WebInteract, index?: number) => boolean | Promise<boolean>
  ): WebInteractArray;

  map<T>(mapFn: (webInteract?: WebInteract, index?: number) => T | any): Promise<T[]>;

  first(): Promise<WebInteract>;

  last(): Promise<WebInteract>;

  get(index: number): Promise<WebInteract>;

  getArray(): Promise<Array<WebInteract>>;
}
