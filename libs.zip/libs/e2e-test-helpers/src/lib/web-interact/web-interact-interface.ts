import { WebInteractArray } from './web-interact-array-int';

export interface WebInteract {
  /**
   * Executes the functions in `this.commandQueue`. This makes chaining available for WebInteract
   */
  execute(): Promise<any>;

  /**
   * Reset the locators for the element to avoid creating the unnecessary objects
   *
   * @param {String} type The type of locator to use, ie. xpath, id, etc.
   * @param {String} locator The actual locator string to be used.
   * @param {String} locatorSimpleName A friendly name of the element, i.e. 'Settings Button'
   */
  setLocator(type: string, locator: string, locatorSimpleName: string): WebInteract;

  /**
   * Function to verify the return value of the previous function in the `this.commandQueue`
   *
   * @param {Function} func Verification function, typically an assert
   */
  verify(func: Function): WebInteract;

  /**
   * Opens a url.
   *
   * @param {String} url The url to open in the browser.
   */
  openUrl(url: string): WebInteract;

  /**
   * Gets the title of the current page.
   */
  getTitle(): Promise<string>;

  /**
   * Waits for an element to be present AND visible before timing out and throwing an exception.
   */
  waitForVisible(): WebInteract;

  /**
   * Overrides the default element timeout used for all 'waitFor' method calls on an element. The new timeout lasts only
   * until a new waitFor calls is performed or a new element find is initiated.
   *
   * @param {Number} timeoutInSec the new timeout in seconds until an element waitFor call will terminate and throw an exception
   */
  setTimeout(timeoutInSec: number): WebInteract;

  /**
   * Pauses the test execution and causes the thread to sleep for the indicated amount of time in milliseconds.
   *
   * @param {Number} waitTimeInMS The amount of time to pause in milliseconds.
   */
  pause(waitTimeInMS: number): WebInteract;

  /**
   * Checks for the presence of the element until the provided timeout expires, and returns true or false.
   *
   * @param {Number} timeoutInSec The amount of time in seconds to check before the element before it returns false, ignored if undefined
   */
  isPresent(timeoutInSec: number): Promise<boolean>;

  /**
   * Checks for the presence AND visibility of the element until the provided timeout expires, and returns true or false.
   *
   * @param {Number} timeoutInSec The amount of time in seconds to check before the element to be visible before it returns false.
   */
  isVisible(timeoutInSec: number): Promise<boolean>;

  /**
   * Checks for the presence of the element with a matching attribute with given attribute value and returns true or false.
   *
   * @param {String} attribute The attribute to check for.
   * @param {String} attributeValue The attribute value to check for.
   */
  hasAttributeWithValue(attribute: string, attributeValue: string): Promise<boolean>;

  /**
   * Waits for an element to be present before timing out and throwing an exception.
   */
  waitForPresent(): WebInteract;

  /**
   * Checks for the presence of the element with matching text and returns true or false.
   *
   * @param {String} text The text to check for.
   */
  hasText(text: string): Promise<boolean>;

  /**
   * Waits for all elements to be present before timing out and throwing an exception.
   */
  waitForAllPresent(): WebInteract;

  /**
   * Waits for an element to NOT be present before timing out and throwing an exception.
   */
  waitForNotPresent(): WebInteract;

  /**
   * Waits for all elements to be present AND visible before timing out and throwing an exception.
   */
  waitForAllVisible(): WebInteract;

  /**
   * Waits for an element to NOT be present and visible before timing out and throwing an exception.
   */
  waitForNotVisible(): WebInteract;

  /**
   * Waits for an element to not be present, or be present but NOT be visible before timing out and throwing an exception.
   */
  waitForNotPresentOrVisible(): WebInteract;

  /**
   * Waits for an element to be present with a matching attribute and attribute value before timing out and throwing an exception.
   *
   * @param {String} attribute The attribute to check for.
   * @param {String} attributeValue The attribute value to check for.
   */
  waitForAttributeWithValue(attribute: string, attributeValue: string): WebInteract;

  /**
   * Waits for an element to NOT be present with a matching attribute and attribute value before timing out and throwing an exception.
   *
   * @param {String} attribute The attribute to check for.
   * @param {String} attributeValue The attribute value to check for.
   */
  waitForNotAttributeWithValue(attribute: string, attributeValue: string): WebInteract;

  /**
   * Waits for an element to be present with a matching text value before timing out and throwing an exception.
   *
   * @param {String} text The text to check for.
   */
  waitForText(text: string): WebInteract;

  /**
   * Waits for an element to NOT be present with a matching text value before timing out and throwing an exception.
   *
   * @param {String} text The text to check for.
   */
  waitForNotText(text: string): WebInteract;

  /**
   * Waits for an element to be scrolled into visibility given the scroll values, before timing out and throwing an
   * exception.
   *
   * @param {Number} maxScrolls The max number of scrolls until the element is visible, before throwing an exception.
   * @param {Number} xNum The X number of the scroll.
   * @param {Number} yNum The Y number of the scroll.
   */
  waitForScrolledTo(maxScrolls: number, xNum: number, yNum: number): any;

  /**
   * Waits for an element to be visible in any available frames, before timing out and throwing an
   * exception. The element is searched for in all frames (and sub-frames), and once the element is found, the frame
   * it is discovered in is given focus.
   */
  waitForPresentInFrame(): WebInteract;

  /**
   * Waits for the url of the browser to equal an expected url before throwing a timeout exception.
   *
   * @param {String} url The url to wait for.
   */
  waitForUrl(url: string): WebInteract;

  /**
   * Waits for the title of the browser page to equal an expected title before throwing a timeout exception.
   *
   * @param {String} title The title to wait for.
   */
  waitForTitle(title: string): WebInteract;

  /**
   * Gets the count of all element matches from the provided locator.
   */
  getCountOfElements(): Promise<number>;

  /**
   * Gets the text from the matching element provided by the locator.
   */
  getText(): Promise<string>;

  /**
   * Returns an array of all text values from all the matching elements as provided by the locator.
   */
  getTextFromAll(): Promise<Array<string>>;

  /**
   * Gets the attribute value from the matching element with the given attribute.
   *
   * @param {String} attribute The attribute to check for.
   */
  getAttributeValue(attribute: string): Promise<string>;

  /**
   * Returns an array of all attribute values from the given attribute, from all the matching elements as provided by the locator.
   *
   * @param {String} attribute The attribute to check for in each element match.
   */
  getAttributeValueFromAll(attribute: string): Promise<Array<string>>;

  /**
   * Gets the element size in a width,height dimension object.
   */
  getSize(): Promise<{ width: number; height: number }>;

  /**
   * Returns a List of all element sizes from all the matching elements as provided by the locator.
   */
  getSizeFromAll(): Promise<Array<{ width: number; height: number }>>;

  /**
   * Returns the location of the element in a x,y point object. The location point is the uppermost, upperleft
   * point of the found element.
   */
  getLocation(): Promise<{ x: number; y: number }>;

  /**
   * Returns a List of all location values from all the matching elements as provided by the locator.
   */
  getLocationFromAll(): Promise<Array<{ x: number; y: number }>>;

  /**
   * Performs a scroll against the browser under test given the number of scrolls and the x,y scroll value.
   *
   * @param {Number} numOfScrolls The number of scrolls to execute.
   * @param {Number} xNum The x value of the scroll.
   * @param {Number} yNum The y value of the scroll.
   */
  scroll(numOfScrolls: number, xNum: number, yNum: number): WebInteract;

  /**
   * Scrolls the currently selected element into view.
   */
  scrollIntoView(): WebInteract;

  /**
   * Clicks the element. The click occurs at the uppermost, upperleft point of the element.
   */
  click(): WebInteract;

  /**
   * Clicks at a point offset from the matching element. The offset occurs from the uppermost, upperleft point
   * of the element.
   *
   * @param {Number} xCoord The X coordinate offset from the element.
   * @param {Number} yCoord The Y coordinate offset from the element.
   */
  clickOffSet(xCoord: number, yCoord: number): WebInteract;

  /**
   * Double clicks the element.
   */
  doubleClick(): WebInteract;

  /**
   * Right clicks the element.
   */
  rightClick(): WebInteract;

  /**
   * Clear a text string from an element.
   */
  clearText(): WebInteract;

  /**
   * Executes javascript against the current window, and returns the output (if any), i.e.
   * String url = executeJavascriptInWindow("return document.URL;");
   */
  executeJavascriptInWindow(javascript: string): WebInteract;

  /**
   * Executes javascript against the currently selected element, and returns the output (if any).
   *
   * @param {String} javascript The javascript string to execute against the currently selected element.
   */
  executeJavascript(javascript: string): WebInteract;

  /**
   * Gets the id of the currently selected window.
   */
  getCurrentWindowId(): Promise<string>;

  /**
   * Gets all the ids of the currently open windows.
   */
  getAllWindowIds(): Promise<Array<string>>;

  /**
   * Switches focus to the indicated window by it's id.
   */
  switchToWindow(windowId: string): WebInteract;

  /**
   * Opens a new window/tab in the current browser, and switches focus to it.
   */
  openNewWindow(): WebInteract;

  /**
   * Closes the current window/tab.
   */
  closeWindow(): WebInteract;

  /**
   * Adds a cookie to the current browser.
   *
   * @param {String} name The name of the cookie to be added.
   * @param {String} value The value of the cookie to be added.
   */
  addCookie(name: string, value: string): WebInteract;

  /**
   * Deletes all cookies from the current browser.
   */
  deleteAllCookies(): WebInteract;

  /**
   * Delete a cookie by name from the current browser.
   */
  deleteCookieByName(name: string): WebInteract;

  /**
   * Gets a Map of all Cookies in the current browser by name,value.
   */
  getAllCookies(): Promise<any>;

  /**
   * Navigates back in the browser.
   */
  goBack(): WebInteract;

  /**
   * Navigates forward in the browser.
   */
  goForward(): WebInteract;

  /**
   * Refresh the current page.
   */
  refresh(): WebInteract;

  /**
   * Gets the url of the current page.
   */
  getUrl(): Promise<string>;

  /**
   * Performs a submit on the currently selected element.
   */
  submit(): WebInteract;

  /**
   * Moves the mouse cursor over the currently selected element. Note that this doesn't always work as expected
   * in a given browser but this is the preferred method.
   */
  mouseOver(): WebInteract;

  /**
   * Moves the mouse cursor over the currently selected element as executed by a javascript event. Note that
   * this is NOT a native event and it may not follow the true user experience, but sometimes it's the only way.
   */
  mouseOverByJavascript(): WebInteract;

  // Current implementation does not work with Global Entry
  /**
   * Moves the element to a new location offset from it's current location
   */
  moveFromTo(xOffset, yOffset): WebInteract;
  /**
   * Returns a List of the text options from a select locator.
   */
  getSelectOptions(): Promise<Array<string>>;

  /**
   * Returns a List of the text options from a select locator ONLY for those options that are currently selected.
   */
  getSelectedOptions(): Promise<Array<string>>;

  /**
   * Selects an option by text from the selected select element.
   *
   * @param {String} text The text of the option to select from the select element.
   */
  selectByText(text: string): WebInteract;

  /**
   * Deselects an option by text from the selected select element.
   *
   * @param {String} text The text of the option to deselect from the select element.
   */
  deselectByText(text: string): WebInteract;

  /**
   * Selects an option by value from the selected select element.
   *
   * @param {String} value The value of the option to select from the select element.
   */
  selectByValue(value: string): WebInteract;

  /**
   * Deselects an option by value from the selected select element.
   *
   * @param {String} value The value of the option to deselect from the select element.
   */
  deselectByValue(value: string): WebInteract;

  /**
   * Selects an option by index from the selected select element.
   *
   * @param {Number} index The index of the option to select from the select element.
   */
  selectByIndex(index: number): WebInteract;

  /**
   * Deselects an option by index from the selected select element.
   *
   * @param {Number} index The index of the option to deselect from the select element.
   */
  deselectByIndex(index: number): WebInteract;

  /**
   * Deselects ALL option from the selected select element.
   */
  deselectAllOptions(): WebInteract;

  /**
   * Switches to the original window, and original frame of the test session. Use this to return
   * to the browser original state after multiple window/frame/alert switches.
   */
  switchToDefaultWindow(): WebInteract;

  /**
   * Switches to the target frame by the supplied index.
   *
   * @param {Number} index The index (starting at 0) of the frame you wish to switch focus to.
   */
  switchToFrameByIndex(index: number): WebInteract;

  /**
   * Switches to the target frame by the id or name.
   *
   * @param {String} id The id (or name) of the frame you wish to switch focus to.
   */
  switchToFrameById(id: string): WebInteract;

  /**
   * Maximizes the browser window - NOTE that not all browsers support this and if an exception is thrown
   * during resize it is ignored.
   */
  maximizeWindow(): WebInteract;

  /**
   * Returns the window size in a width,height dimension object of the browser under test.
   *
   */
  getWindowSize(): Promise<{ width: number; height: number }>;

  /**
   * Returns the window position in a x,y point object of the browser under test.
   */
  getWindowPosition(): Promise<{ x: number; y: number }>;

  /**
   * Sets the window position in a x,y point object of the browser under test. Note that not all browsers/os
   * combinations support this so use at your own risk!
   */
  setWindowPosition(x: number, y: number): WebInteract;

  /**
   * Sets the window size in a x,y dimension object of the browser under test. Note that not all browsers/os
   * combinations support this so use at your own risk!
   */
  setWindowSize(x: number, y: number): WebInteract;

  /**
   * Waits for an alert to be present in the current browser before timing out. If the alert
   * is present within the timeout, it is automatically switched to.
   */
  waitForAlertPresent(): WebInteract;

  /**
   * Waits for an alert to NOT be present in the current browser before timing out.
   */
  waitForAlertNotPresent(): WebInteract;

  /**
   * Switches to and accepts an alert in the current browser.
   */
  acceptAlert(): WebInteract;

  /**
   * Switches to and dismisses an alert in the current browser.
   */
  dismissAlert(): WebInteract;

  /**
   * Switches to and gets the text of an alert in the current browser.
   */
  getAlertText(): Promise<string>;

  /**
   * Switches to and types text into an alert in the current browser.
   */
  typeIntoAlert(text: string): WebInteract;

  /**
   * Gets the screenshot from the browser and stores it to a File object.
   */
  getScreenshot(): Promise<any>;

  getChild(locator: string, locatorSimpleName: string): WebInteract;

  getChilds(locator: string, locatorSimpleName: string): WebInteractArray;

  getAllElements(): WebInteractArray;

  /**
   * Types a text string into an element.
   */
  sendKeys(text: string): WebInteract;

  /**
   * Gets the css value from the matching element with the given property.
   */
  getCssValue(cssProperty: string): Promise<string>;

  waitForChildrenPresent(childLocatorType: string, childLocator: string): WebInteract;

  getClipboardContent(): Promise<string>;

  setClipboardContent(content: string): WebInteract;

  getWebDriverLogs(): Promise<string>;

  getBrowserLogs(): Promise<string>;

  getPageSource(): Promise<string>;

  getScreenRecording(): Promise<string>;

  /**
   * Gets the core server request logs from the session and stores it to a File object.
   *
   * @return {String} The log of the core server instance with file path
   */
  getCoreServerEventLogs(): Promise<string>;
}
