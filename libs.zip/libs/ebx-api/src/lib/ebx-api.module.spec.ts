import { async, TestBed } from '@angular/core/testing';
import { EbxApiModule } from './ebx-api.module';

describe('EbxApiModule', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [EbxApiModule]
    }).compileComponents();
  }));

  it('should create', () => {
    expect(EbxApiModule).toBeDefined();
  });
});
