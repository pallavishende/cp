import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { effects } from './store/effects';
import { guards } from './guards';
import { fromReferenceData, fromSeriesData } from './store/reducers';
import { resources } from './services';
import { ApiParams } from './services/api-params';
import { EBXInterceptor } from './services/ebx.interceptor';
import { InterceptorsModule } from '@content-platform/interceptors';

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    StoreModule.forFeature('referenceData', fromReferenceData.reducer),
    StoreModule.forFeature('seriesData', fromSeriesData.reducer),
    EffectsModule.forFeature([...effects]),
    InterceptorsModule
  ],
  providers: [
    ApiParams,
    ...resources,
    ...guards,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: EBXInterceptor,
      multi: true
    }
  ],
  declarations: []
})
export class EbxApiModule {}
