import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EbxDemoComponent } from './ebx-demo/ebx-demo.component';
import { EbxApiModule } from '../ebx-api.module';

@NgModule({
  imports: [CommonModule, FormsModule, ReactiveFormsModule, EbxApiModule],
  declarations: [EbxDemoComponent],
  exports: [EbxDemoComponent],
  entryComponents: [EbxDemoComponent]
})
export class EbxDemoModule {}
