import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { EbxState } from '../../store/reducers';
import { referenceDataActions, seriesDataActions } from '../../store/actions';
import { referenceDataSelectors, seriesDataSelectors } from '../../store/selectors';
import {
  ReferenceDataType,
  AllReferenceDataTypes,
  SeriesResult,
  Season,
  Series
} from '../../models';
import { GccDataService } from '../../services/gcc-data.service';
import { DatasetValue } from '@content-platform/application-api';
import { map, tap } from 'rxjs/operators';

class RefDataDemoOutput {
  raw$: Observable<any[]>;
  asDataset$: Observable<DatasetValue[]>;
  constructor(private store: Store<EbxState>, public type: ReferenceDataType) {
    this.raw$ = this.store.pipe(select(referenceDataSelectors.getReferenceDataType(this.type)));
    this.asDataset$ = this.store.pipe(
      select(referenceDataSelectors.getReferenceDataAsDatasetValues(this.type)),
      map(set => set[0].values)
    );
  }
}

@Component({
  selector: 'app-ebx-demo',
  templateUrl: './ebx-demo.component.html',
  styleUrls: ['./ebx-demo.component.scss']
})
export class EbxDemoComponent implements OnInit {
  demoOutput: RefDataDemoOutput[] = [];
  searchResults$: Observable<SeriesResult[]>;
  seasonData$: Observable<Season>;
  series$: Observable<Series | any>;
  selectedSeriesId: string;

  constructor(private store: Store<EbxState>, private gcc: GccDataService) {}

  ngOnInit() {
    this.store.dispatch(new referenceDataActions.Load());
    AllReferenceDataTypes.forEach(refType =>
      this.demoOutput.push(new RefDataDemoOutput(this.store, refType))
    );
    this.series$ = this.store.pipe(select(seriesDataSelectors.getSeriesEntities));
    this.store.pipe(
      select(seriesDataSelectors.getSeriesEntities),
      tap(entities => entities[this.selectedSeriesId])
    );
  }

  search(query: string) {
    this.searchResults$ = this.gcc.searchByTitle(query);
  }

  loadSeason(vmid: string) {
    this.seasonData$ = this.gcc.getSeasonData(vmid);
  }

  loadHierarchy(seriesVmid: string) {
    this.selectedSeriesId = seriesVmid;
    this.store.dispatch(
      new seriesDataActions.LoadById({ seriesVmid: seriesVmid, fetchLastSeason: true })
    );
  }
}
