import { ReferenceDataGuard } from './reference-data.guard';

export const guards = [ReferenceDataGuard];

export * from './reference-data.guard';
