import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';

import { Store, select } from '@ngrx/store';
import { Observable, of } from 'rxjs';

import { filter, catchError, withLatestFrom, map } from 'rxjs/operators';
import { referenceDataActions } from '../store/actions';
import { EbxState } from '../store/reducers';
import { referenceDataSelectors } from '../store/selectors';

@Injectable()
export class ReferenceDataGuard implements CanActivate {
  constructor(protected store: Store<EbxState>) {}

  canActivate(): Observable<boolean> {
    return this.checkStore().pipe(catchError(() => of(false)));
  }

  checkStore(): Observable<boolean> {
    return this.store.pipe(
      select(referenceDataSelectors.getReferenceDataLoading),
      withLatestFrom(this.store.pipe(select(referenceDataSelectors.getReferenceDataLoaded))),
      filter(([loading, loaded], index) => {
        if (!loaded && !loading && index === 0) {
          this.store.dispatch(new referenceDataActions.Load());
          return false;
        }
        return !loading;
      }),
      map(([, loaded]) => loaded as boolean)
    );
  }
}
