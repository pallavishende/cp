export class AttachmentFile {
  public fileName: string;
  public fileAliasName: string;
}
