import { Content } from './gcc-content.class';
import { Season } from './gcc-season.class';
import { Episode } from './gcc-episode.class';

export class Card {
  contentDetail: Content;
  seasons?: Array<Season>;
  episodes?: Array<Episode>;
}
