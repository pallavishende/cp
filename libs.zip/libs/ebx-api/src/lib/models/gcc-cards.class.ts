import { Card } from './gcc-card.class';

export class Cards {
  cardsList: Card[];
}
