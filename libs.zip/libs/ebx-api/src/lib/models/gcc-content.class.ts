export class Content {
  contentType: string; /*Series, Movie, Special*/
  vmid: string;
  title: string; // only used in form
  contentTitle: string;
  ownerChannel: string; // linear origin channel
  countryOfOrigin: string; // origin country
  language: string; // origin language
  synopsis: string;
  brand: string;
  provenance: string;
  numberOfEpisodes: number;
  typicalLength?: string;
  script?: string;
  countryLanguage: string;
  genreType?: string;
  genreAuthority?: string;
  genre?: string;
  ratingAuthority?: string;
  ratingDescriptor?: string;
  otherTitles?: string[];

  constructor(contentType: string) {
    this.contentType = contentType;
  }
}
