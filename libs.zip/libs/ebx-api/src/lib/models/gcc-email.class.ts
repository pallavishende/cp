import { AttachmentFile } from './gcc-attachment-file.class';

export class Email {
  public from: string;
  public to: string;
  public cc: string;
  public subject: string;
  public message: string;
  public attachments: Array<AttachmentFile>;
  public firstName: string;
  public lastName: string;
  public displayName: string;
  public userName: string;
  public userGroup: string;
  public requestorInfo: string;
}
