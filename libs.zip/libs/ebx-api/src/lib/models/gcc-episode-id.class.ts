export class IdentificationDetails {
  thirdPartyAuth: string;
  thirdPartyId: string;
}
