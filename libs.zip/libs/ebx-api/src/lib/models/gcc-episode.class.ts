import { Content } from './gcc-content.class';

export class Episode extends Content {
  episodeNumber: string;
  episodeTitle?: string;
  episodeSynopsis: string;
}
