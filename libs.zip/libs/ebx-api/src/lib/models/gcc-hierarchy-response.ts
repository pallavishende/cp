import { HasTitles } from './gcc-search-results';

type HierarchyType = 'Franchise' | 'Series' | 'Season' | 'Episode' | 'Movie' | 'Special';

export interface HierarchyItem extends HasTitles {
  type: HierarchyType;
  vmid: string;
  name: string;
  children?: HierarchyItem[];
  last_update: string;
}

export interface EpisodeHierarchyItem extends HierarchyItem {
  type: 'Episode';
  release_synopsis: string;
  episode_production_number: string;
}

export interface SeasonHierarchyItem extends HierarchyItem {
  type: 'Season';
  season_number: number;
  children: EpisodeHierarchyItem[];
}

export interface SeriesHierarchyItem extends HierarchyItem {
  type: 'Series';
  children: SeasonHierarchyItem[] | EpisodeHierarchyItem[];
}

export interface MovieHierarchyItem extends HierarchyItem {
  type: 'Movie';
}

export interface SpecialHierarchyItem extends HierarchyItem {
  type: 'Special';
}

export interface FranchiseHierarchyItem extends HierarchyItem {
  type: 'Franchise';
}

export interface HierarchyResponse {
  request_vmid: string;
  request_content_type: string;
  request_name: string;
  request_prune_type: string;
  hierarchy: HierarchyItem;
}
