import { DatasetValue } from '@content-platform/application-api';

export type ReferenceDataType = 'brand' | 'channel' | 'language_tag' | 'provenance' | 'country';

export const AllReferenceDataTypes: ReferenceDataType[] = [
  'brand',
  'channel',
  'language_tag',
  'provenance',
  'country'
];

export interface RefItem {
  last_update: string;
}

export interface ReferenceResponse {
  refDataType: ReferenceDataType;
  refData: RefItem[];
}

export interface RefItemWithId extends RefItem {
  id: number;
}

export interface RefItemWithIdAndName extends RefItemWithId {
  name: string;
}

export interface RefItemWithVmid extends RefItemWithIdAndName {
  vmid: string;
}

export interface LanguageTag extends RefItem {
  languageTag: string;
  description: string;
}

export interface Country extends RefItemWithId {
  countryCode: string;
  countryName: string;
}

export interface Provenance extends RefItemWithIdAndName {
  description: string;
}

// export interface IdAuthority extends RefItemWithIdAndName {
//   description?: string;
//   isExternalOrg: boolean;
// }

export type Brand = RefItemWithVmid;

export interface Channel extends RefItemWithVmid {
  code: string;
  status: string;
  brand: Brand;
}

export type AllRefItemType = Brand | Channel | LanguageTag | Country | Provenance;

export function refItemToDatasetValue(referenceItem: RefItem): DatasetValue {
  const refItem = <any>referenceItem;
  if (refItem.vmid && refItem.name) {
    // RefItemWithVmid
    return { ...refItem, name: refItem.vmid, description: refItem.name };
  } else if (refItem.name && refItem.description) {
    // Provenance and some IdAuthorities
    return { ...refItem, name: refItem.name, description: refItem.name };
  } else if (refItem.name) {
    // other Id Authorities
    return { ...refItem, name: refItem.name, description: refItem.name };
  } else if (refItem.countryCode && refItem.countryName) {
    // Country
    return { ...refItem, name: refItem.countryCode, description: refItem.countryName };
  } else if (refItem.languageTag && refItem.description) {
    // LanguageTag
    return { ...refItem, name: refItem.languageTag, description: refItem.description };
  }
}
