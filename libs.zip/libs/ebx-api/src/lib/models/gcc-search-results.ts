export interface Title {
  lang: string;
  last_update: string;
  title_type: string;
  title_value: string;
}

export interface HasTitles {
  titles: Title[];
}

export interface OriginBrand {
  origin_brand_name: string;
  origin_brand_vmid: string;
}

export interface OriginChannel {
  origin_channel_name: string;
  origin_channel_vmid: string;
}

export interface Identitifier {
  identification_authority: string;
  identifier: string;
  last_update: string;
}

export interface Identitifier {
  identification_authority: string;
  identifier: string;
  last_update: string;
}

export interface ContentRelation {
  last_update: string;
  predicate: string;
  target_vmid?: string;
  source_vmid?: string;
}

export interface VmidDetail extends HasTitles {
  content_relations: ContentRelation[];
  ext_attributes: { [key: string]: any };
  external_identifiers: Identitifier[];
  internal_identifiers: Identitifier[];
  last_update: string;
  name: string;
  origin_brand: OriginBrand;
  origin_channel: OriginChannel;
  origin_country: string;
  provenance: string;
  release_synopsis: string;
  type: string;
  vmid: string;
}

export interface SearchResult extends HasTitles {
  titles: Title[];
  type: 'Default Title' | 'Release Title' | 'Formerly Known As Title' | 'Long Title';
  vmid: string;
  vmidDetails: VmidDetail;
}

export interface SearchResponse {
  contentType: string;
  currentPage: number;
  levelOfDetail: string;
  matchType: string;
  maxResultsPerPage: number;
  results: SearchResult[];
  searchText: string;
  totalPages: number;
  totalResults: number;
}
