import { Episode } from './gcc-episode.class';
import { Content } from './gcc-content.class';

export class Season extends Content {
  seasonNumber: number;
  numberOfEpisodes: number;
  episodes?: Array<Episode>;
  seasonTitle?: string;
  seasonSynopsis: string;
}
