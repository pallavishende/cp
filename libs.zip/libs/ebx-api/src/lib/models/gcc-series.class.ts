import { Content } from './gcc-content.class';
import { Season } from './gcc-season.class';
import { Episode } from './gcc-episode.class';

export class Series extends Content {
  seasons?: Array<Season> = [];
  numberOfEpisodes: number;
  episodes?: Array<Episode> = [];
  hasSeasons: boolean;
}
