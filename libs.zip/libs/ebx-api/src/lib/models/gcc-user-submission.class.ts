export class Submission {
  id: number;
  user_id: number;
  date_submitted: Date;
  status: string;
  error_msg: string;
  json_request: string;
}
