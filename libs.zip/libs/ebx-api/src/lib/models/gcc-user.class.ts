export class User {
  id: number;
  first_name: string;
  last_name: string;
  email: string;
  user_group: string;
  user_name: string;
  role_id: number;
  role_name: string;
  user_group_id: number;
  user_group_name: string;
  status: string;
  statusb: boolean;
  edit_mode: boolean;
  created_by: string;
  date_created: Date;
  updated_by: string;
  date_updated: Date;
}

export class RequestorUserGroup {
  requestorGroupID: number;
  requestorGroupName: string;
}
