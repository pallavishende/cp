export class SeriesResult {
  constructor() {}
  vmid: string;
  title_type: string;
  title_value: string;
  language_name: string;
  language_tag: string;
  owner_channel_vmid: string;
  owner_channel: string;
  country_of_origin: string;
  country_name: string;
  description: string;
  provenance: string;
  otherTitles: string[];
  brand: string;
}
