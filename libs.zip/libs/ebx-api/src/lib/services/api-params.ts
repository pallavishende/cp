import { Injectable } from '@angular/core';
import { Environments } from '@content-platform/configuration';

type apiKeys = 'searchByTitle' | 'getDataByVmid' | 'getSeriesHierarchy' | 'getReferenceData';

const FIND_GCC_DATA = '/gccdata/find/json/v1';
const GET_GCC_DATA = '/gccdata/get/json/v1';

const apiEndpoints = {
  searchByTitle: FIND_GCC_DATA + '/title_text',
  getDataByVmid: GET_GCC_DATA + '/vmid/:vmid',
  getSeriesHierarchy: GET_GCC_DATA + '/hierarchy/prune_to_series/:vmid',
  getReferenceData: GET_GCC_DATA + '/refdata/:fieldName'
};

// TODO: We use something similar to this in a lot of places...
// We should probably standardize it (and maybe the resource stuff too) and put it in a library

/**
 * Class with static methods used to get the urls for the api endpoint
 *
 * @export
 * @class ApiParams
 */

@Injectable({
  providedIn: 'root'
})
export class ApiParams {
  constructor() {}

  /**
   * Gets the full url for the given endpoint/type, incase there are dynamic values in the url
   * the user can pass in tokens to replace them.
   *
   * @static
   * @param type
   * @param [tokens] optional tokens for the url
   * @returns the endpoint full url
   */
  getUrl(type: apiKeys, tokens?: { [key: string]: string }) {
    let pattern = apiEndpoints[type];

    if (pattern) {
      if (tokens) {
        Object.keys(tokens).forEach(tokenKey => {
          const tokenVal = encodeURIComponent(tokens[tokenKey]);
          const tokenStandIn = ':' + tokenKey;
          pattern = pattern.replace(tokenStandIn, tokenVal);
        });
      }
      return Environments.getUrl('ebxEndpoint') + pattern;
    }
  }
}
