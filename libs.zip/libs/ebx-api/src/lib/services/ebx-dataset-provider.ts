import { Store, MemoizedSelector, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { withLatestFrom, filter, map } from 'rxjs/operators';
import { CustomDatasetProvider, DatasetOptions } from '@content-platform/dynamic-forms-api';
import { referenceDataSelectors } from '../store/selectors';
import { referenceDataActions } from '../store/actions';
import { ReferenceDataType } from '../models';

function checkEbxDatasets(store: Store<{}>, fieldKeys: string[]): Observable<boolean> {
  let triedToLoad = false;
  return store.pipe(
    select(referenceDataSelectors.getReferenceDataLoading),
    withLatestFrom(store.pipe(select(referenceDataSelectors.getReferenceDataState))),
    filter(([datasetLoading, datasetState]) => {
      if (
        (!datasetState[fieldKeys[0]] || datasetState[fieldKeys[0]].length === 0) &&
        !datasetLoading &&
        !triedToLoad
      ) {
        store.dispatch(new referenceDataActions.Load());
        triedToLoad = true;
        return false;
      }
      return !datasetLoading;
    }),
    map(([, datasetState]) => {
      if (!!datasetState[fieldKeys[0]] && datasetState[fieldKeys[0]].length > 0) {
        return true;
      }
      return false;
    })
  );
}

function checkEbxDataset(store: Store<{}>, fieldKey: string): Observable<boolean> {
  let triedToLoad = false;
  return store.pipe(
    select(referenceDataSelectors.getReferenceDataTypeLoading(fieldKey as ReferenceDataType)),
    withLatestFrom(
      store.pipe(
        select(referenceDataSelectors.getReferenceDataTypeLoaded(fieldKey as ReferenceDataType))
      )
    ),
    filter(([datasetLoading, datasetLoaded]) => {
      if (!datasetLoaded && !datasetLoading && !triedToLoad) {
        store.dispatch(new referenceDataActions.LoadByType(fieldKey as ReferenceDataType));
        triedToLoad = true;
        return false;
      }
      return !datasetLoading;
    }),
    map(([, datasetLoaded]) => datasetLoaded)
  );
}

export function useThisProvider(contentType: string): boolean {
  return contentType.startsWith('cr-');
}

export function checkStore(
  store: Store<{}>,
  _contentType: string,
  fieldKeys: string[]
): Observable<boolean> {
  if (fieldKeys.length === 1) {
    return checkEbxDataset(store, fieldKeys[0]);
  }
  return checkEbxDatasets(store, fieldKeys);
}

export function selectDatasetOptions(
  _contentType: string,
  fieldKey: string
): MemoizedSelector<object, DatasetOptions[]> {
  return referenceDataSelectors.getReferenceDataAsDatasetValues(<ReferenceDataType>fieldKey);
}

export const EbxDatasetProvider: CustomDatasetProvider = {
  useThisProvider,
  checkStore,
  selectDatasetOptions
};
