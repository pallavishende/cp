import { Observable } from 'rxjs';

import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Environments } from '@content-platform/configuration';

/**
 * Interceptor for the EBX requests
 * be on every request.
 *
 * @export
 * @class APIInterceptor
 */
@Injectable()
export class EBXInterceptor implements HttpInterceptor {
  constructor() {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (!request.url.startsWith(Environments.getUrl('ebxEndpoint'))) {
      return next.handle(request);
    }

    request = request.clone({
      setHeaders: {
        'Content-Type': request.headers.get('Content-Type') || 'application/json'
      }
    });
    return next.handle(request);
  }
}
