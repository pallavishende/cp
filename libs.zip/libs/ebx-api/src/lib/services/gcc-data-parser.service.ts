import { Injectable } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable, of, combineLatest } from 'rxjs';
import { map } from 'rxjs/operators';
import {
  SeriesResult,
  SearchResponse,
  LanguageTag,
  Country,
  Season,
  Episode,
  HierarchyResponse,
  SeasonHierarchyItem,
  EpisodeHierarchyItem,
  VmidDetail,
  HasTitles,
  Series
} from '../models';
import { EbxState } from '../store/reducers';
import { referenceDataSelectors } from '../store/selectors';

export class GccParseError extends Error {
  constructor(message: string) {
    super(message);
    // https://stackoverflow.com/questions/41102060/typescript-extending-error-class
    // Set the prototype explicitly.
    Object.setPrototypeOf(this, GccParseError.prototype);
  }
}

@Injectable({
  providedIn: 'root'
})
export class GccDataParserService {
  constructor(private store: Store<EbxState>) {}

  private parseSeasonHierarchy(seasonHierarchy: SeasonHierarchyItem): Season {
    const season = new Season('cr-season');
    season.seasonNumber = seasonHierarchy.season_number;
    season.vmid = seasonHierarchy.vmid;
    season.seasonTitle = this.getTitle(seasonHierarchy);
    season.episodes = seasonHierarchy.children.map(episodeItem =>
      this.parseEpisodeHierarchy(episodeItem)
    );
    season.numberOfEpisodes = season.episodes.length;
    return season;
  }

  private parseEpisodeHierarchy(episodeItem: EpisodeHierarchyItem): Episode {
    const episode = new Episode('cr-episode');
    episode.episodeNumber = episodeItem.episode_production_number;
    episode.vmid = episodeItem.vmid;
    episode.episodeTitle = this.getTitle(episodeItem);
    if (episodeItem.release_synopsis) {
      episode.synopsis = episodeItem.release_synopsis;
    }
    return episode;
  }

  private getTitle(somethingWithTitles: HasTitles): string {
    const releaseTitle = somethingWithTitles.titles.find(x => x.title_type === 'Release Title');
    const defaultTitle = somethingWithTitles.titles.find(x => x.title_type === 'Default Title');
    let title = '';
    if (releaseTitle) {
      title = releaseTitle.title_value;
      if (defaultTitle && defaultTitle.title_value === title) {
        // the release title is the same as the default title... so just ignore it
        title = '';
      }
    }
    return title;
  }

  private getBrand(vmidDetail: VmidDetail): string {
    let brand_name = 'N/A';
    if (vmidDetail.origin_brand) {
      brand_name = vmidDetail.origin_brand.origin_brand_name;
    }
    return brand_name;
  }

  private getOriginChannelData(
    vmidDetail: VmidDetail
  ): { owner_channel_name: string; owner_channel_vmid: string } {
    let owner_channel_name = 'N/A';
    let owner_channel_vmid = '';
    if (vmidDetail.origin_channel) {
      owner_channel_name = vmidDetail.origin_channel.origin_channel_name;
      owner_channel_vmid = vmidDetail.origin_channel.origin_channel_vmid;
    }
    return { owner_channel_name, owner_channel_vmid };
  }

  private getCountryName(vmidDetail: VmidDetail, countries: Country[]): string {
    const countryCode: string = vmidDetail.origin_country;
    // Look up the country name
    const foundCountry = countryCode
      ? countries.find(country => country.countryCode === countryCode)
      : undefined;
    const countryName = foundCountry ? foundCountry.countryName : '';
    return countryName;
  }

  extractSearchData(response: SearchResponse): Observable<SeriesResult[]> {
    if (!response) {
      return of([]);
    }

    return combineLatest(
      this.store.pipe(select(referenceDataSelectors.getReferenceDataType('language_tag'))),
      this.store.pipe(select(referenceDataSelectors.getReferenceDataType('country')))
    ).pipe(
      map(([languages, countries]: [LanguageTag[], Country[]]) => {
        return (response.results || [])
          .map(searchResult => {
            const titles = searchResult.vmidDetails.titles;
            const vmid = searchResult.vmid;
            const description = searchResult.vmidDetails.release_synopsis;
            const provenance = searchResult.vmidDetails.provenance;

            const { owner_channel_name, owner_channel_vmid } = this.getOriginChannelData(
              searchResult.vmidDetails
            );

            const brand = this.getBrand(searchResult.vmidDetails);
            const country_of_origin: string = searchResult.vmidDetails.origin_country;
            const country_name = this.getCountryName(searchResult.vmidDetails, countries);

            let details = titles.find(x => x.title_type === 'Long Title');
            if (!details) {
              details = titles.find(x => x.title_type === 'Default Title');
            }
            if (details) {
              // look up the language
              const foundLanguage = details.lang
                ? languages.find(langauge => langauge.languageTag === details.lang)
                : undefined;
              const language_name = foundLanguage ? foundLanguage.description : '';

              const seriesTitle: SeriesResult = {
                vmid,
                description,
                provenance,
                brand,
                title_type: details.title_type,
                title_value: details.title_value,
                language_tag: details.lang,
                language_name,
                owner_channel_vmid,
                owner_channel: owner_channel_name,
                country_of_origin,
                country_name,
                otherTitles: []
              };

              seriesTitle.otherTitles = (searchResult.vmidDetails.titles || [])
                .filter(
                  otherTitle => otherTitle && otherTitle.title_type === 'Formerly Known As Title'
                )
                .map(title => title.title_value);

              return seriesTitle;
            }
          })
          .filter(item => !!item);
      })
    );
  }

  extractSeriesWithSeasonEpisodeData(
    response: HierarchyResponse,
    seriesId: string,
    additionalSeriesParams?: SeriesResult
  ): Series {
    const existingSeries = new Series('cr-series');

    if (additionalSeriesParams) {
      existingSeries.title = additionalSeriesParams.title_value;
      existingSeries.provenance = additionalSeriesParams.provenance;
      existingSeries.brand = additionalSeriesParams.brand;
      existingSeries.ownerChannel = additionalSeriesParams.owner_channel;
      existingSeries.countryOfOrigin = additionalSeriesParams.country_name;
      existingSeries.language = additionalSeriesParams.language_name;
      existingSeries.synopsis = additionalSeriesParams.description;
      existingSeries.otherTitles = additionalSeriesParams.otherTitles;
    }

    if (!response.hierarchy.children || response.hierarchy.children.length === 0) {
      throw new GccParseError(`Series "${existingSeries.title || seriesId}" - unable to get data`);
    }

    const series = response.hierarchy.children.find(x => x.type === 'Series');

    if (!series) {
      throw new GccParseError(
        `Series "${existingSeries.title || seriesId}" - unable to get series data`
      );
    }

    existingSeries.hasSeasons = false;
    existingSeries.vmid = seriesId;
    if (!series.children) {
      throw new GccParseError(
        `Series "${existingSeries.title ||
          seriesId}" - series data does not include either seasons or episodes`
      );
    }

    series.children.forEach(dataChild => {
      switch (dataChild.type) {
        case 'Season':
          existingSeries.hasSeasons = true;
          existingSeries.seasons.push(this.parseSeasonHierarchy(dataChild as SeasonHierarchyItem));
          break;
        case 'Episode':
          existingSeries.episodes.push(
            this.parseEpisodeHierarchy(dataChild as EpisodeHierarchyItem)
          );
          break;
      }
    });
    existingSeries.numberOfEpisodes = existingSeries.episodes.length;

    return existingSeries;
  }

  extractSeasonData(vmidDetail: VmidDetail): Observable<Season> {
    return this.store.pipe(
      select(referenceDataSelectors.getReferenceDataType('country')),
      map((countries: Country[]) => {
        const season = {} as Season;
        season.vmid = vmidDetail.vmid;
        season.seasonTitle = this.getTitle(vmidDetail);
        season.provenance = vmidDetail.provenance;
        season.countryOfOrigin = this.getCountryName(vmidDetail, countries);
        season.brand = this.getBrand(vmidDetail);
        season.ownerChannel = this.getOriginChannelData(vmidDetail).owner_channel_name;
        season.synopsis = vmidDetail.release_synopsis;
        return season;
      })
    );
  }
}
