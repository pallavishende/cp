import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Observable, of } from 'rxjs';
import { LoggerService } from '@content-platform/logging';
import { ApiParams } from './api-params';
import { GccDataService } from './gcc-data.service';
import { GccDataParserService } from './gcc-data-parser.service';
import { SearchResponse, SeriesResult } from '../models';

describe('GccDataService', () => {
  beforeEach(() =>
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: GccDataParserService,
          useValue: {
            extractSearchData(_response: SearchResponse): Observable<SeriesResult[]> {
              return of([]);
            }
          }
        },
        {
          provide: LoggerService,
          useValue: {
            instance: () => {
              return { log: () => {} };
            }
          }
        },
        {
          provide: ApiParams,
          useValue: {
            getUrl: id => id
          }
        }
      ]
    }));

  it('should be created', () => {
    const service: GccDataService = TestBed.get(GccDataService);
    expect(service).toBeTruthy();
  });
});
