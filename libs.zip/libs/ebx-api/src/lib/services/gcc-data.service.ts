import { Injectable } from '@angular/core';
import { LoggerService } from '@content-platform/logging';
import { throwError, Observable, empty } from 'rxjs';
import { switchMap, map, catchError } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ApiParams } from './api-params';
import {
  SeriesResult,
  ReferenceDataType,
  ReferenceResponse,
  SearchResponse,
  HierarchyResponse,
  VmidDetail,
  Series,
  Season
} from '../models';
import { GccDataParserService, GccParseError } from './gcc-data-parser.service';

@Injectable({
  providedIn: 'root'
})
export class GccDataService {
  private logger: LoggerService;

  constructor(
    private http: HttpClient,
    logger: LoggerService,
    private apiParams: ApiParams,
    private parser: GccDataParserService
  ) {
    this.logger = logger.instance('GccDataService');
  }

  /**
   * error handling in case the resource call fails
   *
   * @protected
   * @param {(Response | any)} error
   * @returns {Observable<any>}
   * @memberof Resource
   */
  protected handleError(msg: string, error: Response | any): Observable<any> {
    const body = error.error && !error.message ? error.error : error;
    this.logger.error(msg, body);
    return throwError({ message: msg, error });
  }

  getReferenceData(fieldName: ReferenceDataType): Observable<ReferenceResponse> {
    const url = this.apiParams.getUrl('getReferenceData', {
      fieldName
    });

    return this.http
      .get(url)
      .pipe(catchError(error => this.handleError(`Unable to load reference data`, error)));
  }

  searchByTitle(title: string, contentType: string = 'Series'): Observable<SeriesResult[]> {
    if (!title || title.length < 2) {
      return empty();
    }

    const url = this.apiParams.getUrl('searchByTitle');

    const body = new URLSearchParams();
    body.set('matchType', 'contains');
    body.set('searchString', title);
    body.set('itemsPerPage', '50');
    body.set('pageNum', '1');
    body.set('contentType', contentType);
    body.set('levelOfDetail', 'verbose');
    body.set('output', 'json');
    const options = {
      headers: new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded')
    };

    return this.http.post(url, body.toString(), options).pipe(
      switchMap((response: SearchResponse) => this.parser.extractSearchData(response)),
      catchError(error =>
        this.handleError(`Unable to search for ${contentType} with title "${title}"`, error)
      )
    );
  }

  getSeriesWithSeasonsAndEpisodes(
    seriesVMID: string,
    updateAdditionalParams: SeriesResult,
    pruneType: string = 'prune_to_series'
  ): Observable<Series> {
    if (!seriesVMID) {
      return empty();
    }
    const url = this.apiParams.getUrl('getSeriesHierarchy', { vmid: seriesVMID, pruneType });
    const options = {
      headers: new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded')
    };

    const defaultErrorMessage = `Unable to get hierarchy for series with VMID ${seriesVMID}`;
    return this.http.get(url, options).pipe(
      map((response: HierarchyResponse) =>
        this.parser.extractSeriesWithSeasonEpisodeData(response, seriesVMID, updateAdditionalParams)
      ),
      catchError(error =>
        this.handleError(
          error && error instanceof GccParseError ? error.message : defaultErrorMessage,
          error
        )
      )
    );
  }

  getSeasonData(seasonVMID: string): Observable<Season> {
    if (!seasonVMID) {
      return empty();
    }
    const url = this.apiParams.getUrl('getDataByVmid', { vmid: seasonVMID });

    const headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    const options = {
      headers: new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded')
    };
    return this.http.get(url, options).pipe(
      switchMap((response: VmidDetail) => this.parser.extractSeasonData(response)),
      catchError(error =>
        this.handleError(`Unable to get data for season with VMID ${seasonVMID}`, error)
      )
    );
  }
}
