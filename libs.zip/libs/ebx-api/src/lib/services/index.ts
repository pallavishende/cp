import { GccDataService } from './gcc-data.service';
export * from './gcc-data.service';
export { EbxDatasetProvider } from './ebx-dataset-provider';

export const resources = [GccDataService];
