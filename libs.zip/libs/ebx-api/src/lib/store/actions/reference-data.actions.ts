import { Action } from '@ngrx/store';
import { ReferenceResponse, ReferenceDataType } from '../../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD = '[ReferenceData] LOAD';
export const LOAD_SUCCESS = '[ReferenceData] LOAD SUCCESS';
export const LOAD_FAILED = '[ReferenceData] LOAD FAILED';
export const LOAD_BY_TYPE = '[ReferenceData] LOAD BY TYPE';
export const LOAD_BY_TYPE_SUCCESS = '[ReferenceData] LOAD BY TYPE SUCCESS';
export const LOAD_BY_TYPE_FAILED = '[ReferenceData] LOAD BY TYPE FAILED';

export class Load implements Action {
  readonly type = LOAD;
  constructor(public payload = null) {}
}

export class LoadSuccess implements Action {
  readonly type = LOAD_SUCCESS;
  constructor() {}
}

export class LoadFailed extends errorActions.Fail {
  readonly type = LOAD_FAILED;
}

export class LoadByType implements Action {
  readonly type = LOAD_BY_TYPE;
  constructor(public payload: ReferenceDataType) {}
}

export class LoadByTypeSuccess implements Action {
  readonly type = LOAD_BY_TYPE_SUCCESS;
  constructor(public payload: ReferenceResponse) {}
}

export class LoadByTypeFailed extends errorActions.Fail {
  readonly type = LOAD_BY_TYPE_FAILED;
}

export type All =
  | Load
  | LoadSuccess
  | LoadFailed
  | LoadByType
  | LoadByTypeSuccess
  | LoadByTypeFailed;
