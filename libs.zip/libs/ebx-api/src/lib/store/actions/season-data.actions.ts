import { Action } from '@ngrx/store';
import { errorActions } from '@content-platform/error-handling';
import { Season } from '../../models';

export const LOAD_BY_ID = '[SeasonData] LOAD BY ID';
export const LOAD_BY_ID_SUCCESS = '[SeasonData] LOAD BY ID SUCCESS';
export const LOAD_BY_ID_FAILED = '[SeasonData] LOAD BY ID FAILED';

export class LoadById implements Action {
  readonly type = LOAD_BY_ID;
  constructor(public payload: {seriesVmid:string, seasonVmid:string}) {}
}

export class LoadByIdSuccess implements Action {
  readonly type = LOAD_BY_ID_SUCCESS;
  constructor(public payload:Season) {}
}

export class LoadByIdFailed extends errorActions.Fail {
  readonly type = LOAD_BY_ID_FAILED;
}

export type All = LoadById | LoadByIdSuccess | LoadByIdFailed;
