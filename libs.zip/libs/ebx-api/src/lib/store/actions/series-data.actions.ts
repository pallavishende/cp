import { Action } from '@ngrx/store';
import { errorActions } from '@content-platform/error-handling';
import { Series, Season, SeriesResult } from '../../models';

export const LOAD_BY_ID = '[SeriesData] LOAD BY ID';
export const LOAD_BY_ID_SUCCESS = '[SeriesData] LOAD BY ID SUCCESS';
export const LOAD_BY_ID_FAILED = '[SeriesData] LOAD BY ID FAILED';

export const UPDATE_SEASON_IN_SERIES = '[SeriesData] UPDATE SEASON IN SERIES';

export const CLEAR_LOADED_SERIES_BY_ID = '[SeriesData] CLEAR LOADED SERIES BY ID';
export const CLEAR_LOADED_SERIES_BY_ID_SUCCESS = '[SeriesData] CLEAR LOADED SERIES BY ID SUCCESS';

export class LoadById implements Action {
  readonly type = LOAD_BY_ID;
  constructor(
    public payload: { seriesVmid: string; fetchLastSeason?: boolean; existingSeries?: SeriesResult }
  ) {}
}

export class LoadByIdSuccess implements Action {
  readonly type = LOAD_BY_ID_SUCCESS;
  constructor(public payload: { series: Series; isFullyLoaded: boolean }) {}
}

export class LoadByIdFailed extends errorActions.Fail {
  readonly type = LOAD_BY_ID_FAILED;
}

export class UpdateSeasonInSeries implements Action {
  readonly type = UPDATE_SEASON_IN_SERIES;
  constructor(public payload: { season: Season; seriesVmid: string }) {}
}

export class ClearLoadedSeriesById implements Action {
  readonly type = CLEAR_LOADED_SERIES_BY_ID;
  constructor(public payload: string) {}
}

export class ClearLoadedSeriesByIdSuccess implements Action {
  readonly type = CLEAR_LOADED_SERIES_BY_ID_SUCCESS;
  constructor(public payload = null) {}
}

export type All =
  | LoadById
  | LoadByIdSuccess
  | LoadByIdFailed
  | UpdateSeasonInSeries
  | ClearLoadedSeriesById
  | ClearLoadedSeriesByIdSuccess;
