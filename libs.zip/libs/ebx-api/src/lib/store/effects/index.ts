import { ReferenceDataEffects } from './reference-data.effects';
import { SeriesDataEffects } from './series-data.effects';
import { SeasonDataEffects } from './season-data.effects';

export * from './reference-data.effects';
export * from './series-data.effects';
export * from './season-data.effects';

const effects = [ReferenceDataEffects, SeriesDataEffects, SeasonDataEffects];

export { effects };
