import { Injectable } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Effect, Actions, ofType } from '@ngrx/effects';
import { DataPersistence } from '@nrwl/nx';
import { State } from '../reducers/reference-data';
import { map, tap, switchMap, filter, catchError } from 'rxjs/operators';

import { GccDataService } from '../../services/gcc-data.service';
import { referenceDataActions } from '../actions';
import { referenceDataSelectors } from '../selectors';
import { AllReferenceDataTypes } from '../../models';

/**
 * The Reference Data effects imported in {@link EbxApiModule }
 *
 */
@Injectable()
export class ReferenceDataEffects {
  constructor(
    private api: GccDataService,
    private store: Store<State>,
    private referenceDataActions$: Actions,
    private dataPersistence: DataPersistence<State>
  ) {}

  @Effect()
  load$ = this.referenceDataActions$.pipe(
    ofType(referenceDataActions.LOAD),
    tap(() =>
      AllReferenceDataTypes.map(refType => {
        this.store.dispatch(new referenceDataActions.LoadByType(refType));
      })
    ),
    switchMap(() => this.store.pipe(select(referenceDataSelectors.getReferenceDataLoaded))),
    filter(loaded => loaded),
    map(() => new referenceDataActions.LoadSuccess()),
    catchError(error => {
      return [
        new referenceDataActions.LoadFailed({
          error: error,
          message: 'Unable to load Reference Data'
        })
      ];
    })
  );

  @Effect()
  loadByType$ = this.dataPersistence.fetch(referenceDataActions.LOAD_BY_TYPE, {
    run: (action: referenceDataActions.LoadByType) => {
      return this.api
        .getReferenceData(action.payload)
        .pipe(map(refResponse => new referenceDataActions.LoadByTypeSuccess(refResponse)));
    },
    onError: (action: referenceDataActions.LoadByType, error) => {
      return new referenceDataActions.LoadFailed({
        error,
        message: 'Unable to load Reference Data of type ' + action.payload
      });
    }
  });
}
