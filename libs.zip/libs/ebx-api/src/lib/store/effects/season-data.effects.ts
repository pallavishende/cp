import { Injectable } from '@angular/core';
import { Effect, ofType, Actions } from '@ngrx/effects';
import { mergeMap, switchMap, map, catchError } from 'rxjs/operators';
import { Season } from '../../models';
import { Observable } from 'rxjs';
import { Action } from '@ngrx/store';

import { GccDataService } from '../../services/gcc-data.service';
import { seasonDataActions, seriesDataActions } from '../actions';

/**
 * The Season Data effects imported in {@link EbxApiModule }
 *
 */
@Injectable()
export class SeasonDataEffects {
  constructor(private api: GccDataService, private seasonDataActions$: Actions) {}

  @Effect()
  loadById$: Observable<Action> = this.seasonDataActions$.pipe(
    ofType(seasonDataActions.LOAD_BY_ID),
    map((action: seasonDataActions.LoadById) => action.payload),
    switchMap(({ seriesVmid, seasonVmid }) =>
      this.api.getSeasonData(seasonVmid).pipe(
        mergeMap((season: Season) => [
          new seriesDataActions.UpdateSeasonInSeries({
            season: season,
            seriesVmid: seriesVmid
          }),
          new seasonDataActions.LoadByIdSuccess(season)
        ]),
        catchError(error => [
          new seasonDataActions.LoadByIdFailed({
            error,
            message: 'Unable to load season data with id ' + seasonVmid
          })
        ])
      )
    )
  );
}
