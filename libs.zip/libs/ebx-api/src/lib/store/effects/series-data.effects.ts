import { Injectable } from '@angular/core';
import { Effect, ofType, Actions } from '@ngrx/effects';
import { mergeMap, switchMap, map, catchError } from 'rxjs/operators';
import { Series } from '../../models';
import { Observable } from 'rxjs';
import { Action } from '@ngrx/store';

import { GccDataService } from '../../services/gcc-data.service';
import { seriesDataActions, seasonDataActions } from '../actions';

/**
 * The Series Data effects imported in {@link EbxApiModule }
 *
 */
@Injectable()
export class SeriesDataEffects {
  constructor(private seriesDataActions$: Actions, private api: GccDataService) {}

  @Effect()
  loadById$: Observable<Action> = this.seriesDataActions$.pipe(
    ofType(seriesDataActions.LOAD_BY_ID),
    map((action: seriesDataActions.LoadById) => action.payload),
    switchMap(({ seriesVmid, fetchLastSeason, existingSeries }) =>
      this.api.getSeriesWithSeasonsAndEpisodes(seriesVmid, existingSeries).pipe(
        mergeMap((series: Series) => {
          if (fetchLastSeason && series.hasSeasons) {
            const lastSeasonVmid = series.seasons[series.seasons.length - 1].vmid;
            return [
              new seriesDataActions.LoadByIdSuccess({ series: series, isFullyLoaded: false }),
              new seasonDataActions.LoadById({
                seriesVmid: series.vmid,
                seasonVmid: lastSeasonVmid
              })
            ];
          }
          return [new seriesDataActions.LoadByIdSuccess({ series: series, isFullyLoaded: true })];
        }),
        catchError(error => [
          new seriesDataActions.LoadByIdFailed({
            error,
            message: error.message || 'Unable to load series data with id ' + seriesVmid
          })
        ])
      )
    )
  );

  @Effect()
  clearSeriesById$ = this.seriesDataActions$.pipe(
    ofType(seriesDataActions.CLEAR_LOADED_SERIES_BY_ID),
    map(() => {
      return new seriesDataActions.ClearLoadedSeriesByIdSuccess();
    })
  );
}
