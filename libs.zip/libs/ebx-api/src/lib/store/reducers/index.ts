import * as fromReferenceData from './reference-data';
import * as fromSeriesData from './series-data';

export interface EbxState {
  referenceData: fromReferenceData.State;
  seriesData:fromSeriesData.State;
}

export { fromReferenceData, fromSeriesData };
