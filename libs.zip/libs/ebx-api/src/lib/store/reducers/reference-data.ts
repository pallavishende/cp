// import { EntityState, createEntityAdapter } from '@ngrx/entity';
import {
  LanguageTag,
  Provenance,
  Country,
  Brand,
  Channel,
  AllReferenceDataTypes
} from '../../models';
import { referenceDataActions } from '../actions';

export interface State {
  language_tag: LanguageTag[];
  provenance: Provenance[];
  country: Country[];
  brand: Brand[];
  channel: Channel[];
  loadedByType: { [type: string]: boolean };
  loadingByType: { [type: string]: boolean };
}

const initalLoadStatus = {};
AllReferenceDataTypes.forEach(type => (initalLoadStatus[type] = false));

export const INIT_STATE: State = {
  language_tag: [],
  provenance: [],
  country: [],
  brand: [],
  channel: [],
  loadedByType: { ...initalLoadStatus },
  loadingByType: { ...initalLoadStatus }
};

export function reducer(state: State = INIT_STATE, action: referenceDataActions.All) {
  switch (action.type) {
    case referenceDataActions.LOAD: {
      return {
        ...state,
        loadedByType: { ...initalLoadStatus }
      };
    }
    case referenceDataActions.LOAD_SUCCESS: {
      return state;
    }
    case referenceDataActions.LOAD_BY_TYPE: {
      const loadingByType = { ...state.loadingByType };
      loadingByType[action.payload] = true;
      const loadedByType = { ...state.loadedByType };
      loadedByType[action.payload] = false;
      return {
        ...state,
        loadingByType,
        loadedByType
      };
    }
    case referenceDataActions.LOAD_BY_TYPE_SUCCESS: {
      const loadingByType = { ...state.loadingByType };
      loadingByType[action.payload.refDataType] = false;
      const loadedByType = { ...state.loadedByType };
      loadedByType[action.payload.refDataType] = true;
      const newState = { ...state, loadingByType, loadedByType };

      switch (action.payload.refDataType) {
        case 'brand':
          newState[action.payload.refDataType] = action.payload.refData as Brand[];
          break;
        case 'channel':
          newState[action.payload.refDataType] = action.payload.refData as Channel[];
          break;
        case 'provenance':
          newState[action.payload.refDataType] = action.payload.refData as Provenance[];
          break;
        case 'language_tag':
          newState[action.payload.refDataType] = action.payload.refData as LanguageTag[];
          break;
        case 'country':
          newState[action.payload.refDataType] = action.payload.refData as Country[];
          break;
      }

      return newState;
    }

    case referenceDataActions.LOAD_FAILED: {
      return { ...state, loading: false, loaded: false };
    }

    default: {
      return state;
    }
  }
}
export const getReferenceDataLoading = (state: State) => {
  return Object.values(state.loadingByType).find(loading => loading);
};
export const getReferenceDataLoaded = (state: State) => {
  return Object.values(state.loadedByType).reduce((loaded, current) => {
    return loaded && current;
  }, true);
};
