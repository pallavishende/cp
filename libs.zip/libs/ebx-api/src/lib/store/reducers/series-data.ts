import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { Series } from '../../models';
import { seriesDataActions } from '../actions';

export const seriesAdapter = createEntityAdapter<Series>({
  selectId: (item: Series) => item.vmid,
  sortComparer: false
});

export interface State extends EntityState<Series> {
  loading: boolean;
  loaded: boolean;
  isFullyLoaded: boolean; // If Series and last season is loaded for the series
  currentSeries: Series;
}

export const INIT_STATE: State = seriesAdapter.getInitialState({
  loading: false,
  loaded: false,
  isFullyLoaded: false,
  currentSeries: undefined
});

export function reducer(state: State = INIT_STATE, action: seriesDataActions.All) {
  switch (action.type) {
    case seriesDataActions.LOAD_BY_ID: {
      return {
        ...state,
        loading: true,
        loaded: false,
        isFullyLoaded: false
      };
    }

    case seriesDataActions.LOAD_BY_ID_SUCCESS: {
      const series = action.payload.series;
      return {
        ...seriesAdapter.addOne(series, state),
        loading: false,
        loaded: true,
        isFullyLoaded: action.payload.isFullyLoaded,
        currentSeries: series
      };
    }

    case seriesDataActions.UPDATE_SEASON_IN_SERIES: {
      const series = state.entities[action.payload.seriesVmid];
      const foundSeason = series.seasons.find(season => season.vmid === action.payload.season.vmid);
      const mergedSeason = Object.assign(action.payload.season, foundSeason);
      series.seasons = series.seasons.map(season => {
        if (season.vmid === mergedSeason.vmid) {
          return mergedSeason;
        }
        return season;
      });
      return {
        ...seriesAdapter.updateOne({ id: series.vmid, changes: series }, state),
        loading: false,
        loaded: true,
        isFullyLoaded: true,
        currentSeries: series
      };
    }

    case seriesDataActions.CLEAR_LOADED_SERIES_BY_ID: {
      const newState = {
        ...seriesAdapter.removeOne(action.payload, state),
        loading: false,
        loaded: false,
        isFullyLoaded: false
      };

      if (state.currentSeries && state.currentSeries.vmid === action.payload) {
        newState.currentSeries = undefined;
      }

      return newState;
    }

    case seriesDataActions.LOAD_BY_ID_FAILED: {
      return { ...state, loading: false, loaded: false, isFullyLoaded: false };
    }

    default: {
      return state;
    }
  }
}
export const getSeriesDataLoading = (state: State) => state.loading;
export const getSeriesDataLoaded = (state: State) => state.loaded;
export const getCurrentSeries = (state: State) => state.currentSeries;

export const getSeriesDataFullyLoaded = (state: State) => state.isFullyLoaded;
