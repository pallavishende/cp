import { createFeatureSelector, createSelector } from '@ngrx/store';
import { fromReferenceData } from '../reducers';
import {
  ReferenceDataType,
  refItemToDatasetValue,
  RefItem,
  LanguageTag,
  Country
} from '../../models';

export const getReferencedataRootState = createFeatureSelector<fromReferenceData.State>(
  'referenceData'
);
export const getReferenceDataState = createSelector(
  getReferencedataRootState,
  state => state
);

/**
 * Selector to return the loaded property of the state
 */
export const getReferenceDataLoaded = createSelector(
  getReferenceDataState,
  fromReferenceData.getReferenceDataLoaded
);

/**
 * Selector to return the loading property of the state
 */
export const getReferenceDataLoading = createSelector(
  getReferenceDataState,
  fromReferenceData.getReferenceDataLoading
);

/**
 * Selector to get the loaded value for a particular type
 */
export const getReferenceDataTypeLoaded = (refType: ReferenceDataType) =>
  createSelector(
    getReferenceDataState,
    (state: fromReferenceData.State) => state.loadedByType[refType]
  );

/**
 * Selector to get the loading value for a particular type
 */
export const getReferenceDataTypeLoading = (refType: ReferenceDataType) =>
  createSelector(
    getReferenceDataState,
    (state: fromReferenceData.State) => state.loadingByType[refType]
  );

/**
 * Selector to get the Reference Data for a particular type
 */
export const getReferenceDataType = (refType: ReferenceDataType) =>
  createSelector(
    getReferenceDataState,
    (state: fromReferenceData.State) => state[refType]
  );

/**
 * Selector to get the Reference Data for a particular type as an array of dataset values
 */
export const getReferenceDataAsDatasetValues = (refType: ReferenceDataType) =>
  createSelector(
    getReferenceDataState,
    (state: fromReferenceData.State) => {
      const datasetOptionsArray = (<RefItem[]>(state[refType] || [])).map(refItem =>
        refItemToDatasetValue(refItem)
      );
      return [
        {
          values: datasetOptionsArray
        }
      ];
    }
  );

/**
 * Selector to get the Language with a particular code
 */
export const findLanguageByCode = (languageTag: string) =>
  createSelector(
    getReferenceDataType('language_tag'),
    (languages: LanguageTag[]) => {
      return languages.find(langauge => langauge.languageTag === languageTag);
    }
  );

/**
 * Selector to get the Country with a particular code
 */
export const findCountryByCode = (countryCode: string) =>
  createSelector(
    getReferenceDataType('country'),
    (countries: Country[]) => {
      return countries.find(country => country.countryCode === countryCode);
    }
  );
