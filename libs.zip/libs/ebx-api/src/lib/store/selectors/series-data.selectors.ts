import { createFeatureSelector, createSelector } from '@ngrx/store';
import { fromSeriesData } from '../reducers';

export const getSeriesdataRootState = createFeatureSelector<fromSeriesData.State>('seriesData');
export const getSeriesDataState = createSelector(getSeriesdataRootState, state => state);

export const {
  selectAll: getSeriesItems,
  selectEntities: getSeriesEntities
} = fromSeriesData.seriesAdapter.getSelectors(getSeriesDataState);

export const getSeriesById = id => createSelector(getSeriesEntities, entities => entities[id]);

/**
 * Selector to return the loaded property of the state
 */
export const getSeriesDataLoaded = createSelector(
  getSeriesDataState,
  fromSeriesData.getSeriesDataLoaded
);

/**
 * Selector to return the loading property of the state
 */
export const getSeriesDataLoading = createSelector(
  getSeriesDataState,
  fromSeriesData.getSeriesDataLoading
);

export const getSeriesFullyLoaded = createSelector(
  getSeriesDataState,
  fromSeriesData.getSeriesDataFullyLoaded
);

export const getCurrentSeries = createSelector(
  getSeriesDataState,
  fromSeriesData.getCurrentSeries
);
