import { Action } from '@ngrx/store';
import { DestinationTemplate } from '../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD = '[DestinationTemplate] LOAD';
export const LOAD_SUCCESS = '[DestinationTemplate] LOAD SUCCESS';
export const LOAD_FAILED = '[DestinationTemplate] LOAD FAILED';
export const LOAD_BY_ID = '[DestinationTemplate] LOAD_BY_ID';
export const LOAD_BY_ID_SUCCESS = '[DestinationTemplate] LOAD_BY_ID SUCCESS';
export const LOAD_BY_ID_FAILED = '[DestinationTemplate] LOAD_BY_ID FAILED';
export const UPDATE = '[DestinationTemplate] UPDATE';
export const UPDATE_SUCCESS = '[DestinationTemplate] UPDATE SUCCESS';
export const UPDATE_FAILED = '[DestinationTemplate] UPDATE FAILED';
export const DELETE = '[DestinationTemplate] DELETE';
export const DELETE_SUCCESS = '[DestinationTemplate] DELETE SUCCESS';
export const DELETE_FAILED = '[DestinationTemplate] DELETE FAILED';
export const CREATE = '[DestinationTemplate] CREATE';
export const CREATE_SUCCESS = '[DestinationTemplate] CREATE SUCCESS';
export const CREATE_FAILED = '[DestinationTemplate] CREATE FAILED';
export const RESET_STORE = '[DestinationTemplate] RESET STORE';

export class Load implements Action {
  readonly type = LOAD;
  constructor(public payload = null) {}
}

export class LoadSuccess implements Action {
  readonly type = LOAD_SUCCESS;
  constructor(public payload: DestinationTemplate[]) {}
}

export class LoadFailed extends errorActions.Fail {
  readonly type = LOAD_FAILED;
}

export class LoadById implements Action {
  readonly type = LOAD_BY_ID;
  constructor(public payload: string) {}
}

export class LoadByIdSuccess implements Action {
  readonly type = LOAD_BY_ID_SUCCESS;
  constructor(public payload: DestinationTemplate) {}
}

export class LoadByIdFailed extends errorActions.Fail {
  readonly type = LOAD_BY_ID_FAILED;
}

export class Update implements Action {
  readonly type = UPDATE;
  constructor(public payload: DestinationTemplate) {}
}

export class UpdateSuccess implements Action {
  readonly type = UPDATE_SUCCESS;
  constructor(public payload: DestinationTemplate) {}
}

export class UpdateFailed extends errorActions.Fail {
  readonly type = UPDATE_FAILED;
}

export class Delete implements Action {
  readonly type = DELETE;
  constructor(public payload: number) {}
}

export class DeleteSuccess implements Action {
  readonly type = DELETE_SUCCESS;
  constructor(public payload: number) {}
}

export class DeleteFailed extends errorActions.Fail {
  readonly type = DELETE_FAILED;
}

export class Create implements Action {
  readonly type = CREATE;
  constructor(public payload: DestinationTemplate) {}
}

export class CreateSuccess implements Action {
  readonly type = CREATE_SUCCESS;
  constructor(public payload: DestinationTemplate) {}
}

export class CreateFailed extends errorActions.Fail {
  readonly type = CREATE_FAILED;
}

export class ResetStore implements Action {
  readonly type = RESET_STORE;
  constructor() {}
}

export type All =
  | Load
  | LoadSuccess
  | LoadFailed
  | LoadById
  | LoadByIdSuccess
  | LoadByIdFailed
  | Update
  | UpdateSuccess
  | UpdateFailed
  | Delete
  | DeleteSuccess
  | DeleteFailed
  | Create
  | CreateSuccess
  | CreateFailed
  | ResetStore;
