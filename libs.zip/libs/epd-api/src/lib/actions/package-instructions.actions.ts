import { Action } from '@ngrx/store';
import { PackageInstructions } from '../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD = '[Package-Instructions] LOAD';
export const LOAD_SUCCESS = '[Package-Instructions] LOAD SUCCESS';
export const LOAD_FAILED = '[Package-Instructions] LOAD FAILED';
export const LOAD_BY_ID = '[Package-Instructions] LOAD_BY_ID';
export const LOAD_BY_ID_SUCCESS = '[Package-Instructions] LOAD_BY_ID SUCCESS';
export const LOAD_BY_ID_FAILED = '[Package-Instructions] LOAD_BY_ID FAILED';
export const UPDATE = '[Package-Instructions] UPDATE';
export const UPDATE_SUCCESS = '[Package-Instructions] UPDATE SUCCESS';
export const UPDATE_FAILED = '[Package-Instructions] UPDATE FAILED';
export const DELETE = '[Package-Instructions] DELETE';
export const DELETE_SUCCESS = '[Package-Instructions] DELETE SUCCESS';
export const DELETE_FAILED = '[Package-Instructions] DELETE FAILED';
export const RESET_STORE = '[Package-Instructions] RESET STORE';

export class Load implements Action {
  readonly type = LOAD;
  constructor(public payload: string) {}
}

export class LoadSuccess implements Action {
  readonly type = LOAD_SUCCESS;
  constructor(public payload: PackageInstructions) {}
}

export class LoadFailed extends errorActions.Fail {
  readonly type = LOAD_FAILED;
}

export class LoadById implements Action {
  readonly type = LOAD_BY_ID;
  constructor(public payload: PackageInstructions) {}
}

export class LoadByIdSuccess implements Action {
  readonly type = LOAD_BY_ID_SUCCESS;
  constructor(public payload: PackageInstructions) {}
}

export class LoadByIdFailed extends errorActions.Fail {
  readonly type = LOAD_BY_ID_FAILED;
}

export class Update implements Action {
  readonly type = UPDATE;
  constructor(public payload: PackageInstructions) {}
}

export class UpdateSuccess implements Action {
  readonly type = UPDATE_SUCCESS;
  constructor(public payload: PackageInstructions) {}
}

export class UpdateFailed extends errorActions.Fail {
  readonly type = UPDATE_FAILED;
}

export class Delete implements Action {
  readonly type = DELETE;
  constructor(public payload: number) {}
}

export class DeleteSuccess implements Action {
  readonly type = DELETE_SUCCESS;
  constructor(public payload: number) {}
}

export class DeleteFailed extends errorActions.Fail {
  readonly type = DELETE_FAILED;
}

export class ResetStore implements Action {
  readonly type = RESET_STORE;
  constructor() {}
}

export type All =
  | Load
  | LoadSuccess
  | LoadFailed
  | LoadById
  | LoadByIdSuccess
  | LoadByIdFailed
  | Update
  | UpdateSuccess
  | UpdateFailed
  | Delete
  | DeleteSuccess
  | DeleteFailed
  | ResetStore;
