import { Action } from '@ngrx/store';
import { PackageStructure } from '../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD = '[PackageStructure] LOAD';
export const LOAD_SUCCESS = '[PackageStructure] LOAD SUCCESS';
export const LOAD_FAILED = '[PackageStructure] LOAD FAILED';
export const LOAD_BY_ID = '[PackageStructure] LOAD BY ID';
export const LOAD_BY_ID_SUCCESS = '[PackageStructure] LOAD BY ID SUCCESS';
export const LOAD_BY_ID_FAILED = '[PackageStructure] LOAD BY ID FAILED';
export const UPDATE = '[PackageStructure] UPDATE';
export const UPDATE_SUCCESS = '[PackageStructure] UPDATE SUCCESS';
export const UPDATE_FAILED = '[PackageStructure] UPDATE FAILED';
export const DELETE = '[PackageStructure] DELETE';
export const DELETE_SUCCESS = '[PackageStructure] DELETE SUCCESS';
export const DELETE_FAILED = '[PackageStructure] DELETE FAILED';
export const CREATE = '[PackageStructure] CREATE';
export const CREATE_SUCCESS = '[PackageStructure] CREATE SUCCESS';
export const CREATE_FAILED = '[PackageStructure] CREATE FAILED';
export const RESET_STORE = '[PackageStructure] RESET STORE';

export class Load implements Action {
  readonly type = LOAD;
  constructor(public payload = null) {}
}
export class LoadSuccess implements Action {
  readonly type = LOAD_SUCCESS;
  constructor(public payload: PackageStructure[]) {}
}
export class LoadFailed extends errorActions.Fail {
  readonly type = LOAD_FAILED;
}

export class LoadById implements Action {
  readonly type = LOAD_BY_ID;
  constructor(public payload: string) {}
}
export class LoadByIdSuccess implements Action {
  readonly type = LOAD_BY_ID_SUCCESS;
  constructor(public payload: PackageStructure) {}
}
export class LoadByIdFailed extends errorActions.Fail {
  readonly type = LOAD_BY_ID_FAILED;
}

export class Update implements Action {
  readonly type = UPDATE;
  constructor(public payload: PackageStructure) {}
}
export class UpdateSuccess implements Action {
  readonly type = UPDATE_SUCCESS;
  constructor(public payload: PackageStructure) {}
}
export class UpdateFailed extends errorActions.Fail {
  readonly type = UPDATE_FAILED;
}

export class Delete implements Action {
  readonly type = DELETE;
  constructor(public payload: number) {}
}
export class DeleteSuccess implements Action {
  readonly type = DELETE_SUCCESS;
  constructor(public payload: number) {}
}
export class DeleteFailed extends errorActions.Fail {
  readonly type = DELETE_FAILED;
}

export class Create implements Action {
  readonly type = CREATE;
  constructor(public payload: PackageStructure) {}
}
export class CreateSuccess implements Action {
  readonly type = CREATE_SUCCESS;
  constructor(public payload: PackageStructure) {}
}
export class CreateFailed extends errorActions.Fail {
  readonly type = CREATE_FAILED;
}

export class ResetStore implements Action {
  readonly type = RESET_STORE;
  constructor() {}
}

export type All =
  | Load
  | LoadSuccess
  | LoadFailed
  | LoadById
  | LoadByIdSuccess
  | LoadByIdFailed
  | Update
  | UpdateSuccess
  | UpdateFailed
  | Create
  | CreateSuccess
  | CreateFailed
  | Delete
  | DeleteSuccess
  | DeleteFailed
  | ResetStore;
