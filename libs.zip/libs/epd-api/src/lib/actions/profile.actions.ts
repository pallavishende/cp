import { Action } from '@ngrx/store';
import { Profile } from '../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD = '[Profile] LOAD';
export const LOAD_SUCCESS = '[Profile] LOAD SUCCESS';
export const LOAD_FAILED = '[Profile] LOAD FAILED';
export const LOAD_BY_ID = '[Profile] LOAD BY ID';
export const LOAD_BY_ID_SUCCESS = '[Profile] LOAD BY ID SUCCESS';
export const LOAD_BY_ID_FAILED = '[Profile] LOAD BY ID FAILED';
export const UPDATE = '[Profile] UPDATE';
export const UPDATE_SUCCESS = '[Profile] UPDATE SUCCESS';
export const UPDATE_FAILED = '[Profile] UPDATE FAILED';
export const DELETE = '[Profile] DELETE';
export const DELETE_SUCCESS = '[Profile] DELETE SUCCESS';
export const DELETE_FAILED = '[Profile] DELETE FAILED';
export const CREATE = '[Profile] CREATE';
export const CREATE_SUCCESS = '[Profile] CREATE SUCCESS';
export const CREATE_FAILED = '[Profile] CREATE FAILED';

export class Load implements Action {
  readonly type = LOAD;
  constructor(public payload = null) {}
}

export class LoadSuccess implements Action {
  readonly type = LOAD_SUCCESS;
  constructor(public payload: Profile[]) {}
}

export class LoadFailed extends errorActions.Fail {
  readonly type = LOAD_FAILED;
}

export class LoadById implements Action {
  readonly type = LOAD_BY_ID;
  constructor(public payload: Profile) {}
}

export class LoadByIdSuccess implements Action {
  readonly type = LOAD_BY_ID_SUCCESS;
  constructor(public payload: Profile) {}
}

export class LoadByIdFailed extends errorActions.Fail {
  readonly type = LOAD_BY_ID_FAILED;
}

export class Update implements Action {
  readonly type = UPDATE;
  constructor(public payload: Profile) {}
}

export class UpdateSuccess implements Action {
  readonly type = UPDATE_SUCCESS;
  constructor(public payload: Profile) {}
}

export class UpdateFailed extends errorActions.Fail {
  readonly type = UPDATE_FAILED;
}

export class Delete implements Action {
  readonly type = DELETE;
  constructor(public payload: number) {}
}

export class DeleteSuccess implements Action {
  readonly type = DELETE_SUCCESS;
  constructor(public payload: number) {}
}

export class DeleteFailed extends errorActions.Fail {
  readonly type = DELETE_FAILED;
}

export class Create implements Action {
  readonly type = CREATE;
  constructor(public payload: Profile) {}
}

export class CreateSuccess implements Action {
  readonly type = CREATE_SUCCESS;
  constructor(public payload: Profile) {}
}

export class CreateFailed extends errorActions.Fail {
  readonly type = CREATE_FAILED;
}

export type All =
  | Load
  | LoadSuccess
  | LoadFailed
  | LoadById
  | LoadByIdSuccess
  | LoadByIdFailed
  | Update
  | UpdateSuccess
  | UpdateFailed
  | Create
  | CreateSuccess
  | CreateFailed
  | Delete
  | DeleteSuccess
  | DeleteFailed;
