import { Action } from '@ngrx/store';
import { ReferenceResponse, ReferenceDataType } from '../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD = '[ReferenceData] LOAD';
export const LOAD_SUCCESS = '[ReferenceData] LOAD SUCCESS';
export const LOAD_FAILED = '[ReferenceData] LOAD FAILED';
export const LOAD_BY_TYPE = '[ReferenceData] LOAD BY TYPE';
export const LOAD_BY_TYPE_SUCCESS = '[ReferenceData] LOAD BY TYPE SUCCESS';
export const LOAD_BY_TYPE_FAILED = '[ReferenceData] LOAD BY TYPE FAILED';
export const LOAD_FALLBACK_PACKAGE_LIST = '[ReferenceData] LOAD FALLBACK PACKAGE LIST';
export const LOAD_FALLBACK_PACKAGE_LIST_SUCCESS =
  '[ReferenceData] LOAD FALLBACK PACKAGE LIST SUCCESS';
export const LOAD_FALLBACK_PACKAGE_LIST_FAILED =
  '[ReferenceData] LOAD FALLBACK PACKAGE LIST FAILED';
export const LOAD_IMAGE_FALLBACK_LIST = '[ReferenceData] LOAD IMAGE FALLBACK LIST';
export const LOAD_IMAGE_FALLBACK_LIST_SUCCESS = '[ReferenceData] LOAD IMAGE FALLBACK LIST SUCCESS';
export const LOAD_IMAGE_FALLBACK_LIST_FAILED = '[ReferenceData] LOAD IMAGE FALLBACK LIST FAILED';
export const LOAD_VIDEO_CODEC_DROPDOWNS = '[ReferenceData] LOAD VIDEO CODEC DROPDOWNS';
export const LOAD_VIDEO_CODEC_DROPDOWNS_SUCCESS =
  '[ReferenceData] LOAD VIDEO CODEC DROPDOWNS SUCCESS';
export const LOAD_VIDEO_CODEC_DROPDOWNS_FAILED =
  '[ReferenceData] LOAD VIDEO CODEC DROPDOWNS FAILED';
export const LOAD_DELIVERY_TEMPLATE_LIST = '[ReferenceData] LOAD DELIVERY TEMPLATE LIST';
export const LOAD_DELIVERY_TEMPLATE_LIST_SUCCESS = '[ReferenceData] LOAD DELIVERY TEMPLATE SUCCESS';
export const LOAD_DELIVERY_TEMPLATE_LIST_FAILED = '[ReferenceData] LOAD DELIVERY TEMPLATE FAILED';
export const LOAD_PACKAGE_TEMPLATE_LIST = '[ReferenceData] LOAD PACKAGE TEMPLATE LIST';
export const LOAD_PACKAGE_TEMPLATE_LIST_SUCCESS = '[ReferenceData] LOAD PACKAGE TEMPLATE SUCCESS';
export const LOAD_PACKAGE_TEMPLATE_LIST_FAILED = '[ReferenceData] LOAD PACKAGE TEMPLATE FAILED';
export const LOAD_PACKAGE_STRUCTURE_LISTS = '[ReferenceData] LOAD PACKAGE STRUCTURE LISTS';
export const LOAD_PACKAGE_STRUCTURE_LISTS_SUCCESS =
  '[ReferenceData] LOAD PACKAGE STRUCTURE LISTS SUCCESS';
export const LOAD_PACKAGE_STRUCTURE_LISTS_FAILED =
  '[ReferenceData] LOAD PACKAGE STRUCTURE LISTS FAILED';

export class Load implements Action {
  readonly type = LOAD;
  constructor(public payload = null) {}
}

export class LoadSuccess implements Action {
  readonly type = LOAD_SUCCESS;
  constructor(public payload: ReferenceResponse) {}
}

export class LoadFailed extends errorActions.Fail {
  readonly type = LOAD_FAILED;
}

export class LoadByType implements Action {
  readonly type = LOAD_BY_TYPE;
  constructor(public payload: ReferenceDataType) {}
}

export class LoadByTypeSuccess implements Action {
  readonly type = LOAD_BY_TYPE_SUCCESS;
  constructor(public payload: ReferenceResponse) {}
}

export class LoadByTypeFailed extends errorActions.Fail {
  readonly type = LOAD_BY_TYPE_FAILED;
}

export class LoadFallbackPackageList implements Action {
  readonly type = LOAD_FALLBACK_PACKAGE_LIST;
  constructor(public payload: any) {}
}
export class LoadFallbackPackageListSuccess implements Action {
  readonly type = LOAD_FALLBACK_PACKAGE_LIST_SUCCESS;
  constructor(public payload: any) {}
}
export class LoadFallbackPackageListFailed extends errorActions.Fail {
  readonly type = LOAD_FALLBACK_PACKAGE_LIST_FAILED;
}

export class LoadImageFallbackList implements Action {
  readonly type = LOAD_IMAGE_FALLBACK_LIST;
  constructor(public payload: number) {}
}
export class LoadImageFallbackListSuccess implements Action {
  readonly type = LOAD_IMAGE_FALLBACK_LIST_SUCCESS;
  constructor(public payload: any) {}
}
export class LoadImageFallbackListFailed extends errorActions.Fail {
  readonly type = LOAD_IMAGE_FALLBACK_LIST_FAILED;
}

export class LoadVideoCodecDropdowns implements Action {
  readonly type = LOAD_VIDEO_CODEC_DROPDOWNS;
  constructor(public payload = null) {}
}
export class LoadVideoCodecDropdownsSuccess implements Action {
  readonly type = LOAD_VIDEO_CODEC_DROPDOWNS_SUCCESS;
  constructor(public payload: any) {}
}
export class LoadVideoCodecDropdownsFailed extends errorActions.Fail {
  readonly type = LOAD_VIDEO_CODEC_DROPDOWNS_FAILED;
}

export class LoadDeliveryTemplateList implements Action {
  readonly type = LOAD_DELIVERY_TEMPLATE_LIST;
  constructor(public payload: any) {}
}
export class LoadDeliveryTemplateListSuccess implements Action {
  readonly type = LOAD_DELIVERY_TEMPLATE_LIST_SUCCESS;
  constructor(public payload: any) {}
}
export class LoadDeliveryTemplateListFailed extends errorActions.Fail {
  readonly type = LOAD_DELIVERY_TEMPLATE_LIST_FAILED;
}

export class LoadPackageTemplateList implements Action {
  readonly type = LOAD_PACKAGE_TEMPLATE_LIST;
  constructor(public payload: any) {}
}
export class LoadPackageTemplateListSuccess implements Action {
  readonly type = LOAD_PACKAGE_TEMPLATE_LIST_SUCCESS;
  constructor(public payload: any) {}
}
export class LoadPackageTemplateListFailed extends errorActions.Fail {
  readonly type = LOAD_PACKAGE_TEMPLATE_LIST_FAILED;
}

export class LoadPackageStructureLists implements Action {
  readonly type = LOAD_PACKAGE_STRUCTURE_LISTS;
  constructor(public payload: any) {}
}
export class LoadPackageStructureListsSuccess implements Action {
  readonly type = LOAD_PACKAGE_STRUCTURE_LISTS_SUCCESS;
  constructor(public payload: any) {}
}
export class LoadPackageStructureListsFailed extends errorActions.Fail {
  readonly type = LOAD_PACKAGE_STRUCTURE_LISTS_FAILED;
}

export type All =
  | Load
  | LoadSuccess
  | LoadFailed
  | LoadByType
  | LoadByTypeSuccess
  | LoadByTypeFailed
  | LoadFallbackPackageList
  | LoadFallbackPackageListSuccess
  | LoadFallbackPackageListFailed
  | LoadImageFallbackList
  | LoadImageFallbackListSuccess
  | LoadImageFallbackListFailed
  | LoadVideoCodecDropdowns
  | LoadVideoCodecDropdownsSuccess
  | LoadVideoCodecDropdownsFailed
  | LoadDeliveryTemplateList
  | LoadDeliveryTemplateListSuccess
  | LoadDeliveryTemplateListFailed
  | LoadPackageTemplateList
  | LoadPackageTemplateListSuccess
  | LoadPackageTemplateListFailed
  | LoadPackageStructureLists
  | LoadPackageStructureListsSuccess
  | LoadPackageStructureListsFailed;
