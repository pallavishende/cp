import { Action } from '@ngrx/store';
import { PackageStructure } from '../models';
import { errorActions } from '@content-platform/error-handling';

export const LOAD_ALL_BY_PARTNER_PROFILE_ID =
  '[PackageStructureListing] LOAD ALL BY PARTNER_PROFILE ID';
export const LOAD_ALL_BY_PARTNER_PROFILE_ID_SUCCESS =
  '[PackageStructureListing] LOAD ALL BY PARTNER_PROFILE ID SUCCESS';
export const LOAD_ALL_BY_PARTNER_PROFILE_ID_FAILED =
  '[PackageStructureListing] LOAD ALL BY PARTNER_PROFILE ID FAILED';
export const UPDATE = '[PackageStructureListing] UPDATE';
export const UPDATE_SUCCESS = '[PackageStructureListing] UPDATE SUCCESS';
export const UPDATE_FAILED = '[PackageStructureListing] UPDATE FAILED';
export const DELETE = '[PackageStructureListing] DELETE';
export const DELETE_SUCCESS = '[PackageStructureListing] DELETE SUCCESS';
export const DELETE_FAILED = '[PackageStructureListing] DELETE FAILED';
export const CREATE = '[PackageStructureListing] CREATE';
export const CREATE_SUCCESS = '[PackageStructureListing] CREATE SUCCESS';
export const CREATE_FAILED = '[PackageStructureListing] CREATE FAILED';

export class LoadAllByPartnerProfileId implements Action {
  readonly type = LOAD_ALL_BY_PARTNER_PROFILE_ID;
  constructor(public payload: PackageStructure) {}
}

export class LoadAllByPartnerProfileIdSuccess implements Action {
  readonly type = LOAD_ALL_BY_PARTNER_PROFILE_ID_SUCCESS;
  constructor(public payload: PackageStructure) {}
}

export class LoadAllByPartnerProfileIdFailed extends errorActions.Fail {
  readonly type = LOAD_ALL_BY_PARTNER_PROFILE_ID_FAILED;
}

export class Update implements Action {
  readonly type = UPDATE;
  constructor(public payload: PackageStructure) {}
}

export class UpdateSuccess implements Action {
  readonly type = UPDATE_SUCCESS;
  constructor(public payload: PackageStructure) {}
}

export class UpdateFailed extends errorActions.Fail {
  readonly type = UPDATE_FAILED;
}

export class Delete implements Action {
  readonly type = DELETE;
  constructor(public payload: number) {}
}

export class DeleteSuccess implements Action {
  readonly type = DELETE_SUCCESS;
  constructor(public payload: number) {}
}

export class DeleteFailed extends errorActions.Fail {
  readonly type = DELETE_FAILED;
}

export class Create implements Action {
  readonly type = CREATE;
  constructor(public payload: PackageStructure) {}
}

export class CreateSuccess implements Action {
  readonly type = CREATE_SUCCESS;
  constructor(public payload: PackageStructure) {}
}

export class CreateFailed extends errorActions.Fail {
  readonly type = CREATE_FAILED;
}

export type All =
  | LoadAllByPartnerProfileId
  | LoadAllByPartnerProfileIdSuccess
  | LoadAllByPartnerProfileIdFailed
  | Update
  | UpdateSuccess
  | UpdateFailed
  | Create
  | CreateSuccess
  | CreateFailed
  | Delete
  | DeleteSuccess
  | DeleteFailed;
