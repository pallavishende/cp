import { Injectable } from '@angular/core';
import { Action, Store, select } from '@ngrx/store';
import { Effect, Actions, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { switchMap, map, catchError, withLatestFrom, mergeMap } from 'rxjs/operators';
import { authSelectors } from '@content-platform/auth';

import { DestinationTemplate } from '../models';
import { destinationTemplateActions } from '../actions';
import {
  DestinationTemplateResource,
  NotificationService,
  ActionDispatchService
} from '../services';
import { EpdState } from '../reducers';

@Injectable()
export class DestinationTemplateEffects {
  constructor(
    private destinationTemplateActions$: Actions,
    private api: DestinationTemplateResource,
    private notification: NotificationService,
    private actionDispatch: ActionDispatchService,
    private store: Store<EpdState>
  ) {}

  /**
   * Loads all the available destination templates only when a user is logged in and triggers a LoadSuccess action.
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when all destination templates are retrieved
   */
  @Effect()
  load$: Observable<Action> = this.destinationTemplateActions$.pipe(
    ofType(destinationTemplateActions.LOAD),
    switchMap(() => {
      return this.api.query().pipe(
        map((destinationTemplates: DestinationTemplate[]) => {
          return new destinationTemplateActions.LoadSuccess(destinationTemplates);
        }),
        catchError(error => [
          this.actionDispatch.getAction(destinationTemplateActions.LoadFailed, error),
          this.notification.error('Unable to load destination templates', error)
        ])
      );
    })
  );

  /**
   * Loads destination templates by ID
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when a destination template has been retrieved
   */
  @Effect()
  loadById$: Observable<Action> = this.destinationTemplateActions$.pipe(
    ofType(destinationTemplateActions.LOAD_BY_ID),
    map((action: destinationTemplateActions.LoadById) => action.payload),
    switchMap(id => {
      return this.api.get(id).pipe(
        map((destinationTemplate: DestinationTemplate) => {
          return new destinationTemplateActions.LoadByIdSuccess(destinationTemplate);
        }),
        catchError(error => [
          this.actionDispatch.getAction(destinationTemplateActions.LoadByIdFailed, error),
          this.notification.error('Unable to load destination template', error)
        ])
      );
    })
  );

  /**
   * Updates the destination template and triggers an UpdateSuccess action.
   *
   * @returns { Observable<Action> } Observable with UpdateSuccess action with the updated destination template
   */
  @Effect()
  update$: Observable<Action> = this.destinationTemplateActions$.pipe(
    ofType(destinationTemplateActions.UPDATE),
    map((action: destinationTemplateActions.Update) => [action.payload]),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([destinationTemplate]) => {
      return this.api.update(destinationTemplate).pipe(
        mergeMap((d: DestinationTemplate) => [
          new destinationTemplateActions.UpdateSuccess(d),
          this.notification.success('The destination template has been successfully updated')
        ]),
        catchError(error => [
          this.actionDispatch.getAction(destinationTemplateActions.UpdateFailed, error),
          this.notification.error('Unable to update destination template', error)
        ])
      );
    })
  );

  /**
   * Create a new destination template and CreateSuccess action.
   *
   * @returns { Observable<Action> } Observable with CreateSuccess action with the updated destination template
   */
  @Effect()
  create$: Observable<Action> = this.destinationTemplateActions$.pipe(
    ofType(destinationTemplateActions.CREATE),
    map((action: destinationTemplateActions.Create) => [action.payload]),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([destinationTemplate]) => {
      return this.api.create(destinationTemplate).pipe(
        mergeMap((newDestinationTemplate: DestinationTemplate) => [
          new destinationTemplateActions.CreateSuccess(newDestinationTemplate),
          this.notification.success('The destination template has been successfully created')
        ]),
        catchError(error => [
          this.actionDispatch.getAction(destinationTemplateActions.CreateFailed, error),
          this.notification.error('Unable to create destination template', error)
        ])
      );
    })
  );

  /**
   * Delete a package structure and triggers DeleteSuccess action.
   *
   * @returns { Observable<Action> } Observable with DeleteSuccess action with the deleted package structure id
   */
  @Effect()
  delete$: Observable<Action> = this.destinationTemplateActions$.pipe(
    ofType(destinationTemplateActions.DELETE),
    map((action: destinationTemplateActions.Delete) => action.payload),
    switchMap((id: number) =>
      this.api.delete(id).pipe(
        mergeMap(() => [
          new destinationTemplateActions.DeleteSuccess(id),
          this.notification.success('The destination template has been successfully deleted')
        ]),
        catchError(error => [
          this.actionDispatch.getAction(destinationTemplateActions.DeleteFailed, error),
          this.notification.error('Unable to delete destination template', error)
        ])
      )
    )
  );
}
