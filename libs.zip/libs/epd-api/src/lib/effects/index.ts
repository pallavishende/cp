import { PartnerEffects } from './partner.effects';
import { ProfileEffects } from './profile.effects';
import { PackageStructureEffects } from './package-structure.effects';
import { StructureListingEffects } from './structure-listing.effects';
import { PackageDefinitionEffects } from './package-definition.effects';
import { PackageInstructionsEffects } from './package-instructions.effects';
import { ReferenceDataEffects } from './reference-data.effects';
import { DestinationTemplateEffects } from './destination-template.effects';

export * from './partner.effects';
export * from './profile.effects';
export * from './package-structure.effects';
export * from './structure-listing.effects';
export * from './package-definition.effects';
export * from './reference-data.effects';
export * from './package-instructions.effects';
export * from './destination-template.effects';

const effects = [
  ReferenceDataEffects,
  ProfileEffects,
  PartnerEffects,
  PackageStructureEffects,
  StructureListingEffects,
  PackageDefinitionEffects,
  PackageInstructionsEffects,
  DestinationTemplateEffects
];

export { effects };
