import { Injectable } from '@angular/core';
import { Action, Store, select } from '@ngrx/store';
import { Effect, Actions, ofType } from '@ngrx/effects';

import { Observable } from 'rxjs';
import { switchMap, map, catchError, withLatestFrom, mergeMap, filter } from 'rxjs/operators';

import { authSelectors } from '@content-platform/auth';

import { PackageDefinition } from '../models';
import { packageDefinitionActions, packageStructureActions } from '../actions';
import { PackageDefinitionResource, NotificationService, ActionDispatchService } from '../services';
import { EpdState } from '../reducers';

@Injectable()
export class PackageDefinitionEffects {
  constructor(
    private packageDefinitionActions$: Actions,
    private api: PackageDefinitionResource,
    private notification: NotificationService,
    private actionDispatch: ActionDispatchService,
    private store: Store<EpdState>
  ) {}

  // TODO: Should refactor all the naming of 'package definition' to be 'material' as both terms means the same.

  /**
   * Loads all the available package definitions only when a user is logged in and triggers a LoadSuccess action.
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when all package definitions are retrieved
   */
  @Effect()
  load$: Observable<Action> = this.packageDefinitionActions$.pipe(
    ofType(packageDefinitionActions.LOAD),
    switchMap(() => {
      return this.api.query().pipe(
        map(
          (packageDefinition: PackageDefinition[]) =>
            new packageDefinitionActions.LoadSuccess(packageDefinition)
        ),
        catchError(error => [
          this.actionDispatch.getAction(packageDefinitionActions.LoadFailed, error),
          this.notification.error('Unable to load materials', error)
        ])
      );
    })
  );

  /**
   * Loads package definition by ID/type
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when a package definition has been retrieved
   */
  @Effect()
  loadByMaterialId$: Observable<Action> = this.packageDefinitionActions$.pipe(
    ofType(packageDefinitionActions.LOAD_BY_ID),
    map((action: packageDefinitionActions.LoadById) => action.payload),
    filter(id => !!id),
    switchMap(payload => {
      return this.api.getPackageDefinitionById(<string>payload.materialId).pipe(
        map((packageDefinition: any) => {
          return new packageDefinitionActions.LoadByIdSuccess(packageDefinition);
        }),
        catchError(error => [
          this.actionDispatch.getAction(packageDefinitionActions.LoadByIdFailed, error),
          this.notification.error('Unable to load material', error)
        ])
      );
    })
  );

  /**
   * Updates the package definition and triggers a UpdateSuccess action.
   *
   * @returns { Observable<Action> } Observable with UpdateSuccess action with the updated package definition
   */
  @Effect()
  update$: Observable<Action> = this.packageDefinitionActions$.pipe(
    ofType(packageDefinitionActions.UPDATE),
    map((action: packageDefinitionActions.Update) => action.payload),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([packageDefinition]) => {
      return this.api.update(packageDefinition).pipe(
        map((p: PackageDefinition) => new packageDefinitionActions.UpdateSuccess(p)),
        catchError(error => [
          this.actionDispatch.getAction(packageDefinitionActions.UpdateFailed, error),
          this.notification.error('Unable to update material', error)
        ])
      );
    })
  );

  /**
   * Create a new package definition and CreateSuccess action.
   *
   * @returns { Observable<Action> } Observable with CreateSuccess action with the updated package definition
   */
  @Effect()
  create$: Observable<Action> = this.packageDefinitionActions$.pipe(
    ofType(packageDefinitionActions.CREATE),
    switchMap((action: packageDefinitionActions.Create) => {
      const packageDefinition = action.payload.packageDefinition;
      const psId = action.payload.psId;
      let payload = [];
      let materialType;
      if (Array.isArray(packageDefinition)) {
        // if this is a new material, we need to make it into an array because that's what the backend expects
        payload = packageDefinition;
        materialType = packageDefinition[0].material.materialType.name;
      } else {
        payload.push(packageDefinition);
        materialType = packageDefinition.material.materialType.name;
      }

      return this.api.create(payload).pipe(
        mergeMap((newPackageDefinition: PackageDefinition) => {
          const results: Array<Action> = [
            new packageDefinitionActions.CreateSuccess(newPackageDefinition),
            this.notification.success(
              `The ${materialType.toLowerCase()} material has been successfully saved`
            )
          ];
          if (psId) {
            results.push(new packageStructureActions.LoadById(psId));
          }
          return results;
        }),
        catchError(error => [
          this.actionDispatch.getAction(packageDefinitionActions.CreateFailed, error),
          this.notification.error(`Unable to create ${materialType.toLowerCase()} material`, error)
        ])
      );
    })
  );

  /**
   * Delete a package definition and triggers DeleteSuccess action.
   *
   * @returns { Observable<Action> } Observable with DeleteSuccess action with the deleted package definition id
   */
  @Effect()
  delete$: Observable<Action> = this.packageDefinitionActions$.pipe(
    ofType(packageDefinitionActions.DELETE),
    map((action: packageDefinitionActions.Delete) => action.payload),
    switchMap((partnerId: number) =>
      this.api.delete(partnerId).pipe(
        map(() => new packageDefinitionActions.DeleteSuccess(partnerId)),
        catchError(error => [
          this.actionDispatch.getAction(packageDefinitionActions.DeleteFailed, error),
          this.notification.error('Unable to delete material', error)
        ])
      )
    )
  );
}
