import { Injectable } from '@angular/core';
import { Action, Store, select } from '@ngrx/store';
import { Effect, Actions, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { switchMap, map, catchError, withLatestFrom, mergeMap } from 'rxjs/operators';

import { authSelectors } from '@content-platform/auth';

import { PackageInstructions } from '../models';
import { packageInstructionsActions } from '../actions';
import {
  PackageInstructionsResource,
  NotificationService,
  ActionDispatchService
} from '../services';
import { EpdState } from '../reducers';

@Injectable()
export class PackageInstructionsEffects {
  constructor(
    private packageInstructionsActions$: Actions,
    private api: PackageInstructionsResource,
    private notification: NotificationService,
    private actionDispatch: ActionDispatchService,
    private store: Store<EpdState>
  ) {}

  /**
   * Loads the available package instructions under a package structure only when a user is logged in and triggers a LoadSuccess action.
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when all package instructions are retrieved
   */
  @Effect()
  load$: Observable<Action> = this.packageInstructionsActions$.pipe(
    ofType(packageInstructionsActions.LOAD),
    map((action: packageInstructionsActions.Load) => action.payload),
    switchMap(payload => {
      return this.api.get(payload).pipe(
        map((packageInstructions: PackageInstructions) => {
          return new packageInstructionsActions.LoadSuccess(packageInstructions[0]);
        }),
        catchError(error => [
          this.actionDispatch.getAction(packageInstructionsActions.LoadFailed, error),
          this.notification.error('Unable to load package instruction data', error)
        ])
      );
    })
  );

  /**
   * Loads the available package instructions under a package structure by id
   * only when a user is logged in and triggers a LoadSuccess action.
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when all package instructions are retrieved
   */
  @Effect()
  loadById$: Observable<Action> = this.packageInstructionsActions$.pipe(
    ofType(packageInstructionsActions.LOAD_BY_ID),
    map((action: packageInstructionsActions.LoadById) => action.payload),
    switchMap(payload => {
      return this.api
        .getById(payload.packageStructureId.toString(), payload.packageInstructionId.toString())
        .pipe(
          map((packageInstructions: PackageInstructions) => {
            return new packageInstructionsActions.LoadByIdSuccess(packageInstructions[0]);
          }),
          catchError(error => [
            this.actionDispatch.getAction(packageInstructionsActions.LoadByIdFailed, error),
            this.notification.error('Unable to load package instruction data', error)
          ])
        );
    })
  );

  /**
   * Updates the package instruction and triggers an UpdateSuccess action.
   *
   * @returns { Observable<Action> } Observable with UpdateSuccess action with the updated package instruction
   */
  @Effect()
  update$: Observable<Action> = this.packageInstructionsActions$.pipe(
    ofType(packageInstructionsActions.UPDATE),
    map((action: packageInstructionsActions.Update) => action.payload),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([packageInstructions]) => {
      return this.api.update(packageInstructions).pipe(
        map((p: PackageInstructions) => new packageInstructionsActions.UpdateSuccess(p)),
        catchError(error => [
          this.actionDispatch.getAction(packageInstructionsActions.UpdateFailed, error),
          this.notification.error('Unable to update package instructions', error)
        ])
      );
    })
  );

  /**
   * Delete a package instruction from the structure page and triggers DeleteSuccess action.
   *
   * @returns { Observable<Action> } Observable with DeleteSuccess action with the deleted package instruction id
   */
  @Effect()
  delete$: Observable<Action> = this.packageInstructionsActions$.pipe(
    ofType(packageInstructionsActions.DELETE),
    map((action: packageInstructionsActions.Delete) => action.payload),
    switchMap((packageInstructionId: number) =>
      this.api.delete(packageInstructionId).pipe(
        mergeMap(() => [
          new packageInstructionsActions.DeleteSuccess(packageInstructionId),
          this.notification.success('The instruction has been successfully deleted')
        ]),
        catchError(error => [
          this.actionDispatch.getAction(packageInstructionsActions.DeleteFailed, error),
          this.notification.error('Unable to delete package instruction data', error)
        ])
      )
    )
  );
}
