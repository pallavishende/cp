import { Injectable } from '@angular/core';
import { Action, Store, select } from '@ngrx/store';
import { Effect, Actions, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { switchMap, map, catchError, withLatestFrom, filter, mergeMap, tap } from 'rxjs/operators';
import { authSelectors } from '@content-platform/auth';

import { PackageStructure } from '../models';
import {
  packageStructureActions,
  structureListingActions,
  packageInstructionsActions
} from '../actions';
import { PackageStructureResource, NotificationService, ActionDispatchService } from '../services';
import { EpdState } from '../reducers';
import { packageStructureSelectors } from '../selectors';
import { Router } from '@angular/router';

@Injectable()
export class PackageStructureEffects {
  constructor(
    private packageStructureActions$: Actions,
    private api: PackageStructureResource,
    private notification: NotificationService,
    private actionDispatch: ActionDispatchService,
    private store: Store<EpdState>,
    private router: Router
  ) {}

  /**
   * Loads all the available package structures only when a user is logged in and triggers a LoadSuccess action.
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when all package structures are retrieved
   */
  @Effect()
  load$: Observable<Action> = this.packageStructureActions$.pipe(
    ofType(packageStructureActions.LOAD),
    switchMap(() => {
      return this.api.query().pipe(
        map((packageStructures: PackageStructure[]) => {
          return new packageStructureActions.LoadSuccess(packageStructures);
        }),
        catchError(error => [
          this.actionDispatch.getAction(packageStructureActions.LoadFailed, error),
          this.notification.error('Unable to load package structures', error)
        ])
      );
    })
  );

  /**
   * Loads package structures by ID
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when a package structure has been retrieved
   */
  @Effect()
  loadByPackageStructureId$: Observable<Action> = this.packageStructureActions$.pipe(
    ofType(packageStructureActions.LOAD_BY_ID),
    map((action: packageStructureActions.LoadById) => action.payload),
    filter(id => !!id),
    switchMap(id => {
      return this.api.get(id).pipe(
        map((packageStructure: PackageStructure) => {
          return new packageStructureActions.LoadByIdSuccess(packageStructure[0]);
        }),
        catchError(error => [
          this.actionDispatch.getAction(packageStructureActions.LoadByIdFailed, error),
          this.notification.error('Unable to load package structure', error)
        ])
      );
    })
  );

  /**
   * Redirects to a PackageStructure by id
   *
   * Redirects use to package structure
   */
  @Effect({ dispatch: false })
  redirectToPackageStructure$ = this.packageStructureActions$.pipe(
    ofType(packageInstructionsActions.UPDATE_SUCCESS, packageStructureActions.CREATE_SUCCESS),
    map(
      (action: packageInstructionsActions.UpdateSuccess | packageStructureActions.CreateSuccess) =>
        action.payload
    ),
    withLatestFrom(this.store.pipe(select(packageStructureSelectors.getCurrentUrl))),
    tap(([action, routerState]) => {
      const partnerId = routerState.state.params.partnerId;
      this.router.navigate(['package-structure', action.packageStructureId, { partnerId }]);
    })
  );

  /**
   * Loads all package structures by partner profile ID
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when all package structures has been retrieved
   */
  @Effect()
  loadAllByPartnerProfileId$: Observable<Action> = this.packageStructureActions$.pipe(
    ofType(structureListingActions.LOAD_ALL_BY_PARTNER_PROFILE_ID),
    map((action: structureListingActions.LoadAllByPartnerProfileId) => action.payload),
    switchMap(payload => {
      return this.api.getByPartnerProfileId(payload.partnerProfileId.toString()).pipe(
        map((packageStructureData: any) => {
          if (!packageStructureData) {
            packageStructureData = {
              packageStructureGridDTOList: []
            };
          }
          return new structureListingActions.LoadAllByPartnerProfileIdSuccess(
            packageStructureData.packageStructureGridDTOList
          );
        }),
        catchError(error => [
          this.actionDispatch.getAction(
            structureListingActions.LoadAllByPartnerProfileIdFailed,
            error
          ),
          this.notification.error('Unable to load package structures data', error)
        ])
      );
    })
  );

  /**
   * Updates the package structure and triggers an UpdateSuccess action.
   *
   * @returns { Observable<Action> } Observable with UpdateSuccess action with the updated package structure
   */
  @Effect()
  update$: Observable<Action> = this.packageStructureActions$.pipe(
    ofType(packageStructureActions.UPDATE),
    map((action: packageStructureActions.Update) => [action.payload]),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([packageStructure]) => {
      if (!packageStructure[0].showNotification) {
        return this.api.update(packageStructure).pipe(
          map((p: PackageStructure) => new packageStructureActions.UpdateSuccess(p)),
          catchError(error => [
            this.actionDispatch.getAction(packageStructureActions.UpdateFailed, error),
            this.notification.error('Unable to update package structure', error)
          ])
        );
      } else {
        return this.api.update(packageStructure).pipe(
          mergeMap((p: PackageStructure) => [
            new packageStructureActions.UpdateSuccess(p),
            this.notification.success('The package structure has been successfully updated')
          ]),
          catchError(error => [
            this.actionDispatch.getAction(packageStructureActions.UpdateFailed, error),
            this.notification.error('Unable to update package structure', error)
          ])
        );
      }
    })
  );

  /**
   * Create a new package structure and CreateSuccess action.
   *
   * @returns { Observable<Action> } Observable with CreateSuccess action with the updated package structure
   */
  @Effect()
  create$: Observable<Action> = this.packageStructureActions$.pipe(
    ofType(packageStructureActions.CREATE),
    map((action: packageStructureActions.Create) => [action.payload]),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([packageStructure]) => {
      return this.api.create(packageStructure).pipe(
        mergeMap((newPackageStructure: PackageStructure) => [
          new packageStructureActions.CreateSuccess(newPackageStructure),
          this.notification.success('The package structure has been successfully created')
        ]),
        catchError(error => [
          this.actionDispatch.getAction(packageStructureActions.CreateFailed, error),
          this.notification.error('Unable to create package structure', error)
        ])
      );
    })
  );

  /**
   * Delete a package structure and triggers DeleteSuccess action.
   *
   * @returns { Observable<Action> } Observable with DeleteSuccess action with the deleted package structure id
   */
  @Effect()
  delete$: Observable<Action> = this.packageStructureActions$.pipe(
    ofType(packageStructureActions.DELETE),
    map((action: packageStructureActions.Delete) => action.payload),
    switchMap((packageStructureId: number) =>
      this.api.delete(packageStructureId).pipe(
        mergeMap(() => [
          new packageStructureActions.DeleteSuccess(packageStructureId),
          this.notification.success('The package structure has been successfully deleted')
        ]),
        catchError(error => [
          this.actionDispatch.getAction(packageStructureActions.DeleteFailed, error),
          this.notification.error('Unable to delete package structure', error)
        ])
      )
    )
  );
}
