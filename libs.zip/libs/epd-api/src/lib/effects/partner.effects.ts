import { Injectable } from '@angular/core';
import { Action, Store, select } from '@ngrx/store';
import { Effect, Actions, ofType } from '@ngrx/effects';

import { Observable } from 'rxjs';
import { switchMap, map, catchError, withLatestFrom, mergeMap } from 'rxjs/operators';

import { authSelectors } from '@content-platform/auth';

import { Partner } from '../models';
import { partnerActions } from '../actions';
import { PartnerResource, NotificationService, ActionDispatchService } from '../services';
import { EpdState } from '../reducers';

/**
 * The partner effects imported in {@link PartnerApiModule }
 *
 */
@Injectable()
export class PartnerEffects {
  constructor(
    private partnerActions$: Actions,
    private api: PartnerResource,
    private notification: NotificationService,
    private actionDispatch: ActionDispatchService,
    private store: Store<EpdState>
  ) {}

  /**
   * Loads all the available partners only when a user is logged in and triggers a LoadSuccess action.
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when all partners are retrieved
   */
  @Effect()
  load$: Observable<Action> = this.partnerActions$.pipe(
    ofType(partnerActions.LOAD),
    switchMap(() => {
      return this.api.query().pipe(
        map((partner: Partner[]) => new partnerActions.LoadSuccess(partner)),
        catchError(error => [
          this.actionDispatch.getAction(partnerActions.LoadFailed, error),
          this.notification.error('Unable to load partners', error)
        ])
      );
    })
  );

  /**
   * Loads a partner only when a user is logged in and triggers a LoadSuccess action.
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when a partner is retrieved
   */
  @Effect()
  loadById$: Observable<Action> = this.partnerActions$.pipe(
    ofType(partnerActions.LOAD_BY_ID),
    map((action: partnerActions.LoadById) => action.payload),
    switchMap(id =>
      this.api.get(id).pipe(
        map((partner: Partner) => new partnerActions.LoadByIdSuccess(partner)),
        catchError(error => [
          this.actionDispatch.getAction(partnerActions.LoadByIdFailed, error),
          this.notification.error('Unable to load partner', error)
        ])
      )
    )
  );

  /**
   * Updates the partner and triggers a UpdateSuccess action.
   *
   * @returns { Observable<Action> } Observable with UpdateSuccess action with the updated partner
   */
  @Effect()
  update$: Observable<Action> = this.partnerActions$.pipe(
    ofType(partnerActions.UPDATE),
    map((action: partnerActions.Update) => action.payload),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([partner]) => {
      return this.api.update(partner).pipe(
        map((p: Partner) => new partnerActions.UpdateSuccess(p)),
        catchError(error => [
          this.actionDispatch.getAction(partnerActions.UpdateFailed, error),
          this.notification.error('Unable to update partner', error)
        ])
      );
    })
  );

  /**
   * Create new partner and CreateSuccess action.
   *
   * @returns { Observable<Action> } Observable with CreateSuccess action with the updated partner
   */
  @Effect()
  create$: Observable<Action> = this.partnerActions$.pipe(
    ofType(partnerActions.CREATE),
    map((action: partnerActions.Update) => action.payload),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([partner]) => {
      return this.api.create(partner).pipe(
        map((newPartner: Partner) => new partnerActions.CreateSuccess(newPartner)),
        catchError(error => [
          this.actionDispatch.getAction(partnerActions.CreateFailed, error),
          this.notification.error('Unable to create partner', error)
        ])
      );
    })
  );

  /**
   * Delete partner and triggers DeleteSuccess action.
   *
   * @returns { Observable<Action> } Observable with DeleteSuccess action with the deleted partner id
   */
  @Effect()
  delete$: Observable<Action> = this.partnerActions$.pipe(
    ofType(partnerActions.DELETE),
    map((action: partnerActions.Delete) => action.payload),
    switchMap((partnerId: number) =>
      this.api.delete(partnerId).pipe(
        mergeMap(() => [
          new partnerActions.DeleteSuccess(partnerId),
          this.notification.success('The partner has been successfully deleted')
        ]),
        catchError(error => [
          this.actionDispatch.getAction(partnerActions.DeleteFailed, error),
          this.notification.error('Unable to delete partner', error)
        ])
      )
    )
  );
}
