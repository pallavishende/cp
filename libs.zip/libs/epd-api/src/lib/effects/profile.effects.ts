import { Injectable } from '@angular/core';
import { Action, Store, select } from '@ngrx/store';
import { Effect, Actions, ofType } from '@ngrx/effects';

import { Observable } from 'rxjs';
import { switchMap, map, catchError, withLatestFrom, mergeMap, filter } from 'rxjs/operators';

import { authSelectors } from '@content-platform/auth';

import { Profile } from '../models';
import { profileActions } from '../actions';
import { ProfileResource, NotificationService, ActionDispatchService } from '../services';
import { EpdState } from '../reducers';

/**
 * The profile effects imported in {@link ProfileApiModule }
 *
 */
@Injectable()
export class ProfileEffects {
  constructor(
    private profileActions$: Actions,
    private api: ProfileResource,
    private notification: NotificationService,
    private actionDispatch: ActionDispatchService,
    private store: Store<EpdState>
  ) {}

  /**
   * Loads all the available profiles only when a user is logged in and triggers a LoadSuccess action.
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when all profiles are retrieved
   */
  @Effect()
  load$: Observable<Action> = this.profileActions$.pipe(
    ofType(profileActions.LOAD),
    switchMap((action: profileActions.Load) => {
      return this.api.getByPartnerId(action.payload.partnerId).pipe(
        map((profiles: Profile[]) => new profileActions.LoadSuccess(profiles)),
        catchError(error => [
          this.actionDispatch.getAction(profileActions.LoadFailed, error),
          this.notification.error('Unable to load profiles', error)
        ])
      );
    })
  );

  /**
   * Loads profile by ID
   *
   * @returns { Observable<Action> } Observable with LoadSuccess action when a profile has been retrieved
   */
  @Effect()
  loadByProfileId$: Observable<Action> = this.profileActions$.pipe(
    ofType(profileActions.LOAD_BY_ID),
    map((action: profileActions.LoadById) => action.payload.id),
    filter(id => !!id),
    switchMap(id => {
      return this.api.get(<number>id).pipe(
        map((profile: any) => {
          return new profileActions.LoadByIdSuccess(profile);
        }),
        catchError(error => [
          this.actionDispatch.getAction(profileActions.LoadByIdFailed, error),
          this.notification.error('Unable to load profile', error)
        ])
      );
    })
  );

  /**
   * Updates the profile and triggers a UpdateSuccess action.
   *
   * @returns { Observable<Action> } Observable with UpdateSuccess action with the updated profile
   */
  @Effect()
  update$: Observable<Action> = this.profileActions$.pipe(
    ofType(profileActions.UPDATE),
    map((action: profileActions.Update) => action.payload),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([profile]) => {
      if (!profile.showNotification) {
        return this.api.update(profile).pipe(
          map((p: Profile) => new profileActions.UpdateSuccess(p)),
          catchError(error => [this.notification.error('Unable to update profile', error)])
        );
      } else {
        return this.api.update(profile).pipe(
          mergeMap((p: Profile) => [
            new profileActions.UpdateSuccess(p),
            this.notification.success('The profile has been successfully updated')
          ]),
          catchError(error => [
            this.actionDispatch.getAction(profileActions.UpdateFailed, error),
            this.notification.error('Unable to update profile', error)
          ])
        );
      }
    })
  );

  /**
   * Create new profile and CreateSuccess action.
   *
   * @returns { Observable<Action> } Observable with CreateSuccess action with the updated profile
   */
  @Effect()
  create$: Observable<Action> = this.profileActions$.pipe(
    ofType(profileActions.CREATE),
    map((action: profileActions.Update) => action.payload),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([profile]) => {
      return this.api.create(profile).pipe(
        mergeMap((newProfile: Profile) => [
          new profileActions.CreateSuccess(newProfile),
          this.notification.success('The profile has been successfully created')
        ]),
        catchError(error => [
          this.actionDispatch.getAction(profileActions.CreateFailed, error),
          this.notification.error('Unable to create profile', error)
        ])
      );
    })
  );

  /**
   * Delete profile and triggers DeleteSuccess action.
   *
   * @returns { Observable<Action> } Observable with DeleteSuccess action with the deleted profile id
   */
  @Effect()
  delete$: Observable<Action> = this.profileActions$.pipe(
    ofType(profileActions.DELETE),
    map((action: profileActions.Delete) => action.payload),
    switchMap((profileId: number) =>
      this.api.delete(profileId).pipe(
        mergeMap(() => [
          new profileActions.DeleteSuccess(profileId),
          this.notification.success('The profile has been successfully deleted')
        ]),
        catchError(errorDetails => {
          if (
            errorDetails.error.detail &&
            errorDetails.error.detail.match('ConstraintViolationException')
          ) {
            return [
              this.actionDispatch.getAction(profileActions.DeleteFailed, errorDetails.message),
              this.notification.error(
                `You are trying to delete a Profile that has associated Package Structures,
              please remove child items before deleting parent items`,
                errorDetails.message
              )
            ];
          }

          return [
            this.actionDispatch.getAction(profileActions.DeleteFailed, errorDetails.message),
            this.notification.error('Unable to delete profile', errorDetails.message)
          ];
        })
      )
    )
  );
}
