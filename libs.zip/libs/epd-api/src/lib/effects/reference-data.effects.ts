import { Action } from '@ngrx/store';
import { Injectable } from '@angular/core';
import { Effect, Actions, ofType } from '@ngrx/effects';
import { map, catchError, switchMap, concatMap, take } from 'rxjs/operators';

import {
  ReferenceDataResource,
  NotificationService,
  ActionDispatchService,
  PackageDefinitionResource,
  PreloadDataResource
} from '../services';
import { referenceDataActions } from '../actions';
import { forkJoin, Observable } from 'rxjs';
import { ReferenceData } from '../models';
import { PackageStructureResource } from '../services';

/**
 * The Reference Data effects imported in {@link EpdApiModule }
 *
 */
@Injectable()
export class ReferenceDataEffects {
  constructor(
    private api: ReferenceDataResource,
    private psApi: PackageStructureResource,
    private pdApi: PackageDefinitionResource,
    private preloadApi: PreloadDataResource,
    private referenceDataActions$: Actions,
    private notification: NotificationService,
    private actionDispatch: ActionDispatchService
  ) {}

  @Effect()
  load$: Observable<Action> = this.referenceDataActions$.pipe(
    ofType(referenceDataActions.LOAD),
    switchMap(() => {
      return this.api.query().pipe(
        map((refResponse: ReferenceData[]) => {
          const parsedRes = this.api.parseResponse(refResponse);
          return new referenceDataActions.LoadSuccess(parsedRes);
        }),
        catchError(error => [
          this.actionDispatch.getAction(referenceDataActions.LoadFailed, error),
          this.notification.error('Unable to load reference data', error)
        ])
      );
    })
  );

  /**
   * Loads image fallback list data
   *
   * @returns { Observable<Action> } Observable with LoadImageFallbackListSuccess action when
   * image fallback list data has been retrieved
   */
  @Effect()
  loadImageFallbackList$: Observable<Action> = this.referenceDataActions$.pipe(
    ofType(referenceDataActions.LOAD_IMAGE_FALLBACK_LIST),
    map((action: referenceDataActions.LoadImageFallbackList) => action.payload),
    switchMap(materialType => {
      return this.pdApi.query().pipe(
        map((refData: any) => {
          const imageFallbackListPayload = this.api.parseMaterialFallbackDropdownData(
            refData,
            materialType
          );
          return new referenceDataActions.LoadImageFallbackListSuccess(imageFallbackListPayload);
        }),
        catchError(error => [
          this.actionDispatch.getAction(referenceDataActions.LoadImageFallbackListFailed, error),
          this.notification.error('Unable to load image fallback list data', error)
        ])
      );
    })
  );

  @Effect()
  LoadVideoCodecDropdowns$: Observable<Action> = this.referenceDataActions$.pipe(
    ofType(referenceDataActions.LOAD_VIDEO_CODEC_DROPDOWNS),
    concatMap(() => {
      return this.preloadApi.videoCodecDropdowns().pipe(
        map((refResponse: []) => {
          return new referenceDataActions.LoadVideoCodecDropdownsSuccess(refResponse);
        }),
        catchError(error => [
          this.actionDispatch.getAction(referenceDataActions.LoadFailed, error),
          this.notification.error('Unable to load reference data', error)
        ])
      );
    })
  );

  /**
   * Loads fallback package list data object by partner profile ID
   *
   * @returns { Observable<Action> } Observable with LoadFallbackPackageListSuccess action when fallback
   * package list data has been retrieved
   */
  @Effect()
  loadFallbackPackageList$: Observable<Action> = this.referenceDataActions$.pipe(
    ofType(referenceDataActions.LOAD_FALLBACK_PACKAGE_LIST),
    map((action: referenceDataActions.LoadFallbackPackageList) => action.payload),
    switchMap(payload => {
      return this.psApi.getByPartnerProfileId(payload.partnerProfileId.toString()).pipe(
        map((refData: any) => {
          const fallbackPackageListPayload = this.api.parseFallbackPackageDropdownData(
            refData.packageStructureGridDTOList,
            payload.currentPs
          );
          return new referenceDataActions.LoadFallbackPackageListSuccess(
            fallbackPackageListPayload
          );
        }),
        catchError(error => [
          this.actionDispatch.getAction(referenceDataActions.LoadFallbackPackageListFailed, error),
          this.notification.error('Unable to load fallback package list data', error)
        ])
      );
    })
  );

  /**
   * Loads delivery template list data
   *
   * @returns { Observable<Action> } Observable with LoadDeliveryTemplateListSuccess action when delivery template list data
   * has been retrieved
   */
  @Effect()
  loadDeliveryTemplateList$: Observable<Action> = this.referenceDataActions$.pipe(
    ofType(referenceDataActions.LOAD_DELIVERY_TEMPLATE_LIST),
    map((action: referenceDataActions.LoadDeliveryTemplateList) => action.payload),
    switchMap(() => {
      return this.api.getAllDeliveryTemplates().pipe(
        map((refData: any) => {
          return new referenceDataActions.LoadDeliveryTemplateListSuccess(refData);
        }),
        catchError(error => [
          this.actionDispatch.getAction(referenceDataActions.LoadDeliveryTemplateListFailed, error),
          this.notification.error('Unable to load delivery template list data', error)
        ])
      );
    })
  );

  /**
   * Loads package template list data
   *
   * @returns { Observable<Action> } Observable with LoadPackageTemplateListSuccess action when delivery template list data
   * has been retrieved
   */
  @Effect()
  loadPackageTemplateList$: Observable<Action> = this.referenceDataActions$.pipe(
    ofType(referenceDataActions.LOAD_PACKAGE_TEMPLATE_LIST),
    map((action: referenceDataActions.LoadPackageTemplateList) => action.payload),
    switchMap(() => {
      return this.api.getAllPackageTemplates().pipe(
        map((refData: any) => {
          return new referenceDataActions.LoadPackageTemplateListSuccess(refData);
        }),
        catchError(error => [
          this.actionDispatch.getAction(referenceDataActions.LoadPackageTemplateListFailed, error),
          this.notification.error('Unable to load package template list data', error)
        ])
      );
    })
  );

  /**
   * Loads all lists on the package structure page
   *
   * @returns { Observable<Action> } Observable with LoadPackageStructureListsSuccess action
   * when all lists have been retrieved
   */
  @Effect()
  loadPackageStructureLists$: Observable<Action> = this.referenceDataActions$.pipe(
    ofType(referenceDataActions.LOAD_PACKAGE_STRUCTURE_LISTS),
    map((action: referenceDataActions.LoadPackageStructureLists) => action.payload),
    switchMap(payload => {
      return forkJoin(
        this.getFallbackPackageList(payload.partnerProfileId, payload.currentPs),
        this.getDeliveryTemplateList(),
        this.getPackageTemplateList()
      ).pipe(
        map(([fallbackPackageList, deliveryTemplateList, packageTemplateList]) => {
          return new referenceDataActions.LoadPackageStructureListsSuccess({
            fallbackPackageList: fallbackPackageList,
            deliveryTemplateList: deliveryTemplateList,
            packageTemplateList: packageTemplateList
          });
        }),
        take(1)
      );
    }),
    catchError(error => [
      this.actionDispatch.getAction(referenceDataActions.LoadPackageStructureListsFailed, error),
      this.notification.error('Unable to load package structure lists', error)
    ])
  );

  private getFallbackPackageList(partnerProfileId, currentPs): Observable<{ [key: string]: any }> {
    return this.psApi.getByPartnerProfileId(partnerProfileId.toString()).pipe(
      map((refData: any) => {
        return this.api.parseFallbackPackageDropdownData(
          refData.packageStructureGridDTOList,
          currentPs
        );
      }),
      take(1),
      catchError(error => [
        this.actionDispatch.getAction(referenceDataActions.LoadFallbackPackageListFailed, error),
        this.notification.error('Unable to load fallback package list data', error)
      ])
    );
  }

  private getDeliveryTemplateList(): Observable<{ [key: string]: any }> {
    return this.api.getAllDeliveryTemplates().pipe(
      take(1),
      catchError(error => [
        this.actionDispatch.getAction(referenceDataActions.LoadDeliveryTemplateListFailed, error),
        this.notification.error('Unable to load delivery templates list data', error)
      ])
    );
  }

  private getPackageTemplateList(): Observable<{ [key: string]: any }> {
    return this.api.getAllPackageTemplates().pipe(
      take(1),
      catchError(error => [
        this.actionDispatch.getAction(referenceDataActions.LoadPackageTemplateListFailed, error),
        this.notification.error('Unable to load package templates list data', error)
      ])
    );
  }
}
