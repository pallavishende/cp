import { Injectable } from '@angular/core';
import { Action, Store, select } from '@ngrx/store';
import { Effect, Actions, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { switchMap, map, catchError, withLatestFrom, mergeMap } from 'rxjs/operators';
import { authSelectors } from '@content-platform/auth';

import { PackageStructure } from '../models';
import { structureListingActions } from '../actions';
import { PackageStructureResource, NotificationService, ActionDispatchService } from '../services';
import { EpdState } from '../reducers';

@Injectable()
export class StructureListingEffects {
  constructor(
    private structureListingActions$: Actions,
    private api: PackageStructureResource,
    private notification: NotificationService,
    private actionDispatch: ActionDispatchService,
    private store: Store<EpdState>
  ) {}

  /**
   * Updates the package structure and triggers an UpdateSuccess action.
   *
   * @returns { Observable<Action> } Observable with UpdateSuccess action with the updated package structure
   */
  @Effect()
  update$: Observable<Action> = this.structureListingActions$.pipe(
    ofType(structureListingActions.UPDATE),
    map((action: structureListingActions.Update) => [action.payload]),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([packageStructure]) => {
      if (!packageStructure[0].showNotification) {
        return this.api.update(packageStructure).pipe(
          map((p: PackageStructure) => new structureListingActions.UpdateSuccess(p)),
          catchError(error => [
            this.actionDispatch.getAction(structureListingActions.UpdateFailed, error),
            this.notification.error('Unable to update package structure', error)
          ])
        );
      } else {
        return this.api.update(packageStructure).pipe(
          mergeMap((p: PackageStructure) => [
            new structureListingActions.UpdateSuccess(p),
            this.notification.success('The package structure has been successfully updated')
          ]),
          catchError(error => [
            this.actionDispatch.getAction(structureListingActions.UpdateFailed, error),
            this.notification.error('Unable to update package structure', error)
          ])
        );
      }
    })
  );

  /**
   * Create a new package structure and CreateSuccess action.
   *
   * @returns { Observable<Action> } Observable with CreateSuccess action with the updated package structure
   */
  @Effect()
  create$: Observable<Action> = this.structureListingActions$.pipe(
    ofType(structureListingActions.CREATE),
    map((action: structureListingActions.Create) => [action.payload]),
    withLatestFrom(this.store.pipe(select(authSelectors.getUserId))),
    switchMap(([packageStructure]) => {
      return this.api.create(packageStructure).pipe(
        mergeMap((newPackageStructure: PackageStructure) => [
          new structureListingActions.CreateSuccess(newPackageStructure),
          this.notification.success('The package structure has been successfully created')
        ]),
        catchError(error => [
          this.actionDispatch.getAction(structureListingActions.CreateFailed, error),
          this.notification.error('Unable to create package structure', error)
        ])
      );
    })
  );

  /**
   * Delete a package structure and triggers DeleteSuccess action.
   *
   * @returns { Observable<Action> } Observable with DeleteSuccess action with the deleted package structure id
   */
  @Effect()
  delete$: Observable<Action> = this.structureListingActions$.pipe(
    ofType(structureListingActions.DELETE),
    map((action: structureListingActions.Delete) => action.payload),
    switchMap((packageStructureId: number) =>
      this.api.delete(packageStructureId).pipe(
        mergeMap(() => [
          new structureListingActions.DeleteSuccess(packageStructureId),
          this.notification.success('The package structure has been successfully deleted')
        ]),
        catchError(error => [
          this.actionDispatch.getAction(structureListingActions.DeleteFailed, error),
          this.notification.error('Unable to delete package structure', error)
        ])
      )
    )
  );
}
