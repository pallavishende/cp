import { async, TestBed } from '@angular/core/testing';
import { EpdApiModule } from './epd-api.module';

describe('EpdApiModule', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [EpdApiModule]
    }).compileComponents();
  }));

  it('should create', () => {
    expect(EpdApiModule).toBeDefined();
  });
});
