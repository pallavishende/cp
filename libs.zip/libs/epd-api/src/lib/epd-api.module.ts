import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AuthModule } from '@content-platform/auth';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { guards } from './guards';
import { effects } from './effects';

import {
  fromPartner,
  fromProfile,
  fromReferenceData,
  fromPackageStructure,
  fromPackageDefinition,
  fromPackageInstructions,
  fromStructureListing,
  fromDestinationTemplate
} from './reducers';

import { resources } from './services';

/**
 * Registers the partner/referenceData and profile state & reducer, and also adds in the
 * {@link PartnerEffects } service and {@link ProfileEffects } service
 *
 */
@NgModule({
  imports: [
    CommonModule,
    AuthModule,
    StoreModule.forFeature('referenceData', fromReferenceData.reducer),
    StoreModule.forFeature('partner', fromPartner.reducer),
    StoreModule.forFeature('packageStructure', fromPackageStructure.reducer),
    StoreModule.forFeature('profile', fromProfile.reducer),
    StoreModule.forFeature('packageDefinition', fromPackageDefinition.reducer),
    StoreModule.forFeature('packageInstructions', fromPackageInstructions.reducer),
    StoreModule.forFeature('structureListing', fromStructureListing.reducer),
    StoreModule.forFeature('destinationTemplate', fromDestinationTemplate.reducer),
    EffectsModule.forFeature([...effects])
  ],
  providers: [...resources, ...guards]
})
export class EpdApiModule {
  constructor() {}
}
