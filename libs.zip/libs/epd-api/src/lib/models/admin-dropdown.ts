/**
 * An interface for admin-dropdown
 */
export interface AdminDropdown {
  id: number;
  name: string;
  epdEntities?: boolean;
  entityValue?: string;

  // channels
  shortName?: string;
  status?: number;
  brand?: { id?: number; brandDesc?: string; brandName?: string };

  // resolution
  width?: number;
  height?: number;

  // language
  code?: string;
  codeBcp47?: string;
  codeIso6391?: string;
  codeIso6392?: string;
  absolutePath?: string;

  // destination template
  fileName?: string | FileName;
  filePath?: string | FilePath;
  basePath?: { id?: number; absolutePath?: string; name?: string };
  compress?: { id?: number; name?: string };
}

export interface FileName {
  fileName?: string;
  id: number;
  name: string;
}

export interface FilePath {
  filePath?: string;
  id: number;
  name?: string;
}
