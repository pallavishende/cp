/**
 * An interface for a destination template
 */
export interface DestinationTemplate {
  id?: number;
  name: string;
  basePath?: { id?: number; name?: string; absolutePath?: string };
  compress?: { id?: number; name?: string };
  fileName?: { id?: number; name?: string; fileName?: string };
  filePath?: { id?: number; name?: string; filePath?: string };
}
