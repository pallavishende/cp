/**
 * An interface for EPD Entities
 */
export interface EpdV3Entities {
  entityValue: string;
  v3EpdEntities: {
    id: number;
  };
}
