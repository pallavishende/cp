export type PackageDefinition =
  | VideoMaterial
  | AudioMaterial
  | ImageMaterial
  | SubtitleMaterial
  | CaptionMaterial
  | MetadataMaterial;

export interface MaterialFormData {
  id?: string;
  name?: string;
  materialTemplate?: string;
  smartZoom?: boolean;
  preserveAspectRatio?: boolean;
  material?: {
    id: number;
    name: string;
    materialType: {
      id: number;
      name: string;
    };
    contentLevel: {
      id: number;
      name: string;
    };
    contentDescriptor: null;
  };
}

export interface VideoMaterial extends MaterialFormData {
  videoUiFieldsDTOList: {
    id?: string;
    name?: string;
    materialTemplate?: string;
    smartZoom?: boolean;
    preserveAspectRatio?: boolean;
    videoTechReqUiDTOList: [
      {
        dimension: { id: number };
        aspectRatio: { id: number };
        frameRate: number;
        scanType: { id: number };
        scanOrder: string;
        profile: string;
        colorSpace: number;
        level: number;
        bitRate: number;
        bitDepth: number;
        chroma: number;
        audioCodecUiDTOList?: EmbeddedAudio[];
        captionUiFieldsDTOList?: CaptionMaterial[];
        subtitleUiFieldsDTOList?: SubtitleMaterial[];
      }
    ];
  };
}

export interface AudioMaterial extends MaterialFormData {
  channels: number;
  layout: string;
  language: { id: number };
  sampleRate: string;
  programLoudness: string;
  maxTruePeak: number;
  maxShortTermLoudness: number;
  profanity: { id: number };
  bitRate: number;
  bitDepth: string;
  dialnorm: number;
  musicAndEffects: boolean;
  dubbed: boolean;
  dvs: boolean;
  muteOrSilence: boolean;
  dialog: boolean;
  voiceOver: boolean;
}

export interface EmbeddedAudio {
  id?: number;
  channels: number;
  layout: string;
  language: { id: number };
  sampleRate: string;
  programLoudness: string;
  maxTruePeak: number;
  maxShortTermLoudness: number;
  profanity: { id: number };
  bitRate: number;
  bitDepth: string;
  dialnorm: number;
  musicAndEffects: boolean;
  dubbed: boolean;
  dvs: boolean;
  muteOrSilence: boolean;
  dialog: boolean;
  voiceOver: boolean;
}

export interface ImageMaterial extends MaterialFormData {
  branded: boolean;
  description: string;
  imageType: { id: number };
  dimension: { id: number };
  language: { id: number };
  fallbackMaterialsList?: [
    {
      fallbackOrder: number;
      fallbackMaterial: { id: number };
    }
  ];
}

export interface SubtitleMaterial extends MaterialFormData {
  backgroundColor: string;
  backgroundOpacity: number;
  frameRate: string;
  fontSize: number;
  fontResolution: number;
  fontColor: string;
  fontOpacity: number;
  language: { id: number };
  languageMap?: { id: number };
  outlineColor: string;
  outlineSize: string;
  profanity: { id: number };
  subtitleFormat: { id: number };
  shadowColor: number;
  shadowOpacity: number;
  shadowXOffset: number;
  shadowYOffset: number;
  textJustify: number;
  xPosition: number;
  yPosition: number;
}

export interface CaptionMaterial extends MaterialFormData {
  captionFormat: { id: number };
  dropFrame: boolean;
  framerate: number;
  language: { id: number };
  profanity: { id: number };
}

export interface MetadataMaterial extends MaterialFormData {
  metadataKeyValueDTOs: [
    {
      key: string;
      value: string;
    }
  ];
}
