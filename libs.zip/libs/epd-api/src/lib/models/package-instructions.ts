/**
 * An interface for a package instruction
 */
export interface PackageInstructions {
  packageInstructionId?: number;
  packageInstructionName?: string;
  platformName?: string;
  destinationTemplateId?: string;
  packageStructureId?: number;
  packageInstructionGridDTOList?: PiMaterial[];
  destinationFileNamesList?: [];
  packageDestinationList?: [];
  sourceDestinationMappingId?: number;
  sourceDestinationMappingName?: string;
}

/**
 * An interface for a package instructions material
 */
export interface PiMaterial {
  fileNameId: number;
  materialName: string;
  sourceDestinationMappingId: number;
  sourceDestinationMappingName: string;
  sourceTemplateName?: string;
}
