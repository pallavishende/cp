/**
 * An interface for a package structure
 */
export interface PackageStructure {
  id?: number;
  name?: string;
  packageStructureId?: number;
  packageStructureName?: string;
  deliveryTemplate?: string[];
  deliveryOrder?: number;
  packagePreferenceOrder?: number;
  packageTemplate?: string;
  deliveryContext?: string[];
  partnerProfileId?: number;
  parentPackageId?: string;
  parentPackageMap?: object;
  showNotification?: boolean;
  packageStructureInstructionDTOList?: any[];
  packageStructureMaterialDTOList?: any[];
}
