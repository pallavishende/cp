/**
 * An interface for partner
 */
export interface Partner {
  id: number;
  name: string;
}
