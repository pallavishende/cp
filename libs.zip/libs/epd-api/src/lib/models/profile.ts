/**
 * An interface for profile
 */
export interface Profile {
  active?: boolean;
  channel?: Channel;
  endPoint?: EndPoint;
  entityType?: BaseProfileProperty;
  id?: number;
  name?: string;
  platform?: BaseProfileProperty;
  priority?: number;
  regions?: BaseProfileProperty[];
  status?: number;
  packageStructureIds?: number[];
  showNotification?: boolean;
}

interface BaseProfileProperty {
  id?: number;
  name?: string;
}

interface EndPoint extends BaseProfileProperty {
  createdDate?: Date;
}

interface Channel extends BaseProfileProperty {
  shortName?: string;
  status?: number;
}
