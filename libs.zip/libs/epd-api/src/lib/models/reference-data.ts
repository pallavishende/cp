import { DatasetValue } from '@content-platform/application-api';

// TODO: update this list as the EPD app will probably use more than that
export type ReferenceDataType =
  | 'dimensionList'
  | 'scanTypeList'
  | 'aspectRatioList'
  | 'subtitleFormatList'
  | 'materialTypeList'
  | 'contentLevelList'
  | 'contentDescriptors'
  | 'contentDescriptorsList'
  | 'frameRateStringList'
  | 'fallbackPackageList'
  | 'destinationTemplateList'
  | 'compressList'
  | 'filePathsList'
  | 'fileNamesList'
  | 'basePathsList'
  | 'imageFallbackList'
  | 'videoCodecDropdowns'
  | 'deliveryTemplateList'
  | 'packageTemplateList'
  | 'languageList';

export const AllReferenceDataTypes: ReferenceDataType[] = [
  'dimensionList',
  'scanTypeList',
  'aspectRatioList',
  'subtitleFormatList',
  'materialTypeList',
  'contentLevelList',
  'contentDescriptorsList',
  'frameRateStringList',
  'fallbackPackageList',
  'destinationTemplateList',
  'compressList',
  'filePathsList',
  'fileNamesList',
  'basePathsList',
  'imageFallbackList',
  'videoCodecDropdowns',
  'deliveryTemplateList',
  'packageTemplateList',
  'languageList'
];

export interface RefItem {
  id: number;
  name: string;
}

export type ReferenceResponse = ReferenceData[];

export interface ReferenceData {
  [key: string]: RefItem[];
}

export function refItemToDatasetValue(referenceItem: RefItem): DatasetValue {
  return { ...(<any>referenceItem), name: referenceItem.id + '', description: referenceItem.name };
}
