import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { DestinationTemplate } from '../models';
import { destinationTemplateActions } from '../actions';

export const destinationTemplateAdapter = createEntityAdapter<DestinationTemplate>({
  selectId: (item: DestinationTemplate) => item.id,
  sortComparer: sortByName
});

export interface State extends EntityState<DestinationTemplate> {
  loading: boolean;
  loaded: boolean;
}

export const INIT_STATE: State = destinationTemplateAdapter.getInitialState({
  loading: false,
  loaded: false
});

export function sortByName(a: DestinationTemplate, b: DestinationTemplate): number {
  return a.name.localeCompare(b.name);
}

export function reducer(state = INIT_STATE, action: destinationTemplateActions.All) {
  switch (action.type) {
    case destinationTemplateActions.LOAD:
    case destinationTemplateActions.LOAD_BY_ID: {
      return {
        ...state,
        loading: true,
        loaded: false
      };
    }
    case destinationTemplateActions.RESET_STORE: {
      return INIT_STATE;
    }
    case destinationTemplateActions.LOAD_SUCCESS: {
      return {
        ...destinationTemplateAdapter.addAll(action.payload, state),
        loading: false,
        loaded: true
      };
    }
    case destinationTemplateActions.LOAD_BY_ID_SUCCESS: {
      return {
        ...destinationTemplateAdapter.upsertOne(action.payload, state),
        loading: false,
        loaded: true
      };
    }
    case destinationTemplateActions.LOAD_FAILED:
    case destinationTemplateActions.LOAD_BY_ID_FAILED: {
      return { ...state, loading: false, loaded: false };
    }
    case destinationTemplateActions.UPDATE_SUCCESS: {
      return destinationTemplateAdapter.updateOne(
        {
          id: action.payload.id,
          changes: action.payload
        },
        state
      );
    }
    case destinationTemplateActions.CREATE_SUCCESS: {
      return destinationTemplateAdapter.upsertOne(action.payload, state);
    }
    case destinationTemplateActions.DELETE_SUCCESS: {
      return destinationTemplateAdapter.removeOne(action.payload, state);
    }
    case destinationTemplateActions.CREATE_FAILED:
    case destinationTemplateActions.UPDATE_FAILED:
    case destinationTemplateActions.DELETE_FAILED: {
      return { ...state, loading: false };
    }
    default: {
      return state;
    }
  }
}
export const getDestinationTemplateLoading = (state: State) => state.loading;
export const getDestinationTemplateLoaded = (state: State) => state.loaded;
