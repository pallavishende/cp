import * as fromPartner from './partner';
import * as fromPackageStructure from './package-structure';
import * as fromPackageDefinition from './package-definition';
import * as fromReferenceData from './reference-data';
import * as fromProfile from './profile';
import * as fromPackageInstructions from './package-instructions';
import * as fromStructureListing from './structure-listing';
import * as fromDestinationTemplate from './destination-template';

export interface EpdState {
  partner: fromPartner.State;
  profile: fromProfile.State;
  PackageStructure: fromPackageStructure.State;
  packageDefinition: fromPackageDefinition.State;
  fromReferenceData: fromReferenceData.State;
  PackageInstructions: fromPackageInstructions.State;
  StructureListing: fromStructureListing.State;
  DestinationTemplate: fromDestinationTemplate.State;
}

export {
  fromPartner,
  fromProfile,
  fromReferenceData,
  fromPackageStructure,
  fromPackageDefinition,
  fromPackageInstructions,
  fromStructureListing,
  fromDestinationTemplate
};
