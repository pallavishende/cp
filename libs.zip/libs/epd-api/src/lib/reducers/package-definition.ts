import { packageDefinitionActions } from '../actions';
import { createEntityAdapter, EntityState } from '@ngrx/entity';
import { PackageDefinition } from '../models';

export const packageDefinitionAdapter = createEntityAdapter<PackageDefinition>({
  selectId: (item: PackageDefinition) => {
    if (item.material) {
      return item.material.id; // editing material
    }
    return item[0].id; // new material
  },
  sortComparer: sortByName
});
export interface State extends EntityState<PackageDefinition> {
  loading: boolean;
  loaded: boolean;
}

export const INIT_STATE: State = packageDefinitionAdapter.getInitialState({
  loading: false,
  loaded: false
});

export function sortByName(a: PackageDefinition, b: PackageDefinition): number {
  a = a[0] ? a[0] : a;
  if (a.material['name'] && b.material['name']) {
    return a.material['name'].localeCompare(b.material['name']);
  }
}

export function reducer(state = INIT_STATE, action: packageDefinitionActions.All) {
  switch (action.type) {
    case packageDefinitionActions.CREATE_SUCCESS: {
      return packageDefinitionAdapter.upsertOne(action.payload[0], state);
    }
    case packageDefinitionActions.CREATE_FAILED: {
      return { ...state, loading: false, loaded: false };
    }
    case packageDefinitionActions.LOAD_BY_ID: {
      return {
        ...state,
        loading: true
      };
    }
    case packageDefinitionActions.LOAD_BY_ID_SUCCESS: {
      return {
        ...packageDefinitionAdapter.upsertOne(action.payload, state),
        loaded: true,
        loading: false
      };
    }
    case packageDefinitionActions.LOAD_BY_ID_FAILED: {
      return {
        ...state,
        loaded: false,
        loading: false
      };
    }
    case packageDefinitionActions.RESET_STORE: {
      return INIT_STATE;
    }
    default: {
      return state;
    }
  }
}

export const getPackageDefinitionLoading = (state: State) => state.loading;
export const getPackageDefinitionLoaded = (state: State) => state.loaded;
