import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { PackageInstructions } from '../models';
import { packageInstructionsActions } from '../actions';

export const packageInstructionsAdapter = createEntityAdapter<PackageInstructions>({
  selectId: (item: PackageInstructions) => item.packageInstructionId,
  sortComparer: sortByName
});

export interface State extends EntityState<PackageInstructions> {
  loading: boolean;
  loaded: boolean;
}

export const INIT_STATE: State = packageInstructionsAdapter.getInitialState({
  loading: false,
  loaded: false
});

export function sortByName(a: PackageInstructions, b: PackageInstructions): number {
  return a.packageInstructionName.localeCompare(b.packageInstructionName);
}

export function reducer(state = INIT_STATE, action: packageInstructionsActions.All) {
  switch (action.type) {
    case packageInstructionsActions.LOAD:
    case packageInstructionsActions.LOAD_BY_ID: {
      return {
        ...state,
        loading: true,
        loaded: false
      };
    }
    case packageInstructionsActions.RESET_STORE: {
      return INIT_STATE;
    }
    case packageInstructionsActions.LOAD_SUCCESS:
    case packageInstructionsActions.LOAD_BY_ID_SUCCESS: {
      return {
        ...packageInstructionsAdapter.upsertOne(action.payload, state),
        loading: false,
        loaded: true
      };
    }
    case packageInstructionsActions.LOAD_FAILED:
    case packageInstructionsActions.LOAD_BY_ID_FAILED: {
      return { ...state, loading: false, loaded: false };
    }
    case packageInstructionsActions.UPDATE_SUCCESS: {
      return packageInstructionsAdapter.updateOne(
        {
          id: action.payload.packageInstructionId,
          changes: action.payload
        },
        state
      );
    }
    case packageInstructionsActions.DELETE_SUCCESS: {
      return packageInstructionsAdapter.removeOne(action.payload, state);
    }
    case packageInstructionsActions.UPDATE_FAILED:
    case packageInstructionsActions.DELETE_FAILED: {
      return { ...state, loading: false };
    }
    default: {
      return state;
    }
  }
}
export const getPackageInstructionsLoading = (state: State) => state.loading;
export const getPackageInstructionsLoaded = (state: State) => state.loaded;
