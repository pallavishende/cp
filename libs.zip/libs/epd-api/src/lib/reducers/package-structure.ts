import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { PackageStructure } from '../models';
import { packageStructureActions } from '../actions';

export const packageStructureAdapter = createEntityAdapter<PackageStructure>({
  selectId: (item: PackageStructure) => item.packageStructureId,
  sortComparer: sortByName
});

export interface State extends EntityState<PackageStructure> {
  loading: boolean;
  loaded: boolean;
}

export const INIT_STATE: State = packageStructureAdapter.getInitialState({
  loading: false,
  loaded: false
});

export function sortByName(a: PackageStructure, b: PackageStructure): number {
  return a.packageStructureName.localeCompare(b.packageStructureName);
}

export function reducer(state = INIT_STATE, action: packageStructureActions.All) {
  switch (action.type) {
    case packageStructureActions.LOAD: {
      return {
        ...state,
        loading: true,
        loaded: false
      };
    }
    case packageStructureActions.LOAD_BY_ID: {
      return {
        ...INIT_STATE,
        loading: true,
        loaded: false
      };
    }
    case packageStructureActions.RESET_STORE: {
      return INIT_STATE;
    }
    case packageStructureActions.LOAD_SUCCESS: {
      return {
        ...packageStructureAdapter.addAll(action.payload as PackageStructure[], state),
        loading: false,
        loaded: true
      };
    }
    case packageStructureActions.LOAD_BY_ID_SUCCESS: {
      return {
        ...packageStructureAdapter.upsertOne(action.payload, state),
        loaded: true,
        loading: false
      };
    }
    case packageStructureActions.UPDATE_SUCCESS: {
      return packageStructureAdapter.updateOne(
        {
          id: action.payload[0].packageStructureId,
          changes: action.payload[0]
        },
        state
      );
    }
    case packageStructureActions.CREATE_SUCCESS: {
      return packageStructureAdapter.addOne(action.payload, state);
    }
    case packageStructureActions.DELETE_SUCCESS: {
      return packageStructureAdapter.removeOne(action.payload, state);
    }
    case packageStructureActions.LOAD_FAILED:
    case packageStructureActions.LOAD_BY_ID_FAILED: {
      return {
        ...state,
        loaded: false,
        loading: false
      };
    }
    case packageStructureActions.CREATE_FAILED:
    case packageStructureActions.DELETE_FAILED:
    case packageStructureActions.UPDATE_FAILED: {
      return { ...state, loading: false };
    }
    default: {
      return state;
    }
  }
}
export const getPackageStructureLoading = (state: State) => state.loading;
export const getPackageStructureLoaded = (state: State) => state.loaded;
