import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { Partner } from '../models';
import { partnerActions } from '../actions';

export const partnerAdapter = createEntityAdapter<Partner>({
  selectId: (item: Partner) => item.id,
  sortComparer: sortByName
});

export interface State extends EntityState<Partner> {
  loading: boolean;
  loaded: boolean;
}

export const INIT_STATE: State = partnerAdapter.getInitialState({
  loading: false,
  loaded: false
});

export function sortByName(a: Partner, b: Partner): number {
  return a.name.localeCompare(b.name);
}

export function reducer(state = INIT_STATE, action: partnerActions.All) {
  switch (action.type) {
    case partnerActions.LOAD: {
      return {
        ...state,
        loading: true,
        loaded: false
      };
    }
    case partnerActions.LOAD_SUCCESS: {
      return {
        ...partnerAdapter.addAll(action.payload as Partner[], state),
        loading: false,
        loaded: true
      };
    }
    case partnerActions.LOAD_BY_ID: {
      return {
        ...state,
        loading: true
      };
    }
    case partnerActions.LOAD_BY_ID_SUCCESS: {
      return {
        ...partnerAdapter.upsertOne(action.payload, state),
        loading: false
      };
    }
    case partnerActions.LOAD_BY_ID_FAILED: {
      return {
        ...state,
        loading: false
      };
    }
    case partnerActions.UPDATE_SUCCESS: {
      return partnerAdapter.updateOne(
        {
          id: action.payload.id,
          changes: action.payload
        },
        state
      );
    }
    case partnerActions.CREATE_SUCCESS: {
      return partnerAdapter.addOne(action.payload, state);
    }
    case partnerActions.DELETE_SUCCESS: {
      return partnerAdapter.removeOne(action.payload, state);
    }
    case partnerActions.LOAD_FAILED: {
      return { ...state, loading: false, loaded: false };
    }
    case partnerActions.CREATE_FAILED:
    case partnerActions.DELETE_FAILED:
    case partnerActions.UPDATE_FAILED: {
      return { ...state, loading: false };
    }
    default: {
      return state;
    }
  }
}
export const getPartnersLoading = (state: State) => state.loading;
export const getPartnersLoaded = (state: State) => state.loaded;
