import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { Profile } from '../models';
import { profileActions } from '../actions';

export const profileAdapter = createEntityAdapter<Profile>({
  selectId: (item: Profile) => item.id,
  sortComparer: sortById
});

export interface State extends EntityState<Profile> {
  loading: boolean;
  loaded: boolean;
}

export const INIT_STATE: State = profileAdapter.getInitialState({
  loading: false,
  loaded: false
});

export function sortById(a: Profile, b: Profile): number {
  return b.id.toString().localeCompare(a.id.toString());
}

export function reducer(state = INIT_STATE, action: profileActions.All) {
  switch (action.type) {
    case profileActions.LOAD: {
      return {
        ...state,
        loading: true,
        loaded: false
      };
    }
    case profileActions.LOAD_SUCCESS: {
      return {
        ...profileAdapter.addAll(action.payload as Profile[], state),
        loading: false,
        loaded: true
      };
    }
    case profileActions.UPDATE_SUCCESS: {
      return profileAdapter.updateOne(
        {
          id: action.payload.id,
          changes: action.payload
        },
        state
      );
    }

    case profileActions.LOAD_BY_ID: {
      return {
        ...INIT_STATE,
        loading: true,
        loaded: false
      };
    }
    case profileActions.LOAD_BY_ID_SUCCESS: {
      return {
        ...profileAdapter.upsertOne(action.payload, state),
        loaded: true,
        loading: false
      };
    }
    case profileActions.LOAD_BY_ID_FAILED: {
      return {
        ...state,
        loaded: false,
        loading: false
      };
    }

    case profileActions.CREATE_SUCCESS: {
      return profileAdapter.addOne(action.payload, state);
    }
    case profileActions.DELETE_SUCCESS: {
      return profileAdapter.removeOne(action.payload, state);
    }
    case profileActions.LOAD_FAILED: {
      return { ...state, loading: false, loaded: false };
    }
    case profileActions.CREATE_FAILED:
    case profileActions.DELETE_FAILED:
    case profileActions.UPDATE_FAILED: {
      return { ...state, loading: false };
    }
    default: {
      return state;
    }
  }
}
export const getProfilesLoading = (state: State) => state.loading;
export const getProfilesLoaded = (state: State) => state.loaded;
