import { ReferenceResponse } from '../models';
import { referenceDataActions } from '../actions';

export interface State {
  referenceData: ReferenceResponse;
  loading: boolean;
  loaded: boolean;
}

export const INIT_STATE: State = {
  referenceData: [],
  loading: false,
  loaded: false
};

export function reducer(state: State = INIT_STATE, action: referenceDataActions.All) {
  switch (action.type) {
    case referenceDataActions.LOAD:
    case referenceDataActions.LOAD_FALLBACK_PACKAGE_LIST:
    case referenceDataActions.LOAD_IMAGE_FALLBACK_LIST:
    case referenceDataActions.LOAD_VIDEO_CODEC_DROPDOWNS:
    case referenceDataActions.LOAD_DELIVERY_TEMPLATE_LIST:
    case referenceDataActions.LOAD_PACKAGE_STRUCTURE_LISTS: {
      return {
        ...state,
        loaded: false,
        loading: true
      };
    }

    case referenceDataActions.LOAD_SUCCESS: {
      return {
        ...state,
        loaded: true,
        loading: false,
        referenceData: action.payload
      };
    }

    case referenceDataActions.LOAD_FALLBACK_PACKAGE_LIST_SUCCESS: {
      return {
        ...state,
        loaded: true,
        loading: false,
        referenceData: {
          ...state.referenceData,
          fallbackPackageList: action.payload
        }
      };
    }

    case referenceDataActions.LOAD_VIDEO_CODEC_DROPDOWNS_SUCCESS: {
      return {
        ...state,
        loaded: true,
        loading: false,
        referenceData: {
          ...state.referenceData,
          videoCodecDropdowns: action.payload
        }
      };
    }

    case referenceDataActions.LOAD_IMAGE_FALLBACK_LIST_SUCCESS: {
      return {
        ...state,
        loaded: true,
        loading: false,
        referenceData: {
          ...state.referenceData,
          imageFallbackList: action.payload
        }
      };
    }

    case referenceDataActions.LOAD_DELIVERY_TEMPLATE_LIST_SUCCESS: {
      return {
        ...state,
        loaded: true,
        loading: false,
        referenceData: {
          ...state.referenceData,
          deliveryTemplateList: action.payload
        }
      };
    }

    case referenceDataActions.LOAD_PACKAGE_TEMPLATE_LIST_SUCCESS: {
      return {
        ...state,
        loaded: true,
        loading: false,
        referenceData: {
          ...state.referenceData,
          packageTemplateList: action.payload
        }
      };
    }

    case referenceDataActions.LOAD_PACKAGE_STRUCTURE_LISTS_SUCCESS: {
      return {
        ...state,
        loaded: true,
        loading: false,
        referenceData: {
          ...state.referenceData,
          fallbackPackageList: action.payload.fallbackPackageList,
          deliveryTemplateList: action.payload.deliveryTemplateList,
          packageTemplateList: action.payload.packageTemplateList
        }
      };
    }

    case referenceDataActions.LOAD_FAILED:
    case referenceDataActions.LOAD_FALLBACK_PACKAGE_LIST_FAILED:
    case referenceDataActions.LOAD_IMAGE_FALLBACK_LIST_FAILED:
    case referenceDataActions.LOAD_VIDEO_CODEC_DROPDOWNS_FAILED:
    case referenceDataActions.LOAD_DELIVERY_TEMPLATE_LIST_FAILED:
    case referenceDataActions.LOAD_PACKAGE_STRUCTURE_LISTS_FAILED: {
      return {
        ...state,
        loading: false,
        loaded: false
      };
    }

    default: {
      return state;
    }
  }
}

export const getReferenceDataLoading = (state: State) => state.loading;
export const getReferenceDataLoaded = (state: State) => state.loaded;
