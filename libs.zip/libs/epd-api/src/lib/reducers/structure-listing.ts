import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { PackageStructure } from '../models';
import { structureListingActions } from '../actions';

export const structureListingAdapter = createEntityAdapter<PackageStructure>({
  selectId: (item: PackageStructure) => item.packageStructureId,
  sortComparer: sortById
});

export interface State extends EntityState<PackageStructure> {
  loading: boolean;
  loaded: boolean;
}

export const INIT_STATE: State = structureListingAdapter.getInitialState({
  loading: false,
  loaded: false
});

export function sortById(a: PackageStructure, b: PackageStructure): number {
  return b.packageStructureId.toString().localeCompare(a.packageStructureId.toString());
}

export function reducer(state = INIT_STATE, action: structureListingActions.All) {
  switch (action.type) {
    case structureListingActions.LOAD_ALL_BY_PARTNER_PROFILE_ID: {
      return {
        ...state,
        loading: true,
        loaded: false
      };
    }
    case structureListingActions.LOAD_ALL_BY_PARTNER_PROFILE_ID_SUCCESS: {
      return {
        ...structureListingAdapter.addAll(action.payload as PackageStructure[], state),
        loading: false,
        loaded: true
      };
    }
    case structureListingActions.LOAD_ALL_BY_PARTNER_PROFILE_ID_FAILED: {
      return {
        ...state,
        loaded: false,
        loading: false
      };
    }
    case structureListingActions.UPDATE_SUCCESS: {
      return structureListingAdapter.updateOne(
        {
          id: action.payload[0].packageStructureId,
          changes: action.payload[0]
        },
        state
      );
    }
    case structureListingActions.CREATE_SUCCESS: {
      return structureListingAdapter.addOne(action.payload, state);
    }
    case structureListingActions.DELETE_SUCCESS: {
      return structureListingAdapter.removeOne(action.payload, state);
    }
    case structureListingActions.CREATE_FAILED:
    case structureListingActions.DELETE_FAILED:
    case structureListingActions.UPDATE_FAILED: {
      return { ...state, loading: false };
    }
    default: {
      return state;
    }
  }
}
export const getStructureListingLoading = (state: State) => state.loading;
export const getStructureListingLoaded = (state: State) => state.loaded;
