import { createFeatureSelector, createSelector } from '@ngrx/store';
import { fromDestinationTemplate } from '../reducers';

export const getDestinationTemplateRootState = createFeatureSelector<fromDestinationTemplate.State>(
  'destinationTemplate'
);
export const getDestinationTemplateState = createSelector(
  getDestinationTemplateRootState,
  state => state
);

export const {
  selectAll: getAllDestinationTemplates,
  selectEntities: getDestinationTemplateEntities
} = fromDestinationTemplate.destinationTemplateAdapter.getSelectors(getDestinationTemplateState);

/**
 * Selector to return the loaded property of the state
 */
export const getDestinationTemplateLoaded = createSelector(
  getDestinationTemplateState,
  fromDestinationTemplate.getDestinationTemplateLoaded
);

/**
 * Selector to return the loading property of the state
 */
export const getDestinationTemplateLoading = createSelector(
  getDestinationTemplateState,
  fromDestinationTemplate.getDestinationTemplateLoading
);
