import * as partnerSelectors from './partner.selectors';
import * as profileSelectors from './profile.selectors';
import * as packageStructureSelectors from './package-structure.selectors';
import * as packageDefinitionSelectors from './package-definition.selectors';
import * as referenceDataSelectors from './reference-data.selectors';
import * as packageInstructionsSelectors from './package-instructions.selectors';
import * as structureListingSelectors from './structure-listing.selectors';
import * as destinationTemplateSelectors from './destination-template.selectors';

export {
  partnerSelectors,
  profileSelectors,
  referenceDataSelectors,
  packageStructureSelectors,
  packageDefinitionSelectors,
  packageInstructionsSelectors,
  structureListingSelectors,
  destinationTemplateSelectors
};
