import { createFeatureSelector, createSelector } from '@ngrx/store';
import { fromPackageDefinition } from '../reducers';

export const getPackageDefinitionRootState = createFeatureSelector<fromPackageDefinition.State>(
  'packageDefinition'
);

export const getPackageDefinitionState = createSelector(
  getPackageDefinitionRootState,
  state => state
);

export const {
  selectAll: getAllPackageDefinitions,
  selectEntities: getPackageDefinitionsEntities,
  selectIds: selectPackageDefinitionIds
} = fromPackageDefinition.packageDefinitionAdapter.getSelectors(getPackageDefinitionState);

/**
 * Selector to get the Reference Data for a particular type
 */
export const getPackageDefinition = () =>
  createSelector(
    getPackageDefinitionState,
    (state: fromPackageDefinition.State) => {
      return state.entities;
    }
  );

/**
 * Selector to get the Reference Data for a particular type
 */
export const getMaterials = () =>
  createSelector(
    getPackageDefinitionState,
    (state: fromPackageDefinition.State) => {
      return state;
    }
  );

/**
 * Selector to return a package Definition by id.
 */
export const getPackageDefinitionById = packageDefinitionId =>
  createSelector(
    getPackageDefinitionsEntities,
    entities => entities[packageDefinitionId]
  );

/**
 * Selector to return the loaded property of the state
 */
export const getPackageDefinitionLoaded = createSelector(
  getPackageDefinitionState,
  fromPackageDefinition.getPackageDefinitionLoaded
);

/**
 * Selector to return the loading property of the state
 */
export const getPackageDefinitionLoading = createSelector(
  getPackageDefinitionState,
  fromPackageDefinition.getPackageDefinitionLoading
);
