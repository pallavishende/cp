import { createFeatureSelector, createSelector } from '@ngrx/store';
import { fromPackageInstructions } from '../reducers';

export const getPackageInstructionsRootState = createFeatureSelector<fromPackageInstructions.State>(
  'packageInstructions'
);
export const getPackageInstructionsState = createSelector(
  getPackageInstructionsRootState,
  state => state
);

export const {
  selectAll: getAllPackageInstructions,
  selectEntities: getPackageInstructionsEntities
} = fromPackageInstructions.packageInstructionsAdapter.getSelectors(getPackageInstructionsState);

/**
 * Selector to return the loaded property of the state
 */
export const getPackageInstructionsLoaded = createSelector(
  getPackageInstructionsState,
  fromPackageInstructions.getPackageInstructionsLoaded
);

/**
 * Selector to return the loading property of the state
 */
export const getPackageInstructionsLoading = createSelector(
  getPackageInstructionsState,
  fromPackageInstructions.getPackageInstructionsLoading
);
