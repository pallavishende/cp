import { createFeatureSelector, createSelector } from '@ngrx/store';
import { fromPackageStructure } from '../reducers';
import { Params } from '@angular/router';

export const getPackageStructureRootState = createFeatureSelector<fromPackageStructure.State>(
  'packageStructure'
);
export const getPackageStructureState = createSelector(
  getPackageStructureRootState,
  state => state
);

export const {
  selectAll: getAllPackageStructures,
  selectEntities: getPackageStructureEntities
} = fromPackageStructure.packageStructureAdapter.getSelectors(getPackageStructureState);

/**
 * Selector to return the loaded property of the state
 */
export const getPackageStructureLoaded = createSelector(
  getPackageStructureState,
  fromPackageStructure.getPackageStructureLoaded
);

/**
 * Selector to return the loading property of the state
 */
export const getPackageStructureLoading = createSelector(
  getPackageStructureState,
  fromPackageStructure.getPackageStructureLoading
);

export const getRouterState = createFeatureSelector('routerReducer');

export interface RouterStateUrl {
  state: {
    url: string;
    queryParams: Params;
    params: Params;
  };
}

export const getCurrentUrl = createSelector(
  getRouterState,
  (state: RouterStateUrl) => {
    return state;
  }
);
