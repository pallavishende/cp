import { createFeatureSelector, createSelector } from '@ngrx/store';
import { fromPartner } from '../reducers';

export const getPartnerRootState = createFeatureSelector<fromPartner.State>('partner');
export const getPartnerState = createSelector(getPartnerRootState, state => state);

export const {
  selectAll: getAllPartners,
  selectEntities: getPartnerEntities
} = fromPartner.partnerAdapter.getSelectors(getPartnerState);

/**
 * Selector to return a partner by id.
 */
export const getPartnerById = partnerId =>
  createSelector(getPartnerEntities, entities => entities[partnerId]);

/**
 * Selector to return the loaded property of the state
 */
export const getPartnersLoaded = createSelector(getPartnerState, fromPartner.getPartnersLoaded);

/**
 * Selector to return the loading property of the state
 */
export const getPartnersLoading = createSelector(getPartnerState, fromPartner.getPartnersLoading);
