import { createFeatureSelector, createSelector } from '@ngrx/store';
import { fromProfile } from '../reducers';

export const getProfileRootState = createFeatureSelector<fromProfile.State>('profile');
export const getProfileState = createSelector(getProfileRootState, state => state);

export const {
  selectAll: getAllProfiles,
  selectEntities: getProfileEntities
} = fromProfile.profileAdapter.getSelectors(getProfileState);

/**
 * Selector to return the loaded property of the state
 */
export const getProfilesLoaded = createSelector(getProfileState, fromProfile.getProfilesLoaded);

/**
 * Selector to return the loading property of the state
 */
export const getProfilesLoading = createSelector(getProfileState, fromProfile.getProfilesLoading);
