import { createFeatureSelector, createSelector } from '@ngrx/store';
import { fromReferenceData } from '../reducers';
import { ReferenceDataType, refItemToDatasetValue, RefItem } from '../models';
import { DatasetValue } from '@content-platform/application-api';

export const getReferencedataRootState = createFeatureSelector<fromReferenceData.State>(
  'referenceData'
);

export const getReferenceDataState = createSelector(
  getReferencedataRootState,
  state => state
);

/**
 * Selector to return the loaded property of the state
 */
export const getReferenceDataLoaded = createSelector(
  getReferenceDataState,
  fromReferenceData.getReferenceDataLoaded
);

/**
 * Selector to return the loading property of the state
 */
export const getReferenceDataLoading = createSelector(
  getReferenceDataState,
  fromReferenceData.getReferenceDataLoading
);

/**
 * Selector to get the Reference Data for a particular type
 */
export const getReferenceDataType = (refType: ReferenceDataType) =>
  createSelector(
    getReferenceDataState,
    (state: fromReferenceData.State) => {
      return state.referenceData[refType];
    }
  );

/**
 * Selector to get the Reference Data for a particular type as an array of dataset values
 */
export const getReferenceDataAsDatasetValues = (refType: ReferenceDataType) =>
  createSelector(
    getReferenceDataState,
    (state: fromReferenceData.State) => {
      let datasetOptionsArray: DatasetValue[];

      // We try to .map on state.referenceData[refType], and if it errors
      // because the expression state.referenceData[refType] initially
      // evaluated to an error object (that obviously has no .map function),
      // then we return an empty array instead.
      try {
        datasetOptionsArray = (<RefItem[]>(state.referenceData[refType] || [])).map(refItem => {
          return refItemToDatasetValue(refItem);
        });
      } catch (e) {
        datasetOptionsArray = [];
      }

      return [
        {
          group: '',
          values: datasetOptionsArray
        }
      ];
    }
  );
