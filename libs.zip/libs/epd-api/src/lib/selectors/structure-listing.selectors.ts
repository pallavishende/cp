import { createFeatureSelector, createSelector } from '@ngrx/store';
import { fromStructureListing } from '../reducers';

export const getStructureListingRootState = createFeatureSelector<fromStructureListing.State>(
  'structureListing'
);
export const getStructureListingState = createSelector(
  getStructureListingRootState,
  state => state
);

export const {
  selectAll: getAllPackageStructures,
  selectEntities: getPackageStructureEntities
} = fromStructureListing.structureListingAdapter.getSelectors(getStructureListingState);

/**
 * Selector to return the loaded property of the state
 */
export const getStructureListingLoaded = createSelector(
  getStructureListingState,
  fromStructureListing.getStructureListingLoaded
);

/**
 * Selector to return the loading property of the state
 */
export const getStructureListingLoading = createSelector(
  getStructureListingState,
  fromStructureListing.getStructureListingLoading
);
