import { Injectable } from '@angular/core';

@Injectable()
export class ActionDispatchService {
  constructor() {}

  /***
   * Get an action object
   *
   * Sample uses:
   *   this.store.dispatch(
   *     ActionDispatchService.getAction(referenceDataActions.LoadFallbackPackageList)
   *   );
   *
   *   catchError(error => [
   *     ActionDispatchService.getAction(profileActions.DeleteFailed, error),
   *   ])
   *
   *   @param action class
   *   @param error string optional
   *   @param showNotifications boolean optional
   *   @param message string optional
   *   @return action object that's ready to be dispatched
   */
  getAction(action: any, error = '', showNotifications = false, message = '') {
    return new action({
      error: error,
      showNotifications: showNotifications,
      message: message
    });
  }
}
