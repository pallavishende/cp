import { Injectable } from '@angular/core';
import { throwError, Observable } from 'rxjs';
import { catchError, mergeMap, tap } from 'rxjs/operators';
import { HttpClient, HttpParams } from '@angular/common/http';
import { AdminDropdown } from '../models';
import { Resource } from './resource';
import { ApiParams } from './api-params';
import { LoggerService } from '@content-platform/logging';
import { NotificationService } from './notification.service';
import { Store } from '@ngrx/store';
import { EpdState } from '../..';

@Injectable()
export class AdminDropdownService extends Resource<AdminDropdown> {
  type: string;
  isEpdEntities = false;
  constructor(
    http: HttpClient,
    private loggerService: LoggerService,
    private apiParams: ApiParams,
    private notification: NotificationService,
    private store: Store<EpdState>
  ) {
    super(http, loggerService.instance('AdminDropdownService'));
    this.type = '';
  }

  checkEpdEntities(payload: any) {
    if (payload.epdEntities) {
      this.isEpdEntities = true;
    }
  }

  getQueryUrl() {
    if (this.isEpdEntities) {
      return this.apiParams.getUrl('epdEntitiesDetails', null, null);
    }
    return this.apiParams.getUrl('', null, this.type);
  }
  getGetUrl() {
    return this.apiParams.getUrl('', null, this.type);
  }
  getCreateUrl() {
    if (this.isEpdEntities) {
      return this.apiParams.getUrl('epdEntitiesDetails', null, null);
    }
    return this.apiParams.getUrl('', null, this.type);
  }
  getUpdateUrl() {
    return this.apiParams.getUrl('', null, this.type);
  }
  getDeleteUrl() {
    if (this.isEpdEntities) {
      return this.apiParams.getUrl('epdEntitiesDetails', null, null);
    }
  }

  get entityName(): string {
    return 'Dropdown Item';
  }

  /**
   * Retrieves a single item, using the dropdown item id
   *
   * @param payload
   * @returns
   */
  getById(payload: any): Observable<AdminDropdown> {
    this.type = '/' + payload.type;
    this.checkEpdEntities(payload);

    return this.http.get<AdminDropdown>(this.getQueryUrl() + '/' + payload.id).pipe(
      mergeMap(data => {
        // begins data normalization because we use two endpoints that returns two different object structures
        if (data.hasOwnProperty('v3EpdEntities')) {
          delete data['v3EpdEntities'];
        }

        let normalizedData = data;

        // epdEntitiesDetails endpoint has {id: number, entityValue: string} where the endpoints that are specific for each entity
        // such as api/v3/entityName, returns {id: number, name: string}
        if (this.isEpdEntities) {
          const { id, entityValue } = data;
          normalizedData = { id, name: entityValue };
        }

        this.loggerService.log(`Retrieved ${this.entityName}`, {
          name: normalizedData.name
        });

        this.isEpdEntities = false;
        return this.transformResponse([normalizedData]);
      }),
      catchError(error => {
        this.isEpdEntities = false;
        this.store.dispatch(this.notification.error('There was an error getting the item details'));
        return this.handleError(`Retrieving ${this.entityName} Failed`, error);
      })
    );
  }

  /**
   * Does a POST to the endpoint, to create a new dropdown item
   *
   * @param data
   * @returns
   */
  create(payload: any): Observable<AdminDropdown> {
    this.type = '/' + payload.type;
    this.checkEpdEntities(payload);

    return this.http.post<AdminDropdown>(this.getCreateUrl(), this.transformRequest(payload)).pipe(
      mergeMap(createdData => {
        this.store.dispatch(
          this.notification.success(payload.payload.name + ' has been successfully created')
        ),
          this.loggerService.log(`Created ${this.entityName}`, {
            name: createdData['name']
          });

        this.isEpdEntities = false;
        return this.transformResponse([createdData]);
      }),
      catchError(error => {
        this.store.dispatch(
          this.notification.error('There was an error creating ' + payload.payload.name)
        );
        return this.handleError(`Create ${this.entityName} Failed`, error);
      })
    );
  }

  /**
   * Does a PUT to the endpoint, to update a dropdown item.
   *
   * @param data
   * @returns
   */
  update(payload: any): Observable<AdminDropdown> {
    this.type = '/' + payload.type;
    return this.http.put<AdminDropdown>(this.getUpdateUrl(), payload.payload).pipe(
      mergeMap(updatedData => {
        this.store.dispatch(
          this.notification.success(payload.payload.name + ' has been successfully updated')
        ),
          this.loggerService.log(`Updated ${this.entityName}`, {
            name: updatedData['name']
          });
        return this.transformResponse([updatedData]);
      }),
      catchError(error => {
        this.store.dispatch(
          this.notification.error('There was an error updating ' + payload.payload.name)
        );
        return this.handleError(`Update ${this.entityName} Failed`, error);
      })
    );
  }

  /**
   * Does a DELETE to the endpoint, to delete a dropdown item.
   *
   * @param data
   * @returns
   */
  delete(payload: any) {
    this.type = '/' + payload.type;
    this.checkEpdEntities(payload);

    return this.http.delete(this.getDeleteUrl() + '/' + payload.id).pipe(
      mergeMap(() => [
        this.loggerService.log(`Deleted ${this.entityName}`),
        this.store.dispatch(
          this.notification.success('The dropdown item has been successfully deleted')
        )
      ]),
      tap(() => (this.isEpdEntities = false)),
      catchError(error => {
        this.store.dispatch(
          this.notification.error('There was an error deleting the dropdown item')
        );
        return this.handleError(`Delete ${this.entityName} Failed`, error);
      })
    );
  }

  query(params?: HttpParams): Observable<AdminDropdown[]> {
    return super.query(params).pipe(catchError(error => throwError(error)));
  }

  // TODO: make it use EpdV3Entities instead of any
  transformRequest(data: AdminDropdown | any): AdminDropdown | any {
    // different payload for epdEntities endpoint
    if (this.isEpdEntities) {
      return {
        entityValue: data.payload.name,
        v3EpdEntities: {
          id: this.getEntityId()
        }
      };
    }

    return data;
  }

  getEntityId() {
    let entityId = null;

    switch (this.type) {
      case 'image-types':
        entityId = 174552;
        break;
      case 'subtitle-formats':
        entityId = 174553;
        break;
      case 'caption-formats':
        entityId = 174554;
        break;
      case 'aspect-ratio':
        entityId = 174555;
        break;
      case 'compresses':
        entityId = 174556;
        break;
      case '/content-levels':
        entityId = 174557;
        break;
      case 'profanities':
        entityId = 174558;
        break;
      case 'scan-types':
        entityId = 174559;
        break;
      case 'layouts':
        entityId = 174561;
        break;
      default:
        break;
    }
    return entityId;
  }
}
