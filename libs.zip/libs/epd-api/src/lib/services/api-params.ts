import { Environments } from '@content-platform/configuration';

const apiEndpoints = {
  partners: '/v3/partners',
  recentPartners: '/v3/recent/partners',
  profilesByPartner: '/v3/:partnerId/partner-profiles',
  profiles: '/v3/partner-profiles',
  packageStructures: '/v3/package-structures',
  packageStructuresByProfile: '/v3/:profileId/package-structures',
  packageInstructions: '/v3/package-instructions',
  loadInstructions: '/v3/:psId/package-instructions/:instructionId',

  videoMaterial: '/v3/video-material',
  audioMaterial: '/v3/audio-material',
  imageMaterial: '/v3/image-material',
  subtitleMaterial: '/v3/subtitle-material',
  captionMaterial: '/v3/caption-material',
  metadataMaterial: '/v3/metadata-material',
  materialTechnical: '/v3/material-technical',
  allMaterials: '/v3/epdgateway/drop-downs',
  getPackageDefinitions: '/v3/materials',
  epdEntitiesDetails: '/v3/epd-entities-details',

  destinationTemplate: '/v3/destination-templates',
  videoCodecFieldsForDropdowns: '/get-video-codec-fields-for-dropdowns',
  deliveryTemplate: '/v3/delivery-template',
  packageTemplate: '/v3/package-template'
};

/**
 * Class with static methods used to get the urls for the api endpoint
 *
 * @export
 * @class ApiParams
 */
export class ApiParams {
  constructor() {}
  /**
   * Gets the full url for the given endpoint/type, in case there are dynamic values in the url
   * the user can pass in tokens to replace them.
   *
   * @static
   * @param type
   * @param [tokens] optional tokens for the url
   * @returns the endpoint full url
   */
  getUrl(type: string, tokens?: { [key: string]: string }, adminType?: string) {
    let pattern = adminType ? adminType : apiEndpoints[type];

    if (pattern) {
      if (tokens) {
        Object.keys(tokens).forEach(tokenKey => {
          const tokenVal = encodeURIComponent(tokens[tokenKey]);
          const tokenStandIn = ':' + tokenKey;
          pattern = pattern.replace(tokenStandIn, tokenVal);
        });
      }

      let url = Environments.getUrl('endpointProfile') + pattern;

      if (url.endsWith('/')) {
        url = url.slice(0, -1);
      }
      return url;
    }
  }

  getUpdatedUrl(currentUrl: string, values: { [key: string]: string }): string {
    let updatedUrl = currentUrl;

    for (const [key, value] of Object.entries(values)) {
      updatedUrl = updatedUrl.replace(key, value);
    }

    return updatedUrl;
  }
}
