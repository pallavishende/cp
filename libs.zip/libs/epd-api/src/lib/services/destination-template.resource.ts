import { Injectable } from '@angular/core';
import { throwError, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpParams } from '@angular/common/http';
import { DestinationTemplate } from '../models';
import { Resource } from './resource';
import { ApiParams } from './api-params';
import { LoggerService } from '@content-platform/logging';

@Injectable()
export class DestinationTemplateResource extends Resource<DestinationTemplate> {
  constructor(http: HttpClient, logger: LoggerService, private apiParams: ApiParams) {
    super(http, logger.instance('DestinationTemplateResource'));
  }

  getQueryUrl() {
    return this.apiParams.getUrl('destinationTemplate');
  }
  getGetUrl() {
    return this.apiParams.getUrl('destinationTemplate');
  }
  getCreateUrl() {
    return this.apiParams.getUrl('destinationTemplate');
  }
  getUpdateUrl() {
    return this.apiParams.getUrl('destinationTemplate');
  }
  getDeleteUrl() {
    return this.apiParams.getUrl('destinationTemplate');
  }

  get entityName(): string {
    return 'DestinationTemplate';
  }

  query(params?: HttpParams): Observable<DestinationTemplate[]> {
    return super.query(params).pipe(catchError(error => throwError(error)));
  }
}
