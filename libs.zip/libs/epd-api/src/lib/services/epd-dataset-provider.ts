import { MemoizedSelector } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { CustomDatasetProvider, DatasetOptions } from '@content-platform/dynamic-forms-api';
import { referenceDataSelectors } from '../selectors';
import { ReferenceDataType } from '../models';

export function useThisProvider(contentType: string): boolean {
  return contentType.startsWith('epd-');
}

export function checkStore(): Observable<boolean> {
  return of(true);
}

export function selectDatasetOptions(
  _contentType: string,
  fieldKey: string
): MemoizedSelector<object, DatasetOptions[]> {
  return referenceDataSelectors.getReferenceDataAsDatasetValues(<ReferenceDataType>fieldKey);
}

export const EpdDatasetProvider: CustomDatasetProvider = {
  useThisProvider,
  checkStore,
  selectDatasetOptions
};
