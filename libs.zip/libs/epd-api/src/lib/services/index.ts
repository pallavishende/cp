import { ApiParams } from './api-params';
import { PartnerResource } from './partner-resource';
import { ProfileResource } from './profile-resource';
import { PackageStructureResource } from './package-structure-resource';
import { PackageDefinitionResource } from './package-definition-resource';
import { ReferenceDataResource } from './reference-data-resource';
import { PreloadDataResource } from './preload-data-resource';
import { LookupService } from './lookup.service';
import { PackageInstructionsResource } from './package-instructions-resource';
import { DestinationTemplateResource } from './destination-template.resource';
import { NotificationService } from './notification.service';
import { ActionDispatchService } from './action-dispatch.service';
import { AdminDropdownService } from './admin-dropdown.service';

export { EpdDatasetProvider } from './epd-dataset-provider';

export * from './api-params';
export * from './partner-resource';
export * from './profile-resource';
export * from './package-structure-resource';
export * from './package-definition-resource';
export * from './reference-data-resource';
export * from './preload-data-resource';
export * from './lookup.service';
export * from './package-instructions-resource';
export * from './destination-template.resource';
export * from './notification.service';
export * from './action-dispatch.service';
export * from './admin-dropdown.service';

const resources = [
  ApiParams,
  PartnerResource,
  ProfileResource,
  PackageStructureResource,
  PackageDefinitionResource,
  ReferenceDataResource,
  PreloadDataResource,
  LookupService,
  PackageStructureResource,
  PackageInstructionsResource,
  DestinationTemplateResource,
  NotificationService,
  ActionDispatchService,
  AdminDropdownService
];

export { resources };
