import { Injectable } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { referenceDataSelectors } from '../selectors';
import { ReferenceData } from '../models';
import { Observable } from 'rxjs';

@Injectable()
export class LookupService {
  materialTypes: Observable<any>;
  contentLevels: Observable<any>;
  contentDescriptors = [
    {
      id: 1,
      name: 'CD1',
      describesVersion: true
    }
  ];

  constructor(public store: Store<ReferenceData>) {
    this.materialTypes = this.store.pipe(
      select(referenceDataSelectors.getReferenceDataType('materialTypeList'))
    );
    this.contentLevels = this.store.pipe(
      select(referenceDataSelectors.getReferenceDataType('contentLevelList'))
    );
  }

  findMaterialType(id?: number, name?: string) {
    let material;

    // find by id
    if (id) {
      this.materialTypes.subscribe(val => {
        material = val.find(item => item.id === id);
      });

      return material;
    }

    // find by name
    this.materialTypes.subscribe(val => {
      material = val.find(item => item.name.toLowerCase() === name.toLowerCase());
    });

    return material;
  }
}
