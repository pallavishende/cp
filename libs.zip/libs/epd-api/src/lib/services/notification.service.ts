import { Injectable } from '@angular/core';
import { notificationActions, NotificationType } from '@content-platform/notifications';

@Injectable()
export class NotificationService {
  DURATION = 5000;

  constructor() {}

  success(message: string) {
    return new notificationActions.Open({
      type: NotificationType.Success,
      durationMs: this.DURATION,
      inputs: {
        props: {
          message: message
        }
      }
    });
  }

  error(message: string, error?: string) {
    if (error) {
      return new notificationActions.Open({
        type: NotificationType.Error,
        durationMs: this.DURATION,
        inputs: {
          props: {
            message: `${message}\n\n  ${error}`
          }
        }
      });
    }

    return new notificationActions.Open({
      type: NotificationType.Error,
      durationMs: this.DURATION,
      inputs: {
        props: {
          message: `${message}`
        }
      }
    });
  }
}
