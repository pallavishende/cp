import { throwError, Observable } from 'rxjs';

import { catchError, switchMap } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { PackageDefinition, ReferenceData } from '../models';
import { Resource } from './resource';
import { LookupService } from './lookup.service';
import { ApiParams } from './api-params';
import { LoggerService } from '@content-platform/logging';
import { Store } from '@ngrx/store';

@Injectable()
export class PackageDefinitionResource extends Resource<PackageDefinition> {
  materialType: { id: number; name: string };

  constructor(
    public store: Store<ReferenceData>,
    public lookupService: LookupService,
    public http: HttpClient,
    public loggerService: LoggerService,
    private apiParams: ApiParams
  ) {
    super(http, loggerService.instance('PackageDefinitionResource'));
  }

  getMaterialType(id) {
    return this.lookupService.findMaterialType(id);
  }

  getQueryUrl() {
    return this.apiParams.getUrl('getPackageDefinitions');
  }
  getGetUrl() {
    return this.apiParams.getUrl('getPackageDefinitions');
  }
  getCreateUrl(data) {
    switch (data[0].material.materialType.name) {
      case 'Video':
        return this.apiParams.getUrl('videoMaterial');
      case 'Audio':
        return this.apiParams.getUrl('audioMaterial');
      case 'Image':
        return this.apiParams.getUrl('imageMaterial');
      case 'Subtitle':
        return this.apiParams.getUrl('subtitleMaterial');
      case 'Caption':
        return this.apiParams.getUrl('captionMaterial');
      case 'Metadata':
        return this.apiParams.getUrl('metadataMaterial');
    }
  }
  getUpdateUrl() {
    return this.apiParams.getUrl('updatePackageDefinition');
  }
  getDeleteUrl() {
    return this.apiParams.getUrl('deletePackageDefinition');
  }

  getPackageDefinitionById(id: string) {
    return this.http
      .get<PackageDefinition>(`${this.apiParams.getUrl('materialTechnical')}/${id}`)
      .pipe(
        switchMap(data => {
          this.loggerService.log(`Retrieved ${this.entityName}`, {
            partnerProfileId: id
          });
          return this.transformResponse([data]);
        }),
        catchError(error => this.handleError(`Retrieving ${this.entityName} Failed`, error))
      );
  }

  get entityName(): string {
    return 'PackageDefinition';
  }

  query(params?: HttpParams): Observable<PackageDefinition[]> {
    return super.query(params).pipe(catchError(error => throwError(error)));
  }
}
