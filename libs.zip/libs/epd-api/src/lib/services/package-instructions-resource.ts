import { Injectable } from '@angular/core';
import { throwError, Observable, of } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';
import { HttpClient, HttpParams } from '@angular/common/http';
import { PackageInstructions } from '../models';
import { Resource } from './resource';
import { ApiParams } from './api-params';
import { LoggerService } from '@content-platform/logging';

@Injectable()
export class PackageInstructionsResource extends Resource<PackageInstructions> {
  constructor(
    http: HttpClient,
    private loggerService: LoggerService,
    private apiParams: ApiParams
  ) {
    super(http, loggerService.instance('PackageInstructionsResource'));
  }

  getQueryUrl() {
    return this.apiParams.getUrl('packageInstructions');
  }
  getGetUrl() {
    return this.apiParams.getUrl('packageInstructions');
  }
  getCreateUrl() {
    return this.apiParams.getUrl('packageInstructions');
  }
  getUpdateUrl() {
    return this.apiParams.getUrl('packageInstructions');
  }
  getDeleteUrl() {
    return this.apiParams.getUrl('packageInstructions');
  }

  get entityName(): string {
    return 'PackageInstructions';
  }

  /**
   * Retrieves a single item, using the package structure id
   *
   * @param packageStructureId
   * @returns
   */
  get(packageStructureId: string): Observable<PackageInstructions> {
    const currentUrl = this.apiParams.getUrl('loadInstructions');
    const updatedUrl = this.apiParams.getUpdatedUrl(currentUrl, {
      ':psId': packageStructureId,
      ':instructionId': '0'
    });

    return this.http.get<PackageInstructions>(updatedUrl).pipe(
      switchMap(data => {
        this.loggerService.log(`Retrieved ${this.entityName}`, {
          packageStructureId: packageStructureId
        });
        return this.transformResponse([data]);
      }),
      catchError(error => this.handleError(`Retrieving ${this.entityName} Failed`, error))
    );
  }

  /**
   * Retrieves a single item, using the package structure id and package instruction id
   *
   * @param packageStructureId
   * @param packageInstructionId
   * @returns
   */
  getById(
    packageStructureId: string,
    packageInstructionId: string
  ): Observable<PackageInstructions> {
    const currentURL = this.apiParams.getUrl('loadInstructions');
    let updatedURL = currentURL.replace(':psId', packageStructureId);
    updatedURL = updatedURL.replace(':instructionId', packageInstructionId);
    return this.http.get<PackageInstructions>(updatedURL).pipe(
      switchMap(data => {
        this.loggerService.log(`Retrieved ${this.entityName}`, {
          packageStructureId: packageStructureId,
          packageInstructionId: packageInstructionId
        });
        return this.transformResponse([data]);
      }),
      catchError(error => this.handleError(`Retrieving ${this.entityName} Failed`, error))
    );
  }

  /**
   * Does a POST to the endpoint, to update a package instruction.
   *
   * @param data
   * @returns
   */
  update(data: PackageInstructions): Observable<PackageInstructions> {
    return this.http
      .post<PackageInstructions>(this.getUpdateUrl(), this.transformRequest(data))
      .pipe(
        switchMap(updatedData => {
          this.loggerService.log(`Updated ${this.entityName}`, {
            id: updatedData['packageInstructionId']
          });
          return of(updatedData);
        }),
        catchError(error => this.handleError(`Update ${this.entityName} Failed`, error))
      );
  }

  query(params?: HttpParams): Observable<PackageInstructions[]> {
    return super.query(params).pipe(catchError(error => throwError(error)));
  }
}
