import { throwError, Observable, of } from 'rxjs';

import { catchError, switchMap } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { PackageStructure } from '../models';
import { Resource } from './resource';
import { ApiParams } from './api-params';
import { LoggerService } from '@content-platform/logging';

@Injectable()
export class PackageStructureResource extends Resource<PackageStructure> {
  constructor(
    http: HttpClient,
    private loggerService: LoggerService,
    private apiParams: ApiParams
  ) {
    super(http, loggerService.instance('PackageStructureResource'));
  }

  getQueryUrl() {
    return this.apiParams.getUrl('packageStructures');
  }
  getGetUrl() {
    return this.apiParams.getUrl('packageStructures');
  }
  getCreateUrl() {
    return this.apiParams.getUrl('packageStructures');
  }
  getUpdateUrl() {
    return this.apiParams.getUrl('packageStructures');
  }
  getDeleteUrl() {
    return this.apiParams.getUrl('packageStructures');
  }

  /**
   * Does a POST to the endpoint, to create a new package structure
   *
   * @param data
   * @returns
   */
  create(data): Observable<PackageStructure> {
    return this.http.post<PackageStructure>(this.getCreateUrl(), this.transformRequest(data)).pipe(
      switchMap(createdData => {
        this.loggerService.log(`Created ${this.entityName}`, {
          packageStructureId: createdData[0]['packageStructureId']
        });
        return of(createdData[0]);
      }),
      catchError(error => this.handleError(`Create ${this.entityName} Failed`, error))
    );
  }

  /**
   * Does a POST to the endpoint, to update an existing package structure
   *
   * @param data
   * @returns
   */
  update(data): Observable<PackageStructure> {
    return this.http.post<PackageStructure>(this.getUpdateUrl(), this.transformRequest(data)).pipe(
      switchMap(updatedData => {
        this.loggerService.log(`Updated ${this.entityName}`, {
          packageStructureId: updatedData[0]['packageStructureId']
        });
        return of(updatedData);
      }),
      catchError(error => this.handleError(`Update ${this.entityName} Failed`, error))
    );
  }

  /**
   * Retrieves a single item, using the partner profile id
   *
   * @param partnerProfileId
   * @returns
   */
  getByPartnerProfileId(partnerProfileId: string): Observable<PackageStructure> {
    const currentUrl = this.apiParams.getUrl('packageStructuresByProfile');
    const updatedUrl = this.apiParams.getUpdatedUrl(currentUrl, { ':profileId': partnerProfileId });

    return this.http.get<PackageStructure>(updatedUrl).pipe(
      switchMap(data => {
        this.loggerService.log(`Retrieved ${this.entityName}`, {
          partnerProfileId: partnerProfileId
        });
        return this.transformResponse([data]);
      }),
      catchError(error => this.handleError(`Retrieving ${this.entityName} Failed`, error))
    );
  }

  get entityName(): string {
    return 'PackageStructure';
  }

  query(params?: HttpParams): Observable<PackageStructure[]> {
    return super.query(params).pipe(catchError(error => throwError(error)));
  }
}
