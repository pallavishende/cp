import { throwError, Observable } from 'rxjs';

import { catchError } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Partner } from '../models';
import { Resource } from './resource';
import { ApiParams } from './api-params';
import { LoggerService } from '@content-platform/logging';

@Injectable()
export class PartnerResource extends Resource<Partner> {
  constructor(http: HttpClient, logger: LoggerService, private apiParams: ApiParams) {
    super(http, logger.instance('PartnerResource'));
  }

  getQueryUrl() {
    return this.apiParams.getUrl('recentPartners');
  }
  getGetUrl() {
    return this.apiParams.getUrl('partners');
  }
  getCreateUrl() {
    return this.apiParams.getUrl('partners');
  }
  getUpdateUrl() {
    return this.apiParams.getUrl('partners');
  }
  getDeleteUrl() {
    return this.apiParams.getUrl('partners');
  }

  get entityName(): string {
    return 'Partner';
  }

  query(params?: HttpParams): Observable<Partner[]> {
    return super.query(params).pipe(catchError(error => throwError(error)));
  }
}
