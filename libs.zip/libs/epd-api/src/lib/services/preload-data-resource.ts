import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { LoggerService } from '@content-platform/logging';
import { ApiParams } from './api-params';
import { Observable } from 'rxjs';
/**
 * The purpose of this service is to have all data preloaded
 * in the same place to keep the app more organized
 * as racing conditions are very likely to happen when trying to preload
 * different kinds of data in different places of the app
 * @export
 * @class PreloadDataResource
 */
@Injectable()
export class PreloadDataResource {
  constructor(
    private http: HttpClient,
    private logger: LoggerService,
    private apiParams: ApiParams
  ) {
    this.logger.log('PreloadDataResource:constructor');
  }

  videoCodecDropdowns(): Observable<any> {
    const url = this.apiParams.getUrl('videoCodecFieldsForDropdowns');
    return this.http.get(url);
  }
}
