import { throwError, Observable, of } from 'rxjs';

import { catchError, switchMap } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Profile } from '../models';
import { Resource } from './resource';
import { ApiParams } from './api-params';
import { LoggerService } from '@content-platform/logging';

@Injectable()
export class ProfileResource extends Resource<Profile> {
  constructor(
    http: HttpClient,
    private loggerService: LoggerService,
    private apiParams: ApiParams
  ) {
    super(http, loggerService.instance('ProfileResource'));
  }

  getQueryUrl() {
    return this.apiParams.getUrl('profilesByPartner');
  }
  getGetUrl() {
    return this.apiParams.getUrl('profiles');
  }
  getCreateUrl() {
    return this.apiParams.getUrl('profiles');
  }
  getUpdateUrl() {
    return this.apiParams.getUrl('profiles');
  }
  getDeleteUrl() {
    return this.apiParams.getUrl('profiles');
  }

  get entityName(): string {
    return 'Profile';
  }

  getByPartnerId(id: string): Observable<Profile[]> {
    const currentUrl = this.getQueryUrl();
    const updatedUrl = this.apiParams.getUpdatedUrl(currentUrl, { ':partnerId': id });

    return this.http.get<Profile>(updatedUrl).pipe(
      switchMap(data => {
        this.loggerService.log(`Retrieved ${this.entityName}`);
        return of(data);
      }),
      catchError(error => this.handleError(`Retrieving ${this.entityName} Failed`, error))
    );
  }

  query(params?: HttpParams): Observable<Profile[]> {
    return super.query(params).pipe(catchError(error => throwError(error)));
  }
}
