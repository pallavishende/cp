#!/usr/bin/env node
const { spawn } = require('child_process');
const program = require('commander');
const request = require('request');

program
  .version('1.0.0')
  .usage('<pr> [options]')
  .option('-b, --buildKey <buildKey>', 'Job\'s buildKey')
  .option('-a, --auth <auth>', 'Encoded auth string')
  .parse(process.argv);

if (program.args.length !== 1) {
  console.error('Invalid arguments');
  process.exit(1);
}
const pr = program.args.shift();

if (!program.buildKey) {
  console.error('Build Key missing');
  process.exit(1);
}
if (!program.auth) {
  console.error('Encoded auth string missing');
  process.exit(1);
}
const postMessage = { name: `PR-${pr}` };
const options = {
  url: `https://bamboo.vmn.io/rest/api/latest/result/${program.buildKey}/label`,
  headers: {
    'Authorization': `Basic ${program.auth}`
  },
  body: postMessage,
  json: true
};
request.post(options, (error, response) => {
  if (error) {
    console.error(error);
    process.exit(1);
  }
  if (typeof response.body !== 'undefined' && response.body['status-code'] === 500) {
    console.error(response.body.message);
    process.exit(1);
  }
  process.exit(0);
});
