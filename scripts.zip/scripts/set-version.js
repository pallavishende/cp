#!/usr/bin/env node
const program = require('commander');
const co = require('co');
const git = require('git-rev');
const replace = require('replace-in-files');

function getSHA() {
  return new Promise((Resolve, Reject) => {
    git.short(sha => {
      if (!sha) {
        Reject('No SHA');
      }
      Resolve(sha);
    })
  })
}

function getBranch() {
  return new Promise((Resolve, Reject) => {
    git.branch(branch => {
      if (!branch) {
        Reject('No Branch');
      }
      Resolve(branch);
    })
  })
}

program
  .version('1.0.0')
  .usage('[options]')
  .option('-b, --branch <branch>', 'Branch; Default: auto detect')
  .option('-c, --customVersion <version>', 'Custom Version; Default: YYYY-MM-DD_branchName_shortHash')
  .parse(process.argv);

co(function* () {
  let sha = '';
  let branch = '';
  let buildVersion = '';
  const date = new Date();
  const dateString = `${date.getFullYear()}-${('0' + (date.getMonth() + 1)).slice(-2)}-${('0' + date.getDate()).slice(-2)}`;

  if (!program.customVersion) {
    sha = yield getSHA();
    branch = !program.branch ? yield getBranch() : program.branch;
    // version: 'YYYY-MM-DD_branchName_shortHash',
    buildVersion = branch === 'master' ? `${dateString}_${sha}` : `${dateString}_${branch}_${sha}`;
  } else {
    buildVersion = `${dateString}_${program.customVersion}`;
  }

  const options = {
    files: ['environments/environment.*.ts', 'environments/environment.ts'],
    from: /version: '(.*)'/g,
    to: `version: '${buildVersion}'`
  };

  replace(options)
    .then(changes => {
      const cc = changes.countOfMatchesByPaths[0];
      const count = Object.keys(cc).reduce((previous, key) => {
        return previous + cc[key];
      }, 0);
      console.log('Updated %i files with version: %s', count, buildVersion);
    })
    .catch(error => {
      console.error('Error while updating versions: ', error);
    })
});
